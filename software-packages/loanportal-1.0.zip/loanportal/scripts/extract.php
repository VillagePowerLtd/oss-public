<?php
$servername = "localhost";
$username = "vp";
$password = "vp";
$dbname = "vp";

$endpoint="http://104.236.194.94:9090/loa-1.0-SNAPSHOT/webresources/loan/csvUpload";
//$endpoint="http://127.0.0.1/test/getfile.php";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "select order.customer,product.product_code,UCASE(order.payment_plan),date(order.dP_date),date(next_payment_date), tot_payments.total_paid,pending_amt,`order`.status,date(completion_date) as completion_date,concat(concat(temp_sales_person.fname,' '),temp_sales_person.lname) as sales_agent, concat(concat(temp_sales_person.fname,' '),temp_sales_person.lname) as sales_person, concat(concat(temp_sales_agent.fname,' '),temp_sales_agent.lname) as vpc, temp_sales_region.region_name,'' from order_item left join `order` on order_item.`order`=`order`.id left join product on order_item.item=product.pid left join sales_agent temp_sales_agent on temp_sales_agent.cid=`order`.sales_agent  left join vp_sales_team as temp_sales_person on temp_sales_person.id=`order`.sales_person left join region as temp_sales_region on `order`.sales_region=temp_sales_region.id left join payment_schedule on `order`.id=payment_schedule.`order` left join (select `order`, sum(amt) as total_paid from payment group by `order`) as tot_payments on tot_payments.`order`=`order`.id where completion_date is not null and next_payment_date is not null group by order.customer";
$result = $conn->query($sql);
$csv="";
    while($row = $result->fetch_assoc()) {
$csv.=implode(",",$row)."\n";
}
$conn->close();
$tmpfname = tempnam(sys_get_temp_dir(), 'csv_upload');
file_put_contents($tmpfname, $csv);

//Send file to endpoint
    $headers = array("Content-Type:multipart/form-data"); // cURL headers for file uploading
    $postfields = array("file" => "@$tmpfname");
    $ch = curl_init();
    $options = array(
        CURLOPT_URL => $endpoint,
        CURLOPT_HEADER => true,
        CURLOPT_POST => 1,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_POSTFIELDS => $postfields,
        CURLOPT_INFILESIZE => strlen($csv),
        CURLOPT_RETURNTRANSFER => true
    ); // cURL options
    curl_setopt_array($ch, $options);
    $result=curl_exec($ch);
    if(!curl_errno($ch))
    {
        $info = curl_getinfo($ch);
        if ($info['http_code'] == 200)
            $errmsg = "File uploaded successfully";
    }
    else
    {
        $errmsg = curl_error($ch);
    }
    curl_close($ch);
print $result;
/*
$ch = curl_init( $endpoint );
# Setup request to send json via POST.
curl_setopt( $ch, CURLOPT_POSTFIELDS, $csv );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
# Send request.
$result = curl_exec($ch);
curl_close($ch);
# Print response.
echo "<pre>$result</pre>";
*/
