/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.rest;


import ch.villagepower.dao.RoleService;
import ch.villagepower.dao.SaveService;
import ch.villagepower.dao.UserBatchService;
import ch.villagepower.dao.UserService;
import ch.villagepower.entities.Role;
import ch.villagepower.entities.UserBatch;
import ch.villagepower.entities.UserGraph;
import ch.villagepower.entities.UserRoles;
import ch.villagepower.entities.Users;
import ch.villagepower.filter.Secured;
import ch.villagepower.utils.Globals;
import ch.villagepower.utils.JsonInput;
import ch.villagepower.utils.JsonReply;
import ch.villagepower.utils.PrintJson;
import ch.villagepower.utils.UserGraphBatch;
import com.google.gson.Gson;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.ejb.EJB;
import javax.mail.MessagingException;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import org.apache.log4j.Logger;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.mindrot.jbcrypt.BCrypt;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Path("users")
@Produces(MediaType.APPLICATION_JSON)
@Api(value = "users", description = "Endpoint for User Profile specific operations")
public class UserResource {

    @EJB
    UserService userService = new UserService();

    final static Logger log = Logger.getLogger(UserResource.class.getName());

    @EJB
    SaveService save = new SaveService();

    @EJB
    RoleService roleService = new RoleService();

    @EJB
    UserBatchService userBatchService = new UserBatchService();

    private JsonReply reply;
    private JsonInput input;
    private Gson gson;

    @POST
    @Path("forgotPassword")
    //@Secured({ch.villagepower.filter.Role.administrator})
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "User Profile", notes = "User reset password.", response = JsonReply.class)
    public String forgotPassword(@Context Request req, @ApiParam(value = "JsonInput.users") String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("forgotPassword");

        gson = new Gson();

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.users != null) {

                if (input.users.getEmail().length() > 0 || input.users.getEmail() != null) {

                    List<Users> u = userService.findByEmail(input.users.getEmail());
                    if (!u.isEmpty()) {

                        Users userId = u.get(0);

                        // generate hash code for email verification
                        String hash = PrintJson.prepareRandomString(30);
                        Properties prop = Globals.setGlobals();
                        userId.setSalt(BCrypt.hashpw(hash, prop.getProperty("SALT")));

                        save.updateObject(userId);

                        PrintJson.sendEmailForgotPasswordLink(userId.getUserId().toString(), userId.getEmail(), hash, userId.getFirstname());

                        reply.setSucc("Email Sent successfully");
                        log.info("Email Sent successfully");
                    } else {
                        reply.setSucc("User email does not exist");
                        log.info("Invalid hash key for User");

                    }

                } else {
                    log.info("Email not sent");
                    reply.setError("Email not sent");
                }

            } else {
                log.info("Please Send some JSON or Send user object");
                reply.setError("Please Send some JSON or Send user object");

            }

        } catch (com.google.gson.JsonSyntaxException | MessagingException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR" + ex.getMessage());
        }

        return reply.toString();

    }

    @POST
    @Path("update")
    //@Secured({ch.villagepower.filter.Role.administrator})
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "User Profile", notes = "User Profile Update.", response = JsonReply.class)
    public String updateUser(@Context Request req, @ApiParam(value = "JsonInput.users") String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("updateUser");

        gson = new Gson();

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.users != null && input.hash.length() > 0) {

                if (input.users.getPassword().length() > 0 || input.users.getPassword() != null) {

                    // get user Id and email verification code Hash code  
                    String userId = input.users.getUserId().toString();
                    Properties prop = Globals.setGlobals();
                    String hash = BCrypt.hashpw(input.hash, prop.getProperty("SALT"));

                    List<Users> u = userService.findByHashID(userId, hash);
                    if (!u.isEmpty()) {

                        u.get(0).setPassword(encrypt(input.users.getPassword()));

                        u.get(0).setEnabled(true);

                        save.updateObject(u.get(0));

                        reply.setSucc("User password updated successfully");
                        log.info("User password updated successfully");

                    } else {
                        log.info("Password not sent or Invalid hash key for User");
                        reply.setError("Password not sent or Invalid hash key for User");
                    }

                } else {

                    log.info("Send userId object and hash");
                    reply.setError("Send userId object ans hash");
                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();

    }

    @POST
    @Path("updateProfile")
    //@Secured({ch.villagepower.filter.Role.administrator})
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "User Profile", notes = "User Profile Update Profile.", response = JsonReply.class)
    public String updateUserProfile(@Context Request req, @ApiParam(value = "JsonInput.users") String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("updateUserProfile");

        gson = new Gson();

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.users != null) {

                if (null != input.users.getUserId()) {

                    // get user by Id  
                    Users u = userService.userById(input.users.getUserId());
                    if (u != null) {

                        List<Role> roles = roleService.findByRolename(input.users.getRole());
                        if (!roles.isEmpty()) {

                            List<UserRoles> ur = userBatchService.userRoleByUserID(u);

                            if (!ur.isEmpty()) {
                                for (UserRoles ubb : ur) {
                                    save.deleteObject(ubb);
                                }
                                log.info("User roles deleted successfully");
                            }

                            //u.setFirstname(input.users.getFirstname());
                            u.setRole(input.users.getRole());
                            save.updateObject(u);

                            //user.setRoleList(roles);
                            UserRoles urole = new UserRoles();
                            urole.setRoleId(roles.get(0).getRoleId());
                            urole.setUserId(u);
                            save.saveObject(urole);

                            //send email
                            //PrintJson.sendEmailRegistrationLink(u.getUserId().toString(), u.getEmail(), "updateuserprofile", u.getFirstname());
                            reply.setSucc("User profile updated successfully");
                            log.info("User profile updated successfully");
                        } else {
                            log.info("Invalid Role");
                            reply.setError("Invalid Role");
                        }

                    } else {
                        log.info("Password not sent or Invalid hash key for User");
                        reply.setError("Password not sent or Invalid hash key for User");
                    }

                } else {

                    log.info("Send userId");
                    reply.setError("Send userId ");
                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException /*| MessagingException8*/ ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();

    }

    @POST
    @Path("delete")
    //@Secured({ch.villagepower.filter.Role.administrator})
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "User Profile", notes = "User Profile Delete.", response = JsonReply.class)
    public String deleteUser(@Context Request req, @ApiParam(value = "JsonInput.users") String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("deleteUser");

        gson = new Gson();

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.users != null) {

                if (input.users.getUserId() != null) {
                    // get user by Id   
                    Users u = userService.userById(input.users.getUserId());
                    if (null != u) {

                        List<UserBatch> ub = userBatchService.userBatchByUser(u);
                        List<UserGraph> ug = userBatchService.userGraphByUserID(u);
                        List<UserRoles> ur = userBatchService.userRoleByUserID(u);

                        if (!ub.isEmpty()) {
                            for (UserBatch ubb : ub) {
                                save.deleteObject(ubb);
                            }
                            log.info("User batches deleted successfully");
                        }

                        if (!ug.isEmpty()) {
                            for (UserGraph ugg : ug) {
                                save.deleteObject(ugg);
                            }
                            log.info("User graphs deleted successfully");
                        }

                        if (!ur.isEmpty()) {
                            for (UserRoles urr : ur) {
                                save.deleteObject(urr);
                            }
                            log.info("User roles deleted successfully");
                        }

                        save.deleteObject(u);
                        reply.setSucc("User deleted successfully");

                    } else {
                        log.info("User does not exist");
                        reply.setError("User does not exist");
                    }

                } else {

                    log.info("Send user object");
                    reply.setError("Send user object");
                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();

    }

    @POST
    @Path("add")
    @Secured({ch.villagepower.filter.Role.administrator})
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "User Add", notes = "Add new User.", response = JsonReply.class)
    public String addUser(@Context Request req, @ApiParam(value = "JsonInput.users") String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("addUser");

        gson = new Gson();

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.users != null) {

                if (input.users.getRole().length() > 0 && input.users.getEmail().length() > 0) {

                    List<Users> user = userService.findByEmail(input.users.getEmail());
                    if (!user.isEmpty()) {
                        reply.setError("User exists already");
                        log.info("user exists already");
                    } else {
                        input.users.setPassword("");
                        input.users.setEnabled(false);

                        //send email
                        List<Role> roles = roleService.findByRolename(input.users.getRole());
                        if (!roles.isEmpty()) {

                            // generate hash code for email verification
                            String hash = PrintJson.prepareRandomString(30);
                            Properties prop = Globals.setGlobals();
                            input.users.setSalt(BCrypt.hashpw(hash, prop.getProperty("SALT")));
                            save.saveObject(input.users);
                            Users user1 = userService.findByEmail(input.users.getEmail()).get(0);

                            System.out.println("user" + user1.getFirstname());

                            //user.setRoleList(roles);
                            UserRoles urole = new UserRoles();
                            urole.setRoleId(roles.get(0).getRoleId());
                            urole.setUserId(user1);
                            save.saveObject(urole);

                            //send email
                            PrintJson.sendEmailRegistrationLink(user1.getUserId().toString(), user1.getEmail(), hash, user1.getFirstname());

                            reply.setSucc("User added, Pending Confirmation");
                            log.info("User added, Pending Confirmation");
                        } else {
                            log.info("Invalid Role");
                            reply.setError("Invalid Role");
                        }
                    }
                } else {
                    log.info("Add user role or email");
                    reply.setError("Add user role or email");
                }

            } else {
                log.info("Please Send some JSON or ");
                reply.setError("Please Send some JSON or Send user object");

            }

        } catch (com.google.gson.JsonSyntaxException | MessagingException ex) {
            System.out.println("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();

    }

    @GET
    @Path("allUsers")
    @Secured({ch.villagepower.filter.Role.administrator})
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "All Users", notes = "Return all users.", response = JsonReply.class)
    public String allUsers() {

        reply = new JsonReply("allUsers");

        List<Users> users = userService.findAll();

        if (!users.isEmpty()) {

            reply.users = users;

            reply.setSucc("Users returned " + users.size());
            log.info("Users returned " + users.size());

        } else {
            log.info("No Users");
            reply.setError("No Users");
        }

        return reply.toString();

    }

    @GET
    @Path("allInvestors")
    @Secured({ch.villagepower.filter.Role.administrator})
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "All Investor Users", notes = "Return all investor users.", response = JsonReply.class)
    public String allInvestors() {

        reply = new JsonReply("allInvestors");

        List<Users> users = userService.userByInvestor("investor");

        if (!users.isEmpty()) {

            reply.users = users;

            reply.setSucc("Investors returned " + users.size());
            log.info("Investors returned " + users.size());

        } else {
            log.info("No Investors");
            reply.setError("No Investors");
        }

        return reply.toString();

    }

    //**************endpoint for all graphs and batches of users*****************
    @POST
    @Path("userBatchGraphs")
    @Secured({ch.villagepower.filter.Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "User Charts", notes = "Return user charts.", response = JsonReply.class)
    public String findUserBatchGraphs(@Context Request req, @ApiParam(value = "JsonInput.users") String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("findUserBatchGraphs");

        gson = new Gson();

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.users != null) {

                List<UserBatch> userBatch = userBatchService.userBatchByUser(input.users);
                List<UserGraph> userGraphs = userBatchService.userGraphByUserID(input.users);

                reply.setSucc("Found batches");
                UserGraphBatch ugb = new UserGraphBatch();
                ugb.setUserBatchs(userBatch);
                ugb.setUserGraphs(userGraphs);

                List<UserGraphBatch> ugbs = new ArrayList<>();
                ugbs.add(ugb);

                reply.userGraphbatches = ugbs;

            } else {
                log.info("Please Send some JSON or Send Batch object");
                reply.setError("Please Send some JSON or Send Batch object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();

    }

    private String encrypt(String password) {
        return new Sha256Hash(password).toString();
    }

    @POST
    @Path("photo")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Company Logo", notes = "Company Logo upload.", response = JsonReply.class)
    public String uploadPhoto(
            @ApiParam(value = "company email") @FormDataParam("email") String email,
            @ApiParam(value = "actual image") @FormDataParam("file") InputStream uploadedInputStream,
            @FormDataParam("file") FormDataContentDisposition fileDetail,
            @FormDataParam("file") FormDataBodyPart body) throws IOException {

        reply = new JsonReply("UploadPhoto");

        //construct user
        Users user;

        user = userService.findByEmail(email).get(0);

        if (user != null) {

            //image location and name            
            String uploadedFileLocation = "/var/www/html/test/" + user.getUserId();
            log.info("img" + uploadedFileLocation);

            // save receipt image
            saveToFile(uploadedInputStream, uploadedFileLocation);

            user.setImageUrl(uploadedFileLocation);
            save.updateObject(user);
            reply.setSucc("Photo Saved id:" + user.getUserId());

        } else {
            log.info("User not found");
            reply.setError("User not found");
        }

        return reply.toString();

    }

    // save uploaded file to new location
    public static void saveToFile(InputStream uploadedInputStream,
            String uploadedFileLocation) throws IOException {
        OutputStream out = null;

        try {

            int read;
            byte[] bytes = new byte[1024];

            out = new FileOutputStream(new File(uploadedFileLocation));
            while ((read = uploadedInputStream.read(bytes)) != -1) {
                out.write(bytes, 0, read);
            }
            out.flush();

        } catch (IOException e) {

            log.info(e);
        } finally {
            //close file io
            out.close();

        }

    }

}
