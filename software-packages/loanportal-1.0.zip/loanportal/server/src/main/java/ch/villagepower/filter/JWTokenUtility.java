/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.filter;


import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.shiro.SecurityUtils;
import org.jose4j.jwk.RsaJsonWebKey;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.lang.JoseException;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
public class JWTokenUtility {

    final static Logger log = Logger.getLogger(JWTokenUtility.class.getName());

    private JWTokenUtility() {
        throw new IllegalAccessError("JWT Utility class");
    }

    public static String buildJWT(String subject) {

        RsaJsonWebKey rsaJsonWebKey = RsaKeyProducer.produce();
        log.info("RSA hash code... " + rsaJsonWebKey.hashCode());

        JwtClaims claims = new JwtClaims();
        claims.setSubject(subject); // the subject/principal is whom the token is about
        claims.setIssuer("village-power.ch");  // who creates the token and signs it
        claims.setExpirationTimeMinutesInTheFuture(30); // token will expire (10 minutes from now)
        claims.setGeneratedJwtId(); // a unique identifier for the token
        claims.setIssuedAtToNow();  // when the token was issued/created (now)
        claims.setNotBeforeMinutesInThePast(2); // time before which the token is not yet valid (2 minutes ago)
        if (SecurityUtils.getSubject().hasRole("administrator")) {
            List<String> role = new ArrayList<>();
            role.add("administrator");
        }
        claims.setStringListClaim("roles", "role"); // multi-valued claims for roles

        JsonWebSignature jws = new JsonWebSignature();
        jws.setPayload(claims.toJson());
        jws.setKey(rsaJsonWebKey.getPrivateKey());
        jws.setAlgorithmHeaderValue(AlgorithmIdentifiers.RSA_USING_SHA256);

        String jwt = null;
        try {
            jwt = jws.getCompactSerialization();
        } catch (JoseException ex) {
            Logger.getLogger(JWTokenUtility.class.getName()).log(Level.ERROR, null, ex);
        }

        log.info("Claim:\n" + claims);
        log.info("JWS:\n" + jws);
        log.info("JWT:\n" + jwt);

        return jwt;
    }

}
