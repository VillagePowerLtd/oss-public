/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.rest;


import au.com.bytecode.opencsv.CSVReader;
import ch.villagepower.dao.BatchAnalysisService;
import ch.villagepower.dao.BatchLoanService;
import ch.villagepower.dao.BatchService;
import ch.villagepower.dao.ChartService;
import ch.villagepower.dao.DepositService;
import ch.villagepower.dao.LoanService;
import ch.villagepower.dao.PaymentService;
import ch.villagepower.dao.SaveService;
import ch.villagepower.dao.UserBatchService;
import ch.villagepower.dao.UserService;
import ch.villagepower.entities.ActualPercentage;
import ch.villagepower.entities.Batch;
import ch.villagepower.entities.BatchAnalysis;
import ch.villagepower.entities.BatchhasLoan;
import ch.villagepower.entities.BatchhasLoanPK;
import ch.villagepower.entities.Deposit;
import ch.villagepower.entities.Loan;
import ch.villagepower.entities.LoanPerformance;
import ch.villagepower.entities.NumberofLoans;
import ch.villagepower.entities.OverdueLoansByNumber;
import ch.villagepower.entities.OverdueLoansByValue;
import ch.villagepower.entities.PaymentStatus;
import ch.villagepower.entities.Payments;
import ch.villagepower.entities.Percentage;
import ch.villagepower.entities.RestructuredLoans;
import ch.villagepower.entities.UserBatch;
import ch.villagepower.entities.UserGraph;
import ch.villagepower.entities.Users;
import ch.villagepower.filter.Role;
import ch.villagepower.filter.Secured;
import ch.villagepower.utils.HibernateProxyTypeAdapter;
import ch.villagepower.utils.JsonInput;
import ch.villagepower.utils.JsonReply;
import ch.villagepower.utils.PrintJson;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.ejb.EJB;
import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import org.apache.log4j.Logger;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Days;
import org.joda.time.LocalDate;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Path("loan")
@Api(value = "loan", description = "Endpoint for Loan specific operations")
public class LoanResource {

    @PersistenceContext(unitName = "com.villagepower_loa_war_1.0-SNAPSHOTPU")
    private EntityManager em;

    final static Logger log = Logger.getLogger(LoanResource.class.getName());

    private JsonReply reply;
    private Gson gson;

    @EJB
    SaveService save = new SaveService();

    @EJB
    LoanService loanService = new LoanService();
    @EJB
    DepositService depositService = new DepositService();

    @EJB
    BatchLoanService bhlService = new BatchLoanService();

    @EJB
    BatchService batchService = new BatchService();

    @EJB
    UserBatchService ubService = new UserBatchService();

    @EJB
    UserService userService = new UserService();

    @EJB
    PaymentService paymentService = new PaymentService();

    @EJB
    ChartService chartService = new ChartService();

    @EJB
    BatchAnalysisService baService = new BatchAnalysisService();

    JsonInput input;

    public LoanResource() {

    }

    // ++++++++++++++++++++++++: BATCH TO INVESTOR:+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Secured({Role.administrator})
    @Path("assignBatchToInvestor")
    @ApiOperation(value = "Assign Batch to Investor", notes = "Assign Batch to Investor.", response = JsonReply.class)
    public String assignBatchToInvestor(@Context Request req, @ApiParam(value = "JsonInput.userBatches") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        reply = new JsonReply("assignBatchToInvestor");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && !input.userBatches.isEmpty()) {

                List<UserBatch> ub = input.userBatches;

                for (UserBatch result : ub) {

                    Batch b = batchService.batchById(result.getBatchid().getId());
                    Users u = userService.userById(result.getUsersuserId().getUserId());

                    if (b != null && u != null) {

                        //CONSTRUCT PK for Batch of loans
                        UserBatch uBatch = new UserBatch();
                        uBatch.setBatchid(b);
                        uBatch.setUsersuserId(u);

                        List<UserBatch> ubList = ubService.userBatchBy(uBatch);

                        if (ubList.isEmpty()) {

                            //ASSIGN LOAN TO BATCH TO INVESTOR
                            save.saveObject(uBatch);

                            reply.setSucc("Batch Assigned to Investor");

                            List<Users> admins = userService.findAllAdmins("administrator");

                            for (Users admin : admins) {

                                PrintJson.sendEmailBatchGraphAssigned(b.getName(), "", u.getEmail(), admin.getFirstname(), admin.getEmail());
                            }

                        } else {
                            log.info("Batch already assigned to Investor");
                            reply.setError("Batch already assigned to Investor");
                        }

                    } else {
                        log.error("User or batch not found");
                        reply.setError("User or Batch does not exist");
                    }

                }

            } else {
                log.info("Please Send some JSON or Both batch and user required in userBatch object");
                reply.setError("Please Send some JSON or Both batch and user required in userBatch object");

            }

        } catch (com.google.gson.JsonSyntaxException | MessagingException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: UNASSIGN LOANS FROM BATCH :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @Path("unAssignLoanBatch")
    @ApiOperation(value = "Unassign Loan from Batch", notes = "Unassign Loan from Batch.", response = JsonReply.class)
    public String unAssignLoanBatch(@Context Request req, @ApiParam(value = "JsonInput.batchLoans") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        reply = new JsonReply("unAssignLoanBatch");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null) {
                if (input.batchLoans.isEmpty()) {
                    log.info("Both batchLoans required");
                    reply.setError("Both batchLoans required");
                } else {

                    List<BatchhasLoan> bl = input.batchLoans;

                    for (BatchhasLoan result : bl) {
                        //GET LOAN and BATCH FROM DB
                        log.info("++++++++++++++++++" + result.getLoan().getId().toString());
                        Batch b = batchService.batchById(result.getBatch().getId());
                        Loan l;
                        l = loanService.loanById(result.getLoan().getId());

                        if (b != null && l != null) {

                            //CONSTRUCT PK for Batch of loans
                            BatchhasLoanPK bhlPK = new BatchhasLoanPK();
                            bhlPK.setBatchid(b.getId());
                            bhlPK.setLoanid(result.getLoan().getId());
                            bhlPK.setBatchPortfolioid(b.getPortfolioid().getId());

                            BatchhasLoan bh = bhlService.batchLoanById(bhlPK);

                            if (bh != null) {

                                //UNASSIGN LOAN TO BATCH AND PK
                                BatchhasLoan bhl = new BatchhasLoan();
                                bhl.setBatch(b);
                                bhl.setLoan(result.getLoan());
                                bhl.setBatchhasLoanPK(bhlPK);
                                //System.out.println("############"+bhl.getLoan().getId());
                                save.deleteObject(bhl);

                                List<BatchhasLoan> blCount = bhlService.batchLoanByLoan(l);

                                l.setNumberBatchAssined(blCount.size());

                                save.updateObject(l);

                            } else {
                                log.info("Loan not assigned to batch");
                                reply.setError("Loan not assigned to batch");
                            }

                        } else {
                            log.error("Loan " + result.getLoan() + ",Batch " + b);
                            reply.setError("Loan or Batch does not exist");
                        }

                    }
                    reply.setSucc("Loans UnAssigned from Batch");

                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

// ++++++++++++++++++++++++: UNASSIGN batch FROM user :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Unassign Batch from Investor", notes = "Unassign Batch to Investor.", response = JsonReply.class)
    @Path("unAssignBatchUser")
    public String unAssignBatchUser(@Context Request req, @ApiParam(value = "JsonInput.userBatches") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        reply = new JsonReply("unAssignBatchUser");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null) {
                if (input.userBatches.isEmpty()) {
                    log.info("User Batches equired");
                    reply.setError("User batches required");
                } else {

                    List<UserBatch> bl = input.userBatches;

                    for (UserBatch result : bl) {
                        //GET LOAN and BATCH FROM DB
                        log.info("++++++++++++++++++" + result.getBatchid().toString());
                        Batch b = batchService.batchById(result.getBatchid().getId());
                        List<UserBatch> l;
                        l = ubService.userBatchExists(result.getUsersuserId(), result.getBatchid());

                        if (b != null && !l.isEmpty()) {

                            save.deleteObject(l.get(0));

                        } else {
                            log.error("UserBatch " + result.getIduserBatch() + ",Batch " + b);
                            reply.setError("User or Batch does not exist");
                        }

                    }
                    reply.setSucc("Batch UnAssigned from User");

                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: UNASSIGN graph FROM user :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @Path("unAssignGraphUser")
    @ApiOperation(value = "Unassign Graph from Investor", notes = "Uassign Graph from Investor.", response = JsonReply.class)
    public String unAssignGraphUser(@Context Request req, @ApiParam(value = "JsonInput.userGraphs") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        reply = new JsonReply("unAssignGraphUser");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null) {
                if (input.userGraphs.isEmpty()) {
                    log.info("User Graphs equired");
                    reply.setError("User Graphs required");
                } else {

                    List<UserGraph> bl = input.userGraphs;

                    for (UserGraph result : bl) {
                        //GET LOAN and BATCH FROM DB
                        log.info("++++++++++++++++++" + result.getGraphs());
                        Users b = userService.userById(result.getUsersuserId().getUserId());

                        if (b != null) {

                            List<UserGraph> ug = ubService.userGraphByUserGraph(b, result.getGraphs());
                            save.deleteObject(ug.get(0));

                        } else {
                            log.error("User " + result.getUsersuserId().getUserId());
                            reply.setError("User or Grpah does not exist");
                        }

                    }
                    reply.setSucc("Graph UnAssigned from User");

                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: GRAPH TO INVESTOR:+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Secured({Role.administrator})
    @Path("assignGraphToInvestor")
    @ApiOperation(value = "Assign Chart to Investor", notes = "Assign Chart to Investor.", response = JsonReply.class)
    public String assignGraphToInvestor(@Context Request req, @ApiParam(value = "JsonInput.userGraphs") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        reply = new JsonReply("assignGraphToInvestor");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && !input.userGraphs.isEmpty()) {

                List<UserGraph> ub = input.userGraphs;

                for (UserGraph result : ub) {

                    Users u = userService.userById(result.getUsersuserId().getUserId());

                    if (u != null) {

                        UserGraph uGraph = new UserGraph();
                        uGraph.setUsersuserId(u);
                        uGraph.setGraphs(result.getGraphs());

                        List<UserGraph> ubList = ubService.userGraphBy(uGraph);

                        if (ubList.isEmpty()) {

                            //ASSIGN Graph TO INVESTOR
                            save.saveObject(uGraph);

                            reply.setSucc("Graphs Assigned to Investor");

                            List<Users> admins = userService.findAllAdmins("administrator");

                            for (Users admin : admins) {

                                PrintJson.sendEmailBatchGraphAssigned("", uGraph.getGraphs(), u.getEmail(), admin.getFirstname(), admin.getEmail());
                            }

                        } else {
                            log.info("graph already assigned to Investor");
                            reply.setError("Graph already assigned to Investor");
                        }

                    } else {
                        log.error("User or batch not found");
                        reply.setError("User or Batch does not exist");
                    }

                }

            } else {
                log.info("Please Send some JSON or Both graph and user required in userGraph object");
                reply.setError("Please Send some JSON or Both graph and user required in userGraph object");

            }

        } catch (com.google.gson.JsonSyntaxException | MessagingException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON or SERVER ERROR");
        }

        return reply.toString();
    }

    //**************endpoint for all loans*****************
    @GET
    @Path("allLoans")
    @Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "All Loans", notes = "Return all Loans.", response = JsonReply.class)
    public String findAll() {

        reply = new JsonReply("getAllLoans+findAll");

        gson = new Gson();

        log.info("@@@@@@@@@@@@@@@@@@@@@@@" + PrintJson.timeZoneKla() + "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

        List<Loan> loans = loanService.findAll();
        if (!loans.isEmpty()) {
            log.info("REEEEEEEEEEESSSSSSSTT");

            reply.loans = loans;
            reply.setSucc("Found loans");

        } else {
            reply.setError("No loans found");
            log.info("No loans found");
        }
        return reply.toString();
    }

    //**************endpoint for all Plans*****************
    @GET
    @Path("allDeposits")
    @Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "All Payment Plans", notes = "Return all Payment Plans.", response = JsonReply.class)
    public String findAllDeposits() {

        reply = new JsonReply("findAllDeposits");

        gson = new Gson();

        List<Deposit> dp = depositService.findAll();
        if (!dp.isEmpty()) {

            reply.deposits = dp;
            reply.setSucc("Found Payment Plans");

        } else {
            reply.setError("No Payment Plans found");
            log.info("No Payment Plans found");
        }
        return reply.toString();
    }

    //**************endpoint for all names of batches of loan*****************
    @POST
    @Path("batchesAssignedToLoans")
    @Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Batches Assigned to Loan", notes = "Batches Assigned to Loan.", response = JsonReply.class)
    public String batchNames(@Context Request req, @ApiParam(value = "JsonInput.loan") String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("batchNames");

        gson = new Gson();

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.loan != null) {

                List<BatchhasLoan> blCount = bhlService.batchOfLoan(input.loan);
                List<Batch> bs = new ArrayList<Batch>();

                for (BatchhasLoan result : blCount) {
                    Batch b = batchService.batchById(result.getBatch().getId());
                    bs.add(b);

                }

                reply.batches = bs;

            } else {
                log.info("Please Send some JSON or Send Loan object");
                reply.setError("Please Send some JSON or Send Loan object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();

    }

    //**************upload loan csv file*****************
    @POST
    @Path("csvUpload")
    //@Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @ApiOperation(value = "Upload Loans", notes = "Upload Loan csv file.", response = JsonReply.class)
    public String csvUpload(
            @ApiParam(value = "Actual file") @FormDataParam("file") InputStream uploadedInputStream,
            @FormDataParam("file") FormDataContentDisposition fileDetail,
            @FormDataParam("file") FormDataBodyPart body) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("csvUploadLoan");
        try {

            gson = new Gson();

            String uploadedFileLocation = "/home/glassfish/loanuploads.csv";
            log.info("file location" + uploadedFileLocation);
            // save csv file
            saveToFile(uploadedInputStream, uploadedFileLocation);

            //create CSVReader object
            CSVReader reader = null;
            List<String[]> records = new ArrayList<>();
            List<Loan> loans = new ArrayList<>();
            try {

                reader = new CSVReader(new FileReader(uploadedFileLocation), ',');
                //read all lines at once
                records = reader.readAll();

            } catch (Exception e) {
                //throw file exception
                log.info("file exception :" + e);
                reply.setError("upload failure");

            } finally {
                //close file io
                if (reader != null) {
                    reader.close();
                }

            }

            log.info("////////////////////" + records.size());

            if (records.size() > 1) {

                Iterator<String[]> iterator = records.iterator();
                //skip header row

                while (iterator.hasNext()) {
                    String[] record = iterator.next();
                    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yy");
                    String dateInString;

                    Loan loan = new Loan();

                    loan.setId(Integer.valueOf(record[0]));

                    dateInString = record[3];
                    Date date = formatter.parse(dateInString);
                    formatter = new SimpleDateFormat("yyyy-MM-dd");
                    dateInString = formatter.format(date);

                    loan.setDownPaymentDate(formatter.parse(dateInString));

                    dateInString = record[4];

                    if ("Permanent".equalsIgnoreCase(dateInString) || dateInString.length() < 0 || "Paid UP".equalsIgnoreCase(dateInString) || "defaulter".equalsIgnoreCase(dateInString)) {
                        loan.setNextPaymentDate(null);
                    } else {
                        formatter = new SimpleDateFormat("dd-MM-yy");
                        date = formatter.parse(dateInString);
                        formatter = new SimpleDateFormat("yyyy-MM-dd");
                        dateInString = formatter.format(date);
                        loan.setNextPaymentDate(formatter.parse(dateInString));
                    }

                    loan.setTotalAmountValue(Double.valueOf(record[5]));

                    if ("paid up".equalsIgnoreCase(record[6])) {
                        loan.setBalance(0.0);
                    } else {
                        loan.setBalance(Double.valueOf(record[6]));
                    }

                    loan.setStatus(record[7]);

                    dateInString = record[8];

                    if (dateInString.length() < 1) {
                        loan.setFullPaymentDate(null);
                    } else {
                        formatter = new SimpleDateFormat("dd-MM-yy");
                        date = formatter.parse(dateInString);
                        formatter = new SimpleDateFormat("yyyy-MM-dd");
                        dateInString = formatter.format(date);

                        loan.setFullPaymentDate(formatter.parse(dateInString));
                    }
                    loan.setModelPurchased(record[1]);

                    loan.setUploadDate(PrintJson.timeZoneKla());
                    loan.setHistoryStatus("current");
                    loan.setSalesAgent(record[9]);
                    loan.setDistributionAgent(record[10]);
                    loan.setInstallationAddress(record[12]);
                    loan.setStore(record[11]);
                    if ("true".equalsIgnoreCase(record[13])) {
                        loan.setAssigned(Boolean.TRUE);
                    } else {
                        loan.setAssigned(Boolean.FALSE);
                    }

                    if ("Paid Up".equalsIgnoreCase(record[16]) || "defaulter".equalsIgnoreCase(record[16]) || "".equalsIgnoreCase(record[16])) {
                        loan.setDay(null);
                    } else {
                        loan.setDay(Integer.valueOf(record[16]));
                    }

                    loan.setDefaultedAmount(Double.valueOf(record[17]));
                    loan.setDiscountedAmount(Double.valueOf(record[18]));
                    loan.setDistrict(record[19]);
                    loan.setSubcounty(record[20]);
                    loan.setParish(record[21]);
                    loan.setVillage(record[22]);
                    loan.setVersion(record[23]);
                    if (record[24].equalsIgnoreCase("yes")) {
                        loan.setRestructured(Boolean.TRUE);
                    } else {
                        loan.setRestructured(Boolean.FALSE);
                    }

                    loan.setRestructuredOverdue(record[25]);
                    loan.setRestructuredOutstanding(Integer.valueOf(record[26]));
                    loans.add(loan);

                }

                for (Loan l : loans) {

                    //Math up the loan
                    //System.out.println(""+l.getId());
                    Double modelPrice = depositService.depositByModelVersion(l.getModelPurchased(), l.getVersion()).get(0).getUpfront();
                    l.setInstallmentsPaid(l.getTotalAmountValue() - modelPrice);
                    if (l.getBalance() != 0) {
                        l.setTotalValueLoan((l.getTotalAmountValue() - modelPrice) + l.getBalance());
                    } else {
                        l.setTotalValueLoan(l.getTotalAmountValue() - modelPrice);
                    }

                    //if(!l.getStatus().equalsIgnoreCase("within plan") && l.getRestructuredOutstanding() !=0){
                    if (l.getRestructured()) {

                        Double modelDailyPrice = depositService.depositByModelVersion(l.getModelPurchased(), l.getVersion()).get(0).getDaily();

                        //String rest = Integer.valueOf(l.getRestructuredOverdue()).toString();
                        if (l.getRestructuredOverdue().equalsIgnoreCase("within plan") || l.getRestructuredOverdue().equalsIgnoreCase("recovered")) {
                            l.setValueOverdueRestructuring(0.0);
                        } else {
                            l.setValueOverdueRestructuring(modelDailyPrice * (Integer.valueOf(l.getRestructuredOverdue())));
                        }

                    } else {
                        l.setValueOverdueRestructuring(0.0);
                    }

                    if (l.getStatus().equalsIgnoreCase("Recovered")) {
                        l.setPar("0");
                    } else if (l.getStatus().equalsIgnoreCase("defaulter")) {
                        l.setPar("0");
                    } else if (l.getStatus().equalsIgnoreCase("Paid Up")) {
                        l.setPar("0");
                    } else {
                        int days = 0;
                        if (l.getNextPaymentDate() == null) {
                            l.setDaysOverdue(0);
                        } else {
                            org.joda.time.DateTime secondDate = new DateTime(l.getNextPaymentDate()).toDateTime(DateTimeZone.forID("Africa/Kampala"));
                            org.joda.time.DateTime firstDate = PrintJson.timeZoneDateTimeKla().toDateTime(DateTimeZone.forID("Africa/Kampala"));
                            //days = firstDate.getMillis() - secondDate.getMillis();
                            days = (Days.daysBetween(firstDate.minusDays(1).toLocalDate(), secondDate.toLocalDate()).getDays()) / -1;
                            //days = days / (24 * 60 * 60 * 1000);
                            //log.info("********diff time*******" + days);
                            //l.setDaysOverdue((int) (long) days);
                            l.setDaysOverdue(days);
                            //log.info("********Long to Int*******" + (int) (long) days);

                        }

                        //Integer i = (int) (long) days;
                        Integer i = days;
                        if (i >= 90) {
                            l.setPar("PAR 90");
                        } else if (i >= 60) {
                            l.setPar("PAR 60");
                        } else if (i >= 30) {
                            l.setPar("PAR 30");
                        } else if (i >= 0) {
                            l.setPar("PAR 1");
                        } else {
                            l.setPar("0");
                        }
                    }
                    Double modelTotal = depositService.depositByModelVersion(l.getModelPurchased(), l.getVersion()).get(0).getFinal1();
                    l.setPercentage(Math.round((l.getTotalAmountValue() / modelTotal) * 1000.0) / 10.0);

                    if (loanService.loanById(l.getId()) == null) {

                        l.setNumberBatchAssined(0);
                        l.setHistoryStatus("new");
                        l.setAssigned(Boolean.FALSE);
                        save.saveObject(l);

                    } else if (loanService.loanById(l.getId()).getNumberBatchAssined() == null) {
                        l.setNumberBatchAssined(0);
                        l.setAssigned(Boolean.FALSE);
                        save.updateObject(l);
                    } else {
                        l.setNumberBatchAssined(loanService.loanById(l.getId()).getNumberBatchAssined());
                        l.setAssigned(Boolean.TRUE);
                        save.updateObject(l);
                    }

                }

                reader.close();

                reply.setSucc("Upload Done " + loans.size() + " Loans");
                log.info("@@@@@ Upload Done " + loans.size() + " Loans");

                //delete old loans not being updated
                deleteOldLoans();
                
                //Update charts automatically
                /*List<Batch> batches = batchService.findAll();
                String rply = "";
                if (!batches.isEmpty()) {
                    for (Batch b : batches) {
                        rply = updateGraphs(b);
                    }
                    log.info("@@@@@ Upload Done " + loans.size() + " Loans, " + rply);
                } else {
                    log.info("UPLOAD ERROR@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@No batches created on system, graphs not created");
                    reply.setError("No batches created on system, graphs not created");
                }*///payments should be uploaded before updating graphs
            } else {
                log.error("Empty File : ");
                reply.setError("Empty File");
            }
        } catch (IOException | ParseException ex) {

            log.error("This is file error : " + ex);
            reply.setError("file error" + ex.toString());
        }

        return reply.toString();
    }

    //**************upload loan payments csv file*****************
    @POST
    @Path("csvPaymentsUpload")
    //@Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "upload payments", notes = "loan payments in json format.", response = JsonReply.class)
    public String csvPaymentsUpload(@Context Request req, @ApiParam(value = "loan payments") String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("csvPaymentsUpload");

        gson = new GsonBuilder().registerTypeAdapterFactory(HibernateProxyTypeAdapter.FACTORY).setDateFormat("dd-MM-yy").setPrettyPrinting().create();

        input = new JsonInput();

        try {

            PrintJson.printJ(json);

            input = gson.fromJson(json, JsonInput.class);

            log.info("deleting old payments...");
            int g = paymentService.deletePayments();
            log.info("deletedddddddddddddddddddddddddddddd" + g);

            if (!input.payments.isEmpty()) {
                List<Payments> payments = input.payments;
                

                for (Payments p : payments) {

                    p.setDateCreated(PrintJson.timeZoneKla());

                    if (loanService.loanById(p.getLoanid().getId()) != null) {
                        save.saveObject(p);
                    }
                }
                //log.info("Upload done +++++++++++++++++++++");

                /*Loan l2 = new Loan();
                l2.setId(70);
                l2.setModelPurchased("VP6");
                Loan l1 = new Loan();
                l1.setId(68);
                l1.setModelPurchased("VP6");
                Loan l3 = new Loan();
                l3.setId(55);
                l3.setModelPurchased("VP4");
                Loan l4 = new Loan();
                l4.setId(74);
                l4.setModelPurchased("VP2");
                Loan l5 = new Loan();
                l5.setId(75);
                l5.setModelPurchased("VP4");
                Loan l6 = new Loan();
                l6.setId(78);
                l6.setModelPurchased("VP2");*/
                //Update curve automatically
                List<Loan> loanList = new ArrayList<>();
                /*loanList.add(l1);
                loanList.add(l2);
                loanList.add(l3);
                loanList.add(l4);
                loanList.add(l5);
                loanList.add(l6);*/

                loanList = loanService.findAll();
                //System.out.println("loanlist"+loanList.size());

                DateTime today = new DateTime();
                //log.info("======================="+today);
                if (!loanList.isEmpty()) {

                    for (Loan l : loanList) {

                        List<BatchhasLoan> loanBatches = bhlService.batchLoanByLoan(l);
                        if (!loanBatches.isEmpty() && l.getVersion() != null) {

//                            DecimalFormat df = new DecimalFormat("#.######");
//                            df.setRoundingMode(RoundingMode.CEILING);
                            double paymentsWithin = 0.0;
                            double paymentsBehind = 0.0;
                            double balanceDueToDate = 0.0;
                            double balanceDue = 0.0;
                            double amountPaidToDate = 0.0;
                            double outstandingOverdue = 0.0;
                            double outstandingWithin = 0.0;

                            double prevPayment = 0.0;
                            double percent;
                            int contractAge = 0;
                            Double modelTotal = depositService.depositByModelVersion(l.getModelPurchased(), l.getVersion()).get(0).getFinal1();
                            Deposit modelUpfront = depositService.depositByModelVersion(l.getModelPurchased(), l.getVersion()).get(0);

                            List<Payments> ps = paymentService.findPaymentsByLoan(l);

//                                for(Payments payt:ps){
//
//                                    //contract day of payment
//                                    org.joda.time.DateTime jodaContract = new DateTime(payt.getContractDate());
//                                    org.joda.time.DateTime jodaPayment = new DateTime(payt.getPaymentDate());
//                                    payt.setContractDayOfPayment(Days.daysBetween(jodaPayment.toLocalDate(), new LocalDate(jodaContract)).getDays()/-1);
//
//                                    //total balance due by payment date
//                                    if(payt.getContractDayOfPayment()<0){
//
//                                        payt.setBalanceDueByPayment(0.0);
//
//                                    }else if(payt.getContractDayOfPayment()==0){
//
//                                        payt.setBalanceDueByPayment(modelUpfront.getUpfront());
//                                    }else{
//                                        //payt.setBalanceDueByPayment(modelUpfront.getUpfront()+modelUpfront.getDaily()*(payt.getContractDayOfPayment()-14));
//                                        payt.setBalanceDueByPayment(modelUpfront.getUpfront()+modelUpfront.getDaily()*payt.getContractDayOfPayment());
//                                    }
//                                    //totsl psyment by payment date
//                                    prevPayment+=payt.getPaymentAmount();
//                          //          log.info("paymentAmount============"+payt.getPaymentAmount());
//                                    payt.setTotalPaidByPayment(prevPayment);
//                            //        log.info("prevPayment============"+prevPayment);
//                              //      log.info("getTotalPaidByPayment============"+payt.getTotalPaidByPayment());
//                                //    log.info("getBalanceDueByPayment============"+payt.getBalanceDueByPayment());
//
//                                   //status by payment date
//                                   if(payt.getContractDayOfPayment()<0){
//
//                                        payt.setStatusOfPayment("deposit installment");
//                                        //paymentsWithin+=payt.getPaymentAmount();
//
//                                    }else if(payt.getPaymentDate().before(payt.getContractDate())){
//
//                                        payt.setStatusOfPayment("");
//
//                                    }else if(payt.getTotalPaidByPayment()>=payt.getBalanceDueByPayment()){
//
//                                        payt.setStatusOfPayment("within");
//                                        //paymentsWithin+=payt.getPaymentAmount();
//
//                                    }else{
//                                        payt.setStatusOfPayment("behind");
//                                        //paymentsBehind+=payt.getPaymentAmount();
//                                    }
//
//                                    save.updateObject(payt);
//                                }
//                              
//                            for(Payments pyt:ps){
//                                if(pyt.getStatusOfPayment().equalsIgnoreCase("deposit installment") || pyt.getStatusOfPayment().equalsIgnoreCase("within")){
//
//                                    paymentsWithin+=pyt.getPaymentAmount();
//
//                                }else if(pyt.getStatusOfPayment().equalsIgnoreCase("behind")){
//
//                                    paymentsBehind+=pyt.getPaymentAmount();
//                                }
//                            }
//                            org.joda.time.DateTime contractDate = new DateTime(l.getDownPaymentDate().getTime());
//                            //not very clean need to verify
//                            //balanceDue= ((Days.daysBetween(today.toLocalDate(), new LocalDate(contractDate)).getDays()/-1) - 14)*modelUpfront.getDaily()+modelUpfront.getUpfront();
//                            //balanceDue= ((Days.daysBetween(today.toLocalDate(), new LocalDate(contractDate)).getDays()/-1) - 14)*modelUpfront.getDaily();
//                            balanceDue= (Days.daysBetween(today.toLocalDate(), new LocalDate(contractDate)).getDays()/-1)*modelUpfront.getDaily()+modelUpfront.getUpfront();
//
//                            if(balanceDue>modelUpfront.getPenguinTotal()){
//                                balanceDueToDate = modelUpfront.getPenguinTotal()-modelUpfront.getUpfront()-l.getDiscountedAmount()-l.getDefaultedAmount();
//                            }else{
//                                balanceDueToDate = balanceDue-modelUpfront.getUpfront()-l.getDiscountedAmount()-l.getDefaultedAmount();
//                            }
//
//    //                        log.info("days"+Days.daysBetween(today.toLocalDate(), new LocalDate(contractDate)).getDays()/-1+" daily"+modelUpfront.getDaily()+" percent"+modelUpfront.getPercent());
//    //                        log.info("balanceDueToDateeeeeeeeeeeeeeeeeeeeeeeeee"+balanceDueToDate+" "+l.getId());
//
//                            amountPaidToDate = prevPayment-modelUpfront.getUpfront();
//
//                            if((amountPaidToDate-balanceDueToDate)<0){
//                                outstandingOverdue = balanceDueToDate-amountPaidToDate;
//                              }else{    
//                                outstandingOverdue= 0.0;
//                            }
//
//                            //outstandingWithin = modelUpfront.getPenguinTotal()-outstandingOverdue-amountPaidToDate-l.getDefaultedAmount()-l.getDiscountedAmount();
//                            outstandingWithin = modelUpfront.getPenguinTotal()-outstandingOverdue-amountPaidToDate-modelUpfront.getUpfront()-l.getDefaultedAmount()-l.getDiscountedAmount();
//                            //outstandingWithin = modelUpfront.getPenguinTotal()-outstandingOverdue-amountPaidToDate-modelUpfront.getUpfront();
//                            //outstandingWithin = modelUpfront.getPenguinTotal()-outstandingOverdue-modelUpfront.getUpfront()-l.getDefaultedAmount()-l.getDiscountedAmount();
//
//                            l.setPaymentsWithin(paymentsWithin-modelUpfront.getUpfront());
//                            l.setPaymentsBehind(paymentsBehind);
//                            l.setBalanceDueToDate(balanceDueToDate);
//                            l.setAmountPaidToDate(amountPaidToDate);
//                            l.setOutstandingOverdue(outstandingOverdue);
//                            //l.setOutstandingWithin(outstandingWithin-modelUpfront.getUpfront());
//                            l.setOutstandingWithin(outstandingWithin);
//                            save.updateObject(l);
//under review
                            for (Payments payt : ps) {

                                //contract day of payment
                                org.joda.time.DateTime jodaContract = new DateTime(payt.getContractDate());
                                org.joda.time.DateTime jodaPayment = new DateTime(payt.getPaymentDate());
                                payt.setContractDayOfPayment(Days.daysBetween(jodaPayment.toLocalDate(), new LocalDate(jodaContract)).getDays() / -1);

                                //total balance due by payment date
                                if (payt.getContractDayOfPayment() < 0) {

                                    payt.setBalanceDueByPayment(0.0);

                                    payt.setStatusOfPayment("deposit installment");
                                    //paymentsWithin+=payt.getPaymentAmount();

                                } else if (payt.getContractDayOfPayment() == 0) {

                                    payt.setBalanceDueByPayment(modelUpfront.getUpfront());
                                } else {
                                    //payt.setBalanceDueByPayment(modelUpfront.getUpfront()+modelUpfront.getDaily()*(payt.getContractDayOfPayment()-14));
                                    payt.setBalanceDueByPayment(modelUpfront.getUpfront() + modelUpfront.getDaily() * payt.getContractDayOfPayment());
                                }
                                //totsl psyment by payment date
                                prevPayment += payt.getPaymentAmount();
                                //          log.info("paymentAmount============"+payt.getPaymentAmount());
                                payt.setTotalPaidByPayment(prevPayment);
                                //        log.info("prevPayment============"+prevPayment);
                                //      log.info("getTotalPaidByPayment============"+payt.getTotalPaidByPayment());
                                //    log.info("getBalanceDueByPayment============"+payt.getBalanceDueByPayment());

                                //status by payment date
                                if (payt.getPaymentDate().before(payt.getContractDate())) {

                                    payt.setStatusOfPayment("");

                                } else if (payt.getTotalPaidByPayment() >= payt.getBalanceDueByPayment()) {

                                    payt.setStatusOfPayment("within");
                                    //paymentsWithin+=payt.getPaymentAmount();

                                } else if (payt.getTotalPaidByPayment() < payt.getBalanceDueByPayment()) {
                                    payt.setStatusOfPayment("behind");
                                    //paymentsBehind+=payt.getPaymentAmount();
                                }

                                save.updateObject(payt);
                            }

                            //bad idea please remove
                            for (Payments pyt : ps) {
                                if (pyt.getStatusOfPayment().equalsIgnoreCase("deposit installment") || pyt.getStatusOfPayment().equalsIgnoreCase("within")) {

                                    paymentsWithin += pyt.getPaymentAmount();

                                } else if (pyt.getStatusOfPayment().equalsIgnoreCase("behind")) {

                                    paymentsBehind += pyt.getPaymentAmount();
                                }
                            }
                            org.joda.time.DateTime contractDate = new DateTime(l.getDownPaymentDate().getTime());
                            //not very clean need to verify
                            //balanceDue= ((Days.daysBetween(today.toLocalDate(), new LocalDate(contractDate)).getDays()/-1) - 14)*modelUpfront.getDaily()+modelUpfront.getUpfront();
                            //balanceDue= ((Days.daysBetween(today.toLocalDate(), new LocalDate(contractDate)).getDays()/-1) - 14)*modelUpfront.getDaily();
                            contractAge = Days.daysBetween(today.minusDays(1).toLocalDate(), new LocalDate(contractDate)).getDays() / -1;
                            /*balanceDue= contractAge*modelUpfront.getDaily()+modelUpfront.getUpfront();

                            if(balanceDue>modelUpfront.getPenguinTotal()){
                                balanceDueToDate = modelUpfront.getPenguinTotal()-modelUpfront.getUpfront()-l.getDiscountedAmount()-l.getDefaultedAmount();
                            }else{
                                balanceDueToDate = balanceDue-modelUpfront.getUpfront()-l.getDiscountedAmount()-l.getDefaultedAmount();
                            }*/

                            //                        log.info("days"+Days.daysBetween(today.toLocalDate(), new LocalDate(contractDate)).getDays()/-1+" daily"+modelUpfront.getDaily()+" percent"+modelUpfront.getPercent());
                            //                        log.info("balanceDueToDateeeeeeeeeeeeeeeeeeeeeeeeee"+balanceDueToDate+" "+l.getId());
                            if (contractAge > 360) {
                                balanceDueToDate = modelUpfront.getDaily() * 360;
                            } //else if(contractAge<0)
                            else if (l.getStatus().equalsIgnoreCase("paid up")) {
                                balanceDueToDate = 0.0;
                            } else {
                                balanceDueToDate = contractAge * modelUpfront.getDaily();
                            }

                            /*if(amountPaidToDate>modelUpfront.getPenguinTotal())
                                amountPaidToDate = modelUpfront.getPenguinTotal();
                            else
                                amountPaidToDate = prevPayment;*/
                            amountPaidToDate = prevPayment - modelUpfront.getUpfront();

                            /*if((amountPaidToDate-balanceDueToDate)<0){
                                outstandingOverdue = balanceDueToDate-amountPaidToDate;
                              }else{    
                                outstandingOverdue= 0.0;
                            }*/ //catering for -ve outstanding balance
                            if ((balanceDueToDate - amountPaidToDate) < 0 || balanceDueToDate == 0 || l.getStatus().equalsIgnoreCase("defaulter") || l.getStatus().equalsIgnoreCase("recovered") || l.getStatus().equalsIgnoreCase("paid up")) {
                                outstandingOverdue = 0.0;

                            } else {
                                outstandingOverdue = balanceDueToDate - amountPaidToDate;

                            }

                            if (l.getStatus().equalsIgnoreCase("paid up") || l.getStatus().equalsIgnoreCase("defaulter") || l.getStatus().equalsIgnoreCase("recovered")) {
                                outstandingWithin = 0.0;

                            } else if (amountPaidToDate > balanceDueToDate) {
                                outstandingWithin = modelUpfront.getPenguinTotal() - modelUpfront.getUpfront() - amountPaidToDate;

                            } else {
                                outstandingWithin = modelUpfront.getPenguinTotal() - modelUpfront.getUpfront() - balanceDueToDate;
                            }

                            //ask annie in daily payments is deposit installment included or already removed?
                            //outstandingWithin = modelUpfront.getPenguinTotal()-outstandingOverdue-amountPaidToDate-l.getDefaultedAmount()-l.getDiscountedAmount();
                            //recent--outstandingWithin = modelUpfront.getPenguinTotal()-outstandingOverdue-amountPaidToDate-modelUpfront.getUpfront()-l.getDefaultedAmount()-l.getDiscountedAmount();
                            //outstandingWithin = modelUpfront.getPenguinTotal()-outstandingOverdue-amountPaidToDate-modelUpfront.getUpfront();
                            //outstandingWithin = modelUpfront.getPenguinTotal()-outstandingOverdue-modelUpfront.getUpfront()-l.getDefaultedAmount()-l.getDiscountedAmount();
                            //l.setPaymentsWithin(paymentsWithin-modelUpfront.getUpfront());
                            l.setPaymentsWithin(paymentsWithin);
                            l.setPaymentsBehind(paymentsBehind);
                            l.setBalanceDueToDate(balanceDueToDate);
                            l.setAmountPaidToDate(amountPaidToDate);
                            l.setOutstandingOverdue(outstandingOverdue);
                            //l.setOutstandingWithin(outstandingWithin-modelUpfront.getUpfront());
                            l.setOutstandingWithin(outstandingWithin);
                            save.updateObject(l);

                            //this code is under review but currently happening on another endpoint                     
//                                for(BatchhasLoan bl:loanBatches){
//                                    List<BatchAnalysis> ba = baService.getBatchAnalysis(bl.getBatch());
//                                    if(!ba.isEmpty()){
//                            //prepare for curve analysis- shares data with collections chart.
//                            prevPayment=0.0;
//                            for (int day = 0; day <= ba.get(0).getAnalysisDays(); day++) {
//
//                                if (day == 0) {
//
//                                    for (Payments p : ps) {
//                                        if (!p.getPaymentDate().after(p.getContractDate())) {
//                                            prevPayment += p.getPaymentAmount();
//                                        }
//                                    }
//                            //        log.info("at zerooooooooooooooooooooooooooooooo" + prevPayment);
//                                    percent = prevPayment / modelTotal;
//                                    //persist percentage
//                                    Percentage perc = new Percentage();
//                                    perc.setDay(day);
//                                    //System.out.println("the looooooooooooooooooooooooooooooooooooooan "+l.getId()+" percent "+df.format(percent));
//                                    if("NaN".equalsIgnoreCase(String.valueOf(percent))){
//                                        perc.setPercentage(0.0);
//                                    }else{
//                                        perc.setPercentage(Double.valueOf(df.format(percent)));
//                                    }
//                                    perc.setLoanid(l);
//                                    perc.setBatchid(ba.get(0).getBatchid());
//                                    if (paymentService.findPercentageByLoan(l, day, ba.get(0).getBatchid()).isEmpty()) {
//                                        save.saveObject(perc);
//                                    } else {
//                                        Percentage p = paymentService.findPercentageByLoan(l, day, ba.get(0).getBatchid()).get(0);
//                                        p.setPercentage(perc.getPercentage());
//                                        save.updateObject(p);
//                                    }
//                                } else {
//                              //      log.info(""+Days.daysBetween(today.toLocalDate(), new LocalDate(contractDate)).getDays()+" "+day);
//                                //    log.info("todat"+today+"==="+"contractDate"+contractDate);
//                                    if(Days.daysBetween(today.plusDays(1).toLocalDate(), new LocalDate(contractDate)).getDays()/-1>day){
//                                  //      log.info(""+Days.daysBetween(today.toLocalDate(), new LocalDate(contractDate)).getDays()+" "+day);
//                                    for (Payments p : ps) {
//                                        org.joda.time.DateTime dtContract = new DateTime(p.getContractDate());
//                                        org.joda.time.DateTime dtPayment = new DateTime(p.getPaymentDate().getTime());
//                                        LocalDate d1 = new LocalDate(dtContract);
//                                        LocalDate d2 = new LocalDate(dtPayment);
//
//                                        if (d1.plusDays(day).isEqual(d2)) {
//                                    //        log.info("Dateeeeeeeeeeeee" + dtContract.plusDays(day).toString() + "= =" + dtPayment.toString());
//                                            prevPayment += p.getPaymentAmount();
//                                        }
//                                    }
//                                    //log.info("at oneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" + prevPayment);
//                                    percent = prevPayment / modelTotal;
//                                    //persist
//                                    Percentage perc = new Percentage();
//                                    perc.setDay(day);
//                                    if("NaN".equalsIgnoreCase(String.valueOf(percent))){
//                                        perc.setPercentage(0.0);
//                                    }else{
//                                        perc.setPercentage(Double.valueOf(df.format(percent)));
//                                    }
//                                    perc.setBatchid(ba.get(0).getBatchid());
//                                    perc.setLoanid(l);
//                                    List<Percentage> pct = paymentService.findPercentageByLoan(l, day,ba.get(0).getBatchid());
//                                    if (pct.isEmpty()) {
//                                        save.saveObject(perc);
//                                    } else {
//                                        pct.get(0).setPercentage(Double.valueOf(df.format(percent)));
//                                      //  log.info("updated..............................percentage");
//                                        save.updateObject(pct.get(0));
//                                    }
//                                  } 
//                                }
//                            }
//                        }else{
//                                    log.info("No batch Analysis Information "+bl.getBatch().getId());
//                                    }
//                      }
                        } else {
                            log.info("Loan not assigned to batch " + l.getId());
                        }
                    }

                    //update graphs manually
                    /* Batch ba = new Batch();
                    ba.setId(20);
                    String rply = updateGraphs(ba);*/
                    //Update charts automatically
                    List<Batch> batches = batchService.findAll();
                    String rply = "";
                    if (!batches.isEmpty()) {
                        for (Batch b : batches) {
                            rply = updateGraphs(b);
                            System.out.println("Batch complete " + b.getId());
                        }

                    } else {
                        log.info("UPLOAD ERROR@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@No batches created on system, graphs not created");
//                          reply.setError("No batches created on system, graphs not created");
                    }

                    //log.info("@@@@@ Upload Done for curve");
                    reply.setSucc("Curve data updated");

                } else {
                    // log.info("No loans in loan portal tool");
                    reply.setError("No loans in loan portal tool");
                }

            } else {
                //log.info("Empty payments object");
                reply.setError("Empty payments object");
            }

        } catch (com.google.gson.JsonSyntaxException ex) {

            log.error("JSON error : " + ex);
            reply.setError("JSON" + ex.toString());
        }

        return reply.toString();
    }

    public String updateGraphs(Batch b) {
        if (b != null) {

            List<BatchhasLoan> bloans = bhlService.batchLoanByBatch(b);
            List<BatchAnalysis> ba = baService.getBatchAnalysis(b);

            if (bloans.isEmpty()) {
                log.info("No loans assigned to batch " + bloans.size());
                reply.setError("No loans assigned to batch");
            } else {

                Double w = 0.0, p = 0.0, o = 0.0, d = 0.0;
                Double wn = 0.0, pu = 0.0, od = 0.0, df = 0.0, dfOutstanding = 0.0, reposessed = 0.0;
                Double outWithin = 0.0, outPlanPaidUp = 0.0, outOverdue = 0.0, par1NumberLoans = 0.0, par30NumberLoans = 0.0, par60NumberLoans = 0.0, par90NumberLoans = 0.0;
                Double accountsDefaulted = 0.0, accountsReposessed = 0.0, accountsWithin = 0.0, accountsPaidUp = 0.0;
                Double collected = 0.0, outstanding = 0.0, par1 = 0.0, par30 = 0.0, par60 = 0.0, par90 = 0.0;

                double paymentsWithin = 0;
                double paymentsBehind = 0;
                double balanceDueToDate = 0;
                double amountPaidToDate = 0;
                double outstandingOverdue = 0;
                double outstandingWithin = 0;
                double defaulted = 0;
                double discounted = 0;
                double reposessedInstallments = 0;

                BigDecimal[] actualPercent = new BigDecimal[0];
                Integer[] ap = new Integer[0];
                Double[] actualPercent2 = new Double[0];
                Double[] ap2 = new Double[0];
                int ii = 0;

                if (!ba.isEmpty()) {

                    if (ba.get(0).getAnalysisDays() > 80 && ba.get(0).getAnalysisDays() < 540) {
                        actualPercent = new BigDecimal[ba.get(0).getAnalysisDays() / 7];
                        ap = new Integer[ba.get(0).getAnalysisDays() / 7];
                        actualPercent2 = new Double[ba.get(0).getAnalysisDays() / 7];
                        ap2 = new Double[ba.get(0).getAnalysisDays() / 7];
                        ii = ba.get(0).getAnalysisDays() / 7 - 1;

                        while (ii >= 0) {

                            actualPercent[ii] = BigDecimal.ZERO;
                            ap[ii] = 0;
                            actualPercent2[ii] = 0.0;
                            ap2[ii] = 0.0;

                            ii--;

                        }
                    } else if (ba.get(0).getAnalysisDays() > 540) {

                        actualPercent = new BigDecimal[ba.get(0).getAnalysisDays() / 30];
                        ap = new Integer[ba.get(0).getAnalysisDays() / 30];
                        ii = ba.get(0).getAnalysisDays() / 30 - 1;

                        while (ii >= 0) {

                            actualPercent[ii] = BigDecimal.ZERO;
                            ap[ii] = 0;
                            actualPercent2[ii] = 0.0;
                            ap2[ii] = 0.0;

                            ii--;

                        }

                    } else {

                        actualPercent = new BigDecimal[ba.get(0).getAnalysisDays()];
                        ap = new Integer[ba.get(0).getAnalysisDays()];
                        ii = ba.get(0).getAnalysisDays() - 1;

                        while (ii >= 0) {

                            actualPercent[ii] = BigDecimal.ZERO;
                            ap[ii] = 0;
                            actualPercent2[ii] = 0.0;
                            ap2[ii] = 0.0;

                            ii--;

                        }

                    }
                }
                double paidupExcess = 0.0;
                int restructured = 0;
                double outstandingRestructured = 0;
                double outstandingOverdueRestructured = 0;

                for (BatchhasLoan result : bloans) {
                    Loan l = loanService.loanById(result.getLoan().getId());

                    outstanding += l.getBalance();
                    collected += l.getInstallmentsPaid();
                    paymentsWithin += (l.getAmountPaidToDate() - l.getPaymentsBehind());
                    //paymentsWithin+=l.getPaymentsWithin();
                    paymentsBehind += l.getPaymentsBehind();
                    balanceDueToDate += l.getBalanceDueToDate();
                    amountPaidToDate += l.getAmountPaidToDate();
                    outstandingOverdue += l.getOutstandingOverdue();
                    outstandingWithin += l.getOutstandingWithin();
                    defaulted += l.getDefaultedAmount();
                    discounted += l.getDiscountedAmount();

                    switch (l.getStatus().toLowerCase()) {
                        case "within plan":
                            ++w;
                            wn += l.getTotalValueLoan();
                            outWithin += l.getBalance();
                            ++accountsWithin;
                            break;
                        case "paid up":
                            ++p;
                            pu += l.getTotalValueLoan();
                            outPlanPaidUp += l.getInstallmentsPaid() + l.getBalance();
                            paymentsWithin += l.getBalance();
                            paidupExcess += l.getBalance();
                            ++accountsPaidUp;
                            break;
                        case "overdue":
                            ++o;
                            od += l.getTotalValueLoan();
                            outOverdue += l.getBalance();
                            break;
                        case "defaulter":
                            ++d;
                            df += l.getTotalValueLoan();
                            dfOutstanding += l.getBalance();
                            ++accountsDefaulted;
                            break;
                        case "recovered":
                            reposessed += l.getBalance();
                            reposessedInstallments += l.getTotalAmountValue();
                            ++accountsReposessed;
                            break;
                        default:

                    }

                    switch (l.getPar()) {
                        case "PAR 1":
                            par1 += (l.getBalance());
                            ++par1NumberLoans;
                            break;
                        case "PAR 30":

                            par30 += (l.getBalance());
                            ++par30NumberLoans;
                            break;
                        case "PAR 60":

                            par60 += (l.getBalance());
                            ++par60NumberLoans;
                            break;
                        case "PAR 90":

                            par90 += (l.getBalance());
                            ++par90NumberLoans;
                            break;
                        default:

                    }

                    if (l.getRestructured()) {
                        restructured++;
                        outstandingRestructured += l.getRestructuredOutstanding();
                        outstandingOverdueRestructured += l.getValueOverdueRestructuring();
                    }

                    if (!ba.isEmpty()) {

                        if (ba.get(0).getAnalysisDays() > 80 && ba.get(0).getAnalysisDays() < 540) {

                            int g = 0;
                            for (int day = 0; day < ba.get(0).getAnalysisDays() - 1; day += 7) {
                                //double percent = 0.0;

                                List<Percentage> lns = paymentService.findPercentageByLoan(l, day, b);

                                if (!lns.isEmpty() && lns.get(0).getPercentage()!=0) {
                                    actualPercent[g] = BigDecimal.valueOf(lns.get(0).getPercentage()).add(actualPercent[g]);
                                    ap[g] += 1;
                                    actualPercent2[g] += lns.get(0).getPreviousPayment();
                                    ap2[g] += lns.get(0).getModelTotal();
                                }

                                g++;

                            }

                        } else if (ba.get(0).getAnalysisDays() > 540) {

                            int g = 0;
                            for (int day = 0; day < ba.get(0).getAnalysisDays() - 1; day += 30) {
                                //double percent = 0.0;

                                List<Percentage> lns = paymentService.findPercentageByLoan(l, day, b);

                                if (!lns.isEmpty() && lns.get(0).getPercentage()!=0 ) {
                                    actualPercent[g] = BigDecimal.valueOf(lns.get(0).getPercentage()).add(actualPercent[g]);
                                    ap[g] += 1;
                                    actualPercent2[g] += lns.get(0).getPreviousPayment();
                                    ap2[g] += lns.get(0).getModelTotal();
                                }

                                g++;

                            }

                        } else {

                            int g = 0;
                            for (int day = 0; day < ba.get(0).getAnalysisDays() - 1; day++) {
                                //double percent = 0.0;

                                List<Percentage> lns = paymentService.findPercentageByLoan(l, day, b);

                                if (!lns.isEmpty() && lns.get(0).getPercentage()!=0) {
                                    actualPercent[g] = BigDecimal.valueOf(lns.get(0).getPercentage()).add(actualPercent[g]);
                                    ap[g] += 1;
                                    actualPercent2[g] += lns.get(0).getPreviousPayment();
                                    ap2[g] += lns.get(0).getModelTotal();
                                }

                                g++;

                            }

                        }
                    } else {
                        log.info("No batch curve analysis for batch " + b.getId());
                    }

                }

                par1 = par1 / 1000000;
                par30 = par30 / 1000000;
                par60 = par60 / 1000000;  
                //par90 = (par90 - dfOutstanding - reposessed) / 1000000;
                par90 = (par90) / 1000000;//recovered accouts tracked separately from pa90

                RestructuredLoans rl = new RestructuredLoans();
                rl.setBatchid(b.getId());
                rl.setDateCreated(PrintJson.timeZoneKla());
                Calendar cal = Calendar.getInstance();
                rl.setMonth(String.valueOf(cal.get(Calendar.MONTH) + 1));
                rl.setNumberRestructured(restructured);
                rl.setOutstandingRestructured(outstandingRestructured);
                rl.setOutstandingOverdueRestructured(outstandingOverdueRestructured);

                List<RestructuredLoans> RLnew = chartService.getBatchRestrucredMonth(rl.getMonth(), b.getId());
                if (RLnew.isEmpty()) {
                    save.saveObject(rl);
                } else {
                    RLnew.get(0).setDateCreated(PrintJson.timeZoneKla());
                    RLnew.get(0).setNumberRestructured(restructured);
                    RLnew.get(0).setOutstandingRestructured(outstandingRestructured);
                    RLnew.get(0).setOutstandingOverdueRestructured(outstandingOverdueRestructured);

                    save.updateObject(RLnew.get(0));
                }

                NumberofLoans nl = new NumberofLoans();
                nl.setBatchid(b.getId());
                nl.setDateCreated(PrintJson.timeZoneKla());
                nl.setMonth(String.valueOf(cal.get(Calendar.MONTH) + 1));
                nl.setOverDue(o);
                nl.setPaidUp(p);
                nl.setWithin(w);
                nl.setClosed(d + accountsReposessed);
                nl.setRecovered(accountsReposessed);
                List<NumberofLoans> NLnew = chartService.getBatchNumberMonth(nl.getMonth(), b.getId());
                if (NLnew.isEmpty()) {
                    save.saveObject(nl);
                } else {
                    NLnew.get(0).setDateCreated(PrintJson.timeZoneKla());
                    NLnew.get(0).setOverDue(o);
                    NLnew.get(0).setPaidUp(p);
                    NLnew.get(0).setWithin(w);
                    NLnew.get(0).setClosed(d + accountsReposessed);
                    NLnew.get(0).setRecovered(accountsReposessed);
                    save.updateObject(NLnew.get(0));
                }

                PaymentStatus ps = new PaymentStatus();
                ps.setBatchid(b.getId());
                ps.setClosed(defaulted + reposessed);
                ps.setDateCreated(PrintJson.timeZoneKla());
                ps.setOverDue(outOverdue);
                ps.setPaidUp(outPlanPaidUp);
                ps.setWithin(outWithin);
                ps.setCollected(collected - outPlanPaidUp + paidupExcess);
                ps.setMonth(String.valueOf(cal.get(Calendar.MONTH) + 1));
                ps.setDiscountedAmount(discounted);
                List<PaymentStatus> NLnewP = chartService.getBatchPaymentStatusMonth(ps.getMonth(), b.getId());
                if (NLnewP.isEmpty()) {
                    save.saveObject(ps);
                } else {

                    NLnewP.get(0).setClosed(defaulted + reposessed);
                    NLnewP.get(0).setDateCreated(PrintJson.timeZoneKla());
                    NLnewP.get(0).setOverDue(outOverdue);
                    NLnewP.get(0).setPaidUp(outPlanPaidUp);
                    NLnewP.get(0).setWithin(outWithin);
                    NLnewP.get(0).setCollected(collected - outPlanPaidUp + paidupExcess);
                    NLnewP.get(0).setDiscountedAmount(discounted);
                    save.updateObject(NLnewP.get(0));
                }

                LoanPerformance lp = new LoanPerformance();
                lp.setBatchid(b.getId());
                lp.setCollected(collected);
                lp.setDateCreated(PrintJson.timeZoneKla());
                lp.setOutstanding(outstanding);
                lp.setPaymentsWithin(paymentsWithin);
                lp.setPaymentsBehind(paymentsBehind);
                lp.setOutstandingWithin(outstandingWithin);
                //lp.setOutstandingOverdue(outstandingOverdue -reposessed-paidupExcess);
                lp.setOutstandingOverdue(outstandingOverdue);
                lp.setAmountPaidToDate(amountPaidToDate);
                lp.setBalanceDueToDate(balanceDueToDate);
                lp.setDefaultedAmount(defaulted + reposessed);
                lp.setDiscountedAmount(discounted);
                lp.setDateCreated(PrintJson.timeZoneKla());
                lp.setMonth(String.valueOf(cal.get(Calendar.MONTH) + 1));
                List<LoanPerformance> NLnewL = chartService.getBatchLoanPerformanceMonth(ps.getMonth(), b.getId());
                if (NLnewL.isEmpty()) {
                    save.saveObject(lp);
                } else {
                    NLnewL.get(0).setCollected(collected);
                    NLnewL.get(0).setOutstanding(outstanding);
                    NLnewL.get(0).setPaymentsWithin(paymentsWithin);
                    NLnewL.get(0).setPaymentsBehind(paymentsBehind);
                    NLnewL.get(0).setOutstandingWithin(outstandingWithin);
                    //NLnewL.get(0).setOutstandingOverdue(outstandingOverdue -reposessed-paidupExcess);
                    NLnewL.get(0).setOutstandingOverdue(outstandingOverdue);
                    NLnewL.get(0).setAmountPaidToDate(amountPaidToDate);
                    NLnewL.get(0).setBalanceDueToDate(balanceDueToDate);
                    NLnewL.get(0).setDefaultedAmount(defaulted + reposessed);
                    NLnewL.get(0).setDiscountedAmount(discounted);
                    NLnewL.get(0).setDateCreated(PrintJson.timeZoneKla());
                    save.updateObject(NLnewL.get(0));
                }

                OverdueLoansByNumber odn = new OverdueLoansByNumber();
                Double outstandingNumberAccounts;
                outstandingNumberAccounts = (par1NumberLoans + par30NumberLoans + par60NumberLoans + par90NumberLoans + accountsDefaulted + accountsPaidUp + accountsReposessed + accountsWithin);
                odn.setNumberPar1(par1NumberLoans);
                odn.setNumberPar30(par30NumberLoans);
                odn.setNumberPar60(par60NumberLoans);
                //odn.setNumberPar90(par90NumberLoans - accountsDefaulted);
                odn.setNumberPar90(par90NumberLoans);//we skip defaulters when deciding PAR value
                odn.setNumberWithinPaidUp(accountsPaidUp + accountsWithin);
                odn.setNumberOnDefaulted(accountsDefaulted + accountsReposessed);
                odn.setNumberOnReposessed(accountsReposessed);
                if(outstandingNumberAccounts==0){
                   odn.setParByNumber(0.0); 
                   odn.setParDefaultedNumber(0.0);
                   odn.setParReposessedNumber(0.0);
                }
                else{
                    odn.setParByNumber((par1NumberLoans + par30NumberLoans + par60NumberLoans + par90NumberLoans) / outstandingNumberAccounts);
                    odn.setParDefaultedNumber(accountsDefaulted / outstandingNumberAccounts);
                    odn.setParReposessedNumber(accountsReposessed / outstandingNumberAccounts);
            }
                odn.setMonth(String.valueOf((cal.get(Calendar.MONTH) + 1)));
                
                odn.setBatchid(b.getId());
                odn.setDateCreated(PrintJson.timeZoneKla());
                List<OverdueLoansByNumber> NLnewO = chartService.getBatchODNMonth(ps.getMonth(), b.getId());
                if (NLnewO.isEmpty()) {
                    save.saveObject(odn);
                } else {
                    NLnewO.get(0).setNumberPar1(par1NumberLoans);
                    NLnewO.get(0).setNumberPar30(par30NumberLoans);
                    NLnewO.get(0).setNumberPar60(par60NumberLoans);
                    //NLnewO.get(0).setNumberPar90(par90NumberLoans - accountsDefaulted);
                    NLnewO.get(0).setNumberPar90(par90NumberLoans);//we skip defaulters when deciding PAR value
                    NLnewO.get(0).setNumberWithinPaidUp(accountsPaidUp + accountsWithin);
                    NLnewO.get(0).setNumberOnDefaulted(accountsDefaulted + accountsReposessed);
                    NLnewO.get(0).setNumberOnReposessed(accountsReposessed);
                    if(outstandingNumberAccounts==0){
                        NLnewO.get(0).setParByNumber(0.0);
                        NLnewO.get(0).setParDefaultedNumber(0.0);
                        NLnewO.get(0).setParReposessedNumber(0.0);
                    }
                    else{
                        NLnewO.get(0).setParByNumber((par1NumberLoans + par30NumberLoans + par60NumberLoans + par90NumberLoans) / outstandingNumberAccounts);
                        NLnewO.get(0).setParDefaultedNumber(accountsDefaulted / outstandingNumberAccounts);
                    NLnewO.get(0).setParReposessedNumber(accountsReposessed / outstandingNumberAccounts);
                }
                    NLnewO.get(0).setMonth(String.valueOf((cal.get(Calendar.MONTH) + 1)));
                    

                    NLnewO.get(0).setDateCreated(PrintJson.timeZoneKla());
                    save.updateObject(NLnewO.get(0));
                }

                Double outstandingParAccounts;
                outstandingParAccounts = (par1 + par30 + par60 + par90 + (outWithin / 1000000) + (outPlanPaidUp / 1000000) + (reposessed / 1000000) + (dfOutstanding / 1000000));
                OverdueLoansByValue odv = new OverdueLoansByValue();
                odv.setOutstandingWithinPaidUp((outWithin / 1000000) + (outPlanPaidUp / 1000000));
                if(outstandingParAccounts==0){
                    odv.setParByValue(0.0);
                    odv.setParDefaultedValue(0.0);
                    odv.setParReposessedValue(0.0);
                }else{
                    odv.setParByValue((par1 + par30 + par60 + par90) / outstandingParAccounts);
                    odv.setParDefaultedValue((defaulted / 1000000) / outstandingParAccounts);
                    odv.setParReposessedValue((reposessed / 1000000) / outstandingParAccounts);
                }
                odv.setOutstandingPar1(par1);
                odv.setOutstandingPar30(par30);
                odv.setOutstandingPar60(par60);
                odv.setOutstandingPar90(par90);
                odv.setRecoveryAmount((defaulted / 1000000) / 2);
                odv.setOutstandingOnDefaulted((defaulted + reposessed) / 1000000);
                odv.setOutstandingOnReposessed(reposessed / 1000000);
                odv.setDateCreated(PrintJson.timeZoneKla());
                odv.setBatchid(b.getId());
                odv.setMonth(String.valueOf((cal.get(Calendar.MONTH) + 1)));
                List<OverdueLoansByValue> NLnewV = chartService.getBatchODVMonth(ps.getMonth(), b.getId());
                if (NLnewV.isEmpty()) {
                    save.saveObject(odv);
                } else {
                    NLnewV.get(0).setOutstandingWithinPaidUp((outWithin / 1000000) + (outPlanPaidUp / 1000000));
                if(outstandingParAccounts==0){
                    NLnewV.get(0).setParByValue(0.0);
                    NLnewV.get(0).setParDefaultedValue(0.0);
                    NLnewV.get(0).setParReposessedValue(0.0);
                }else{
                    NLnewV.get(0).setParByValue((par1 + par30 + par60 + par90) / outstandingParAccounts);
                    NLnewV.get(0).setParDefaultedValue((defaulted / 1000000) / outstandingParAccounts);
                    NLnewV.get(0).setParReposessedValue((reposessed / 1000000) / outstandingParAccounts);
                }
                    NLnewV.get(0).setOutstandingPar1(par1);
                    NLnewV.get(0).setOutstandingPar30(par30);
                    NLnewV.get(0).setOutstandingPar60(par60);
                    NLnewV.get(0).setOutstandingPar90(par90);
                    NLnewV.get(0).setRecoveryAmount((defaulted / 1000000) / 2);
                    NLnewV.get(0).setOutstandingOnDefaulted((defaulted + reposessed) / 1000000);
                    NLnewV.get(0).setOutstandingOnReposessed(reposessed / 1000000);
                    NLnewV.get(0).setDateCreated(PrintJson.timeZoneKla());
                    save.updateObject(NLnewV.get(0));
                }

                //save if week, month,year displays
                //save batch curve
                if (!ba.isEmpty()) {
                    
                    DecimalFormat dft = new DecimalFormat("#.######");
                    dft.setRoundingMode(RoundingMode.CEILING);
                    
                    if (ba.get(0).getAnalysisDays() > 80 && ba.get(0).getAnalysisDays() < 540) {
                        for (int i = 0; i < (ba.get(0).getAnalysisDays() / 7/*-1*/); i++) {
                            ActualPercentage ac = new ActualPercentage();
                            ac.setActualDay(i);
                            //System.out.println(" ---"+actualPercent[i]+"-----"+ap[i]);
                            if (ap[i] == 0) {
                                ac.setActualPercent(BigDecimal.ZERO);
                                ac.setActualPercent2(0.0);
                            } else {
                                //System.out.println("i=iterastion"+i);
                                //System.out.println("actaulPercent"+actualPercent[i].toString()+"-"+"elements"+ap[i]);
                                // if(actualPercent[i].isInfinite()){
                                //     ac.setActualPercent(Double.POSITIVE_INFINITY/ap[i]);
                                // }else{
                                ac.setActualPercent(actualPercent[i].divide(BigDecimal.valueOf(ap[i]), 2, RoundingMode.HALF_UP));
                                ac.setActualPercent2(Double.valueOf(dft.format(actualPercent2[i]/ap2[i])));
                                // }
                                ac.setBatchid(b.getId());
                                List<ActualPercentage> acList = paymentService.findPercentByDayBatch(i, b.getId());

                                if (acList.isEmpty()) {

                                    save.saveObject(ac);
                                } else {
                                    acList.get(0).setActualPercent(ac.getActualPercent());
                                    acList.get(0).setActualPercent2(ac.getActualPercent2());
                                    save.updateObject(acList.get(0));
                                }
                            }

                        }
                    } else if (ba.get(0).getAnalysisDays() > 540) {

                        for (int i = 0; i < (ba.get(0).getAnalysisDays() / 30 - 1); i++) {
                            ActualPercentage ac = new ActualPercentage();
                            ac.setActualDay(i);

                            if (ap[i] == 0) {
                                ac.setActualPercent(BigDecimal.ZERO);
                                ac.setActualPercent2(0.0);
                            } else {
                                ac.setActualPercent(actualPercent[i].divide(BigDecimal.valueOf(ap[i].doubleValue()), 2, RoundingMode.HALF_UP));
                                ac.setActualPercent2(Double.valueOf(dft.format(actualPercent2[i]/ap2[i])));
                                ac.setBatchid(b.getId());
                                List<ActualPercentage> acList = paymentService.findPercentByDayBatch(i, b.getId());

                                if (acList.isEmpty()) {

                                    save.saveObject(ac);
                                } else {
                                    acList.get(0).setActualPercent(ac.getActualPercent());
                                    acList.get(0).setActualPercent2(ac.getActualPercent2());
                                    save.updateObject(acList.get(0));
                                }
                            }

                        }

                    } else {

                        for (int i = 0; i < ba.get(0).getAnalysisDays() - 1; i++) {
                            ActualPercentage ac = new ActualPercentage();
                            ac.setActualDay(i);

                            if (ap[i] == 0) {
                                ac.setActualPercent(BigDecimal.ZERO);
                                ac.setActualPercent2(0.0);
                            } else {
                                ac.setActualPercent(actualPercent[i].divide(BigDecimal.valueOf(ap[i]), 2, RoundingMode.HALF_UP));
                                ac.setActualPercent2(Double.valueOf(dft.format(actualPercent2[i]/ap2[i])));
                                ac.setBatchid(b.getId());
                                List<ActualPercentage> acList = paymentService.findPercentByDayBatch(i, b.getId());

                                if (acList.isEmpty()) {

                                    save.saveObject(ac);
                                } else {
                                    acList.get(0).setActualPercent(ac.getActualPercent());
                                    acList.get(0).setActualPercent2(ac.getActualPercent2());
                                    save.updateObject(acList.get(0));
                                }
                            }

                        }

                    }
                } else {
                    log.info("No batch Analysis Information");
                }

                reply.setSucc("Graph Data Updated");
                log.info("@@@@@@@@@@@@@@@@@@@@@@@@@ Graph Data Updated");

            }

        } else {

            log.info("Send Batch object");
            reply.setError("Send Batch object");
        }
        return reply.toString();
    }

    // ++++++++++++++++++++++++: FETCH SEARCHED LOANS :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Secured({Role.administrator})
    @Path("searchLoans")
    @ApiOperation(value = "Search Loans", notes = "Search for loans.", response = JsonReply.class)
    public String searchLoans(@Context Request req, @ApiParam(value = "JsonInput.loan") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new GsonBuilder().setDateFormat("MM/dd/yyyy").create();

        //response
        reply = new JsonReply("searchLoans");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);

            if (input != null || input.loan != null) {

                if (input.loan.getDownPaymentDate() != null && input.loan.getSalesAgent().length() > 0 && input.loan.getStore().length() > 0 && input.loan.getInstallationAddress().length() > 0 && input.loan.getDistributionAgent().length() > 0) {

                    reply.loans = loanService.searchLoan(input.loan.getDownPaymentDate(), input.loan.getNextPaymentDate(), input.loan.getSalesAgent().toLowerCase(), input.loan.getDistributionAgent().toLowerCase(), input.loan.getStore().toLowerCase(), input.loan.getInstallationAddress().toLowerCase());

                } else if (input.loan.getDownPaymentDate() != null && input.loan.getSalesAgent().length() > 0 && input.loan.getStore().length() > 0 && input.loan.getDistributionAgent().length() > 0) {

                    reply.loans = loanService.searchLoanD(input.loan.getDownPaymentDate(), input.loan.getNextPaymentDate(), input.loan.getSalesAgent().toLowerCase(), input.loan.getDistributionAgent().toLowerCase(), input.loan.getStore().toLowerCase());

                } else if (input.loan.getDownPaymentDate() != null && input.loan.getSalesAgent().length() > 0 && input.loan.getInstallationAddress().length() > 0 && input.loan.getDistributionAgent().length() > 0) {

                    reply.loans = loanService.searchLoanN(input.loan.getDownPaymentDate(), input.loan.getNextPaymentDate(), input.loan.getSalesAgent().toLowerCase(), input.loan.getDistributionAgent().toLowerCase(), input.loan.getInstallationAddress().toLowerCase());
                } else if (input.loan.getStore().length() > 0 && input.loan.getSalesAgent().length() > 0l && input.loan.getInstallationAddress().length() > 0 && input.loan.getDistributionAgent().length() > 0) {
                    reply.loans = loanService.searchLoanK(input.loan.getInstallationAddress().toLowerCase(), input.loan.getSalesAgent().toLowerCase(), input.loan.getStore().toLowerCase(), input.loan.getDistributionAgent().toLowerCase());

                } else if (input.loan.getDownPaymentDate() != null && input.loan.getSalesAgent().length() > 0 && input.loan.getInstallationAddress().length() > 0 && input.loan.getStore().length() > 0) {

                    reply.loans = loanService.searchLoanW(input.loan.getDownPaymentDate(), input.loan.getNextPaymentDate(), input.loan.getSalesAgent().toLowerCase(), input.loan.getInstallationAddress().toLowerCase(), input.loan.getStore().toLowerCase());

                } else if (input.loan.getInstallationAddress().length() > 0 && input.loan.getDownPaymentDate() != null) {

                    reply.loans = loanService.searchLoanP(input.loan.getDownPaymentDate(), input.loan.getNextPaymentDate(), input.loan.getInstallationAddress().toLowerCase());
                } else if (input.loan.getSalesAgent().length() > 0 && input.loan.getDownPaymentDate() != null) {

                    reply.loans = loanService.searchLoanQ(input.loan.getDownPaymentDate(), input.loan.getNextPaymentDate(), input.loan.getSalesAgent().toLowerCase());
                } else if (input.loan.getStore().length() > 0 && input.loan.getDownPaymentDate() != null) {

                    reply.loans = loanService.searchLoanL(input.loan.getDownPaymentDate(), input.loan.getNextPaymentDate(), input.loan.getStore().toLowerCase());
                    /*}else if(input.loan.getSalesAgent()!=null && input.loan.getStore()!=null && input.loan.getInstallationAddress()!=null){
                   
                    reply.loans = loanService.searchLoan(input.loan.getSalesAgent().toLowerCase(), input.loan.getStore().toLowerCase(), input.loan.getInstallationAddress().toLowerCase());
                }else if(input.loan.getSalesAgent()!=null && input.loan.getStore()!=null && input.loan.getDistributionAgent()!=null){
                    
                    reply.loans = loanService.searchLoan(input.loan.getSalesAgent().toLowerCase(), input.loan.getStore().toLowerCase(), input.loan.getDownPaymentDate().toLowerCase());
                }else if(input.loan.getSalesAgent()!=null && input.loan.getInstallationAddress()!=null && input.loan.getDistributionAgent()!=null){
                    reply.loans = loanService.searchLoan(input.loan.getSalesAgent().toLowerCase(), input.loan.getInstallationAddress().toLowerCase(), input.loan.getDistributionAgent().toLowerCase());
                }else if(input.loan.getInstallationAddress()!=null && input.loan.getDistributionAgent()!=null){
                   reply.loans = loanService.searchLoan(input.loan.getInstallationAddress().toLowerCase(), input.loan.getDistributionAgent().toLowerCase());
               }else if(input.loan.getSalesAgent()!=null && input.loan.getStore()!=null){
                   reply.loans = loanService.searchLoan(input.loan.getSalesAgent().toLowerCase(), input.loan.getStore().toLowerCase());
               }else if(input.loan.getDistributionAgent()!=null && input.loan.getStore()!=null){
                   reply.loans = loanService.searchLoan(input.loan.getDistributionAgent().toLowerCase(), input.loan.getStore().toLowerCase());
               }else if(input.loan.getSalesAgent()!=null && input.loan.getInstallationAddress()!=null){
                   reply.loans = loanService.searchLoan(input.loan.getSalesAgent().toLowerCase(), input.loan.getInstallationAddress().toLowerCase());
                     */
                } else if (input.loan.getStore().length() > 0 && input.loan.getDistributionAgent().length() > 0) {
                    reply.loans = loanService.searchLoanS(input.loan.getStore().toLowerCase(), input.loan.getDistributionAgent().toLowerCase());
                } else if (input.loan.getInstallationAddress().length() > 0 && input.loan.getDownPaymentDate() != null) {
                    reply.loans = loanService.searchLoanInstallationDate(input.loan.getDownPaymentDate(), input.loan.getInstallationAddress().toLowerCase());
                } else if (input.loan.getInstallationAddress().length() > 0 && input.loan.getStore().length() > 0) {
                    reply.loans = loanService.searchLoanP(input.loan.getInstallationAddress().toLowerCase(), input.loan.getStore().toLowerCase());
                } else if (input.loan.getDownPaymentDate() != null) {
                    reply.loans = loanService.searchDate(input.loan.getDownPaymentDate(), input.loan.getNextPaymentDate());
                } else if (input.loan.getDistributionAgent().length() > 0) {
                    reply.loans = loanService.searchDistribution(input.loan.getDistributionAgent().toLowerCase());
                } else if (input.loan.getInstallationAddress().length() > 0) {
                    reply.loans = loanService.searchInstallation(input.loan.getInstallationAddress().toLowerCase());
                } else if (input.loan.getStore().length() > 0) {
                    reply.loans = loanService.searchStore(input.loan.getStore().toLowerCase());
                } else if (input.loan.getSalesAgent().length() > 0) {
                    reply.loans = loanService.searchSalesAgent(input.loan.getSalesAgent().toLowerCase());
                } else if (input.rangeOne.length() > 0 && input.rangeTwo.length() > 0) {
                    reply.loans = loanService.searchRange(input.rangeOne, input.rangeTwo);
                }

                if (!reply.loans.isEmpty()) {
                    reply.setSucc("Found loans " + reply.loans.size());
                    log.info("Found loans " + reply.loans.size());
                } else {
                    reply.setError("No loans matched");
                    log.info("Mo loans matched");

                }

            } else {
                log.info("Please Send some JSON or Send Loan object");
                reply.setError("Please Send some JSON or Send Loan object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }
    
    
    
     // discard legacy accounts
    private void deleteOldLoans()  {
        
        
        
        DateTime today = new DateTime();
        //today += today.minusDays(14).toLocalDate();
        
        List<Loan> oldLoans = loanService.findOldLoansByDate(today.minusDays(4));
        
        
        if(!oldLoans.isEmpty()){
            
            for(Loan l:oldLoans){
                List<BatchhasLoan> loanBatches = bhlService.batchLoanByLoan(l);
                
                if(!loanBatches.isEmpty()){
                    for(BatchhasLoan b:loanBatches){
                        save.deleteObject(b);
                    }
                    
                    List<Percentage> lns = paymentService.findPercentageByLoanOnly(l);
                
                    if(!lns.isEmpty()){
                        for(Percentage p:lns){
                            save.deleteObject(p);
                        }
                
                    }
                }
                
                save.deleteObject(l);
            }
            
        }
    }

    // save uploaded file to new location
    private void saveToFile(InputStream uploadedInputStream,
            String uploadedFileLocation) throws IOException {
        
            OutputStream out=null;
        try {

            int read;
            byte[] bytes = new byte[1024];

            out = new FileOutputStream(new File(uploadedFileLocation));
            while ((read = uploadedInputStream.read(bytes)) != -1) {
                out.write(bytes, 0, read);
            }
            out.flush();

        } catch (IOException e) {

            log.info(e);
        } finally {
            //close file io
            out.close();

        }

    }

}
