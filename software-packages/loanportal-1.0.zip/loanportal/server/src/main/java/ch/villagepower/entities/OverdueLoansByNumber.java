/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import io.swagger.annotations.ApiModel;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Entity
@Table(name = "overdue_loans_by_number")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "OverdueLoansByNumber.findAll", query = "SELECT o FROM OverdueLoansByNumber o"),
    @NamedQuery(name = "OverdueLoansByNumber.findByIdoverdueLoansByNumber", query = "SELECT o FROM OverdueLoansByNumber o WHERE o.idoverdueLoansByNumber = :idoverdueLoansByNumber"),
    @NamedQuery(name = "OverdueLoansByNumber.findByNumberPar1", query = "SELECT o FROM OverdueLoansByNumber o WHERE o.numberPar1 = :numberPar1"),
    @NamedQuery(name = "OverdueLoansByNumber.findByNumberPar30", query = "SELECT o FROM OverdueLoansByNumber o WHERE o.numberPar30 = :numberPar30"),
    @NamedQuery(name = "OverdueLoansByNumber.findByNumberPar60", query = "SELECT o FROM OverdueLoansByNumber o WHERE o.numberPar60 = :numberPar60"),
    @NamedQuery(name = "OverdueLoansByNumber.findByNumberPar90", query = "SELECT o FROM OverdueLoansByNumber o WHERE o.numberPar90 = :numberPar90"),
    @NamedQuery(name = "OverdueLoansByNumber.findByNumberOnDefaulted", query = "SELECT o FROM OverdueLoansByNumber o WHERE o.numberOnDefaulted = :numberOnDefaulted"),
    @NamedQuery(name = "OverdueLoansByNumber.findByNumberOnReposessed", query = "SELECT o FROM OverdueLoansByNumber o WHERE o.numberOnReposessed = :numberOnReposessed"),
    @NamedQuery(name = "OverdueLoansByNumber.findByNumberWithinPaidUp", query = "SELECT o FROM OverdueLoansByNumber o WHERE o.numberWithinPaidUp = :numberWithinPaidUp"),
    @NamedQuery(name = "OverdueLoansByNumber.findByParByNumber", query = "SELECT o FROM OverdueLoansByNumber o WHERE o.parByNumber = :parByNumber"),
    @NamedQuery(name = "OverdueLoansByNumber.findByParDefaultedNumber", query = "SELECT o FROM OverdueLoansByNumber o WHERE o.parDefaultedNumber = :parDefaultedNumber"),
    @NamedQuery(name = "OverdueLoansByNumber.findByParReposessedNumber", query = "SELECT o FROM OverdueLoansByNumber o WHERE o.parReposessedNumber = :parReposessedNumber")})
@ApiModel
public class OverdueLoansByNumber implements Serializable {

    @Column(name = "Batch_id")
    private Integer batchid;
    @Size(max = 45)
    @Column(name = "month")
    private String month;
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idoverdue_loans_by_number")
    private Integer idoverdueLoansByNumber;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "number_par1")
    private Double numberPar1;
    @Column(name = "number_par30")
    private Double numberPar30;
    @Column(name = "number_par60")
    private Double numberPar60;
    @Column(name = "number_par90")
    private Double numberPar90;
    @Column(name = "number_on_defaulted")
    private Double numberOnDefaulted;
    @Column(name = "number_on_reposessed")
    private Double numberOnReposessed;
    @Column(name = "number_within_paid_up")
    private Double numberWithinPaidUp;
    @Column(name = "par_by_number")
    private Double parByNumber;
    @Column(name = "par_defaulted_number")
    private Double parDefaultedNumber;
    @Column(name = "par_reposessed_number")
    private Double parReposessedNumber;

    public OverdueLoansByNumber() {
    }

    public OverdueLoansByNumber(Integer idoverdueLoansByNumber) {
        this.idoverdueLoansByNumber = idoverdueLoansByNumber;
    }

    public Integer getIdoverdueLoansByNumber() {
        return idoverdueLoansByNumber;
    }

    public void setIdoverdueLoansByNumber(Integer idoverdueLoansByNumber) {
        this.idoverdueLoansByNumber = idoverdueLoansByNumber;
    }

    public Double getNumberPar1() {
        return numberPar1;
    }

    public void setNumberPar1(Double numberPar1) {
        this.numberPar1 = numberPar1;
    }

    public Double getNumberPar30() {
        return numberPar30;
    }

    public void setNumberPar30(Double numberPar30) {
        this.numberPar30 = numberPar30;
    }

    public Double getNumberPar60() {
        return numberPar60;
    }

    public void setNumberPar60(Double numberPar60) {
        this.numberPar60 = numberPar60;
    }

    public Double getNumberPar90() {
        return numberPar90;
    }

    public void setNumberPar90(Double numberPar90) {
        this.numberPar90 = numberPar90;
    }

    public Double getNumberOnDefaulted() {
        return numberOnDefaulted;
    }

    public void setNumberOnDefaulted(Double numberOnDefaulted) {
        this.numberOnDefaulted = numberOnDefaulted;
    }

    public Double getNumberOnReposessed() {
        return numberOnReposessed;
    }

    public void setNumberOnReposessed(Double numberOnReposessed) {
        this.numberOnReposessed = numberOnReposessed;
    }

    public Double getNumberWithinPaidUp() {
        return numberWithinPaidUp;
    }

    public void setNumberWithinPaidUp(Double numberWithinPaidUp) {
        this.numberWithinPaidUp = numberWithinPaidUp;
    }

    public Double getParByNumber() {
        return parByNumber;
    }

    public void setParByNumber(Double parByNumber) {
        this.parByNumber = parByNumber;
    }

    public Double getParDefaultedNumber() {
        return parDefaultedNumber;
    }

    public void setParDefaultedNumber(Double parDefaultedNumber) {
        this.parDefaultedNumber = parDefaultedNumber;
    }

    public Double getParReposessedNumber() {
        return parReposessedNumber;
    }

    public void setParReposessedNumber(Double parReposessedNumber) {
        this.parReposessedNumber = parReposessedNumber;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idoverdueLoansByNumber != null ? idoverdueLoansByNumber.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof OverdueLoansByNumber)) {
            return false;
        }
        OverdueLoansByNumber other = (OverdueLoansByNumber) object;
        if ((this.idoverdueLoansByNumber == null && other.idoverdueLoansByNumber != null) || (this.idoverdueLoansByNumber != null && !this.idoverdueLoansByNumber.equals(other.idoverdueLoansByNumber))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.OverdueLoansByNumber[ idoverdueLoansByNumber=" + idoverdueLoansByNumber + " ]";
    }

    public Integer getBatchid() {
        return batchid;
    }

    public void setBatchid(Integer batchid) {
        this.batchid = batchid;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

}
