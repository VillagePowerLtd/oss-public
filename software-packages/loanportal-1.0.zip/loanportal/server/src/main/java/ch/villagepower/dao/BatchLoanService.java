/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;


import ch.villagepower.entities.Batch;
import ch.villagepower.entities.BatchhasLoan;
import ch.villagepower.entities.BatchhasLoanPK;
import ch.villagepower.entities.Loan;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.apache.log4j.Logger;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Stateless
public class BatchLoanService {

    @PersistenceContext
    private EntityManager em;

    final Logger log = Logger.getLogger(BatchLoanService.class.getName());

    //return batch byt id
    public BatchhasLoan batchLoanById(BatchhasLoanPK id) {

        BatchhasLoan bhl = em.find(BatchhasLoan.class, id);

        return bhl;
    }

    //return batch by batch
    public List<BatchhasLoan> batchLoanByBatch(Batch id) {

        Query query = em.createQuery("SELECT s FROM BatchhasLoan s WHERE s.batch = :a");
        query.setParameter("a", id);

        return query.getResultList();
    }

    public List<BatchhasLoan> batchLoanByLoan(Loan id) {

        Query query = em.createQuery("SELECT s FROM BatchhasLoan s WHERE s.loan = :a");
        query.setParameter("a", id);

        return query.getResultList();
    }

    public List<BatchhasLoan> batchOfLoan(Loan id) {

        Query query = em.createQuery("SELECT s.batch FROM BatchhasLoan s WHERE s.loan = :a");
        query.setParameter("a", id);

        return query.getResultList();
    }

    public List<BatchhasLoan> deleteLaonBatch(Loan id, Batch b) {

        Query query = em.createQuery("SELECT s.batch FROM BatchhasLoan s WHERE s.loan = :a AND s.batch = :b");
        query.setParameter("a", id);
        query.setParameter("b", b);

        return query.getResultList();
    }

}
