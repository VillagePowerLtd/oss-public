/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import io.swagger.annotations.ApiModel;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Entity
@Table(name = "batch_analysis")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "BatchAnalysis.findAll", query = "SELECT b FROM BatchAnalysis b"),
    @NamedQuery(name = "BatchAnalysis.findByIdbatchAnalysis", query = "SELECT b FROM BatchAnalysis b WHERE b.idbatchAnalysis = :idbatchAnalysis"),
    @NamedQuery(name = "BatchAnalysis.findByAnalysisDays", query = "SELECT b FROM BatchAnalysis b WHERE b.analysisDays = :analysisDays"),
    @NamedQuery(name = "BatchAnalysis.findByDisplayType", query = "SELECT b FROM BatchAnalysis b WHERE b.displayType = :displayType")})
@ApiModel
public class BatchAnalysis implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idbatch_analysis")
    private Integer idbatchAnalysis;
    @Column(name = "analysis_days")
    private Integer analysisDays;
    @Size(max = 6)
    @Column(name = "display_type")
    private String displayType;
    @JoinColumn(name = "Batch_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Batch batchid;

    public BatchAnalysis() {
    }

    public BatchAnalysis(Integer idbatchAnalysis) {
        this.idbatchAnalysis = idbatchAnalysis;
    }

    public Integer getIdbatchAnalysis() {
        return idbatchAnalysis;
    }

    public void setIdbatchAnalysis(Integer idbatchAnalysis) {
        this.idbatchAnalysis = idbatchAnalysis;
    }

    public Integer getAnalysisDays() {
        return analysisDays;
    }

    public void setAnalysisDays(Integer analysisDays) {
        this.analysisDays = analysisDays;
    }

    public String getDisplayType() {
        return displayType;
    }

    public void setDisplayType(String displayType) {
        this.displayType = displayType;
    }

    public Batch getBatchid() {
        return batchid;
    }

    public void setBatchid(Batch batchid) {
        this.batchid = batchid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idbatchAnalysis != null ? idbatchAnalysis.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof BatchAnalysis)) {
            return false;
        }
        BatchAnalysis other = (BatchAnalysis) object;
        if ((this.idbatchAnalysis == null && other.idbatchAnalysis != null) || (this.idbatchAnalysis != null && !this.idbatchAnalysis.equals(other.idbatchAnalysis))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.BatchAnalysis[ idbatchAnalysis=" + idbatchAnalysis + " ]";
    }

}
