/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
import ch.villagepower.entities.Batch;
import java.util.List;
import ch.villagepower.entities.Portfolio;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class PortfolioService {

    @PersistenceContext
    private EntityManager em;

    public List<Portfolio> findAll() {

        List<Portfolio> portfolios;

        Query q = em.createQuery("from Portfolio", Portfolio.class);

        portfolios = q.getResultList();

        return portfolios;

    }

    public List<Batch> findBatchPortfolio(Portfolio x) {

        List<Batch> batches;

        Query q = em.createQuery("SELECT p FROM Batch p WHERE p.portfolioid = :a");
        batches = q.setParameter("a", x).getResultList();

        return batches;

    }

    //return portfolio byt id
    public Portfolio portfolioById(Integer id) {

        Portfolio port = em.find(Portfolio.class, id);

        return port;
    }

}
