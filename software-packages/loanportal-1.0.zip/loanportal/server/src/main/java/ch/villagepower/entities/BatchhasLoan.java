/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import io.swagger.annotations.ApiModel;
import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Entity
@Table(name = "Batch_has_Loan")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "BatchhasLoan.findAll", query = "SELECT b FROM BatchhasLoan b"),
    @NamedQuery(name = "BatchhasLoan.findByBatchid", query = "SELECT b FROM BatchhasLoan b WHERE b.batchhasLoanPK.batchid = :batchid"),
    @NamedQuery(name = "BatchhasLoan.findByBatchPortfolioid", query = "SELECT b FROM BatchhasLoan b WHERE b.batchhasLoanPK.batchPortfolioid = :batchPortfolioid"),
    @NamedQuery(name = "BatchhasLoan.findByLoanid", query = "SELECT b FROM BatchhasLoan b WHERE b.batchhasLoanPK.loanid = :loanid")})
@ApiModel
public class BatchhasLoan implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected BatchhasLoanPK batchhasLoanPK;
    @JoinColumn(name = "Loan_id", referencedColumnName = "id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Loan loan;
    @JoinColumn(name = "Batch_id", referencedColumnName = "id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Batch batch;

    public BatchhasLoan() {
    }

    public BatchhasLoan(BatchhasLoanPK batchhasLoanPK) {
        this.batchhasLoanPK = batchhasLoanPK;
    }

    public BatchhasLoan(int batchid, int batchPortfolioid, int loanid) {
        this.batchhasLoanPK = new BatchhasLoanPK(batchid, batchPortfolioid, loanid);
    }

    public BatchhasLoanPK getBatchhasLoanPK() {
        return batchhasLoanPK;
    }

    public void setBatchhasLoanPK(BatchhasLoanPK batchhasLoanPK) {
        this.batchhasLoanPK = batchhasLoanPK;
    }

    public Loan getLoan() {
        return loan;
    }

    public void setLoan(Loan loan) {
        this.loan = loan;
    }

    public Batch getBatch() {
        return batch;
    }

    public void setBatch(Batch batch) {
        this.batch = batch;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (batchhasLoanPK != null ? batchhasLoanPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof BatchhasLoan)) {
            return false;
        }
        BatchhasLoan other = (BatchhasLoan) object;
        if ((this.batchhasLoanPK == null && other.batchhasLoanPK != null) || (this.batchhasLoanPK != null && !this.batchhasLoanPK.equals(other.batchhasLoanPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.BatchhasLoan[ batchhasLoanPK=" + batchhasLoanPK + " ]";
    }

}
