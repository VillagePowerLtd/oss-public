/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;


/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
import java.util.List;
import ch.villagepower.entities.Loan;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import org.joda.time.DateTime;

@Stateless
public class LoanService {

    @PersistenceContext
    private EntityManager em;

    public List<Loan> searchLoan(Date startDate, Date endDate, String std, String std1, String std2, String std3) {
        List<Loan> searchLoans = em.createQuery("SELECT g FROM Loan g WHERE  g.salesAgent = :std AND g.distributionAgent = :std1 AND g.store LIKE :std2 AND g.installationAddress = :std3 AND g.downPaymentDate BETWEEN :startDate AND :endDate")
                // List<Loan> searchLoans = em.createNativeQuery("SELECT * FROM Loan g WHERE g.sales_agent = :std AND g.distribution_agent = :std1 AND g.store = :std2 AND g.installation_address = :std3 AND g.down_payment_date BETWEEN :startDate AND :endDate",Loan.class)
                .setParameter("startDate", startDate, TemporalType.DATE)
                .setParameter("endDate", endDate, TemporalType.DATE)
                .setParameter("std", std)
                .setParameter("std1", std1)
                .setParameter("std2", std2)
                .setParameter("std3", std3)
                .getResultList();
        System.out.println("date1: " + startDate + " date2: " + endDate);

        return searchLoans;

    }

    public List<Loan> searchLoanS(String std, String std1) {

        List<Loan> searchLoans = em.createQuery("SELECT g FROM Loan g WHERE  g.distributionAgent = :std1 AND g.store LIKE :std")
                .setParameter("std", std)
                .setParameter("std1", std1)
                .getResultList();

        return searchLoans;

    }

    public List<Loan> searchLoanP(String std, String std1) {

        List<Loan> searchLoans = em.createQuery("SELECT g FROM Loan g WHERE g.installationAddress = :std AND g.store LIKE :std1")
                .setParameter("std", std)
                .setParameter("std1", std1)
                .getResultList();

        return searchLoans;

    }

    public List<Loan> searchSalesAgent(String std) {

        List<String> locationList = Arrays.asList(std.split(","));
        List<Loan> searchLoans = new ArrayList<>();

        for (String s : locationList) {

            List<Loan> resultLoans = em.createQuery("SELECT g FROM Loan g WHERE g.salesAgent = :std")
                    .setParameter("std", s)
                    .getResultList();
            searchLoans.addAll(resultLoans);
        }

        return searchLoans;

    }

    public List<Loan> searchStore(String std) {

        List<String> locationList = Arrays.asList(std.split(","));
        List<Loan> searchLoans = new ArrayList<>();

        for (String s : locationList) {

            List<Loan> resultLoans = em.createQuery("SELECT g FROM Loan g WHERE g.store LIKE :std")
                    .setParameter("std", s)
                    .getResultList();

            searchLoans.addAll(resultLoans);
        }
        return searchLoans;

    }

    public List<Loan> searchInstallation(String std) {

        List<String> locationList = Arrays.asList(std.split(","));
        List<Loan> searchLoans = new ArrayList<>();

        for (String s : locationList) {

            List<Loan> resultLoans = em.createQuery("SELECT g FROM Loan g WHERE g.installationAddress = :std")
                    .setParameter("std", s)
                    .getResultList();

            searchLoans.addAll(resultLoans);
        }

        return searchLoans;

    }

    public List<Loan> searchRange(String one, String two) {

        List<Loan> searchLoans = em.createQuery("SELECT g FROM Loan g WHERE g.id >= :one1 AND g.id <= :two2")
                .setParameter("one1", Integer.valueOf(one))
                .setParameter("two2", Integer.valueOf(two))
                .getResultList();

        return searchLoans;

    }

    public List<Loan> searchDistribution(String std) {

        List<String> locationList = Arrays.asList(std.split(","));
        List<Loan> searchLoans = new ArrayList<>();

        for (String s : locationList) {

            List<Loan> resultLoans = em.createQuery("SELECT g FROM Loan g WHERE g.distributionAgent = :std")
                    .setParameter("std", s)
                    .getResultList();

            searchLoans.addAll(resultLoans);
        }

        return searchLoans;

    }

    public List<Loan> searchDate(Date startDate, Date endDate) {

        List<Loan> searchLoans = em.createQuery("SELECT g FROM Loan g WHERE  g.downPaymentDate BETWEEN :startDate AND :endDate")
                .setParameter("startDate", startDate, TemporalType.DATE)
                .setParameter("endDate", endDate, TemporalType.DATE)
                .getResultList();

        return searchLoans;

    }

    public List<Loan> searchLoanW(Date startDate, Date endDate, String std, String std1, String std2) {

        List<Loan> searchLoans = em.createQuery("SELECT g FROM Loan g WHERE  g.salesAgent = :std AND g.store LIKE :std2 AND g.installationAddress = :std1 AND g.downPaymentDate BETWEEN :startDate AND :endDate")
                .setParameter("startDate", startDate, TemporalType.DATE)
                .setParameter("endDate", endDate, TemporalType.DATE)
                .setParameter("std", std)
                .setParameter("std1", std1)
                .setParameter("std2", std2)
                .getResultList();

        return searchLoans;

    }

    public List<Loan> searchLoanP(Date startDate, Date endDate, String std) {

        List<Loan> searchLoans = em.createQuery("SELECT g FROM Loan g WHERE  g.installationAddress = :std AND g.downPaymentDate BETWEEN :startDate AND :endDate")
                .setParameter("startDate", startDate, TemporalType.DATE)
                .setParameter("endDate", endDate, TemporalType.DATE)
                .setParameter("std", std)
                .getResultList();

        return searchLoans;

    }

    public List<Loan> searchLoanQ(Date startDate, Date endDate, String std) {

        List<Loan> searchLoans = em.createQuery("SELECT g FROM Loan g WHERE  g.salesAgent = :std AND g.downPaymentDate BETWEEN :startDate AND :endDate")
                .setParameter("startDate", startDate, TemporalType.DATE)
                .setParameter("endDate", endDate, TemporalType.DATE)
                .setParameter("std", std)
                .getResultList();

        return searchLoans;

    }

    public List<Loan> searchLoanL(Date startDate, Date endDate, String std) {

        List<Loan> searchLoans = em.createQuery("SELECT g FROM Loan g WHERE  g.store LIKE :std AND g.downPaymentDate BETWEEN :startDate AND :endDate")
                .setParameter("startDate", startDate, TemporalType.DATE)
                .setParameter("endDate", endDate, TemporalType.DATE)
                .setParameter("std", std)
                .getResultList();

        return searchLoans;

    }

    public List<Loan> searchLoanD(Date startDate, Date endDate, String std, String std1, String std2) {

        List<Loan> searchLoans = em.createQuery("SELECT g FROM Loan g WHERE  g.salesAgent = :std AND g.distributionAgent = :std1 AND g.store = :std2 AND g.downPaymentDate BETWEEN :startDate AND :endDate")
                .setParameter("startDate", startDate, TemporalType.DATE)
                .setParameter("endDate", endDate, TemporalType.DATE)
                .setParameter("std", std)
                .setParameter("std1", std1)
                .setParameter("std2", std2)
                .getResultList();

        return searchLoans;

    }

    public List<Loan> searchLoanN(Date startDate, Date endDate, String std, String std1, String std2) {

        List<Loan> searchLoans = em.createQuery("SELECT g FROM Loan g WHERE  g.salesAgent = :std AND g.distributionAgent = :std1 AND g.installationAddress = :std2 AND g.downPaymentDate BETWEEN :startDate AND :endDate")
                .setParameter("startDate", startDate, TemporalType.DATE)
                .setParameter("endDate", endDate, TemporalType.DATE)
                .setParameter("std", std)
                .setParameter("std1", std1)
                .setParameter("std2", std2)
                .getResultList();

        return searchLoans;

    }

    public List<Loan> searchLoanInstallationDate(Date startDate, String std) {

        List<Loan> searchLoans = em.createQuery("SELECT g FROM Loan g WHERE  g.installationAddress = :std AND g.downPaymentDate = :startDate")
                .setParameter("startDate", startDate, TemporalType.DATE)
                .setParameter("std", std)
                .getResultList();

        return searchLoans;

    }

    public List<Loan> searchLoanK(String std, String std1, String std2, String std3) {

        List<Loan> searchLoans = em.createQuery("SELECT g FROM Loan g WHERE g.installationAddress = :std AND g.salesAgent = :std1 AND g.distributionAgent = :std3 AND g.store LIKE :std2")
                .setParameter("std", std)
                .setParameter("std1", std1)
                .setParameter("std3", std3)
                .setParameter("std2", std2)
                .getResultList();

        return searchLoans;

    }

    public List<Loan> findAll() {

        List<Loan> loans;
        Query q = em.createQuery("from Loan", Loan.class);

        loans = q.getResultList();

        return loans;

    }

    public List<Loan> findAllAscendingLimit() {

        List<Loan> loans;

        Query q = em.createQuery("SELECT l FROM Loan l ORDER BY l.id ASC").setMaxResults(6);

        loans = q.getResultList();

        return loans;

    }

    public List<Loan> findAllWithVersion() {

        List<Loan> loans;

        Query q = em.createQuery("SELECT l FROM Loan l WHERE l.version != :std")
                .setParameter("std", "NULL");

        loans = q.getResultList();

        return loans;

    }

    public List<Loan> findAllWithLimit(int x) {

        List<Loan> loans;

        Query q = em.createQuery("from Loan", Loan.class).setMaxResults(x);

        loans = q.getResultList();

        return loans;

    }

    public List<Loan> findAllWithDay(int x, int y) {

        Query query = em.createQuery("SELECT l FROM Loan l WHERE l.day >= :a AND l.day< :b");
        query.setParameter("a", x);
        query.setParameter("b", y);

        return query.getResultList();

    }
    
    
    public List<Loan> findOldLoansByDate(DateTime date) {

        Query query = em.createQuery("SELECT l FROM Loan l WHERE l.uploadDate < :a");
        query.setParameter("a", date.toDate());
        

        return query.getResultList();

    }

    public List<Loan> findAllWithOneDay(int x) {

        Query query = em.createQuery("SELECT l FROM Loan l WHERE l.day = :a");
        query.setParameter("a", x);

        return query.getResultList();

    }

    //return loan byt id
    public Loan loanById(Integer id) {

        Loan loan = em.find(Loan.class, id);

        return loan;
    }

}
