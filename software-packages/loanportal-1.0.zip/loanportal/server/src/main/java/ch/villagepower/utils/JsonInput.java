/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.utils;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
import ch.villagepower.entities.Batch;
import ch.villagepower.entities.BatchAnalysis;
import ch.villagepower.entities.BatchProjectedCurve;
import ch.villagepower.entities.BatchhasLoan;
import ch.villagepower.entities.Deposit;
import ch.villagepower.entities.Loan;
import ch.villagepower.entities.Payments;
import ch.villagepower.entities.Portfolio;
import ch.villagepower.entities.UserBatch;
import ch.villagepower.entities.UserGraph;
import ch.villagepower.entities.Users;
import java.util.List;

public class JsonInput {

    public Portfolio portfolio;
    public Batch batch;
    public Loan loan;

    public String batchId;
    public String loanId;

    public String username;
    public String password;
    public boolean rememberMe;

    public List<BatchhasLoan> batchLoans;

    public Users users;
    public List<UserBatch> userBatches;
    public List<UserGraph> userGraphs;
    public String hash;

    public List<Payments> payments;

    public Deposit deposit;
    public BatchAnalysis batchAnalysis;
    public BatchProjectedCurve batchProjectedCurve;

    public String rangeOne = "";
    public String rangeTwo = "";
    
    public String display="monthly";

}
