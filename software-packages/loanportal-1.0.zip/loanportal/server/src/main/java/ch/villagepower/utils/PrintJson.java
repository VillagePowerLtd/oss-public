/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.utils;


import ch.villagepower.dao.BatchLoanService;
import ch.villagepower.dao.DepositService;
import ch.villagepower.dao.LoanService;
import ch.villagepower.dao.SaveService;
import static ch.villagepower.utils.Globals.setGlobals;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;
import java.util.Date;
import java.util.Properties;
import java.util.Random;
import javax.ejb.EJB;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
public class PrintJson {

    final static Logger log = Logger.getLogger(PrintJson.class.getName());

    private static JsonReply reply;

    @EJB
    private static SaveService save = new SaveService();

    @EJB
    private static LoanService loanService = new LoanService();
    @EJB
    private static DepositService depositService = new DepositService();

    @EJB
    private BatchLoanService bhlService = new BatchLoanService();

    private static final char[] symbols;
    //private static final Gson gson = new Gson();

    static {
        StringBuilder tmp = new StringBuilder();
        for (char ch = '0'; ch <= '9'; ++ch) {
            tmp.append(ch);
        }
        for (char ch = 'a'; ch <= 'z'; ++ch) {
            tmp.append(ch);
        }
        symbols = tmp.toString().toCharArray();
    }

    private static final Random random = new Random();

    public static String prepareRandomString(int len) {
        char[] buf = new char[len];
        for (int idx = 0; idx < buf.length; ++idx) {
            buf[idx] = symbols[random.nextInt(symbols.length)];
        }
        return new String(buf);
    }

    public static void sendEmailRegistrationLink(String id, String email, String hash, String firstname) throws AddressException, MessagingException {

        final Properties prop = setGlobals();

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", prop.getProperty("MAIL_SMTP_HOST"));
        props.put("mail.smtp.port", prop.getProperty("MAIL_SMTP_PORT"));

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(prop.getProperty("MAIL_USERNAME"), prop.getProperty("MAIL_PASSWORD"));
            }
        });

        String link = prop.getProperty("MAIL_REGISTRATION_SITE_LINK") + "?userId=" + id + "&hash=" + hash + "&email=" + email;

        StringBuilder bodyText = new StringBuilder();
        bodyText.append("<div>")
                .append("  Dear " + firstname + "<br/><br/>")
                .append("  You have been registered with Village Power Loan Portal.<br/><br/> Your username is your email address (" + email + ").<br/><br/>")
                .append("  To complete setting up your secure account, please follow the following link to set up and confirm a new password for your account<br/>")
                .append("  <a href=\"" + link + "\">" + link + "</a>")
                .append("  <br/><br/>")
                .append("  Thanks,<br/>")
                .append("  The Loan Portal Team")
                .append("</div>");
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(prop.getProperty("MAIL_USERNAME")));
        message.setRecipients(Message.RecipientType.TO,
                InternetAddress.parse(email));
        message.setSubject("Email Registration- Village Power");
        message.setContent(bodyText.toString(), "text/html; charset=utf-8");
        Transport.send(message);
    }

    public static void sendEmailBatchGraphAssigned(String batch, String graph, String userEmail, String firstname, String adminEmail) throws AddressException, MessagingException {

        final Properties prop = setGlobals();

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", prop.getProperty("MAIL_SMTP_HOST"));
        props.put("mail.smtp.port", prop.getProperty("MAIL_SMTP_PORT"));

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(prop.getProperty("MAIL_USERNAME"), prop.getProperty("MAIL_PASSWORD"));
            }
        });

        StringBuilder bodyText = new StringBuilder();

        if (batch.length() > 0) {

            bodyText.append("<div>")
                    .append("  Dear " + firstname + "<br/><br/>")
                    .append("  The Loan Portal user " + userEmail + " is now able to view the batch " + batch + " on the Loan Portal.<br/><br/>")
                    .append("  <br/><br/>")
                    .append("  Thanks,<br/>")
                    .append("  The Loan Portal Team")
                    .append("</div>");
        } else {
            bodyText.append("<div>")
                    .append("  Dear " + firstname + "<br/><br/>")
                    .append("  The Loan Portal user " + userEmail + " is now able to view the chart " + graph + " on the Loan Portal.<br/><br/>")
                    .append("  <br/><br/>")
                    .append("  Thanks,<br/>")
                    .append("  The Loan Portal Team")
                    .append("</div>");

        }
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(prop.getProperty("MAIL_USERNAME")));
        message.setRecipients(Message.RecipientType.TO,
                InternetAddress.parse(adminEmail));
        message.setSubject("Email Registration- Village Power");
        message.setContent(bodyText.toString(), "text/html; charset=utf-8");
        Transport.send(message);
    }

    public static void sendEmailForgotPasswordLink(String id, String email, String hash, String firstname) throws AddressException, MessagingException {

        final Properties prop = Globals.setGlobals();

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", prop.getProperty("MAIL_SMTP_HOST"));
        props.put("mail.smtp.port", prop.getProperty("MAIL_SMTP_PORT"));

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(prop.getProperty("MAIL_USERNAME"), prop.getProperty("MAIL_PASSWORD"));
            }
        });

        String link = prop.getProperty("MAIL_REGISTRATION_SITE_LINK") + "?userId=" + id + "&hash=" + hash + "&email=" + email;

        StringBuilder bodyText = new StringBuilder();
        bodyText.append("<div>")
                .append("  Dear " + firstname + "<br/><br/>")
                .append("  You have requested to reset your password with Village Power Loan Portal.<br/><br/> Your username is your email address (" + email + ").<br/><br/>")
                .append("  To complete resetting your password, kindly follow the following link<br/>")
                .append("  <a href=\"" + link + "\">" + link + "</a>")
                .append("  <br/><br/>")
                .append("  Thanks,<br/>")
                .append("  The Loan Portal Team")
                .append("</div>");
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(prop.getProperty("MAIL_USERNAME")));
        message.setRecipients(Message.RecipientType.TO,
                InternetAddress.parse(email));
        message.setSubject("Email Registration- Village Power");
        message.setContent(bodyText.toString(), "text/html; charset=utf-8");
        Transport.send(message);
    }

    public static String printJ(String json) {

        String prettyJson = new GsonBuilder().setPrettyPrinting().create().toJson(new JsonParser().parse(json));
        log.info(prettyJson);

        return prettyJson;

    }

    public static Date timeZoneKla() {
        DateTimeZone timeZoneKla = DateTimeZone.forID("Africa/Kampala");
        DateTime nowKla = DateTime.now(timeZoneKla);

        return nowKla.toLocalDateTime().toDate();

    }

    public static org.joda.time.DateTime timeZoneDateTimeKla() {
        DateTimeZone timeZoneKla = DateTimeZone.forID("Africa/Kampala");
        DateTime nowKla = DateTime.now(timeZoneKla);

        return new DateTime(nowKla);

    }

}
