/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;


import ch.villagepower.entities.LoanPerformance;
import ch.villagepower.entities.NumberofLoans;
import ch.villagepower.entities.OverdueLoansByNumber;
import ch.villagepower.entities.OverdueLoansByValue;
import ch.villagepower.entities.PaymentStatus;
import ch.villagepower.entities.RestructuredLoans;
import java.util.Calendar;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Stateless
public class ChartService {

    @PersistenceContext
    private EntityManager em;

    public List<NumberofLoans> getBatchNumberOfLoans(Integer id) {

        Query query = em.createQuery("SELECT s FROM NumberofLoans s WHERE s.batchid = :a ORDER BY s.idNumberofLoans ASC");
        query.setParameter("a", id);

        return query.getResultList();
    }

    public List<OverdueLoansByNumber> getBatchOverdueLoansByNumber(Integer id) {

        Query query = em.createQuery("SELECT s FROM OverdueLoansByNumber s WHERE s.batchid = :a ORDER BY s.idoverdueLoansByNumber ASC").setMaxResults(200);
        query.setParameter("a", id);

        return query.getResultList();
    }

    public List<OverdueLoansByValue> getBatchOverdueLoansByValue(Integer id) {

        Query query = em.createQuery("SELECT s FROM OverdueLoansByValue s WHERE s.batchid = :a ORDER BY s.idoverdueLoansByValue ASC").setMaxResults(200);
        query.setParameter("a", id);

        return query.getResultList();
    }

    public List<PaymentStatus> getBatchPaymentStatus(Integer id) {

        Query query = em.createQuery("SELECT s FROM PaymentStatus s WHERE s.batchid = :a ORDER BY s.idPaymentStatus ASC").setMaxResults(200);
        query.setParameter("a", id);

        return query.getResultList();
    }

    public List<RestructuredLoans> getBatchRestructuredLoans(Integer id) {

        Query query = em.createQuery("SELECT s FROM RestructuredLoans s WHERE s.batchid = :a ORDER BY s.id ASC").setMaxResults(200);
        query.setParameter("a", id);

        return query.getResultList();
    }

    public List<NumberofLoans> getBatchNumberMonth(String id, int batch) {

        Query query = em.createQuery("SELECT s FROM NumberofLoans s WHERE s.month = :a AND s.batchid=:b");
        query.setParameter("a", id);
        query.setParameter("b", batch);

        return query.getResultList();
    }

    public List<RestructuredLoans> getBatchRestrucredMonth(String id, int batch) {

        Query query = em.createQuery("SELECT s FROM RestructuredLoans s WHERE s.month = :a AND s.batchid=:b");
        query.setParameter("a", id);
        query.setParameter("b", batch);

        return query.getResultList();
    }

    public List<PaymentStatus> getBatchPaymentStatusMonth(String id, int batch) {

        Query query = em.createQuery("SELECT s FROM PaymentStatus s WHERE s.month = :a AND s.batchid=:b");
        query.setParameter("a", id);
        query.setParameter("b", batch);

        return query.getResultList();
    }

    public List<LoanPerformance> getBatchLoanPerformanceMonth(String id, int batch) {

        Query query = em.createQuery("SELECT s FROM LoanPerformance s WHERE s.month = :a AND s.batchid=:b");
        query.setParameter("a", id);
        query.setParameter("b", batch);

        return query.getResultList();
    }

    public List<OverdueLoansByNumber> getBatchODNMonth(String id, int batch) {

        Query query = em.createQuery("SELECT s FROM OverdueLoansByNumber s WHERE s.month = :a AND s.batchid=:b");
        query.setParameter("a", id);
        query.setParameter("b", batch);

        return query.getResultList();
    }

    public List<OverdueLoansByValue> getBatchODVMonth(String id, int batch) {

        Query query = em.createQuery("SELECT s FROM OverdueLoansByValue s WHERE s.month = :a AND s.batchid=:b");
        query.setParameter("a", id);
        query.setParameter("b", batch);

        return query.getResultList();
    }

    public List<LoanPerformance> getBatchLoanPerformance(Integer id) {

        Query query = em.createQuery("SELECT s FROM LoanPerformance s WHERE s.batchid = :a ORDER BY s.idLoanPerformance ASC").setMaxResults(200);
        query.setParameter("a", id);

        return query.getResultList();
    }

    public List<LoanPerformance> getBatchLoanPerformanceCurrent(Integer id) {

        Calendar cal = Calendar.getInstance();
        String s = String.valueOf(cal.get(Calendar.MONTH) + 1);

        Query query = em.createQuery("SELECT s FROM LoanPerformance s WHERE s.batchid = :a AND s.month= :b ORDER BY s.idLoanPerformance DESC").setMaxResults(200);
        query.setParameter("a", id);
        query.setParameter("b", s);

        return query.getResultList();
    }

    public List<NumberofLoans> getBatchNumberOfLoansCurrentMonth(Integer id) {

        Calendar cal = Calendar.getInstance();
        String s = String.valueOf(cal.get(Calendar.MONTH) + 1);

        Query query = em.createQuery("SELECT s FROM NumberofLoans s WHERE s.batchid = :a AND s.month= :b ORDER BY s.idNumberofLoans DESC");
        query.setParameter("a", id);
        query.setParameter("b", s);

        return query.getResultList();
    }

    public List<PaymentStatus> getBatchRepaymentsCurrentMonth(Integer id) {

        Calendar cal = Calendar.getInstance();
        String s = String.valueOf(cal.get(Calendar.MONTH) + 1);

        Query query = em.createQuery("SELECT s FROM PaymentStatus s WHERE s.batchid = :a AND s.month= :b ORDER BY s.idPaymentStatus DESC");
        query.setParameter("a", id);
        query.setParameter("b", s);

        return query.getResultList();
    }

    public List<LoanPerformance> getBatchCollectionsOfLoansCurrentMonth(Integer id) {

        Calendar cal = Calendar.getInstance();
        String s = String.valueOf(cal.get(Calendar.MONTH) + 1);

        Query query = em.createQuery("SELECT s FROM LoanPerformance s WHERE s.batchid = :a AND s.month= :b ORDER BY s.idLoanPerformance DESC");
        query.setParameter("a", id);
        query.setParameter("b", s);

        return query.getResultList();
    }

    public List<OverdueLoansByValue> getBatchOverdueLoansByValueCurrent(Integer id) {

        Calendar cal = Calendar.getInstance();
        String s = String.valueOf(cal.get(Calendar.MONTH) + 1);

        Query query = em.createQuery("SELECT s FROM OverdueLoansByValue s WHERE s.batchid = :a AND s.month= :b ORDER BY s.idoverdueLoansByValue DESC").setMaxResults(200);
        query.setParameter("a", id);
        query.setParameter("b", s);

        return query.getResultList();
    }

    public List<OverdueLoansByNumber> getBatchOverdueLoansByNumberCurrent(Integer id) {

        Calendar cal = Calendar.getInstance();
        String s = String.valueOf(cal.get(Calendar.MONTH) + 1);

        Query query = em.createQuery("SELECT s FROM OverdueLoansByNumber s WHERE s.batchid = :a AND s.month= :b ORDER BY s.idoverdueLoansByNumber DESC").setMaxResults(200);
        query.setParameter("a", id);
        query.setParameter("b", s);

        return query.getResultList();
    }

}
