/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.filter;


import ch.villagepower.utils.JsonReply;
import java.io.IOException;
import java.security.Principal;
import javax.annotation.Priority;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.ext.Provider;
import org.apache.log4j.Logger;
import org.jose4j.jwk.RsaJsonWebKey;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.MalformedClaimException;
import org.jose4j.jwt.consumer.InvalidJwtException;
import org.jose4j.jwt.consumer.JwtConsumer;
import org.jose4j.jwt.consumer.JwtConsumerBuilder;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Secured
@Provider
@Priority(Priorities.AUTHENTICATION)
public class JWTAuthFilter implements ContainerRequestFilter {

    final static Logger log = Logger.getLogger(JWTAuthFilter.class.getName());

    JsonReply reply = new JsonReply("JWTAuthFilter");

    @Override
    public void filter(ContainerRequestContext requestContext/*,  ContainerResponseContext responseContext*/) throws IOException {

        String token = requestContext.getHeaderString("Authorization");

        //consume JWT i.e. execute signature validation
        if (token != null) {
            try {
                log.info("JWT based Auth in action... time to verify th signature");
                log.info("JWT being tested:\n" + token);
                final String subject = validate(token);

                System.out.println("======2" + subject);
                final SecurityContext securityContext = requestContext.getSecurityContext();
                if (!subject.isEmpty()) {
                    requestContext.setSecurityContext(new SecurityContext() {
                        @Override
                        public Principal getUserPrincipal() {
                            return new Principal() {
                                @Override
                                public String getName() {
                                    log.info("Returning custom Principal - " + subject);
                                    return subject;
                                }
                            };
                        }

                        @Override
                        public boolean isUserInRole(String role) {
                            return securityContext.isUserInRole(role);
                        }

                        @Override
                        public boolean isSecure() {
                            return securityContext.isSecure();
                        }

                        @Override
                        public String getAuthenticationScheme() {
                            return securityContext.getAuthenticationScheme();
                        }
                    });
                } else {
                    log.info("JWT unauthorised Token Malformed");
                    reply.setError("JWT unauthorised Token Malformed");

                    requestContext.setProperty("auth-failed", true);
                    requestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).entity(reply.toString()).build());

                }
            } catch (InvalidJwtException | MalformedClaimException ex) {
                log.info("JWT validation failed" + ex);
                reply.setError("unauthorised " + ex.toString());

                requestContext.setProperty("auth-failed", true);
                requestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).entity(reply.toString()).build());

            }

        } else {
            log.info("No JWT token !");
            reply.setError("No jwt token sent");
            requestContext.setProperty("auth-failed", true);
            requestContext.abortWith(Response.status(Response.Status.UNAUTHORIZED).entity(reply.toString()).build());
        }

    }

    private String validate(String jwt) throws InvalidJwtException, MalformedClaimException {
        String subject = "";
        RsaJsonWebKey rsaJsonWebKey = RsaKeyProducer.produce();

        log.info("RSA hash code... " + rsaJsonWebKey.hashCode());

        JwtConsumer jwtConsumer = new JwtConsumerBuilder()
                .setRequireSubject() // the JWT must have a subject claim
                .setVerificationKey(rsaJsonWebKey.getKey()) // verify the signature with the public key
                .build(); // create the JwtConsumer instance

        try {
            //  Validate the JWT and process it to the Claims
            JwtClaims jwtClaims = jwtConsumer.processToClaims(jwt);
            subject = (String) jwtClaims.getClaimValue("sub");
            log.info("JWT validation succeeded! " + jwtClaims.getSubject());
        } catch (InvalidJwtException | MalformedClaimException e) {
            log.info(e);
        }
        return subject;
    }

}
