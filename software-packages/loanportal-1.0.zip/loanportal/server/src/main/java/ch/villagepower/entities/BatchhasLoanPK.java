/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Embeddable
public class BatchhasLoanPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "Batch_id")
    private int batchid;
    @Basic(optional = false)
    @Column(name = "Batch_Portfolio_id")
    private int batchPortfolioid;
    @Basic(optional = false)
    @Column(name = "Loan_id")
    private int loanid;

    public BatchhasLoanPK() {
    }

    public BatchhasLoanPK(int batchid, int batchPortfolioid, int loanid) {
        this.batchid = batchid;
        this.batchPortfolioid = batchPortfolioid;
        this.loanid = loanid;
    }

    public int getBatchid() {
        return batchid;
    }

    public void setBatchid(int batchid) {
        this.batchid = batchid;
    }

    public int getBatchPortfolioid() {
        return batchPortfolioid;
    }

    public void setBatchPortfolioid(int batchPortfolioid) {
        this.batchPortfolioid = batchPortfolioid;
    }

    public int getLoanid() {
        return loanid;
    }

    public void setLoanid(int loanid) {
        this.loanid = loanid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) batchid;
        hash += (int) batchPortfolioid;
        hash += (int) loanid;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof BatchhasLoanPK)) {
            return false;
        }
        BatchhasLoanPK other = (BatchhasLoanPK) object;
        if (this.batchid != other.batchid) {
            return false;
        }
        if (this.batchPortfolioid != other.batchPortfolioid) {
            return false;
        }
        if (this.loanid != other.loanid) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.BatchhasLoanPK[ batchid=" + batchid + ", batchPortfolioid=" + batchPortfolioid + ", loanid=" + loanid + " ]";
    }

}
