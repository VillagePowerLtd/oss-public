/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.rest;


import au.com.bytecode.opencsv.CSVReader;
import ch.villagepower.dao.BatchAnalysisService;
import ch.villagepower.dao.BatchService;
import ch.villagepower.dao.DepositService;
import ch.villagepower.entities.Portfolio;
import ch.villagepower.dao.PortfolioService;
import ch.villagepower.dao.SaveService;
import ch.villagepower.dao.UserBatchService;
import ch.villagepower.entities.Batch;
import ch.villagepower.entities.BatchAnalysis;
import ch.villagepower.entities.BatchProjectedCurve;
import ch.villagepower.entities.Deposit;
import ch.villagepower.filter.Role;
import ch.villagepower.filter.Secured;
import static ch.villagepower.rest.LoanResource.log;
import ch.villagepower.utils.JsonInput;
import ch.villagepower.utils.PrintJson;
import ch.villagepower.utils.JsonReply;
import com.google.gson.Gson;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import org.apache.log4j.Logger;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Path("portfolio")
@Api(value = "portfolio", description = "Endpoint for Loan & batch extended operations")
public class PortfolioResource {

    final static Logger log = Logger.getLogger(PortfolioResource.class.getName());

    @Context
    private UriInfo context;

    @EJB
    PortfolioService portfolioService = new PortfolioService();

    @EJB
    DepositService depositService = new DepositService();

    @EJB
    SaveService save = new SaveService();

    @EJB
    BatchService batchService = new BatchService();

    @EJB
    UserBatchService ubService = new UserBatchService();

    @EJB
    BatchAnalysisService baService = new BatchAnalysisService();

    Gson gson;
    JsonReply reply;
    JsonInput input;

    //**************endpoint for all portfolioes*****************
    @GET
    @Path("allPortfolioes")
    @Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    public String findAll() {

        reply = new JsonReply("getAllPortfolioes+findAll");

        gson = new Gson();

        List<Portfolio> portfolios = portfolioService.findAll();
        log.info("REEEEEEEEEEESSSSSSSTT");

        for (Portfolio o : portfolios) {

            log.info("-" + o.getName() + " " + o.getId());

        }
        reply.portfolios = portfolios;
        reply.setSucc("got " + portfolios.size());

        return reply.toString();
    }

    // ++++++++++++++++++++++++: CREATE PORTFOLIO :+++++++++++++++++++++++++++++++
    @POST
    @ApiOperation(value = "Creates portfolio")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Secured({Role.administrator})
    @Path("createPortfolio")
    public String receivePortfolio(@Context Request req, String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("receivePortfolio");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.portfolio != null) {

                if (input.portfolio.getName() == null) {
                    log.info("Portfolio should have a name");
                    reply.setError("Send Portfolio name");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    Portfolio portfolio = new Portfolio();
                    portfolio.setName(input.portfolio.getName());
                    portfolio.setDescription(input.portfolio.getDescription());
                    portfolio.setDateCreated(PrintJson.timeZoneKla());
                    portfolio.setLastUpdated(PrintJson.timeZoneKla());
                    save.saveObject(portfolio);

                    reply.portfolios = portfolioService.findAll();
                    reply.setSucc("Portfolio created");

                }

            } else {
                log.info("Please Send some JSON or Send Portfolio object");
                reply.setError("Please Send some JSON or Send Portfolio object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: CREATE BatchAnalysis :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Secured({Role.administrator})
    @Path("addBatchAnalysis")
    @ApiOperation(value = "Batch detail Analysis", notes = "Add Batch detail Analysis info.", response = JsonReply.class)
    public String addBatchAnalysis(@Context Request req, @ApiParam(value = "JsonInput.batchAnalysis") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("addBatchAnalysis");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.batchAnalysis != null) {

                if (input.batchAnalysis.getBatchid() == null) {
                    log.info("BatchAnalysis should have a batch");
                    reply.setError("BatchAnalysis should have a batch");
                } else {

                    Batch b = batchService.batchById(input.batchAnalysis.getBatchid().getId());
                    if (b != null) {

                        List<BatchAnalysis> ba = baService.getBatchAnalysis(b);

                        if (ba.isEmpty()) {
                            BatchAnalysis newBA = new BatchAnalysis();
                            newBA.setAnalysisDays(input.batchAnalysis.getAnalysisDays());
                            newBA.setBatchid(input.batchAnalysis.getBatchid());
                            newBA.setDisplayType("days");

                            save.saveObject(newBA);

                            reply.batchAnalysises = baService.findAll();
                            reply.setSucc("BatchAnalysis created");
                        } else {
                            ba.get(0).setAnalysisDays(input.batchAnalysis.getAnalysisDays());
                            save.updateObject(ba.get(0));
                            reply.batchAnalysises = baService.findAll();
                            reply.setSucc("BatchAnalysis updated");
                        }
                    } else {

                        log.info("Batch does not exist");
                        reply.setError("Batch does not exist");
                    }

                }

            } else {
                log.info("Please Send some JSON or Send BatchAnalysis object");
                reply.setError("Please Send some JSON or Send BatchAnalysis object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    //**************endpoint for all BatchAnalysis*****************
    @GET
    @Path("allBatchAnalyses")
    @Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "All Batch analysis", notes = "Return all Batch Analysis.", response = JsonReply.class)
    public String findAllBatchAnalysis() {

        reply = new JsonReply("findAllBatchAnalysis");

        gson = new Gson();

        List<BatchAnalysis> bas = baService.findAll();

        if (!bas.isEmpty()) {
            reply.batchAnalysises = bas;
            reply.setSucc("got " + bas.size());
        } else {
            log.info("No existing Batch Analysis Info");
            reply.setError("No existing Batch Analysis Info");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: CREATE Batch Projected Curve data :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    //@Secured({Role.administrator})
    @Path("addBatchProjectedData")
    @ApiOperation(value = "Upload Batch Projected curve data", notes = "Upload Batch Projected curve data.", response = JsonReply.class)
    public String addBatchProjectedData(
            @ApiParam(value = "batch ID") @FormDataParam("batch") String batch,
            @ApiParam(value = "csv file with data") @FormDataParam("file") InputStream uploadedInputStream,
            @FormDataParam("file") FormDataContentDisposition fileDetail,
            @FormDataParam("file") FormDataBodyPart body) throws com.google.gson.JsonSyntaxException {

        //response
        reply = new JsonReply("addBatchProjectedData");

        try {

            String uploadedFileLocation = "/home/glassfish/projectedcurveuploads.csv";

            if (batch.length() > 0) {
                // save csv file
                saveToFile(uploadedInputStream, uploadedFileLocation);

                //create CSVReader object
                CSVReader reader = new CSVReader(new FileReader(uploadedFileLocation), ',', '\'', 1);

                List<BatchProjectedCurve> bpc = new ArrayList<>();
                //read all lines at once
                List<String[]> records = reader.readAll();
                reader.close();

                if (records.size() > 1) {

                    Iterator<String[]> iterator = records.iterator();
                    //skip header row

                    Batch b = batchService.batchById(Integer.valueOf(batch));
                    while (iterator.hasNext()) {
                        String[] record = iterator.next();

                        BatchProjectedCurve bp = new BatchProjectedCurve();

                        if (b != null) {
                            bp.setBatchid(b);
                            bp.setProjectedTime(Integer.valueOf(record[0]));
                            bp.setProjectedValue(Double.valueOf(record[1]));

                            bpc.add(bp);
                        }
                    }

                    List<BatchAnalysis> ba = baService.getBatchAnalysis(b);

                    if (!bpc.isEmpty()) {
                        int d = 0;
                        if (ba.get(0).getAnalysisDays() > 80 && ba.get(0).getAnalysisDays() < 540) {
                            for (int day = 0; day < (int) ba.get(0).getAnalysisDays() - 1; day += 7) {

                                List<BatchProjectedCurve> bppc = baService.getBatchValueTime(bpc.get(day).getBatchid(), day);
                                if (bppc.isEmpty()) {
                                    bpc.get(day).setProjectedTime(d);
                                    save.saveObject(bpc.get(day));
                                } else {
                                    bppc.get(0).setProjectedValue(bpc.get(day).getProjectedValue());
                                    bppc.get(0).setProjectedTime(d);
                                    save.updateObject(bppc.get(0));
                                }
                                d++;

                            }
                        } else if (ba.get(0).getAnalysisDays() > 540) {
                            for (int day = 0; day < ba.get(0).getAnalysisDays() - 1; day += 30) {
                                List<BatchProjectedCurve> bppc = baService.getBatchValueTime(bpc.get(day).getBatchid(), day);
                                if (bppc.isEmpty()) {
                                    bpc.get(day).setProjectedTime(d);
                                    save.saveObject(bpc.get(day));
                                } else {
                                    bppc.get(0).setProjectedValue(bpc.get(day).getProjectedValue());
                                    bppc.get(0).setProjectedTime(d);
                                    save.updateObject(bppc.get(0));
                                }
                                d++;
                            }
                        } else {
                            for (int day = 0; day < ba.get(0).getAnalysisDays() - 1; day++) {
                                for (BatchProjectedCurve bp : bpc) {
                                    List<BatchProjectedCurve> bppc = baService.getBatchValueTime(bpc.get(day).getBatchid(), day);
                                    if (bppc.isEmpty()) {
                                        bpc.get(day).setProjectedTime(day);
                                        save.saveObject(bpc.get(day));
                                    } else {
                                        bppc.get(0).setProjectedValue(bpc.get(day).getProjectedValue());
                                        save.updateObject(bppc.get(0));
                                    }
                                }
                            }
                        }

                        reply.setSucc("Batch Projected Data created");

                    } else {
                        log.error("Batch does not exist");
                        reply.setError("Batch does not exist");
                    }

                } else {
                    log.error("Empty File : ");
                    reply.setError("Empty File");
                }

            } else {
                log.error("Please select Batch");
                reply.setError("Please select Batch");
            }
        } catch (IOException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: CREATE DEPOSIT :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Secured({Role.administrator})
    @Path("createDeposit")
    @ApiOperation(value = "Add Payment Plan", notes = "Add new payment plan.", response = JsonReply.class)
    public String receiveDeposit(@Context Request req, @ApiParam(value = "JsonInput.deposit") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("receiveDeposit");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.deposit != null) {

                if (input.deposit.getFinal1() == null) {
                    log.info("Final should have a value");
                    reply.setError("Final should have a value");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    Deposit deposit = new Deposit();
                    deposit.setDaily(input.deposit.getDaily());
//                        deposit.setDefaltRateOnInstallments(input.deposit.getDefaltRateOnInstallments());
                    deposit.setFinal1(input.deposit.getFinal1());
                    deposit.setGracePeriodUpfront(input.deposit.getGracePeriodUpfront());
                    deposit.setInitialPaytWindow(input.deposit.getInitialPaytWindow());
                    //                       deposit.setMonthly(input.deposit.getMonthly());
                    deposit.setPaytPerirod(input.deposit.getPaytPerirod());
                    deposit.setPenguinTotal(input.deposit.getPenguinTotal());
                    deposit.setPercent(input.deposit.getPercent());
                    deposit.setSystemCost(input.deposit.getSystemCost());
                    deposit.setTotal(input.deposit.getTotal());
                    deposit.setUpfront(input.deposit.getUpfront());
                    deposit.setUpfrontPayment(input.deposit.getUpfrontPayment());
//                        deposit.setWeekly(input.deposit.getWeekly());
                    deposit.setIdDeposit(input.deposit.getIdDeposit());
                    deposit.setVersion(input.deposit.getVersion());

                    save.saveObject(deposit);

                    reply.deposits = depositService.findAll();
                    reply.setSucc("Down Payment created");

                }

            } else {
                log.info("Please Send some JSON or Send Deposit object");
                reply.setError("Please Send some JSON or Send Deposit object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: UPDATE Payment Plan :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Secured({Role.administrator})
    @ApiOperation(value = "Update Payment plan data", notes = "Update payment plan data.", response = JsonReply.class)
    @Path("updatePlan")
    public String updatePlan(@Context Request req, @ApiParam(value = "JsonInput.deposit") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("updatePlan");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.deposit != null) {

                if (input.deposit.getFinal1() == null) {
                    log.info("Final should have a value");
                    reply.setError("Final should have a value");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    List<Deposit> deposit = depositService.depositByModelVersion(input.deposit.getIdDeposit(), input.deposit.getVersion());
                    if (!deposit.isEmpty()) {
                        deposit.get(0).setDaily(input.deposit.getDaily());
//                        deposit.setDefaltRateOnInstallments(input.deposit.getDefaltRateOnInstallments());
                        deposit.get(0).setFinal1(input.deposit.getFinal1());
                        deposit.get(0).setGracePeriodUpfront(input.deposit.getGracePeriodUpfront());
                        deposit.get(0).setInitialPaytWindow(input.deposit.getInitialPaytWindow());
//                        deposit.setMonthly(input.deposit.getMonthly());
                        deposit.get(0).setPaytPerirod(input.deposit.getPaytPerirod());
                        deposit.get(0).setPenguinTotal(input.deposit.getPenguinTotal());
                        deposit.get(0).setPercent(input.deposit.getPercent());
                        deposit.get(0).setSystemCost(input.deposit.getSystemCost());
                        deposit.get(0).setTotal(input.deposit.getTotal());
                        deposit.get(0).setUpfront(input.deposit.getUpfront());
                        deposit.get(0).setUpfrontPayment(input.deposit.getUpfrontPayment());
//                        deposit.setWeekly(input.deposit.getWeekly());
                        deposit.get(0).setIdDeposit(input.deposit.getIdDeposit());
                        deposit.get(0).setVersion(input.deposit.getVersion());

                        save.updateObject(deposit);

                        reply.deposits = depositService.findAll();
                        reply.setSucc("Payment Plan updated");

                    } else {
                        log.info("This Plan does not Exist " + input.deposit.getIdDeposit() + " Version:" + input.deposit.getVersion());
                        reply.setError("This Plan does not Exist " + input.deposit.getIdDeposit() + " Version:" + input.deposit.getVersion());
                    }
                }

            } else {
                log.info("Please Send some JSON or Send Deposit object");
                reply.setError("Please Send some JSON or Send Deposit object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: DELETE deposit :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Secured({Role.administrator})
    @Path("deletePlan")
    @ApiOperation(value = "Delete Payment plan", notes = "delete payment plan.", response = JsonReply.class)
    public String deletePlan(@Context Request req, @ApiParam(value = "JsonInput.deposit") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        reply = new JsonReply("deletePlan");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null) {
                if (input.deposit == null) {
                    log.info("Payment Plan  equired");
                    reply.setError("Payment Plan required");
                } else {

                    //GET LOAN and BATCH FROM DB
                    List<Deposit> b = depositService.depositByModelVersion(input.deposit.getIdDeposit(), input.deposit.getVersion());

                    if (!b.isEmpty()) {

                        save.deleteObject(b.get(0));
                        reply.setSucc("Payment Plan deleted");

                    } else {
                        log.error("No Payment Plan of that Kind " + input.deposit.getIdDeposit() + " Version:" + input.deposit.getVersion());
                        reply.setError("No Payment Plan of that Kind " + input.deposit.getIdDeposit() + " Version:" + input.deposit.getVersion());
                    }

                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: DELETE batch :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Secured({Role.administrator})
    @Path("deleteBatch")
    @ApiOperation(value = "Delete batch", notes = "Delete batch.", response = JsonReply.class)
    public String deleteBatch(@Context Request req, @ApiParam(value = "JsonInput.batch") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        reply = new JsonReply("deleteBatch");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null) {
                if (input.batch == null) {
                    log.info("Batch Object  equired");
                    reply.setError("Batch Object required");
                } else {

                    //GET LOAN and BATCH FROM DB
                    Batch b = batchService.batchById(input.batch.getId());

                    if (b != null) {

                        if (ubService.userBatchHasLoan(b).isEmpty() && ubService.userBatchHasUser(b).isEmpty()) {

                            save.deleteObject(b);
                            reply.setSucc("Batch deleted");

                        } else {
                            log.error("Batch is assined to user or Loans");
                            reply.setError("Batch is assined to user or Loans");
                        }
                    } else {
                        log.error("Batch does not exist " + input.batch.getId());
                        reply.setError("Batch does not exist " + input.batch.getId());
                    }

                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: DELETE batch :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Secured({Role.administrator})
    @Path("deleteBatchAnalysis")
    @ApiOperation(value = "delete batch analysis Data", notes = "delete batch analysis data.", response = JsonReply.class)
    public String deleteBatchAnalysis(@Context Request req, @ApiParam(value = "JsonInput.batchAnalysis") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        reply = new JsonReply("deleteBatchAnalysis");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null) {
                if (input.batchAnalysis == null) {
                    log.info("BatchAnalysis Object  equired");
                    reply.setError("BatchAnalysis Object required");
                } else {

                    //GET LOAN and BATCH FROM DB
                    BatchAnalysis b = baService.batchAnalysisById(input.batchAnalysis.getIdbatchAnalysis());

                    if (b != null) {

                        save.deleteObject(b);
                        reply.setSucc("BatchAnalysis deleted");

                    } else {
                        log.error("BatchAnalysis does not exist " + input.batchAnalysis.getIdbatchAnalysis());
                        reply.setError("BatchAnalysis does not exist " + input.batchAnalysis.getIdbatchAnalysis());
                    }

                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: UPDATE batch :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Secured({Role.administrator})
    @Path("updateBatch")
    @ApiOperation(value = "Update batch details", notes = "Update batch details.", response = JsonReply.class)
    public String updateBatch(@Context Request req, @ApiParam(value = "JsonInput.batch") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        reply = new JsonReply("updateBatch");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null) {
                if (input.batch == null) {
                    log.info("Batch Object  equired");
                    reply.setError("Batch Object required");
                } else {

                    //GET LOAN and BATCH FROM DB
                    Batch b = batchService.batchById(input.batch.getId());

                    if (b != null) {
                        b.setDescription(input.batch.getDescription());
                        b.setName(input.batch.getName());
                        b.setUpdateDate(PrintJson.timeZoneKla());

                        save.updateObject(b);
                        reply.setSucc("Batch Updated");

                    } else {
                        log.error("Batch does not exist " + input.batch.getId());
                        reply.setError("Batch does not exist " + input.batch.getId());
                    }

                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

//**************endpoint for all batches in portfolio*****************
    @POST
    @Path("allBatchesInPortfolio")
    @Secured({ch.villagepower.filter.Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    public String findAllBatchesInPortfolio(@Context Request req, String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("findAllBatchesInPortfolio");

        gson = new Gson();

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.portfolio != null) {

                List<Batch> portfolioBatch = portfolioService.findBatchPortfolio(input.portfolio);
                if (portfolioBatch.isEmpty()) {
                    reply.setError("No batches in portfolio");
                } else {
                    reply.setSucc("Found batches in Portfolio");
                    reply.batches = portfolioBatch;
                }

            } else {
                log.info("Please Send some JSON or Send Batch object");
                reply.setError("Please Send some JSON or Send Batch object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();

    }

    // save uploaded file to new location
    private void saveToFile(InputStream uploadedInputStream,
            String uploadedFileLocation) throws IOException {
            OutputStream out=null;
        try {
            
            int read;
            byte[] bytes = new byte[1024];

            out = new FileOutputStream(new File(uploadedFileLocation));
            while ((read = uploadedInputStream.read(bytes)) != -1) {
                out.write(bytes, 0, read);
            }
            out.flush();
            //out.close();
        } catch (IOException e) {

            log.info(e);
        }finally {
            //close file io
            out.close();

        }

    }

}
