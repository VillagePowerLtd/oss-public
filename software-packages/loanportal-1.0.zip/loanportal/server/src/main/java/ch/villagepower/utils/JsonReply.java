/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.utils;


import ch.villagepower.entities.Batch;
import ch.villagepower.entities.BatchAnalysis;
import ch.villagepower.entities.BatchhasLoan;
import ch.villagepower.entities.Deposit;
import ch.villagepower.entities.Loan;
import ch.villagepower.entities.Portfolio;
import ch.villagepower.entities.UserGraph;
import ch.villagepower.entities.Users;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import io.swagger.annotations.ApiModel;
import java.util.List;
import org.apache.log4j.Logger;

/**
 *
 * @author Mac
 */
@ApiModel
public class JsonReply/* implements Serializable*/ {

    //private static final long serialVersionUID = 1L;
    final static Logger log = Logger.getLogger(JsonReply.class.getName());

    //public Gson gson;
    static Gson toStringGson = new GsonBuilder().registerTypeAdapterFactory(HibernateProxyTypeAdapter.FACTORY).setDateFormat("yyyy/MM/dd HH:mm a").setPrettyPrinting().create();

    public String transType;
    public boolean result;
    public String errorMessage;
    public String message;

    public Portfolio portfolio;
    public Batch batch;

    public List<BatchhasLoan> batchhasLoans;
    public List<UserGraph> usergraph;
    public List<Portfolio> portfolios;
    public List<BatchAnalysis> batchAnalysises;
    public List<Batch> batches;
    public List<UserGraphBatch> userGraphbatches;
    public List<Loan> loans;
    public LoanBarGraph loanBarGraph;
    public LoanDonutChart loanDonutChart;
    public List<Nummber> number;
    public List<Collection> collection;
    public List<Repayment> repayment;

    public String role;
    public String email;

    public List<Users> users;
    public Users user;

    public String jwt;
    public String photoUrl;
    public List<Deposit> deposits;
    
    public String display="";
    public String displayCurve="";

    public JsonReply(String type) {
        log.info("+++++++++++: TRANS INIT:" + type);
        this.transType = type;
        //  gson = new Gson();
    }

    public JsonReply() {
    }

    //UTILS FOR PROCESSING
    //SET ERROR
    public void setError(String error) {
        result = false;
        errorMessage = error;
    }

    //SET SUCCESS
    public void setSucc(String message) {
        result = true;
        this.message = message;
    }

    @Override
    public String toString() {
        return toStringGson.toJson(this);
    }

}
