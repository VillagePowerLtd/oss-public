/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;


import ch.villagepower.entities.Batch;
import ch.villagepower.entities.BatchhasLoan;
import ch.villagepower.entities.BatchhasLoanPK;
import ch.villagepower.entities.Loan;
import ch.villagepower.entities.UserBatch;
import ch.villagepower.entities.UserGraph;
import ch.villagepower.entities.UserRoles;
import ch.villagepower.entities.Users;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Stateless
public class UserBatchService {

    @PersistenceContext
    private EntityManager em;

    //return batch byt id
    public BatchhasLoan batchLoanById(BatchhasLoanPK id) {

        BatchhasLoan bhl = em.find(BatchhasLoan.class, id);

        return bhl;
    }

    //return batch by batch
    public List<UserBatch> userBatchBy(UserBatch id) {

        Query query = em.createQuery("SELECT s FROM UserBatch s WHERE s.iduserBatch = :a AND s.usersuserId = :b");
        query.setParameter("a", id.getBatchid().getId());
        query.setParameter("b", id.getUsersuserId());

        return query.getResultList();
    }

    //return batch by batch
    public List<UserBatch> userBatchHasUser(Batch id) {

        Query query = em.createQuery("SELECT s FROM UserBatch s WHERE s.batchid = :a");
        query.setParameter("a", id);

        return query.getResultList();
    }

    //return batch by batch
    public List<BatchhasLoan> userBatchHasLoan(Batch id) {

        Query query = em.createQuery("SELECT s FROM BatchhasLoan s WHERE s.batch = :a");
        query.setParameter("a", id);

        return query.getResultList();
    }

    //return userGraph by graph
    public List<UserGraph> userGraphBy(UserGraph id) {

        Query query = em.createQuery("SELECT s FROM UserGraph s WHERE s.usersuserId = :a AND s.graphs = :b");
        query.setParameter("a", id.getUsersuserId());
        query.setParameter("b", id.getGraphs());

        return query.getResultList();
    }

    //return userGraph by user
    public List<UserGraph> userGraphByUser(String id) {

        Query query = em.createQuery("SELECT s FROM Users s WHERE s.email = :a");
        query.setParameter("a", id);
        List<Users> u = query.getResultList();

        Query query1 = em.createQuery("SELECT s FROM UserGraph s WHERE s.usersuserId = :b");
        query1.setParameter("b", u.get(0));

        return query1.getResultList();
    }

    //return userGraph by user
    public List<UserGraph> userGraphByUserID(Users id) {

        Query query1 = em.createQuery("SELECT s FROM UserGraph s WHERE s.usersuserId = :b");
        query1.setParameter("b", id);

        return query1.getResultList();
    }

    //return userRole by user
    public List<UserRoles> userRoleByUserID(Users id) {

        Query query1 = em.createQuery("SELECT r FROM UserRoles r WHERE r.userId = :b");
        query1.setParameter("b", id);

        return query1.getResultList();
    }

    //return userGraph by user
    public List<UserGraph> userGraphByUserGraph(Users id, String graph) {

        Query query1 = em.createQuery("SELECT s FROM UserGraph s WHERE s.usersuserId = :b AND s.graphs = :a");
        query1.setParameter("b", id);
        query1.setParameter("a", graph);

        return query1.getResultList();
    }

    public List<BatchhasLoan> batchLoanByLoan(Loan id) {

        Query query = em.createQuery("SELECT s FROM BatchhasLoan s WHERE s.loan = :a");
        query.setParameter("a", id);

        return query.getResultList();
    }

    //return batch by user
    public List<UserBatch> userBatchByUser(Users id) {

        Query query = em.createQuery("SELECT s FROM UserBatch s WHERE s.usersuserId = :b");
        query.setParameter("b", id);

        return query.getResultList();
    }

    //return batch by user exist
    public List<UserBatch> userBatchExists(Users id, Batch b) {

        Query query = em.createQuery("SELECT s FROM UserBatch s WHERE s.usersuserId = :b AND s.batchid = :a");
        query.setParameter("b", id);
        query.setParameter("a", b);

        return query.getResultList();
    }

    public List<BatchhasLoan> batchOfLoan(Loan id) {

        Query query = em.createQuery("SELECT s.batch FROM BatchhasLoan s WHERE s.loan = :a");
        query.setParameter("a", id);

        return query.getResultList();
    }

}
