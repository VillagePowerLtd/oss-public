/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Entity
@Table(name = "restructured_loans")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "RestructuredLoans.findAll", query = "SELECT r FROM RestructuredLoans r"),
    @NamedQuery(name = "RestructuredLoans.findById", query = "SELECT r FROM RestructuredLoans r WHERE r.id = :id"),
    @NamedQuery(name = "RestructuredLoans.findByNumberRestructured", query = "SELECT r FROM RestructuredLoans r WHERE r.numberRestructured = :numberRestructured"),
    @NamedQuery(name = "RestructuredLoans.findByOutstandingRestructured", query = "SELECT r FROM RestructuredLoans r WHERE r.outstandingRestructured = :outstandingRestructured"),
    @NamedQuery(name = "RestructuredLoans.findByBatchid", query = "SELECT r FROM RestructuredLoans r WHERE r.batchid = :batchid"),
    @NamedQuery(name = "RestructuredLoans.findByMonth", query = "SELECT r FROM RestructuredLoans r WHERE r.month = :month"),
    @NamedQuery(name = "RestructuredLoans.findByDateCreated", query = "SELECT r FROM RestructuredLoans r WHERE r.dateCreated = :dateCreated")})
public class RestructuredLoans implements Serializable {

    @Column(name = "outstanding_overdue_restructured")
    private Double outstandingOverdueRestructured;

    @Column(name = "Batch_id")
    private Integer batchid;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "number_restructured")
    private Integer numberRestructured;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "outstanding_restructured")
    private Double outstandingRestructured;
    @Size(max = 45)
    @Column(name = "month")
    private String month;
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;

    public RestructuredLoans() {
    }

    public RestructuredLoans(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNumberRestructured() {
        return numberRestructured;
    }

    public void setNumberRestructured(Integer numberRestructured) {
        this.numberRestructured = numberRestructured;
    }

    public Double getOutstandingRestructured() {
        return outstandingRestructured;
    }

    public void setOutstandingRestructured(Double outstandingRestructured) {
        this.outstandingRestructured = outstandingRestructured;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof RestructuredLoans)) {
            return false;
        }
        RestructuredLoans other = (RestructuredLoans) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.RestructuredLoans[ id=" + id + " ]";
    }

    public Integer getBatchid() {
        return batchid;
    }

    public void setBatchid(Integer batchid) {
        this.batchid = batchid;
    }

    public Double getOutstandingOverdueRestructured() {
        return outstandingOverdueRestructured;
    }

    public void setOutstandingOverdueRestructured(Double outstandingOverdueRestructured) {
        this.outstandingOverdueRestructured = outstandingOverdueRestructured;
    }

}
