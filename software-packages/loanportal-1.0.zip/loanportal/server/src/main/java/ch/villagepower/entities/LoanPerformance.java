/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import io.swagger.annotations.ApiModel;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Entity
@Table(name = "Loan_Performance")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "LoanPerformance.findAll", query = "SELECT l FROM LoanPerformance l"),
    @NamedQuery(name = "LoanPerformance.findByBatchid", query = "SELECT l FROM LoanPerformance l WHERE l.batchid = :batchid"),
    @NamedQuery(name = "LoanPerformance.findByOutstanding", query = "SELECT l FROM LoanPerformance l WHERE l.outstanding = :outstanding"),
    @NamedQuery(name = "LoanPerformance.findByCollected", query = "SELECT l FROM LoanPerformance l WHERE l.collected = :collected"),
    @NamedQuery(name = "LoanPerformance.findByMonth", query = "SELECT l FROM LoanPerformance l WHERE l.month = :month"),
    @NamedQuery(name = "LoanPerformance.findByIdLoanPerformance", query = "SELECT l FROM LoanPerformance l WHERE l.idLoanPerformance = :idLoanPerformance")})
@ApiModel
public class LoanPerformance implements Serializable {

    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;

    @Column(name = "defaulted_amount")
    private Double defaultedAmount;
    @Column(name = "discounted_amount")
    private Double discountedAmount;

    @Column(name = "payments_within")
    private Double paymentsWithin;
    @Column(name = "payments_behind")
    private Double paymentsBehind;
    @Column(name = "balance_due_to_date")
    private Double balanceDueToDate;
    @Column(name = "amount_paid_to_date")
    private Double amountPaidToDate;
    @Column(name = "outstanding_overdue")
    private Double outstandingOverdue;
    @Column(name = "outstanding_within")
    private Double outstandingWithin;

    private static final long serialVersionUID = 1L;
    @Column(name = "Batch_id")
    private Integer batchid;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "outstanding")
    private Double outstanding;
    @Column(name = "collected")
    private Double collected;
    @Size(max = 45)
    @Column(name = "month")
    private String month;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idLoan_Performance")
    private Integer idLoanPerformance;

    public LoanPerformance() {
    }

    public LoanPerformance(Integer idLoanPerformance) {
        this.idLoanPerformance = idLoanPerformance;
    }

    public Integer getBatchid() {
        return batchid;
    }

    public void setBatchid(Integer batchid) {
        this.batchid = batchid;
    }

    public Double getOutstanding() {
        return outstanding;
    }

    public void setOutstanding(Double outstanding) {
        this.outstanding = outstanding;
    }

    public Double getCollected() {
        return collected;
    }

    public void setCollected(Double collected) {
        this.collected = collected;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Integer getIdLoanPerformance() {
        return idLoanPerformance;
    }

    public void setIdLoanPerformance(Integer idLoanPerformance) {
        this.idLoanPerformance = idLoanPerformance;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idLoanPerformance != null ? idLoanPerformance.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof LoanPerformance)) {
            return false;
        }
        LoanPerformance other = (LoanPerformance) object;
        if ((this.idLoanPerformance == null && other.idLoanPerformance != null) || (this.idLoanPerformance != null && !this.idLoanPerformance.equals(other.idLoanPerformance))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.LoanPerformance[ idLoanPerformance=" + idLoanPerformance + " ]";
    }

    public Double getPaymentsWithin() {
        return paymentsWithin;
    }

    public void setPaymentsWithin(Double paymentsWithin) {
        this.paymentsWithin = paymentsWithin;
    }

    public Double getPaymentsBehind() {
        return paymentsBehind;
    }

    public void setPaymentsBehind(Double paymentsBehind) {
        this.paymentsBehind = paymentsBehind;
    }

    public Double getBalanceDueToDate() {
        return balanceDueToDate;
    }

    public void setBalanceDueToDate(Double balanceDueToDate) {
        this.balanceDueToDate = balanceDueToDate;
    }

    public Double getAmountPaidToDate() {
        return amountPaidToDate;
    }

    public void setAmountPaidToDate(Double amountPaidToDate) {
        this.amountPaidToDate = amountPaidToDate;
    }

    public Double getOutstandingOverdue() {
        return outstandingOverdue;
    }

    public void setOutstandingOverdue(Double outstandingOverdue) {
        this.outstandingOverdue = outstandingOverdue;
    }

    public Double getOutstandingWithin() {
        return outstandingWithin;
    }

    public void setOutstandingWithin(Double outstandingWithin) {
        this.outstandingWithin = outstandingWithin;
    }

    public Double getDefaultedAmount() {
        return defaultedAmount;
    }

    public void setDefaultedAmount(Double defaultedAmount) {
        this.defaultedAmount = defaultedAmount;
    }

    public Double getDiscountedAmount() {
        return discountedAmount;
    }

    public void setDiscountedAmount(Double discountedAmount) {
        this.discountedAmount = discountedAmount;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

}
