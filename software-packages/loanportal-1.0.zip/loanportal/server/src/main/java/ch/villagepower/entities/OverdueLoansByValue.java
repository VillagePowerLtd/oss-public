/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import io.swagger.annotations.ApiModel;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Entity
@Table(name = "overdue_loans_by_value")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "OverdueLoansByValue.findAll", query = "SELECT o FROM OverdueLoansByValue o"),
    @NamedQuery(name = "OverdueLoansByValue.findByIdoverdueLoansByValue", query = "SELECT o FROM OverdueLoansByValue o WHERE o.idoverdueLoansByValue = :idoverdueLoansByValue"),
    @NamedQuery(name = "OverdueLoansByValue.findByOutstandingPar1", query = "SELECT o FROM OverdueLoansByValue o WHERE o.outstandingPar1 = :outstandingPar1"),
    @NamedQuery(name = "OverdueLoansByValue.findByOutstandingPar30", query = "SELECT o FROM OverdueLoansByValue o WHERE o.outstandingPar30 = :outstandingPar30"),
    @NamedQuery(name = "OverdueLoansByValue.findByOutstandingPar60", query = "SELECT o FROM OverdueLoansByValue o WHERE o.outstandingPar60 = :outstandingPar60"),
    @NamedQuery(name = "OverdueLoansByValue.findByOutstandingPar90", query = "SELECT o FROM OverdueLoansByValue o WHERE o.outstandingPar90 = :outstandingPar90"),
    @NamedQuery(name = "OverdueLoansByValue.findByOutstandingOnDefaulted", query = "SELECT o FROM OverdueLoansByValue o WHERE o.outstandingOnDefaulted = :outstandingOnDefaulted"),
    @NamedQuery(name = "OverdueLoansByValue.findByOutstandingOnReposessed", query = "SELECT o FROM OverdueLoansByValue o WHERE o.outstandingOnReposessed = :outstandingOnReposessed"),
    @NamedQuery(name = "OverdueLoansByValue.findByOutstandingWithinPaidUp", query = "SELECT o FROM OverdueLoansByValue o WHERE o.outstandingWithinPaidUp = :outstandingWithinPaidUp"),
    @NamedQuery(name = "OverdueLoansByValue.findByParByValue", query = "SELECT o FROM OverdueLoansByValue o WHERE o.parByValue = :parByValue"),
    @NamedQuery(name = "OverdueLoansByValue.findByParDefaultedValue", query = "SELECT o FROM OverdueLoansByValue o WHERE o.parDefaultedValue = :parDefaultedValue"),
    @NamedQuery(name = "OverdueLoansByValue.findByParReposessedValue", query = "SELECT o FROM OverdueLoansByValue o WHERE o.parReposessedValue = :parReposessedValue"),
    @NamedQuery(name = "OverdueLoansByValue.findByBatchid", query = "SELECT o FROM OverdueLoansByValue o WHERE o.batchid = :batchid"),
    @NamedQuery(name = "OverdueLoansByValue.findByMonth", query = "SELECT o FROM OverdueLoansByValue o WHERE o.month = :month"),
    @NamedQuery(name = "OverdueLoansByValue.findByDateCreated", query = "SELECT o FROM OverdueLoansByValue o WHERE o.dateCreated = :dateCreated"),
    @NamedQuery(name = "OverdueLoansByValue.findByRecoveryAmount", query = "SELECT o FROM OverdueLoansByValue o WHERE o.recoveryAmount = :recoveryAmount")})
@ApiModel
public class OverdueLoansByValue implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idoverdue_loans_by_value")
    private Integer idoverdueLoansByValue;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "outstanding_par1")
    private Double outstandingPar1;
    @Column(name = "outstanding_par30")
    private Double outstandingPar30;
    @Column(name = "outstanding_par60")
    private Double outstandingPar60;
    @Column(name = "outstanding_par90")
    private Double outstandingPar90;
    @Column(name = "outstanding_on_defaulted")
    private Double outstandingOnDefaulted;
    @Column(name = "outstanding_on_reposessed")
    private Double outstandingOnReposessed;
    @Column(name = "outstanding_within_paid_up")
    private Double outstandingWithinPaidUp;
    @Column(name = "par_by_value")
    private Double parByValue;
    @Column(name = "par_defaulted_value")
    private Double parDefaultedValue;
    @Column(name = "par_reposessed_value")
    private Double parReposessedValue;
    @Column(name = "Batch_id")
    private Integer batchid;
    @Size(max = 45)
    @Column(name = "month")
    private String month;
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    @Column(name = "recovery_amount")
    private Double recoveryAmount;

    public OverdueLoansByValue() {
    }

    public OverdueLoansByValue(Integer idoverdueLoansByValue) {
        this.idoverdueLoansByValue = idoverdueLoansByValue;
    }

    public Integer getIdoverdueLoansByValue() {
        return idoverdueLoansByValue;
    }

    public void setIdoverdueLoansByValue(Integer idoverdueLoansByValue) {
        this.idoverdueLoansByValue = idoverdueLoansByValue;
    }

    public Double getOutstandingPar1() {
        return outstandingPar1;
    }

    public void setOutstandingPar1(Double outstandingPar1) {
        this.outstandingPar1 = outstandingPar1;
    }

    public Double getOutstandingPar30() {
        return outstandingPar30;
    }

    public void setOutstandingPar30(Double outstandingPar30) {
        this.outstandingPar30 = outstandingPar30;
    }

    public Double getOutstandingPar60() {
        return outstandingPar60;
    }

    public void setOutstandingPar60(Double outstandingPar60) {
        this.outstandingPar60 = outstandingPar60;
    }

    public Double getOutstandingPar90() {
        return outstandingPar90;
    }

    public void setOutstandingPar90(Double outstandingPar90) {
        this.outstandingPar90 = outstandingPar90;
    }

    public Double getOutstandingOnDefaulted() {
        return outstandingOnDefaulted;
    }

    public void setOutstandingOnDefaulted(Double outstandingOnDefaulted) {
        this.outstandingOnDefaulted = outstandingOnDefaulted;
    }

    public Double getOutstandingOnReposessed() {
        return outstandingOnReposessed;
    }

    public void setOutstandingOnReposessed(Double outstandingOnReposessed) {
        this.outstandingOnReposessed = outstandingOnReposessed;
    }

    public Double getOutstandingWithinPaidUp() {
        return outstandingWithinPaidUp;
    }

    public void setOutstandingWithinPaidUp(Double outstandingWithinPaidUp) {
        this.outstandingWithinPaidUp = outstandingWithinPaidUp;
    }

    public Double getParByValue() {
        return parByValue;
    }

    public void setParByValue(Double parByValue) {
        this.parByValue = parByValue;
    }

    public Double getParDefaultedValue() {
        return parDefaultedValue;
    }

    public void setParDefaultedValue(Double parDefaultedValue) {
        this.parDefaultedValue = parDefaultedValue;
    }

    public Double getParReposessedValue() {
        return parReposessedValue;
    }

    public void setParReposessedValue(Double parReposessedValue) {
        this.parReposessedValue = parReposessedValue;
    }

    public Integer getBatchid() {
        return batchid;
    }

    public void setBatchid(Integer batchid) {
        this.batchid = batchid;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Double getRecoveryAmount() {
        return recoveryAmount;
    }

    public void setRecoveryAmount(Double recoveryAmount) {
        this.recoveryAmount = recoveryAmount;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idoverdueLoansByValue != null ? idoverdueLoansByValue.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof OverdueLoansByValue)) {
            return false;
        }
        OverdueLoansByValue other = (OverdueLoansByValue) object;
        if ((this.idoverdueLoansByValue == null && other.idoverdueLoansByValue != null) || (this.idoverdueLoansByValue != null && !this.idoverdueLoansByValue.equals(other.idoverdueLoansByValue))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.OverdueLoansByValue[ idoverdueLoansByValue=" + idoverdueLoansByValue + " ]";
    }

}
