/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author root
 */
@Entity
@Table(name = "actual_percentage")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ActualPercentage.findAll", query = "SELECT a FROM ActualPercentage a"),
    @NamedQuery(name = "ActualPercentage.findByIdactualPercentage", query = "SELECT a FROM ActualPercentage a WHERE a.idactualPercentage = :idactualPercentage"),
    @NamedQuery(name = "ActualPercentage.findByActualDay", query = "SELECT a FROM ActualPercentage a WHERE a.actualDay = :actualDay"),
    @NamedQuery(name = "ActualPercentage.findByActualPercent", query = "SELECT a FROM ActualPercentage a WHERE a.actualPercent = :actualPercent")})
public class ActualPercentage implements Serializable {

    @Column(name = "actual_percent2")
    private Double actualPercent2;

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "actual_percent")
    private BigDecimal actualPercent;

    @Column(name = "Batch_id")
    private Integer batchid;

    @Column(name = "actual_day")
    private Integer actualDay;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idactual_percentage")
    private Integer idactualPercentage;

    public ActualPercentage() {
    }

    public ActualPercentage(Integer idactualPercentage) {
        this.idactualPercentage = idactualPercentage;
    }

    public Integer getIdactualPercentage() {
        return idactualPercentage;
    }

    public void setIdactualPercentage(Integer idactualPercentage) {
        this.idactualPercentage = idactualPercentage;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idactualPercentage != null ? idactualPercentage.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ActualPercentage)) {
            return false;
        }
        ActualPercentage other = (ActualPercentage) object;
        if ((this.idactualPercentage == null && other.idactualPercentage != null) || (this.idactualPercentage != null && !this.idactualPercentage.equals(other.idactualPercentage))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.ActualPercentage[ idactualPercentage=" + idactualPercentage + " ]";
    }

    public Integer getActualDay() {
        return actualDay;
    }

    public void setActualDay(Integer actualDay) {
        this.actualDay = actualDay;
    }

    /*public Double getActualPercent() {
        return actualPercent;
    }

    public void setActualPercent(Double actualPercent) {
            if(actualPercent == Double.POSITIVE_INFINITY)
                this.actualPercent = Double.MAX_VALUE;
            else if(actualPercent == Double.NEGATIVE_INFINITY)
                this.actualPercent = Double.MIN_VALUE;
            else
                this.actualPercent = actualPercent;
    }
     */
    public Integer getBatchid() {
        return batchid;
    }

    public void setBatchid(Integer batchid) {
        this.batchid = batchid;
    }

    public BigDecimal getActualPercent() {
        return actualPercent;
    }

    public void setActualPercent(BigDecimal actualPercent) {
        this.actualPercent = actualPercent;
    }

    public Double getActualPercent2() {
        return actualPercent2;
    }

    public void setActualPercent2(Double actualPercent2) {
        this.actualPercent2 = actualPercent2;
    }

}
