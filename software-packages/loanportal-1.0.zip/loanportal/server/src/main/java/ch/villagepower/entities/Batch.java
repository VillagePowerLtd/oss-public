/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import io.swagger.annotations.ApiModel;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Entity
@Table(name = "Batch")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Batch.findAll", query = "SELECT b FROM Batch b"),
    @NamedQuery(name = "Batch.findById", query = "SELECT b FROM Batch b WHERE b.id = :id"),
    @NamedQuery(name = "Batch.findByUploadDate", query = "SELECT b FROM Batch b WHERE b.uploadDate = :uploadDate"),
    @NamedQuery(name = "Batch.findByStatus", query = "SELECT b FROM Batch b WHERE b.status = :status"),
    @NamedQuery(name = "Batch.findByName", query = "SELECT b FROM Batch b WHERE b.name = :name"),
    @NamedQuery(name = "Batch.findByDescription", query = "SELECT b FROM Batch b WHERE b.description = :description"),
    @NamedQuery(name = "Batch.findByUpdateDate", query = "SELECT b FROM Batch b WHERE b.updateDate = :updateDate"),
    @NamedQuery(name = "Batch.findByDateCreated", query = "SELECT b FROM Batch b WHERE b.dateCreated = :dateCreated")})
@ApiModel
public class Batch implements Serializable {

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "batchid")
    private transient List<Percentage> percentageList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "batchid")
    private transient List<BatchProjectedCurve> batchProjectedCurveList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "batchid")
    private transient List<BatchAnalysis> batchAnalysisList;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "batchid", fetch = FetchType.EAGER)
    private transient List<UserBatch> userBatchList;
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "upload_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date uploadDate;
    @Size(max = 45)
    @Column(name = "status")
    private String status;
    @Size(max = 50)
    @Column(name = "name")
    private String name;
    @Size(max = 145)
    @Column(name = "description")
    private String description;
    @Column(name = "update_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    @JoinColumn(name = "Portfolio_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Portfolio portfolioid;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "batch")
    private transient List<BatchhasLoan> batchhasLoanList;

    public Batch() {
    }

    public Batch(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(Date uploadDate) {
        this.uploadDate = uploadDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Portfolio getPortfolioid() {
        return portfolioid;
    }

    public void setPortfolioid(Portfolio portfolioid) {
        this.portfolioid = portfolioid;
    }

    @XmlTransient
    public List<BatchhasLoan> getBatchhasLoanList() {
        return batchhasLoanList;
    }

    public void setBatchhasLoanList(List<BatchhasLoan> batchhasLoanList) {
        this.batchhasLoanList = batchhasLoanList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Batch)) {
            return false;
        }
        Batch other = (Batch) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.Batch[ id=" + id + " ]";
    }

    @XmlTransient
    public List<UserBatch> getUserBatchList() {
        return userBatchList;
    }

    public void setUserBatchList(List<UserBatch> userBatchList) {
        this.userBatchList = userBatchList;
    }

    @XmlTransient
    public List<Percentage> getPercentageList() {
        return percentageList;
    }

    public void setPercentageList(List<Percentage> percentageList) {
        this.percentageList = percentageList;
    }

    @XmlTransient
    public List<BatchProjectedCurve> getBatchProjectedCurveList() {
        return batchProjectedCurveList;
    }

    public void setBatchProjectedCurveList(List<BatchProjectedCurve> batchProjectedCurveList) {
        this.batchProjectedCurveList = batchProjectedCurveList;
    }

    @XmlTransient
    public List<BatchAnalysis> getBatchAnalysisList() {
        return batchAnalysisList;
    }

    public void setBatchAnalysisList(List<BatchAnalysis> batchAnalysisList) {
        this.batchAnalysisList = batchAnalysisList;
    }

}
