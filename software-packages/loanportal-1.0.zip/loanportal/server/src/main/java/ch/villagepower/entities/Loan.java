/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import io.swagger.annotations.ApiModel;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Entity
@Table(name = "Loan")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Loan.findAll", query = "SELECT l FROM Loan l"),
    @NamedQuery(name = "Loan.findByStatus", query = "SELECT l FROM Loan l WHERE l.status = :status"),
    @NamedQuery(name = "Loan.findById", query = "SELECT l FROM Loan l WHERE l.id = :id"),
    @NamedQuery(name = "Loan.findByTotalAmountValue", query = "SELECT l FROM Loan l WHERE l.totalAmountValue = :totalAmountValue"),
    @NamedQuery(name = "Loan.findByBalance", query = "SELECT l FROM Loan l WHERE l.balance = :balance"),
    @NamedQuery(name = "Loan.findByFullPaymentDate", query = "SELECT l FROM Loan l WHERE l.fullPaymentDate = :fullPaymentDate"),
    @NamedQuery(name = "Loan.findByNextPaymentDate", query = "SELECT l FROM Loan l WHERE l.nextPaymentDate = :nextPaymentDate"),
    @NamedQuery(name = "Loan.findByModelPurchased", query = "SELECT l FROM Loan l WHERE l.modelPurchased = :modelPurchased"),
    @NamedQuery(name = "Loan.findByHistoryStatus", query = "SELECT l FROM Loan l WHERE l.historyStatus = :historyStatus"),
    @NamedQuery(name = "Loan.findByUploadDate", query = "SELECT l FROM Loan l WHERE l.uploadDate = :uploadDate"),
    @NamedQuery(name = "Loan.findByInstallmentsPaid", query = "SELECT l FROM Loan l WHERE l.installmentsPaid = :installmentsPaid"),
    @NamedQuery(name = "Loan.findByTotalValueLoan", query = "SELECT l FROM Loan l WHERE l.totalValueLoan = :totalValueLoan"),
    @NamedQuery(name = "Loan.findByDaysOverdue", query = "SELECT l FROM Loan l WHERE l.daysOverdue = :daysOverdue"),
    @NamedQuery(name = "Loan.findByPar", query = "SELECT l FROM Loan l WHERE l.par = :par"),
    @NamedQuery(name = "Loan.findByDownPaymentDate", query = "SELECT l FROM Loan l WHERE l.downPaymentDate = :downPaymentDate"),
    @NamedQuery(name = "Loan.findBySalesAgent", query = "SELECT l FROM Loan l WHERE l.salesAgent = :salesAgent"),
    @NamedQuery(name = "Loan.findByDistributionAgent", query = "SELECT l FROM Loan l WHERE l.distributionAgent = :distributionAgent"),
    @NamedQuery(name = "Loan.findByStore", query = "SELECT l FROM Loan l WHERE l.store = :store"),
    @NamedQuery(name = "Loan.findByInstallationAddress", query = "SELECT l FROM Loan l WHERE l.installationAddress = :installationAddress"),
    @NamedQuery(name = "Loan.findByAssigned", query = "SELECT l FROM Loan l WHERE l.assigned = :assigned"),
    @NamedQuery(name = "Loan.findByNumberBatchAssined", query = "SELECT l FROM Loan l WHERE l.numberBatchAssined = :numberBatchAssined")})
@ApiModel
public class Loan implements Serializable {

    @Column(name = "value_overdue_restructuring")
    private Double valueOverdueRestructuring;

    @Size(max = 145)
    @Column(name = "restructured_overdue")
    private String restructuredOverdue;
    @Column(name = "restructured_outstanding")
    private Integer restructuredOutstanding;

    @Column(name = "restructured")
    private Boolean restructured;

    @Size(max = 45)
    @Column(name = "version")
    private String version;

    @Size(max = 100)
    @Column(name = "district")
    private String district;
    @Size(max = 100)
    @Column(name = "subcounty")
    private String subcounty;
    @Size(max = 100)
    @Column(name = "parish")
    private String parish;
    @Size(max = 100)
    @Column(name = "village")
    private String village;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "loanid")
    private transient List<Percentage> percentageList;

    @Column(name = "defaulted_amount")
    private Double defaultedAmount;
    @Column(name = "discounted_amount")
    private Double discountedAmount;

    @Column(name = "payments_within")
    private Double paymentsWithin;
    @Column(name = "payments_behind")
    private Double paymentsBehind;
    @Column(name = "balance_due_to_date")
    private Double balanceDueToDate;
    @Column(name = "amount_paid_to_date")
    private Double amountPaidToDate;
    @Column(name = "outstanding_overdue")
    private Double outstandingOverdue;
    @Column(name = "outstanding_within")
    private Double outstandingWithin;

    @Column(name = "day")
    private Integer day;
    @Column(name = "percentage")
    private Double percentage;

    private static final long serialVersionUID = 1L;
    @Size(max = 13)
    @Column(name = "status")
    private String status;
    @Id
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "total_amount_value")
    private Double totalAmountValue;
    @Column(name = "balance")
    private Double balance;
    @Column(name = "full_payment_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fullPaymentDate;
    @Column(name = "next_payment_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date nextPaymentDate;
    @Size(max = 100)
    @Column(name = "model_purchased")
    private String modelPurchased;
    @Size(max = 45)
    @Column(name = "history_status")
    private String historyStatus;
    @Column(name = "upload_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date uploadDate;
    @Column(name = "installments_paid")
    private Double installmentsPaid;
    @Column(name = "total_value_loan")
    private Double totalValueLoan;
    @Column(name = "days_overdue")
    private Integer daysOverdue;
    @Size(max = 45)
    @Column(name = "par")
    private String par;
    @Column(name = "down_payment_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date downPaymentDate;
    @Size(max = 145)
    @Column(name = "sales_agent")
    private String salesAgent;
    @Size(max = 145)
    @Column(name = "distribution_agent")
    private String distributionAgent;
    @Size(max = 145)
    @Column(name = "store")
    private String store;
    @Size(max = 145)
    @Column(name = "installation_address")
    private String installationAddress;
    @Column(name = "assigned")
    private Boolean assigned;
    @Column(name = "number_batch_assined")
    private Integer numberBatchAssined;

    public Loan() {
    }

    public Loan(Integer id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Double getTotalAmountValue() {
        return totalAmountValue;
    }

    public void setTotalAmountValue(Double totalAmountValue) {
        this.totalAmountValue = totalAmountValue;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }

    public Date getFullPaymentDate() {
        return fullPaymentDate;
    }

    public void setFullPaymentDate(Date fullPaymentDate) {
        this.fullPaymentDate = fullPaymentDate;
    }

    public Date getNextPaymentDate() {
        return nextPaymentDate;
    }

    public void setNextPaymentDate(Date nextPaymentDate) {
        this.nextPaymentDate = nextPaymentDate;
    }

    public String getModelPurchased() {
        return modelPurchased;
    }

    public void setModelPurchased(String modelPurchased) {
        this.modelPurchased = modelPurchased;
    }

    public String getHistoryStatus() {
        return historyStatus;
    }

    public void setHistoryStatus(String historyStatus) {
        this.historyStatus = historyStatus;
    }

    public Date getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(Date uploadDate) {
        this.uploadDate = uploadDate;
    }

    public Double getInstallmentsPaid() {
        return installmentsPaid;
    }

    public void setInstallmentsPaid(Double installmentsPaid) {
        this.installmentsPaid = installmentsPaid;
    }

    public Double getTotalValueLoan() {
        return totalValueLoan;
    }

    public void setTotalValueLoan(Double totalValueLoan) {
        this.totalValueLoan = totalValueLoan;
    }

    public Integer getDaysOverdue() {
        return daysOverdue;
    }

    public void setDaysOverdue(Integer daysOverdue) {
        this.daysOverdue = daysOverdue;
    }

    public String getPar() {
        return par;
    }

    public void setPar(String par) {
        this.par = par;
    }

    public Date getDownPaymentDate() {
        return downPaymentDate;
    }

    public void setDownPaymentDate(Date downPaymentDate) {
        this.downPaymentDate = downPaymentDate;
    }

    public String getSalesAgent() {
        return salesAgent;
    }

    public void setSalesAgent(String salesAgent) {
        this.salesAgent = salesAgent;
    }

    public String getDistributionAgent() {
        return distributionAgent;
    }

    public void setDistributionAgent(String distributionAgent) {
        this.distributionAgent = distributionAgent;
    }

    public String getStore() {
        return store;
    }

    public void setStore(String store) {
        this.store = store;
    }

    public String getInstallationAddress() {
        return installationAddress;
    }

    public void setInstallationAddress(String installationAddress) {
        this.installationAddress = installationAddress;
    }

    public Boolean getAssigned() {
        return assigned;
    }

    public void setAssigned(Boolean assigned) {
        this.assigned = assigned;
    }

    public Integer getNumberBatchAssined() {
        return numberBatchAssined;
    }

    public void setNumberBatchAssined(Integer numberBatchAssined) {
        this.numberBatchAssined = numberBatchAssined;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Loan)) {
            return false;
        }
        Loan other = (Loan) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.Loan[ id=" + id + " ]";
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public Double getPercentage() {
        return percentage;
    }

    public void setPercentage(Double percentage) {
        this.percentage = percentage;
    }

    public Double getPaymentsWithin() {
        return paymentsWithin;
    }

    public void setPaymentsWithin(Double paymentsWithin) {
        this.paymentsWithin = paymentsWithin;
    }

    public Double getPaymentsBehind() {
        return paymentsBehind;
    }

    public void setPaymentsBehind(Double paymentsBehind) {
        this.paymentsBehind = paymentsBehind;
    }

    public Double getBalanceDueToDate() {
        return balanceDueToDate;
    }

    public void setBalanceDueToDate(Double balanceDueToDate) {
        this.balanceDueToDate = balanceDueToDate;
    }

    public Double getAmountPaidToDate() {
        return amountPaidToDate;
    }

    public void setAmountPaidToDate(Double amountPaidToDate) {
        this.amountPaidToDate = amountPaidToDate;
    }

    public Double getOutstandingOverdue() {
        return outstandingOverdue;
    }

    public void setOutstandingOverdue(Double outstandingOverdue) {
        this.outstandingOverdue = outstandingOverdue;
    }

    public Double getOutstandingWithin() {
        return outstandingWithin;
    }

    public void setOutstandingWithin(Double outstandingWithin) {
        this.outstandingWithin = outstandingWithin;
    }

    public Double getDefaultedAmount() {
        return defaultedAmount;
    }

    public void setDefaultedAmount(Double defaultedAmount) {
        this.defaultedAmount = defaultedAmount;
    }

    public Double getDiscountedAmount() {
        return discountedAmount;
    }

    public void setDiscountedAmount(Double discountedAmount) {
        this.discountedAmount = discountedAmount;
    }

    @XmlTransient
    public List<Percentage> getPercentageList() {
        return percentageList;
    }

    public void setPercentageList(List<Percentage> percentageList) {
        this.percentageList = percentageList;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getSubcounty() {
        return subcounty;
    }

    public void setSubcounty(String subcounty) {
        this.subcounty = subcounty;
    }

    public String getParish() {
        return parish;
    }

    public void setParish(String parish) {
        this.parish = parish;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Boolean getRestructured() {
        return restructured;
    }

    public void setRestructured(Boolean restructured) {
        this.restructured = restructured;
    }

    public Integer getRestructuredOutstanding() {
        return restructuredOutstanding;
    }

    public void setRestructuredOutstanding(Integer restructuredOutstanding) {
        this.restructuredOutstanding = restructuredOutstanding;
    }

    public String getRestructuredOverdue() {
        return restructuredOverdue;
    }

    public void setRestructuredOverdue(String restructuredOverdue) {
        this.restructuredOverdue = restructuredOverdue;
    }

    public Double getValueOverdueRestructuring() {
        return valueOverdueRestructuring;
    }

    public void setValueOverdueRestructuring(Double valueOverdueRestructuring) {
        this.valueOverdueRestructuring = valueOverdueRestructuring;
    }

}
