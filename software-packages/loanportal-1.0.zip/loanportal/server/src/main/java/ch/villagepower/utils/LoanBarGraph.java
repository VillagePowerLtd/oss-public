/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.utils;


import java.util.Date;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
public class LoanBarGraph {

    private AmountOfOverdueLoans amountOfOverdueLoan;
    private Repayments repayments;
    private Collections collections;
    private Numbers numbers;
    private NumberOfOverdueLoans numberOfOverdueLoans;
    private WriteOffsRecovery writeOffsRecovery;
    private Restructured restructured;
    private Date latsUpdated;
    private RestructuredLoan restructuredLoanNumber;
    private RestructuredLoan restructuredLoanValue;

    public RestructuredLoan getRestructuredLoanNumber() {
        return restructuredLoanNumber;
    }

    public void setRestructuredLoanNumber(RestructuredLoan restructuredLoanNumber) {
        this.restructuredLoanNumber = restructuredLoanNumber;
    }

    public RestructuredLoan getRestructuredLoanValue() {
        return restructuredLoanValue;
    }

    public void setRestructuredLoanValue(RestructuredLoan restructuredLoanValue) {
        this.restructuredLoanValue = restructuredLoanValue;
    }

    public Restructured getRestructured() {
        return restructured;
    }

    public void setRestructured(Restructured restructured) {
        this.restructured = restructured;
    }

    public Date getLatsUpdated() {
        return latsUpdated;
    }

    public void setLatsUpdated(Date latsUpdated) {
        this.latsUpdated = latsUpdated;
    }

    public WriteOffsRecovery getWriteOffsRecovery() {
        return writeOffsRecovery;
    }

    public void setWriteOffsRecovery(WriteOffsRecovery writeOffsRecovery) {
        this.writeOffsRecovery = writeOffsRecovery;
    }

    public NumberOfOverdueLoans getNumberOfOverdueLoans() {
        return numberOfOverdueLoans;
    }

    public void setNumberOfOverdueLoans(NumberOfOverdueLoans numberOfOverdueLoans) {
        this.numberOfOverdueLoans = numberOfOverdueLoans;
    }

    public Numbers getNumbers() {
        return numbers;
    }

    public void setNumbers(Numbers numbers) {
        this.numbers = numbers;
    }

    public Collections getCollections() {
        return collections;
    }

    public void setCollections(Collections collections) {
        this.collections = collections;
    }

    public Repayments getRepayments() {
        return repayments;
    }

    public void setRepayments(Repayments repayments) {
        this.repayments = repayments;
    }

    public AmountOfOverdueLoans getAmountOfOverdueLoan() {
        return amountOfOverdueLoan;
    }

    public void setAmountOfOverdueLoan(AmountOfOverdueLoans amountOfOverdueLoan) {
        this.amountOfOverdueLoan = amountOfOverdueLoan;
    }

}
