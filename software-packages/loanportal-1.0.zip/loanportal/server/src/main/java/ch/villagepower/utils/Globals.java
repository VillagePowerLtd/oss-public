/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.utils;


import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.apache.log4j.Logger;

/**
 *
 */
public class Globals {

    static Properties prop = new Properties();
    static InputStream input = null;

    static String filename = "";
    final static Logger log = Logger.getLogger(Globals.class.getName());

    public static Properties setGlobals() {

        try {

            filename = "Globals.properties";
            input = PrintJson.class.getClassLoader().getResourceAsStream(filename);

            if (input == null) {
                log.info("Sorry, unable to find " + filename);

                //return;
            } else {

                //load a properties file from class path, inside static method
                prop.load(input);

                input.close();

            }

        } catch (IOException ex) {
            log.info("ClassPath Error: " + ex);
        }
        return prop;
    }
}
