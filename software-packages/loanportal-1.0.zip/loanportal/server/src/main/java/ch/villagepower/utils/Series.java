/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.utils;


import java.util.ArrayList;


/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
public class Series {

    private ArrayList series;

//    private Double[] series;
//    private List series1;
//
//    public Series() {
//        //this.series = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
//
//    }
//
//    public Double[] getSeries() {
//        return series;
//    }
//
//    public void setSeries(Double[] series) {
//        this.series = series;
//    }
//
//    public void setSeries1(List series1) {
//        this.series1 = series1;
//    }
    public ArrayList getSeries() {
        return series;
    }

    public void setSeries(ArrayList series) {
        this.series = series;
    }

}
