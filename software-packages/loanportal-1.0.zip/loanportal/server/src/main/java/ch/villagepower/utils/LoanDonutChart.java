/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.utils;


import java.util.Date;
import java.util.List;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
public class LoanDonutChart {

    private List<Nummber> numbers;
    private List<Collection> collections;
    private List<Repayment> repayments;

    private Double totalCollections;
    private Double totalRepayments;
    private Double totalLoans;
    private int numberOverdueLoans;
    private int writeOffAmount;
    private int recoveryAmount;
    private int outstanding;
    private Double accountsDefaulted;
    private Double accountsReposessed;

    private Double valueRecoveredReposessed;
    private Double outstandingDefaulted;

    private Date latsUpdated;

    public Double getAccountsDefaulted() {
        return accountsDefaulted;
    }

    public void setAccountsDefaulted(Double accountsDefaulted) {
        this.accountsDefaulted = accountsDefaulted;
    }

    public Double getAccountsReposessed() {
        return accountsReposessed;
    }

    public void setAccountsReposessed(Double accountsReposessed) {
        this.accountsReposessed = accountsReposessed;
    }

    public Double getValueRecoveredReposessed() {
        return valueRecoveredReposessed;
    }

    public void setValueRecoveredReposessed(Double valueRecoveredReposessed) {
        this.valueRecoveredReposessed = valueRecoveredReposessed;
    }

    public Double getOutstandingDefaulted() {
        return outstandingDefaulted;
    }

    public void setOutstandingDefaulted(Double outstandingDefaulted) {
        this.outstandingDefaulted = outstandingDefaulted;
    }

    public int getWriteOffAmount() {
        return writeOffAmount;
    }

    public void setWriteOffAmount(int writeOffAmount) {
        this.writeOffAmount = writeOffAmount;
    }

    public int getOutstanding() {
        return outstanding;
    }

    public void setOutstanding(int outstanding) {
        this.outstanding = outstanding;
    }

    public int getRecoveryAmount() {
        return recoveryAmount;
    }

    public void setRecoveryAmount(int recoveryAmount) {
        this.recoveryAmount = recoveryAmount;
    }

    public int getNumberOverdueLoans() {
        return numberOverdueLoans;
    }

    public void setNumberOverdueLoans(int numberOverdueLoans) {
        this.numberOverdueLoans = numberOverdueLoans;
    }

    public Double getTotalCollections() {
        return totalCollections;
    }

    public void setTotalCollections(Double totalCollections) {
        this.totalCollections = totalCollections;
    }

    public Double getTotalRepayments() {
        return totalRepayments;
    }

    public void setTotalRepayments(Double totalRepayments) {
        this.totalRepayments = totalRepayments;
    }

    public Double getTotalLoans() {
        return totalLoans;
    }

    public void setTotalLoans(Double totalLoans) {
        this.totalLoans = totalLoans;
    }

    public Date getLatsUpdated() {
        return latsUpdated;
    }

    public void setLatsUpdated(Date latsUpdated) {
        this.latsUpdated = latsUpdated;
    }

    public List<Repayment> getRepayments() {
        return repayments;
    }

    public void setRepayments(List<Repayment> repayments) {
        this.repayments = repayments;
    }

    public List<Collection> getCollections() {
        return collections;
    }

    public void setCollections(List<Collection> collections) {
        this.collections = collections;
    }

    public List<Nummber> getNumbers() {
        return numbers;
    }

    public void setNumbers(List<Nummber> numbers) {
        this.numbers = numbers;
    }

}
