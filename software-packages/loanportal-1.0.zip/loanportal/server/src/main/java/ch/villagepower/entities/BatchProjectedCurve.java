/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import io.swagger.annotations.ApiModel;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Entity
@Table(name = "batch_projected_curve")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "BatchProjectedCurve.findAll", query = "SELECT b FROM BatchProjectedCurve b"),
    @NamedQuery(name = "BatchProjectedCurve.findByIdbatchProjectedCurve", query = "SELECT b FROM BatchProjectedCurve b WHERE b.idbatchProjectedCurve = :idbatchProjectedCurve"),
    @NamedQuery(name = "BatchProjectedCurve.findByProjectedValue", query = "SELECT b FROM BatchProjectedCurve b WHERE b.projectedValue = :projectedValue"),
    @NamedQuery(name = "BatchProjectedCurve.findByProjectedTime", query = "SELECT b FROM BatchProjectedCurve b WHERE b.projectedTime = :projectedTime")})
@ApiModel
public class BatchProjectedCurve implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idbatch_projected_curve")
    private Integer idbatchProjectedCurve;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "projected_value")
    private Double projectedValue;
    @Column(name = "projected_time")
    private Integer projectedTime;
    @JoinColumn(name = "Batch_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Batch batchid;

    public BatchProjectedCurve() {
    }

    public BatchProjectedCurve(Integer idbatchProjectedCurve) {
        this.idbatchProjectedCurve = idbatchProjectedCurve;
    }

    public Integer getIdbatchProjectedCurve() {
        return idbatchProjectedCurve;
    }

    public void setIdbatchProjectedCurve(Integer idbatchProjectedCurve) {
        this.idbatchProjectedCurve = idbatchProjectedCurve;
    }

    public Double getProjectedValue() {
        return projectedValue;
    }

    public void setProjectedValue(Double projectedValue) {
        this.projectedValue = projectedValue;
    }

    public Integer getProjectedTime() {
        return projectedTime;
    }

    public void setProjectedTime(Integer projectedTime) {
        this.projectedTime = projectedTime;
    }

    public Batch getBatchid() {
        return batchid;
    }

    public void setBatchid(Batch batchid) {
        this.batchid = batchid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idbatchProjectedCurve != null ? idbatchProjectedCurve.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof BatchProjectedCurve)) {
            return false;
        }
        BatchProjectedCurve other = (BatchProjectedCurve) object;
        if ((this.idbatchProjectedCurve == null && other.idbatchProjectedCurve != null) || (this.idbatchProjectedCurve != null && !this.idbatchProjectedCurve.equals(other.idbatchProjectedCurve))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.BatchProjectedCurve[ idbatchProjectedCurve=" + idbatchProjectedCurve + " ]";
    }

}
