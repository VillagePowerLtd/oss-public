/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;


import ch.villagepower.entities.Batch;
import ch.villagepower.entities.BatchAnalysis;
import ch.villagepower.entities.BatchProjectedCurve;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Stateless
public class BatchAnalysisService {

    @PersistenceContext
    private EntityManager em;

    public List<BatchAnalysis> getBatchAnalysis(Batch b) {

        List<BatchAnalysis> baas = em.createQuery("SELECT g FROM BatchAnalysis g WHERE  g.batchid = :a")
                .setParameter("a", b)
                .getResultList();

        return baas;

    }

    public List<BatchProjectedCurve> getBatchProjected(Batch b) {

        List<BatchProjectedCurve> bpc = em.createQuery("SELECT g FROM BatchProjectedCurve g WHERE  g.batchid = :a")
                .setParameter("a", b)
                .getResultList();

        return bpc;

    }

    public List<BatchProjectedCurve> getBatchValueTime(Batch b, int x) {

        List<BatchProjectedCurve> bpc = em.createQuery("SELECT g FROM BatchProjectedCurve g WHERE  g.batchid = :a AND g.projectedTime=:b")
                .setParameter("a", b)
                .setParameter("b", x)
                .getResultList();

        return bpc;

    }

    //return batch analysis byt id
    public BatchAnalysis batchAnalysisById(Integer id) {

        BatchAnalysis batchA = em.find(BatchAnalysis.class, id);

        return batchA;
    }

    public List<BatchAnalysis> findAll() {

        List<BatchAnalysis> bas;

        Query q = em.createQuery("from BatchAnalysis", BatchAnalysis.class);

        bas = q.getResultList();

        return bas;

    }

}
