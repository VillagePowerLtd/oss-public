/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.rest;


import ch.villagepower.dao.BatchAnalysisService;
import ch.villagepower.dao.BatchLoanService;
import ch.villagepower.entities.Batch;
import ch.villagepower.dao.BatchService;
import ch.villagepower.dao.DepositService;
import ch.villagepower.dao.LoanService;
import ch.villagepower.dao.PortfolioService;
import ch.villagepower.dao.SaveService;
import ch.villagepower.dao.ChartService;
import ch.villagepower.dao.PaymentService;
import ch.villagepower.dao.UserBatchService;
import ch.villagepower.dao.UserService;
import ch.villagepower.entities.ActualPercentage;
import ch.villagepower.entities.BatchAnalysis;
import ch.villagepower.entities.BatchProjectedCurve;
import ch.villagepower.entities.BatchhasLoan;
import ch.villagepower.entities.BatchhasLoanPK;
import ch.villagepower.entities.Deposit;
import ch.villagepower.entities.Loan;
import ch.villagepower.entities.LoanPerformance;
import ch.villagepower.entities.NumberofLoans;
import ch.villagepower.entities.OverdueLoansByNumber;
import ch.villagepower.entities.OverdueLoansByValue;
import ch.villagepower.entities.PaymentStatus;
import ch.villagepower.entities.Payments;
import ch.villagepower.entities.Percentage;
import ch.villagepower.entities.Portfolio;
import ch.villagepower.entities.RestructuredLoans;
import ch.villagepower.entities.UserBatch;
import ch.villagepower.entities.Users;
import ch.villagepower.filter.Role;
import ch.villagepower.filter.Secured;
import ch.villagepower.utils.AmountOfOverdueLoans;
import ch.villagepower.utils.Collection;
import ch.villagepower.utils.Collections;
import ch.villagepower.utils.LoanBarGraph;
import ch.villagepower.utils.LoanDonutChart;

import ch.villagepower.utils.JsonInput;
import ch.villagepower.utils.JsonReply;
import ch.villagepower.utils.NumberOfOverdueLoans;
import ch.villagepower.utils.Numbers;
import ch.villagepower.utils.Nummber;
import ch.villagepower.utils.PrintJson;
import ch.villagepower.utils.Repayment;
import ch.villagepower.utils.Repayments;
import ch.villagepower.utils.Restructured;
import ch.villagepower.utils.RestructuredLoan;
import ch.villagepower.utils.Series;
import ch.villagepower.utils.WriteOffsRecovery;
import com.google.gson.Gson;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.Principal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;

import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.SecurityContext;
import org.apache.log4j.Logger;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.LocalDate;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
//@Secured({Role.administrator})
@Path("batch")
@Api(value = "batch", description = "Endpoint for Batch specific operations")
public class BatchResource {

    final static Logger log = Logger.getLogger(BatchResource.class.getName());

    @EJB
    BatchService batchService = new BatchService();

    @EJB
    SaveService save = new SaveService();

    @EJB
    PortfolioService psService = new PortfolioService();

    @EJB
    LoanService loanService = new LoanService();

    @EJB
    ChartService chartService = new ChartService();

    @EJB
    DepositService depositService = new DepositService();

    @EJB
    BatchLoanService bhlService = new BatchLoanService();

    @EJB
    UserService userService = new UserService();

    @EJB
    UserBatchService ubService = new UserBatchService();

    @EJB
    PaymentService pService = new PaymentService();

    @EJB
    PaymentService paymentService = new PaymentService();

    @EJB
    BatchAnalysisService baService = new BatchAnalysisService();

    @Context
    SecurityContext securityContext;

    Gson gson;
    JsonReply reply;
    JsonInput input;

    //**************endpoint for all summary*****************
    @POST
    @Path("summaryOfLoans")
    @Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Summary details", notes = "Returns Chart Summary details.", response = LoanDonutChart.class)
    public String findSummaryLoans(@Context Request req, @ApiParam(value = "JsonInput.Batch") String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("findSummaryLoans");

        gson = new Gson();

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.batch != null) {

                List<Loan> l = loanService.findAllWithLimit(100);
                List<NumberofLoans> numberLoans = chartService.getBatchNumberOfLoansCurrentMonth(input.batch.getId());
                if (numberLoans.isEmpty()) {
                    reply.setError("No Summary for current month loans in batch");
                } else {

                    List<Nummber> number = new ArrayList<>();
                    NumberofLoans nl = numberLoans.get(0);

                    Nummber within = new Nummber();
                    within.setLabel("Within");
                    within.setValue(String.valueOf(nl.getWithin()));

                    Nummber paidup = new Nummber();
                    paidup.setLabel("Paid Up");
                    paidup.setValue(String.valueOf(nl.getPaidUp()));

                    Nummber overdue = new Nummber();
                    overdue.setLabel("Overdue");
                    overdue.setValue(String.valueOf(nl.getOverDue()));

                    Nummber closed = new Nummber();
                    closed.setLabel("Defaulted");
                    closed.setValue(String.valueOf(nl.getClosed()));

                    Double totalLoans = nl.getWithin() + nl.getPaidUp() + nl.getOverDue() + nl.getClosed();
                    Double numberOverdueLoans = nl.getOverDue();
                    Double activeLoans = totalLoans - nl.getPaidUp() - nl.getPaidUp();
                    Double withinLoans = nl.getWithin();

                    number.add(within);
                    number.add(paidup);
                    number.add(overdue);
                    number.add(closed);

                    LoanDonutChart ldc = new LoanDonutChart();
                    ldc.setNumbers(number);

                    List<PaymentStatus> pss = chartService.getBatchRepaymentsCurrentMonth(input.batch.getId());

                    List<Repayment> repayments = new ArrayList<>();
                    PaymentStatus ps = pss.get(0);
                    Repayment rwithin = new Repayment();
                    rwithin.setLabel("Within");
                    rwithin.setValue(String.valueOf(ps.getWithin()));
                    Repayment rpaidup = new Repayment();
                    rpaidup.setLabel("Paid Up");
                    rpaidup.setValue(String.valueOf(ps.getPaidUp()));
                    Repayment roverdue = new Repayment();
                    roverdue.setLabel("Overdue");
                    roverdue.setValue(String.valueOf(ps.getOverDue()));
                    Repayment rclosed = new Repayment();
                    rclosed.setLabel("Defaulted");
                    rclosed.setValue(String.valueOf(ps.getClosed()));
                    Repayment rcollected = new Repayment();
                    rcollected.setLabel("Collected");
                    rcollected.setValue(String.valueOf(ps.getCollected()));
                    Repayment rdiscounted = new Repayment();
                    rdiscounted.setLabel("Discounted");
                    rdiscounted.setValue(String.valueOf(ps.getDiscountedAmount()));

                    Double totalRepayments = ps.getWithin() + ps.getOverDue() + ps.getPaidUp() + ps.getClosed() + ps.getCollected() + ps.getDiscountedAmount();

                    repayments.add(rwithin);
                    repayments.add(rclosed);
                    repayments.add(roverdue);
                    repayments.add(rpaidup);
                    repayments.add(rcollected);
                    repayments.add(rdiscounted);

                    ldc.setRepayments(repayments);

                    List<LoanPerformance> lps = chartService.getBatchCollectionsOfLoansCurrentMonth(input.batch.getId());

                    List<Collection> collections = new ArrayList<>();
                    LoanPerformance lp = lps.get(0);
                    Collection cwithin = new Collection();
                    cwithin.setLabel("Payments Within Plan");
                    cwithin.setValue(String.valueOf(lp.getPaymentsWithin()));
                    collections.add(cwithin);
                    Collection cpaidup = new Collection();
                    cpaidup.setLabel("Payments Overdue");
                    cpaidup.setValue(String.valueOf(lp.getPaymentsBehind()));
                    collections.add(cpaidup);
                    Collection outstandingWithin = new Collection();
                    outstandingWithin.setLabel("Balance Within");
                    outstandingWithin.setValue(String.valueOf(lp.getOutstandingWithin()));
                    collections.add(outstandingWithin);
                    Collection outstandingOverdue = new Collection();
                    outstandingOverdue.setLabel("Balance Overdue");
                    outstandingOverdue.setValue(String.valueOf(lp.getOutstandingOverdue()));
                    collections.add(outstandingOverdue);

                    if (lp.getDefaultedAmount() != 0) {
                        Collection default1 = new Collection();
                        default1.setLabel("Default");
                        default1.setValue(String.valueOf(lp.getDefaultedAmount()));
                        collections.add(default1);

                    }
                    if (lp.getDiscountedAmount() != 0) {
                        Collection discount = new Collection();
                        discount.setLabel("Discount");
                        discount.setValue(String.valueOf(lp.getDiscountedAmount()));
                        collections.add(discount);
                    }

                    Double totalCollections = lp.getCollected() + lp.getOutstanding();

                    List<OverdueLoansByValue> odByValue = chartService.getBatchOverdueLoansByValueCurrent(input.batch.getId());
                    Double writeOffAmount = odByValue.get(0).getOutstandingOnDefaulted();

                    ldc.setCollections(collections);

                    //display date of last table/process update
                    if (l.get(99).getUploadDate().before(nl.getDateCreated())) {
                        ldc.setLatsUpdated(l.get(99).getUploadDate());
                    } else {
                        ldc.setLatsUpdated(nl.getDateCreated());
                    }

                    ldc.setTotalLoans(totalLoans);
                    ldc.setTotalCollections(totalCollections);
                    ldc.setTotalRepayments(totalRepayments);
                    ldc.setNumberOverdueLoans((int) (numberOverdueLoans / (numberOverdueLoans + withinLoans) * 100.0));
                    ldc.setWriteOffAmount((int) (writeOffAmount * 1000000));
                    ldc.setRecoveryAmount((int) ((writeOffAmount * 1000000) / 2));
                    //ldc.setOutstanding(ps.getOverDue());
                    ldc.setOutstanding((int) (lp.getOutstandingOverdue() / (lp.getOutstandingWithin() + lp.getOutstandingOverdue()) * 100.0));
                    ldc.setAccountsDefaulted(nl.getClosed() - nl.getRecovered());
                    ldc.setAccountsReposessed(nl.getRecovered());
                    ldc.setOutstandingDefaulted(ps.getClosed());
                    ldc.setValueRecoveredReposessed(ps.getClosed());

                    reply.loanDonutChart = ldc;
                    reply.setSucc("Found Summary");

                }

            } else {
                log.info("Please Send some JSON or Send Batch object");
                reply.setError("Please Send some JSON or Send Batch object");

            }

        } catch (com.google.gson.JsonSyntaxException | NullPointerException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR" + ex.getMessage());
        }

        return reply.toString();

    }

    //**************endpoint for batch chart*****************
    @POST
    @Path("batchChart")
    @Produces(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @SuppressWarnings("empty-statement")
    @ApiOperation(value = "Detailed details", notes = "Returns Chart Detailed details.", response = LoanBarGraph.class)
    public String findBatchChart(@Context Request req, @ApiParam(value = "JsonInput.Batch") String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("findBatchChart");

        gson = new Gson();
        //INNIT JSON INPUT
        input = new JsonInput();

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);

            if (input != null && input.batch != null) {

                //check if batch was calculated for current month
                List<NumberofLoans> numberLoans = chartService.getBatchNumberOfLoans(input.batch.getId());
                if (!numberLoans.isEmpty()) {

                    //Now retrieve for UI 
                    List<NumberofLoans> numbLoans = chartService.getBatchNumberOfLoans(input.batch.getId());
                    List<OverdueLoansByNumber> odByNumber = chartService.getBatchOverdueLoansByNumber(input.batch.getId());
                    List<OverdueLoansByValue> odByValue = chartService.getBatchOverdueLoansByValue(input.batch.getId());
                    List<LoanPerformance> lps = chartService.getBatchLoanPerformance(input.batch.getId());
                    List<PaymentStatus> pss = chartService.getBatchPaymentStatus(input.batch.getId());
                    List<RestructuredLoans> rl = chartService.getBatchRestructuredLoans(input.batch.getId());

                    //twelve months data
                    ArrayList sW = new ArrayList();
                    ArrayList sO = new ArrayList();
                    ArrayList sP = new ArrayList();
                    ArrayList sC = new ArrayList();
                    ArrayList sCC = new ArrayList();
                    ArrayList sDD = new ArrayList();

                    //populate bar graph
                    Series seriesW = new Series();
                    Series seriesO = new Series();
                    Series seriesP = new Series();
                    Series seriesC = new Series();

                    //reset UI objects
                    //views/graphs for UI
                    AmountOfOverdueLoans aol = new AmountOfOverdueLoans();
                    Repayments r = new Repayments();
                    Collections c = new Collections();
                    RestructuredLoan rloans = new RestructuredLoan();
                    RestructuredLoan rloansValue = new RestructuredLoan();
                    Numbers n = new Numbers();
                    NumberOfOverdueLoans nol = new NumberOfOverdueLoans();
                    WriteOffsRecovery wor = new WriteOffsRecovery();
                    Restructured rst = new Restructured();

                    ArrayList month = new ArrayList();
                    List<ArrayList> serie = new ArrayList<>();
                    serie.add(sW);
                    serie.add(sO);
                    serie.add(sP);
                    serie.add(sC);

                    //number of loans for current month and previous months
                    for (NumberofLoans result : numbLoans) {
                        if(!input.display.equalsIgnoreCase("quarterly")){
                            
                        switch (result.getMonth()) {
                            case "7":
                                setUpMonth(month, 6, serie, "JUL", result);
                                break;
                            case "4":
                                setUpMonth(month, 3, serie, "APR", result);
                                break;
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "2":
                                setUpMonth(month, 1, serie, "FEB", result);
                                break;
                            case "1":
                                setUpMonth(month, 0, serie, "JAN", result);
                                break;
                            case "8":
                                setUpMonth(month, 7, serie, "AUG", result);
                                break;
                            case "5":
                                setUpMonth(month, 4, serie, "MAY", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "10":
                                setUpMonth(month, 9, serie, "OCT", result);
                                break;
                            case "11":
                                setUpMonth(month, 10, serie, "NOV", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }
                      }else{
                            switch (result.getMonth()) {
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }
                        }
                    }

                    seriesW.setSeries(sW);
                    seriesO.setSeries(sO);
                    seriesP.setSeries(sP);
                    seriesC.setSeries(sC);
                    //log.info("object"+seriesW.getSeries().toString());

                    List<Series> s = new ArrayList<>();
                    s.add(seriesW);
                    s.add(seriesO);
                    s.add(seriesP);
                    s.add(seriesC);

                    n.setSeries(s);
                    n.setLabels(month);

                    LoanBarGraph lbg = new LoanBarGraph();
                    lbg.setNumbers(n);

                    //resetData(sW,sO,sP,sC,seriesW,seriesO,seriesP,seriesC);
                    sW = new ArrayList();
                    sP = new ArrayList();
                    sC = new ArrayList();
                    sO = new ArrayList();
                    sCC = new ArrayList();
                    sDD = new ArrayList();

                    month = new ArrayList();
                    serie = new ArrayList();
                    serie.add(sW);
                    serie.add(sO);
                    serie.add(sP);
                    serie.add(sC);
                    serie.add(sCC);
                    serie.add(sDD);

                    //reset UI objects
                    seriesW = new Series();
                    seriesO = new Series();
                    seriesP = new Series();
                    seriesC = new Series();
                    Series seriesCC = new Series();
                    Series seriesDD = new Series();

//                        //payment status of loans for current month and previous months
                    for (PaymentStatus result : pss) {
                        if(!input.display.equalsIgnoreCase("quarterly")){
                        switch (result.getMonth()) {
                            case "7":
                                setUpMonth(month, 6, serie, "JUL", result);
                                break;
                            case "4":
                                setUpMonth(month, 3, serie, "APR", result);
                                break;
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "2":
                                setUpMonth(month, 1, serie, "FEB", result);
                                break;
                            case "1":
                                setUpMonth(month, 0, serie, "JAN", result);
                                break;
                            case "8":
                                setUpMonth(month, 7, serie, "AUG", result);
                                break;
                            case "5":
                                setUpMonth(month, 4, serie, "MAY", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "10":
                                setUpMonth(month, 9, serie, "OCT", result);
                                break;
                            case "11":
                                setUpMonth(month, 10, serie, "NOV", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }}else{
                            switch (result.getMonth()) {
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }
                        }
                    }

                    //populate repayments                              
                    seriesW.setSeries(sW);
                    seriesO.setSeries(sO);
                    seriesP.setSeries(sP);
                    seriesC.setSeries(sC);
                    seriesCC.setSeries(sCC);
                    seriesDD.setSeries(sDD);

                    List<Series> s1 = new ArrayList<>();
                    s1.add(seriesW);
                    s1.add(seriesO);
                    s1.add(seriesP);
                    s1.add(seriesC);
                    s1.add(seriesCC);
                    s1.add(seriesDD);

                    r.setSeries(s1);
                    r.setLabels(month);

                    //repayments graph
                    lbg.setRepayments(r);

                    //reset datastructure for next graph
                    sW = new ArrayList();
                    sP = new ArrayList();
                    sC = new ArrayList();
                    sO = new ArrayList();
                    sCC = new ArrayList();
                    sDD = new ArrayList();

                    month = new ArrayList();
                    serie = new ArrayList();
                    serie.add(sW);
                    serie.add(sO);
                    serie.add(sP);
                    serie.add(sC);
                    serie.add(sCC);

                    //reset UI objects
                    seriesW = new Series();
                    seriesO = new Series();
                    seriesP = new Series();
                    seriesC = new Series();
                    seriesCC = new Series();
//                        seriesDD = new Series();//not being used here

                    //overdue value loans for current month and previous months
                    for (OverdueLoansByValue result : odByValue) {
                        if(!input.display.equalsIgnoreCase("quarterly")){
                        switch (result.getMonth()) {
                            case "7":
                                setUpMonth(month, 6, serie, "JUL", result);
                                break;
                            case "4":
                                setUpMonth(month, 3, serie, "APR", result);
                                break;
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "2":
                                setUpMonth(month, 1, serie, "FEB", result);
                                break;
                            case "1":
                                setUpMonth(month, 0, serie, "JAN", result);
                                break;
                            case "8":
                                setUpMonth(month, 7, serie, "AUG", result);
                                break;
                            case "5":
                                setUpMonth(month, 4, serie, "MAY", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "10":
                                setUpMonth(month, 9, serie, "OCT", result);
                                break;
                            case "11":
                                setUpMonth(month, 10, serie, "NOV", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }
                        }else{
                            switch (result.getMonth()) {
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }
                        }
                    }
                    //populate series object for UI
                    seriesW.setSeries(sW);
                    seriesO.setSeries(sO);
                    seriesP.setSeries(sP);
                    seriesC.setSeries(sC);
                    seriesCC.setSeries(sCC);

                    //populate overdue loans by value
                    List<Series> s4 = new ArrayList<>();
                    s4.add(seriesW);
                    s4.add(seriesO);
                    s4.add(seriesP);
                    s4.add(seriesC);
                    s4.add(seriesCC);
                    aol.setSeries(s4);
                    aol.setLabels(month);

                    //Value of overdue loans graph
                    lbg.setAmountOfOverdueLoan(aol);

//                        //reset datastructure for next graph
                    sW = new ArrayList();
                    sP = new ArrayList();
                    sC = new ArrayList();
                    sO = new ArrayList();
                    sCC = new ArrayList();

                    month = new ArrayList();
                    serie = new ArrayList();
                    serie.add(sW);
                    serie.add(sO);
                    serie.add(sP);
                    serie.add(sC);
                    serie.add(sCC);

//                        //reset UI objects
                    seriesW = new Series();
                    seriesO = new Series();
                    seriesP = new Series();
                    seriesC = new Series();
                    seriesCC = new Series();

                    //overdue number  loans for current month and previous months
                    for (OverdueLoansByNumber result : odByNumber) {
                        if(!input.display.equalsIgnoreCase("quarterly")){
                        switch (result.getMonth()) {
                            case "7":
                                setUpMonth(month, 6, serie, "JUL", result);
                                break;
                            case "4":
                                setUpMonth(month, 3, serie, "APR", result);
                                break;
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "2":
                                setUpMonth(month, 1, serie, "FEB", result);
                                break;
                            case "1":
                                setUpMonth(month, 0, serie, "JAN", result);
                                break;
                            case "8":
                                setUpMonth(month, 7, serie, "AUG", result);
                                break;
                            case "5":
                                setUpMonth(month, 4, serie, "MAY", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "10":
                                setUpMonth(month, 9, serie, "OCT", result);
                                break;
                            case "11":
                                setUpMonth(month, 10, serie, "NOV", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }
                        }else{
                            switch (result.getMonth()) {
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }
                        }
                    }

                    //populate series object for UI
                    seriesW.setSeries(sW);
                    seriesO.setSeries(sO);
                    seriesP.setSeries(sP);
                    seriesC.setSeries(sC);
                    seriesCC.setSeries(sCC);

                    //populate overdue loans by value
                    List<Series> s5 = new ArrayList<>();
                    s5.add(seriesW);
                    s5.add(seriesO);
                    s5.add(seriesP);
                    s5.add(seriesC);
                    s5.add(seriesCC);
                    nol.setSeries(s5);
                    nol.setLabels(month);

                    //Number of Over due loans graph
                    lbg.setNumberOfOverdueLoans(nol);

                    //reset datastructure for next graph
                    sW = new ArrayList();
                    sP = new ArrayList();
                    sC = new ArrayList();
                    sO = new ArrayList();
                    sCC = new ArrayList();
                    sDD = new ArrayList();

                    month = new ArrayList();
                    serie = new ArrayList();
                    serie.add(sW);
                    serie.add(sO);
                    serie.add(sP);
                    serie.add(sC);
                    serie.add(sCC);
                    serie.add(sDD);

                    //reset UI objects
                    seriesW = new Series();
                    seriesO = new Series();
                    seriesP = new Series();
                    seriesC = new Series();
                    seriesCC = new Series();
                    seriesDD = new Series();

                    //Loan Perfoemance data
                    for (LoanPerformance result : lps) {
                        if(!input.display.equalsIgnoreCase("quarterly")){
                        switch (result.getMonth()) {
                            case "7":
                                setUpMonth(month, 6, serie, "JUL", result);
                                break;
                            case "4":
                                setUpMonth(month, 3, serie, "APR", result);
                                break;
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "2":
                                setUpMonth(month, 1, serie, "FEB", result);
                                break;
                            case "1":
                                setUpMonth(month, 0, serie, "JAN", result);
                                break;
                            case "8":
                                setUpMonth(month, 7, serie, "AUG", result);
                                break;
                            case "5":
                                setUpMonth(month, 4, serie, "MAY", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "10":
                                setUpMonth(month, 9, serie, "OCT", result);
                                break;
                            case "11":
                                setUpMonth(month, 10, serie, "NOV", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }
                        }else{
                            switch (result.getMonth()) {
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }
                        }
                    }

                    //populate collections
                    seriesW.setSeries(sW);
                    seriesO.setSeries(sO);
                    seriesP.setSeries(sP);
                    seriesC.setSeries(sC);
                    seriesCC.setSeries(sCC);
                    seriesDD.setSeries(sDD);

                    List<Series> s3 = new ArrayList<>();
                    s3.add(seriesW);
                    s3.add(seriesO);
                    s3.add(seriesP);
                    s3.add(seriesC);
                    s3.add(seriesCC);
                    s3.add(seriesDD);

                    c.setSeries(s3);
                    c.setLabels(month);

                    //collections graph
                    lbg.setCollections(c);

                    //reset datastructure for next graph
                    sW = new ArrayList();
                    sP = new ArrayList();
                    sC = new ArrayList();
                    sO = new ArrayList();
                    sCC = new ArrayList();
                    sDD = new ArrayList();

                    month = new ArrayList();
                    serie = new ArrayList();
                    serie.add(sW);

                    //reset UI objects
                    seriesW = new Series();

                    //Loan Restructured data
                    for (RestructuredLoans result : rl) {
                        if(!input.display.equalsIgnoreCase("quarterly")){
                        switch (result.getMonth()) {
                            case "7":
                                setUpMonth(month, 6, serie, "JUL", result);
                                break;
                            case "4":
                                setUpMonth(month, 3, serie, "APR", result);
                                break;
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "2":
                                setUpMonth(month, 1, serie, "FEB", result);
                                break;
                            case "1":
                                setUpMonth(month, 0, serie, "JAN", result);
                                break;
                            case "8":
                                setUpMonth(month, 7, serie, "AUG", result);
                                break;
                            case "5":
                                setUpMonth(month, 4, serie, "MAY", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "10":
                                setUpMonth(month, 9, serie, "OCT", result);
                                break;
                            case "11":
                                setUpMonth(month, 10, serie, "NOV", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }
                        }else{
                            switch (result.getMonth()) {
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }
                        }
                    }

                    //populate collections
                    seriesW.setSeries(sW);

                    List<Series> s7 = new ArrayList<>();
                    s7.add(seriesW);

                    rloans.setSeries(s7);
                    rloans.setLabels(month);

                    //collections graph
                    lbg.setRestructuredLoanNumber(rloans);

                    //reset datastructure for next graph
                    sW = new ArrayList();
                    sP = new ArrayList();
                    sC = new ArrayList();
                    sO = new ArrayList();
                    sCC = new ArrayList();
                    sDD = new ArrayList();

                    month = new ArrayList();
                    serie = new ArrayList();
                    serie.add(sW);
                    serie.add(sO);

                    //reset UI objects
                    seriesW = new Series();
                    seriesO = new Series();

                    //Loan Restructured data
                    for (RestructuredLoans result : rl) {
                        if(!input.display.equalsIgnoreCase("quarterly")){
                        switch (result.getMonth()) {
                            case "7":
                                setUpMonth(month, 6, serie, "JUL", result);
                                break;
                            case "4":
                                setUpMonth(month, 3, serie, "APR", result);
                                break;
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "2":
                                setUpMonth(month, 1, serie, "FEB", result);
                                break;
                            case "1":
                                setUpMonth(month, 0, serie, "JAN", result);
                                break;
                            case "8":
                                setUpMonth(month, 7, serie, "AUG", result);
                                break;
                            case "5":
                                setUpMonth(month, 4, serie, "MAY", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "10":
                                setUpMonth(month, 9, serie, "OCT", result);
                                break;
                            case "11":
                                setUpMonth(month, 10, serie, "NOV", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }
}else{
                            switch (result.getMonth()) {
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }
                        }
                    }

                    //populate collections
                    seriesW.setSeries(sW);
                    seriesO.setSeries(sO);

                    List<Series> s8 = new ArrayList<>();
                    s8.add(seriesW);
                    s8.add(seriesO);

                    rloansValue.setSeries(s8);
                    rloansValue.setLabels(month);

                    //collections graph
                    lbg.setRestructuredLoanValue(rloansValue);

//                        //reset datastructure for next graph
                    sW = new ArrayList();
                    sO = new ArrayList();
                    sP = new ArrayList();

                    month = new ArrayList();
                    serie = new ArrayList();
                    serie.add(sW);
                    serie.add(sO);

                    //reset UI objects
                    seriesW = new Series();
                    seriesO = new Series();

                    //overdue value loans for current month and previous months
                    for (OverdueLoansByValue result : odByValue) {
                        if(!input.display.equalsIgnoreCase("quarterly")){
                        switch (result.getMonth()) {
                            case "7":
                                setUpMonth(month, 6, serie, "JUL", result);
                                break;
                            case "4":
                                setUpMonth(month, 3, serie, "APR", result);
                                break;
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "2":
                                setUpMonth(month, 1, serie, "FEB", result);
                                break;
                            case "1":
                                setUpMonth(month, 0, serie, "JAN", result);
                                break;
                            case "8":
                                setUpMonth(month, 7, serie, "AUG", result);
                                break;
                            case "5":
                                setUpMonth(month, 4, serie, "MAY", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "10":
                                setUpMonth(month, 9, serie, "OCT", result);
                                break;
                            case "11":
                                setUpMonth(month, 10, serie, "NOV", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }
                        }else{
                            switch (result.getMonth()) {
                            case "3":
                                setUpMonth(month, 2, serie, "MAR", result);
                                break;
                            case "6":
                                setUpMonth(month, 5, serie, "JUN", result);
                                break;
                            case "9":
                                setUpMonth(month, 8, serie, "SEP", result);
                                break;
                            case "12":
                                setUpMonth(month, 11, serie, "DEC", result);
                                break;
                            default:

                        }
                        }
                    }
                    //populate series object for UI
                    seriesW.setSeries(sW);
                    seriesO.setSeries(sO);

                    //populate overdue loans by value
                    List<Series> s6 = new ArrayList<>();
                    s6.add(seriesW);
                    s6.add(seriesO);

                    wor.setSeries(s6);
                    wor.setLabels(month);

                    //Value of overdue loans graph
                    lbg.setWriteOffsRecovery(wor);

                    //Restructured Graph
                    List<String> days = new ArrayList<>();
                    List<BigDecimal> actual = new ArrayList<>();
                    List<BatchAnalysis> ba = baService.getBatchAnalysis(input.batch);

                    ArrayList ar1 = new ArrayList<>();
                    double y = 20;

                    if (!ba.isEmpty()) {
                        if (ba.get(0).getAnalysisDays() > 80 && ba.get(0).getAnalysisDays() < 540) {

                            List<BatchProjectedCurve> bpc = baService.getBatchProjected(input.batch);
                            for (BatchProjectedCurve bp : bpc) {

                                ar1.add(bp.getProjectedValue());
                                days.add(String.valueOf(bp.getProjectedTime()));
                            }
                            reply.displayCurve="Weeks";

                        } else if (ba.get(0).getAnalysisDays() > 540) {
                            List<BatchProjectedCurve> bpc = baService.getBatchProjected(input.batch);
                            for (BatchProjectedCurve bp : bpc) {

                                ar1.add(bp.getProjectedValue());
                                days.add(String.valueOf(bp.getProjectedTime()));
                            }
                            reply.displayCurve="Months";

                        } else {

                            List<BatchProjectedCurve> bpc = baService.getBatchProjected(input.batch);
                            for (BatchProjectedCurve bp : bpc) {

                                ar1.add(bp.getProjectedValue());
                                days.add(String.valueOf(bp.getProjectedTime()));
                            }
                            reply.displayCurve="Days";

                        }

                        // for later
                        List<ActualPercentage> apc = pService.findPercentByBatch(input.batch.getId());
                        for (ActualPercentage ac : apc) {

                            actual.add(BigDecimal.valueOf(Math.round(ac.getActualPercent2() * 1000.0) / 10.0));
                            //actual.add(ac.getActualPercent().multiply(BigDecimal.valueOf(1000.0)).divide(BigDecimal.valueOf(10.0)));

                        }

                        rst.setLabels(days);
                        rst.setActual(actual);
                        rst.setExpected(ar1);
                        lbg.setRestructured(rst);

                    }

                    if(input.display.equalsIgnoreCase("quarterly")){
                        reply.display="quarterly";
                    }
                    reply.loanBarGraph = lbg;
                    reply.setSucc("Graph exists");

                } else {

                    log.info("Please update the graphs");
                    reply.setError("Please update the Graphs");

                }

            } else {
                log.info("Please Send some JSON or Send Batch object");
                reply.setError("Please Send some JSON or Send Batch object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }
        return reply.toString();
    }

    //**************endpoint for update calculations*****************
    @POST
    @Path("updateBarGraph")
    @Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Update chart details", notes = "Update Chart details.", response = JsonReply.class)
    public String updateGraphs(@Context Request req, @ApiParam(value = "JsonInput.Batch") String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("updateGraphs");

        gson = new Gson();

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null) {

                if (input.batch != null) {
                    log.info("got batch---" + input.batch.toString());
            List<BatchhasLoan> bloans = bhlService.batchLoanByBatch(input.batch);
            List<BatchAnalysis> ba = baService.getBatchAnalysis(input.batch);

            if (bloans.isEmpty()) {
                log.info("No loans assigned to batch " + bloans.size());
                reply.setError("No loans assigned to batch");
            } else {

                Double w = 0.0, p = 0.0, o = 0.0, d = 0.0;
                Double wn = 0.0, pu = 0.0, od = 0.0, df = 0.0, dfOutstanding = 0.0, reposessed = 0.0;
                Double outWithin = 0.0, outPlanPaidUp = 0.0, outOverdue = 0.0, par1NumberLoans = 0.0, par30NumberLoans = 0.0, par60NumberLoans = 0.0, par90NumberLoans = 0.0;
                Double accountsDefaulted = 0.0, accountsReposessed = 0.0, accountsWithin = 0.0, accountsPaidUp = 0.0;
                Double collected = 0.0, outstanding = 0.0, par1 = 0.0, par30 = 0.0, par60 = 0.0, par90 = 0.0;

                double paymentsWithin = 0;
                double paymentsBehind = 0;
                double balanceDueToDate = 0;
                double amountPaidToDate = 0;
                double outstandingOverdue = 0;
                double outstandingWithin = 0;
                double defaulted = 0;
                double discounted = 0;
                double reposessedInstallments = 0;

                BigDecimal[] actualPercent = new BigDecimal[0];
                Integer[] ap = new Integer[0];
                Double[] actualPercent2 = new Double[0];
                Double[] ap2 = new Double[0];
                int ii = 0;

                if (!ba.isEmpty()) {

                    if (ba.get(0).getAnalysisDays() > 80 && ba.get(0).getAnalysisDays() < 540) {
                        actualPercent = new BigDecimal[ba.get(0).getAnalysisDays() / 7];
                        ap = new Integer[ba.get(0).getAnalysisDays() / 7];
                        actualPercent2 = new Double[ba.get(0).getAnalysisDays() / 7];
                        ap2 = new Double[ba.get(0).getAnalysisDays() / 7];
                        ii = ba.get(0).getAnalysisDays() / 7 - 1;

                        while (ii >= 0) {

                            actualPercent[ii] = BigDecimal.ZERO;
                            ap[ii] = 0;
                            actualPercent2[ii] = 0.0;
                            ap2[ii] = 0.0;

                            ii--;

                        }
                    } else if (ba.get(0).getAnalysisDays() > 540) {

                        actualPercent = new BigDecimal[ba.get(0).getAnalysisDays() / 30];
                        ap = new Integer[ba.get(0).getAnalysisDays() / 30];
                        ii = ba.get(0).getAnalysisDays() / 30 - 1;

                        while (ii >= 0) {

                            actualPercent[ii] = BigDecimal.ZERO;
                            ap[ii] = 0;
                            actualPercent2[ii] = 0.0;
                            ap2[ii] = 0.0;

                            ii--;

                        }

                    } else {

                        actualPercent = new BigDecimal[ba.get(0).getAnalysisDays()];
                        ap = new Integer[ba.get(0).getAnalysisDays()];
                        ii = ba.get(0).getAnalysisDays() - 1;

                        while (ii >= 0) {

                            actualPercent[ii] = BigDecimal.ZERO;
                            ap[ii] = 0;
                            actualPercent2[ii] = 0.0;
                            ap2[ii] = 0.0;

                            ii--;

                        }

                    }
                }
                double paidupExcess = 0.0;
                int restructured = 0;
                double outstandingRestructured = 0;
                double outstandingOverdueRestructured = 0;

                for (BatchhasLoan result : bloans) {
                    Loan l = loanService.loanById(result.getLoan().getId());

                    outstanding += l.getBalance();
                    collected += l.getInstallmentsPaid();
                    paymentsWithin += (l.getAmountPaidToDate() - l.getPaymentsBehind());
                    //paymentsWithin+=l.getPaymentsWithin();
                    paymentsBehind += l.getPaymentsBehind();
                    balanceDueToDate += l.getBalanceDueToDate();
                    amountPaidToDate += l.getAmountPaidToDate();
                    outstandingOverdue += l.getOutstandingOverdue();
                    outstandingWithin += l.getOutstandingWithin();
                    defaulted += l.getDefaultedAmount();
                    discounted += l.getDiscountedAmount();

                    switch (l.getStatus().toLowerCase()) {
                        case "within plan":
                            ++w;
                            wn += l.getTotalValueLoan();
                            outWithin += l.getBalance();
                            ++accountsWithin;
                            break;
                        case "paid up":
                            ++p;
                            pu += l.getTotalValueLoan();
                            outPlanPaidUp += l.getInstallmentsPaid() + l.getBalance();
                            paymentsWithin += l.getBalance();
                            paidupExcess += l.getBalance();
                            ++accountsPaidUp;
                            break;
                        case "overdue":
                            ++o;
                            od += l.getTotalValueLoan();
                            outOverdue += l.getBalance();
                            break;
                        case "defaulter":
                            ++d;
                            df += l.getTotalValueLoan();
                            dfOutstanding += l.getBalance();
                            ++accountsDefaulted;
                            break;
                        case "recovered":
                            reposessed += l.getBalance();
                            reposessedInstallments += l.getTotalAmountValue();
                            ++accountsReposessed;
                            break;
                        default:

                    }

                    switch (l.getPar()) {
                        case "PAR 1":
                            par1 += (l.getBalance());
                            ++par1NumberLoans;
                            break;
                        case "PAR 30":

                            par30 += (l.getBalance());
                            ++par30NumberLoans;
                            break;
                        case "PAR 60":

                            par60 += (l.getBalance());
                            ++par60NumberLoans;
                            break;
                        case "PAR 90":

                            par90 += (l.getBalance());
                            ++par90NumberLoans;
                            break;
                        default:

                    }

                    if (l.getRestructured()) {
                        restructured++;
                        outstandingRestructured += l.getRestructuredOutstanding();
                        outstandingOverdueRestructured += l.getValueOverdueRestructuring();
                    }

                    if (!ba.isEmpty()) {

                        if (ba.get(0).getAnalysisDays() > 80 && ba.get(0).getAnalysisDays() < 540) {

                            int g = 0;
                            for (int day = 0; day < ba.get(0).getAnalysisDays() - 1; day += 7) {
                                //double percent = 0.0;

                                List<Percentage> lns = paymentService.findPercentageByLoan(l, day, input.batch);

                                if (!lns.isEmpty() && lns.get(0).getPercentage()!=0) {
                                    actualPercent[g] = BigDecimal.valueOf(lns.get(0).getPercentage()).add(actualPercent[g]);
                                    ap[g] += 1;
                                    actualPercent2[g] += lns.get(0).getPreviousPayment();
                                    ap2[g] += lns.get(0).getModelTotal();
                                }

                                g++;

                            }

                        } else if (ba.get(0).getAnalysisDays() > 540) {

                            int g = 0;
                            for (int day = 0; day < ba.get(0).getAnalysisDays() - 1; day += 30) {
                                //double percent = 0.0;

                                List<Percentage> lns = paymentService.findPercentageByLoan(l, day, input.batch);

                                if (!lns.isEmpty() && lns.get(0).getPercentage()!=0 ) {
                                    actualPercent[g] = BigDecimal.valueOf(lns.get(0).getPercentage()).add(actualPercent[g]);
                                    ap[g] += 1;
                                    actualPercent2[g] += lns.get(0).getPreviousPayment();
                                    ap2[g] += lns.get(0).getModelTotal();
                                }

                                g++;

                            }

                        } else {

                            int g = 0;
                            for (int day = 0; day < ba.get(0).getAnalysisDays() - 1; day++) {
                                //double percent = 0.0;

                                List<Percentage> lns = paymentService.findPercentageByLoan(l, day, input.batch);

                                if (!lns.isEmpty() && lns.get(0).getPercentage()!=0) {
                                    actualPercent[g] = BigDecimal.valueOf(lns.get(0).getPercentage()).add(actualPercent[g]);
                                    ap[g] += 1;
                                    actualPercent2[g] += lns.get(0).getPreviousPayment();
                                    ap2[g] += lns.get(0).getModelTotal();
                                }

                                g++;

                            }

                        }
                    } else {
                        log.info("No batch curve analysis for batch " + input.batch.getId());
                    }

                }

                par1 = par1 / 1000000;
                par30 = par30 / 1000000;
                par60 = par60 / 1000000;  
                //par90 = (par90 - dfOutstanding - reposessed) / 1000000;
                par90 = (par90) / 1000000;//recovered accouts tracked separately from pa90

                RestructuredLoans rl = new RestructuredLoans();
                rl.setBatchid(input.batch.getId());
                rl.setDateCreated(PrintJson.timeZoneKla());
                Calendar cal = Calendar.getInstance();
                rl.setMonth(String.valueOf(cal.get(Calendar.MONTH) + 1));
                rl.setNumberRestructured(restructured);
                rl.setOutstandingRestructured(outstandingRestructured);
                rl.setOutstandingOverdueRestructured(outstandingOverdueRestructured);

                List<RestructuredLoans> RLnew = chartService.getBatchRestrucredMonth(rl.getMonth(), input.batch.getId());
                if (RLnew.isEmpty()) {
                    save.saveObject(rl);
                } else {
                    RLnew.get(0).setDateCreated(PrintJson.timeZoneKla());
                    RLnew.get(0).setNumberRestructured(restructured);
                    RLnew.get(0).setOutstandingRestructured(outstandingRestructured);
                    RLnew.get(0).setOutstandingOverdueRestructured(outstandingOverdueRestructured);

                    save.updateObject(RLnew.get(0));
                }

                NumberofLoans nl = new NumberofLoans();
                nl.setBatchid(input.batch.getId());
                nl.setDateCreated(PrintJson.timeZoneKla());
                nl.setMonth(String.valueOf(cal.get(Calendar.MONTH) + 1));
                nl.setOverDue(o);
                nl.setPaidUp(p);
                nl.setWithin(w);
                nl.setClosed(d + accountsReposessed);
                nl.setRecovered(accountsReposessed);
                List<NumberofLoans> NLnew = chartService.getBatchNumberMonth(nl.getMonth(), input.batch.getId());
                if (NLnew.isEmpty()) {
                    save.saveObject(nl);
                } else {
                    NLnew.get(0).setDateCreated(PrintJson.timeZoneKla());
                    NLnew.get(0).setOverDue(o);
                    NLnew.get(0).setPaidUp(p);
                    NLnew.get(0).setWithin(w);
                    NLnew.get(0).setClosed(d + accountsReposessed);
                    NLnew.get(0).setRecovered(accountsReposessed);
                    save.updateObject(NLnew.get(0));
                }

                PaymentStatus ps = new PaymentStatus();
                ps.setBatchid(input.batch.getId());
                ps.setClosed(defaulted + reposessed);
                ps.setDateCreated(PrintJson.timeZoneKla());
                ps.setOverDue(outOverdue);
                ps.setPaidUp(outPlanPaidUp);
                ps.setWithin(outWithin);
                ps.setCollected(collected - outPlanPaidUp + paidupExcess);
                ps.setMonth(String.valueOf(cal.get(Calendar.MONTH) + 1));
                ps.setDiscountedAmount(discounted);
                List<PaymentStatus> NLnewP = chartService.getBatchPaymentStatusMonth(ps.getMonth(), input.batch.getId());
                if (NLnewP.isEmpty()) {
                    save.saveObject(ps);
                } else {

                    NLnewP.get(0).setClosed(defaulted + reposessed);
                    NLnewP.get(0).setDateCreated(PrintJson.timeZoneKla());
                    NLnewP.get(0).setOverDue(outOverdue);
                    NLnewP.get(0).setPaidUp(outPlanPaidUp);
                    NLnewP.get(0).setWithin(outWithin);
                    NLnewP.get(0).setCollected(collected - outPlanPaidUp + paidupExcess);
                    NLnewP.get(0).setDiscountedAmount(discounted);
                    save.updateObject(NLnewP.get(0));
                }

                LoanPerformance lp = new LoanPerformance();
                lp.setBatchid(input.batch.getId());
                lp.setCollected(collected);
                lp.setDateCreated(PrintJson.timeZoneKla());
                lp.setOutstanding(outstanding);
                lp.setPaymentsWithin(paymentsWithin);
                lp.setPaymentsBehind(paymentsBehind);
                lp.setOutstandingWithin(outstandingWithin);
                //lp.setOutstandingOverdue(outstandingOverdue -reposessed-paidupExcess);
                lp.setOutstandingOverdue(outstandingOverdue);
                lp.setAmountPaidToDate(amountPaidToDate);
                lp.setBalanceDueToDate(balanceDueToDate);
                lp.setDefaultedAmount(defaulted + reposessed);
                lp.setDiscountedAmount(discounted);
                lp.setDateCreated(PrintJson.timeZoneKla());
                lp.setMonth(String.valueOf(cal.get(Calendar.MONTH) + 1));
                List<LoanPerformance> NLnewL = chartService.getBatchLoanPerformanceMonth(ps.getMonth(), input.batch.getId());
                if (NLnewL.isEmpty()) {
                    save.saveObject(lp);
                } else {
                    NLnewL.get(0).setCollected(collected);
                    NLnewL.get(0).setOutstanding(outstanding);
                    NLnewL.get(0).setPaymentsWithin(paymentsWithin);
                    NLnewL.get(0).setPaymentsBehind(paymentsBehind);
                    NLnewL.get(0).setOutstandingWithin(outstandingWithin);
                    //NLnewL.get(0).setOutstandingOverdue(outstandingOverdue -reposessed-paidupExcess);
                    NLnewL.get(0).setOutstandingOverdue(outstandingOverdue);
                    NLnewL.get(0).setAmountPaidToDate(amountPaidToDate);
                    NLnewL.get(0).setBalanceDueToDate(balanceDueToDate);
                    NLnewL.get(0).setDefaultedAmount(defaulted + reposessed);
                    NLnewL.get(0).setDiscountedAmount(discounted);
                    NLnewL.get(0).setDateCreated(PrintJson.timeZoneKla());
                    save.updateObject(NLnewL.get(0));
                }

                OverdueLoansByNumber odn = new OverdueLoansByNumber();
                Double outstandingNumberAccounts;
                outstandingNumberAccounts = (par1NumberLoans + par30NumberLoans + par60NumberLoans + par90NumberLoans + accountsDefaulted + accountsPaidUp + accountsReposessed + accountsWithin);
                odn.setNumberPar1(par1NumberLoans);
                odn.setNumberPar30(par30NumberLoans);
                odn.setNumberPar60(par60NumberLoans);
                //odn.setNumberPar90(par90NumberLoans - accountsDefaulted);
                odn.setNumberPar90(par90NumberLoans);//we skip defaulters when deciding PAR value
                odn.setNumberWithinPaidUp(accountsPaidUp + accountsWithin);
                odn.setNumberOnDefaulted(accountsDefaulted + accountsReposessed);
                odn.setNumberOnReposessed(accountsReposessed);
                if(outstandingNumberAccounts==0){
                   odn.setParByNumber(0.0); 
                   odn.setParDefaultedNumber(0.0);
                   odn.setParReposessedNumber(0.0);
                }
                else{
                    odn.setParByNumber((par1NumberLoans + par30NumberLoans + par60NumberLoans + par90NumberLoans) / outstandingNumberAccounts);
                    odn.setParDefaultedNumber(accountsDefaulted / outstandingNumberAccounts);
                    odn.setParReposessedNumber(accountsReposessed / outstandingNumberAccounts);
            }
                odn.setMonth(String.valueOf((cal.get(Calendar.MONTH) + 1)));
                
                odn.setBatchid(input.batch.getId());
                odn.setDateCreated(PrintJson.timeZoneKla());
                List<OverdueLoansByNumber> NLnewO = chartService.getBatchODNMonth(ps.getMonth(), input.batch.getId());
                if (NLnewO.isEmpty()) {
                    save.saveObject(odn);
                } else {
                    NLnewO.get(0).setNumberPar1(par1NumberLoans);
                    NLnewO.get(0).setNumberPar30(par30NumberLoans);
                    NLnewO.get(0).setNumberPar60(par60NumberLoans);
                    //NLnewO.get(0).setNumberPar90(par90NumberLoans - accountsDefaulted);
                    NLnewO.get(0).setNumberPar90(par90NumberLoans);//we skip defaulters when deciding PAR value
                    NLnewO.get(0).setNumberWithinPaidUp(accountsPaidUp + accountsWithin);
                    NLnewO.get(0).setNumberOnDefaulted(accountsDefaulted + accountsReposessed);
                    NLnewO.get(0).setNumberOnReposessed(accountsReposessed);
                    if(outstandingNumberAccounts==0){
                        NLnewO.get(0).setParByNumber(0.0);
                        NLnewO.get(0).setParDefaultedNumber(0.0);
                        NLnewO.get(0).setParReposessedNumber(0.0);
                    }
                    else{
                        NLnewO.get(0).setParByNumber((par1NumberLoans + par30NumberLoans + par60NumberLoans + par90NumberLoans) / outstandingNumberAccounts);
                        NLnewO.get(0).setParDefaultedNumber(accountsDefaulted / outstandingNumberAccounts);
                    NLnewO.get(0).setParReposessedNumber(accountsReposessed / outstandingNumberAccounts);
                }
                    NLnewO.get(0).setMonth(String.valueOf((cal.get(Calendar.MONTH) + 1)));
                    

                    NLnewO.get(0).setDateCreated(PrintJson.timeZoneKla());
                    save.updateObject(NLnewO.get(0));
                }

                Double outstandingParAccounts;
                outstandingParAccounts = (par1 + par30 + par60 + par90 + (outWithin / 1000000) + (outPlanPaidUp / 1000000) + (reposessed / 1000000) + (dfOutstanding / 1000000));
                OverdueLoansByValue odv = new OverdueLoansByValue();
                odv.setOutstandingWithinPaidUp((outWithin / 1000000) + (outPlanPaidUp / 1000000));
                if(outstandingParAccounts==0){
                    odv.setParByValue(0.0);
                    odv.setParDefaultedValue(0.0);
                    odv.setParReposessedValue(0.0);
                }else{
                    odv.setParByValue((par1 + par30 + par60 + par90) / outstandingParAccounts);
                    odv.setParDefaultedValue((defaulted / 1000000) / outstandingParAccounts);
                    odv.setParReposessedValue((reposessed / 1000000) / outstandingParAccounts);
                }
                odv.setOutstandingPar1(par1);
                odv.setOutstandingPar30(par30);
                odv.setOutstandingPar60(par60);
                odv.setOutstandingPar90(par90);
                odv.setRecoveryAmount((defaulted / 1000000) / 2);
                odv.setOutstandingOnDefaulted((defaulted + reposessed) / 1000000);
                odv.setOutstandingOnReposessed(reposessed / 1000000);
                odv.setDateCreated(PrintJson.timeZoneKla());
                odv.setBatchid(input.batch.getId());
                odv.setMonth(String.valueOf((cal.get(Calendar.MONTH) + 1)));
                List<OverdueLoansByValue> NLnewV = chartService.getBatchODVMonth(ps.getMonth(), input.batch.getId());
                if (NLnewV.isEmpty()) {
                    save.saveObject(odv);
                } else {
                    NLnewV.get(0).setOutstandingWithinPaidUp((outWithin / 1000000) + (outPlanPaidUp / 1000000));
                if(outstandingParAccounts==0){
                    NLnewV.get(0).setParByValue(0.0);
                    NLnewV.get(0).setParDefaultedValue(0.0);
                    NLnewV.get(0).setParReposessedValue(0.0);
                }else{
                    NLnewV.get(0).setParByValue((par1 + par30 + par60 + par90) / outstandingParAccounts);
                    NLnewV.get(0).setParDefaultedValue((defaulted / 1000000) / outstandingParAccounts);
                    NLnewV.get(0).setParReposessedValue((reposessed / 1000000) / outstandingParAccounts);
                }
                    NLnewV.get(0).setOutstandingPar1(par1);
                    NLnewV.get(0).setOutstandingPar30(par30);
                    NLnewV.get(0).setOutstandingPar60(par60);
                    NLnewV.get(0).setOutstandingPar90(par90);
                    NLnewV.get(0).setRecoveryAmount((defaulted / 1000000) / 2);
                    NLnewV.get(0).setOutstandingOnDefaulted((defaulted + reposessed) / 1000000);
                    NLnewV.get(0).setOutstandingOnReposessed(reposessed / 1000000);
                    NLnewV.get(0).setDateCreated(PrintJson.timeZoneKla());
                    save.updateObject(NLnewV.get(0));
                }

                //save if week, month,year displays
                //save batch curve
                if (!ba.isEmpty()) {
                    
                    DecimalFormat dft = new DecimalFormat("#.######");
                    dft.setRoundingMode(RoundingMode.CEILING);
                    
                    if (ba.get(0).getAnalysisDays() > 80 && ba.get(0).getAnalysisDays() < 540) {
                        for (int i = 0; i < (ba.get(0).getAnalysisDays() / 7/*-1*/); i++) {
                            ActualPercentage ac = new ActualPercentage();
                            ac.setActualDay(i);
                            //System.out.println(" ---"+actualPercent[i]+"-----"+ap[i]);
                            if (ap[i] == 0) {
                                ac.setActualPercent(BigDecimal.ZERO);
                                ac.setActualPercent2(0.0);
                            } else {
                                //System.out.println("i=iterastion"+i);
                                //System.out.println("actaulPercent"+actualPercent[i].toString()+"-"+"elements"+ap[i]);
                                // if(actualPercent[i].isInfinite()){
                                //     ac.setActualPercent(Double.POSITIVE_INFINITY/ap[i]);
                                // }else{
                                ac.setActualPercent(actualPercent[i].divide(BigDecimal.valueOf(ap[i]), 2, RoundingMode.HALF_UP));
                                ac.setActualPercent2(Double.valueOf(dft.format(actualPercent2[i]/ap2[i])));
                                // }
                                ac.setBatchid(input.batch.getId());
                                List<ActualPercentage> acList = paymentService.findPercentByDayBatch(i, input.batch.getId());

                                if (acList.isEmpty()) {

                                    save.saveObject(ac);
                                } else {
                                    acList.get(0).setActualPercent(ac.getActualPercent());
                                    acList.get(0).setActualPercent2(ac.getActualPercent2());
                                    save.updateObject(acList.get(0));
                                }
                            }

                        }
                    } else if (ba.get(0).getAnalysisDays() > 540) {

                        for (int i = 0; i < (ba.get(0).getAnalysisDays() / 30 - 1); i++) {
                            ActualPercentage ac = new ActualPercentage();
                            ac.setActualDay(i);

                            if (ap[i] == 0) {
                                ac.setActualPercent(BigDecimal.ZERO);
                                ac.setActualPercent2(0.0);
                            } else {
                                ac.setActualPercent(actualPercent[i].divide(BigDecimal.valueOf(ap[i].doubleValue()), 2, RoundingMode.HALF_UP));
                                ac.setActualPercent2(Double.valueOf(dft.format(actualPercent2[i]/ap2[i])));
                                ac.setBatchid(input.batch.getId());
                                List<ActualPercentage> acList = paymentService.findPercentByDayBatch(i, input.batch.getId());

                                if (acList.isEmpty()) {

                                    save.saveObject(ac);
                                } else {
                                    acList.get(0).setActualPercent(ac.getActualPercent());
                                    acList.get(0).setActualPercent2(ac.getActualPercent2());
                                    save.updateObject(acList.get(0));
                                }
                            }

                        }

                    } else {

                        for (int i = 0; i < ba.get(0).getAnalysisDays() - 1; i++) {
                            ActualPercentage ac = new ActualPercentage();
                            ac.setActualDay(i);

                            if (ap[i] == 0) {
                                ac.setActualPercent(BigDecimal.ZERO);
                                ac.setActualPercent2(0.0);
                            } else {
                                ac.setActualPercent(actualPercent[i].divide(BigDecimal.valueOf(ap[i]), 2, RoundingMode.HALF_UP));
                                ac.setActualPercent2(Double.valueOf(dft.format(actualPercent2[i]/ap2[i])));
                                ac.setBatchid(input.batch.getId());
                                List<ActualPercentage> acList = paymentService.findPercentByDayBatch(i, input.batch.getId());

                                if (acList.isEmpty()) {

                                    save.saveObject(ac);
                                } else {
                                    acList.get(0).setActualPercent(ac.getActualPercent());
                                    acList.get(0).setActualPercent2(ac.getActualPercent2());
                                    save.updateObject(acList.get(0));
                                }
                            }

                        }

                    }
                } else {
                    log.info("No batch Analysis Information");
                }

                reply.setSucc("Graph Data Updated");
                log.info("@@@@@@@@@@@@@@@@@@@@@@@@@ Graph Data Updated");

            }

        } else {

                    log.info("Send Batch object");
                    reply.setError("Send Batch object");
                }

            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }
        return reply.toString();
    }

    //**************endpoint for update repayment curve*****************
    @POST
    @Path("updateCurve")
    //@Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Update batch curve details", notes = "Update batch curve details.", response = JsonReply.class)
    public String updateRepaymentCurve(@Context Request req, @ApiParam(value = "JsonInput.Batch") String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("updateCurve");

        gson = new Gson();

        try {
            //PRINT INPUT
            PrintJson.printJ(json);
            
            log.info("deleting old percents...");
            int g = paymentService.deletePercents();
            log.info("deletedddddddddddddddddddddddddddddd" + g);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null) {

                if (input.batch != null) {
                    log.info("got batch---" + input.batch.toString());
                    List<BatchhasLoan> bloans = bhlService.batchLoanByBatch(input.batch);
                    List<BatchAnalysis> ba = baService.getBatchAnalysis(input.batch);

                    if (bloans.isEmpty()) {
                        log.info("No loans assigned to batch " + bloans.size());
                        reply.setError("No loans assigned to batch");
                    } else {

                        List<Loan> loanList = loanService.findAll();
                        DateTime today = new DateTime();

                        if (!loanList.isEmpty()) {
                            for (Loan l : loanList) {

                                List<BatchhasLoan> loanBatches = bhlService.batchLoanByLoan(l);
                                Double modelTotal = depositService.depositByModelVersion(l.getModelPurchased(), l.getVersion()).get(0).getFinal1();
                                Deposit modelUpfront = depositService.depositByModelVersion(l.getModelPurchased(), l.getVersion()).get(0);
                                org.joda.time.DateTime contractDate = new DateTime(l.getDownPaymentDate().getTime());
                                List<Payments> ps = paymentService.findPaymentsByLoan(l);

                                if (!loanBatches.isEmpty() && l.getVersion() != null) {
                                    DecimalFormat df = new DecimalFormat("#.######");
                                    df.setRoundingMode(RoundingMode.CEILING);

                                    double prevPayment = 0.0;
                                    double percent;

                                    for (BatchhasLoan bl : loanBatches) {
                                        List<BatchAnalysis> bas = baService.getBatchAnalysis(bl.getBatch());

                                       
                                            
                                            
                                            if(!bas.isEmpty()){

                                            prevPayment = 0.0;
                                            for (int day = 0; day <= bas.get(0).getAnalysisDays(); day++) {

                                                if (day == 0) {

                                                    for (Payments p : ps) {
                                                        if (!p.getPaymentDate().after(p.getContractDate())) {
                                                            prevPayment += p.getPaymentAmount();
                                                        }
                                                    }

                                                    percent = prevPayment / modelTotal;

                                                    Percentage perc = new Percentage();
                                                    perc.setDay(day);

                                                    if ("NaN".equalsIgnoreCase(String.valueOf(percent))) {
                                                        perc.setPercentage(0.0);
                                                        perc.setModelTotal(0.0);
                                                        perc.setPreviousPayment(0.0);
                                                    } else {
                                                        perc.setPercentage(Double.valueOf(df.format(percent)));
                                                        perc.setModelTotal(modelTotal);
                                                        perc.setPreviousPayment(prevPayment);
                                                    }
                                                    perc.setLoanid(l);
                                                    perc.setBatchid(bas.get(0).getBatchid());
                                                    if (paymentService.findPercentageByLoan(l, day, bas.get(0).getBatchid()).isEmpty()) {
                                                        save.saveObject(perc);
                                                    } else {
                                                        Percentage p = paymentService.findPercentageByLoan(l, day, bas.get(0).getBatchid()).get(0);
                                                        p.setPercentage(Double.valueOf(df.format(percent)));
                                                        p.setModelTotal(modelTotal);
                                                        p.setPreviousPayment(prevPayment);
                                                        save.updateObject(p);
                                                    }
                                                } else if (Days.daysBetween(today.minusDays(1).toLocalDate(), new LocalDate(contractDate)).getDays() / -1 > day) {

                                                    for (Payments p : ps) {
                                                        org.joda.time.DateTime dtContract = new DateTime(p.getContractDate());
                                                        org.joda.time.DateTime dtPayment = new DateTime(p.getPaymentDate().getTime());
                                                        LocalDate d1 = new LocalDate(dtContract);
                                                        LocalDate d2 = new LocalDate(dtPayment);

                                                        if (d1.plusDays(day).isEqual(d2)) {

                                                            prevPayment += p.getPaymentAmount();
                                                        }
                                                    }

                                                    percent = prevPayment / modelTotal;

                                                    Percentage perc = new Percentage();
                                                    perc.setDay(day);
                                                    if ("NaN".equalsIgnoreCase(String.valueOf(percent))) {
                                                        perc.setPercentage(0.0);
                                                        perc.setModelTotal(0.0);
                                                        perc.setPreviousPayment(0.0);
                                                    } else {
                                                        perc.setPercentage(Double.valueOf(df.format(percent)));
                                                        perc.setModelTotal(modelTotal);
                                                        perc.setPreviousPayment(prevPayment);
                                                    }
                                                    perc.setBatchid(bas.get(0).getBatchid());
                                                    perc.setLoanid(l);
                                                    List<Percentage> pct = paymentService.findPercentageByLoan(l, day, bas.get(0).getBatchid());
                                                    if (pct.isEmpty()) {
                                                        save.saveObject(perc);
                                                    } else {
                                                        pct.get(0).setPercentage(Double.valueOf(df.format(percent)));
                                                        pct.get(0).setModelTotal(modelTotal);
                                                        pct.get(0).setPreviousPayment(prevPayment);
                                                        save.updateObject(pct.get(0));
                                                    }
                                                }
                                            }
                                            } else {
                                                log.info("No batch Analysis Information " + bl.getBatch().getId());
                                        }
                                        
                                        
                                    }

                                } else {
                                    log.info("Loan not assigned to batch " + l.getId());
                                }
                            }

                            log.info("curve data updated ###########");

                        } else {
                            // log.info("No loans in loan portal tool");
                            reply.setError("No loans in loan portal tool");
                        }

                    }

                } else {

                    log.info("Send Batch object");
                    reply.setError("Send Batch object");
                }

            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }
        return reply.toString();
    }
    //**************endpoint for all batches*****************
    @POST
    @Path("allLoansInBatches")
    @Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Loans in Batch", notes = "Returns All Loans in Batch.", response = JsonReply.class)
    public String findAllLoansInBatch(@Context Request req, @ApiParam(value = "JsonInput.Batch") String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("findAllLoansInBatch");

        gson = new Gson();

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.batch != null) {

                List<BatchhasLoan> batchLoans = bhlService.batchLoanByBatch(input.batch);
                if (batchLoans.isEmpty()) {
                    reply.setError("No loans in batch");
                } else {
                    reply.setSucc("Found loans in batch");
                    reply.batchhasLoans = batchLoans;
                }

            } else {
                log.info("Please Send some JSON or Send Batch object");
                reply.setError("Please Send some JSON or Send Batch object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();

    }

    //**************endpoint for all batches*****************
    @GET
    @Path("allBatches")
    @Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "All Batches", notes = "Returns Batch details.", response = JsonReply.class)
    public String findAll(@Context Request req) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("getAllBatches+findAll");

        Principal principal = securityContext.getUserPrincipal();
        String username = principal.getName();

        Users u = userService.findByEmail(username).get(0);
        if (u != null) {

            if ("administrator".equalsIgnoreCase(u.getRole())) {
                List<Batch> batches = batchService.findAll();
                reply.batches = batches;
                reply.setSucc("Found batches");
            } else {

                List<UserBatch> ub = ubService.userBatchByUser(u);

                if (!ub.isEmpty()) {
                    List<Batch> batches = new ArrayList<>();
                    for (UserBatch o : ub) {
                        batches.add(o.getBatchid());

                    }

                    reply.batches = batches;
                    reply.setSucc("Found batches");

                } else {
                    reply.setError("No batches assigned to user");
                }

            }
        } else {
            reply.setError("User Not found");
            log.info("User not found");
        }
        return reply.toString();
    }

    
    
     // ++++++++++++++++++++++++: LOANS TO BATCH :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Secured({Role.administrator})
    @Path("assignLoanBatch")
    @ApiOperation(value = "Assign Loan to Batch", notes = "Assign New Loan to Batch.", response = JsonReply.class)
    public String assignLoanBatch(@Context Request req, @ApiParam(value = "JsonInput.BatchLoans") String json) throws com.google.gson.JsonSyntaxException {
        log.info("=====================:assignLoanBatch");

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        reply = new JsonReply("AssignLoanBatch");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null) {
                if (input.batchLoans.isEmpty()) {
                    log.info("Both batchLoans required");
                    reply.setError("Both batchLoans required");
                } else {

                    List<BatchhasLoan> bl = input.batchLoans;

                    for (BatchhasLoan result : bl) {
                        //GET LOAN and BATCH FROM DB
                        log.info("++++++++++++++++++" + result.getLoan().getId().toString());
                        Batch b = batchService.batchById(result.getBatch().getId());
                        Loan l;
                        l = loanService.loanById(result.getLoan().getId());

                        if (b != null && l != null) {

                            //CONSTRUCT PK for Batch of loans
                            BatchhasLoanPK bhlPK = new BatchhasLoanPK();
                            bhlPK.setBatchid(b.getId());
                            bhlPK.setLoanid(result.getLoan().getId());
                            bhlPK.setBatchPortfolioid(b.getPortfolioid().getId());
                            //save.saveObject(bhlPK);
                            BatchhasLoan bh = bhlService.batchLoanById(bhlPK);

                            if (bh == null) {

                                //ASSIGN LOAN TO BATCH AND PK
                                BatchhasLoan bhl = new BatchhasLoan();
                                bhl.setBatch(b);
                                bhl.setLoan(result.getLoan());
                                bhl.setBatchhasLoanPK(bhlPK);
                                save.saveObject(bhl);
                                l.setAssigned(Boolean.TRUE);

                                List<BatchhasLoan> blCount = bhlService.batchLoanByLoan(l);

                                l.setNumberBatchAssined(blCount.size());

                                save.updateObject(l);

                                reply.setSucc("Loans Assined to Batch");

                            } else {
                                log.info("Loan already assigned to batch");
                                reply.setError("Loan already assigned to batch");
                            }

                        } else {
                            log.error("Loan " + result.getLoan() + ",Batch " + b);
                            reply.setError("Loan or Batch does not exist");
                        }

                    }

                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: CREATE BATCH :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Secured({Role.administrator})
    @ApiOperation(value = "Add Batch", notes = "Creates new Batch.", response = JsonReply.class)
    @Path("createBatch")
    public String createBatch(@Context Request req, @ApiParam(value = "JsonInput.Batch") String json) throws com.google.gson.JsonSyntaxException {
        log.info("=====================:createBatch");

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();
        reply = new JsonReply("createBatch");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.batch != null) {

                if (input.batch.getName() == null || input.batch.getPortfolioid() == null) {
                    log.info("Batch should have a name or Portfolio");
                    reply.setError("Send Batch name and Portfolio");
                } else {

                    //CONSTRUCT PORTFOLIO
                    Portfolio port;
                    port = psService.portfolioById(input.batch.getPortfolioid().getId());

                    if (port != null) {

                        //CONSTRUCT SAVE NEW BATCH
                        Batch batch = new Batch();
                        batch.setPortfolioid(port);

                        batch.setName(input.batch.getName());
                        batch.setDescription(input.batch.getDescription());
                        batch.setDateCreated(PrintJson.timeZoneKla());
                        batch.setUpdateDate(PrintJson.timeZoneKla());
                        batch.setUploadDate(PrintJson.timeZoneKla());
                        batch.setStatus(input.batch.getStatus());
                        save.saveObject(batch);

                        reply.batches = batchService.findAll();

                        reply.setSucc("Batch created");
                        log.info("Batch created" + batch.getId());

                    } else {
                        log.info("Portfolio for Batch not found");
                        reply.setError("Portfolio for Batch not found");
                    }
                }

            } else {
                log.info("Please Send some JSON or Send Batch object");
                reply.setError("Please Send some JSON or Send Batch object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    

    public void setUpMonth(ArrayList month, int currentMonth, List<ArrayList> s, String mnth, Object result) {

        

            month.add(month.size(), mnth);
            
            if ((result instanceof NumberofLoans)) {
                NumberofLoans nl = (NumberofLoans) result;
                s.get(0).add(month.size()-1, nl.getWithin());
                s.get(1).add(month.size()-1, nl.getOverDue());
                s.get(2).add(month.size()-1, nl.getPaidUp());
                s.get(3).add(month.size()-1, nl.getClosed());
            } else if ((result instanceof PaymentStatus)) {

                PaymentStatus nl = (PaymentStatus) result;

                s.get(0).add(month.size()-1, Math.round((nl.getWithin() / 1000000) * 100.0) / 100.0);
                s.get(1).add(month.size()-1, Math.round((nl.getOverDue() / 1000000) * 100.0) / 100.0);
                s.get(2).add(month.size()-1, Math.round((nl.getPaidUp() / 1000000) * 100.0) / 100.0);
                s.get(3).add(month.size()-1, Math.round((nl.getClosed() / 1000000) * 100.0) / 100.0);
                s.get(4).add(month.size()-1, Math.round((nl.getCollected() / 1000000) * 100.0) / 100.0);
                s.get(5).add(month.size()-1, Math.round((nl.getDiscountedAmount() / 1000000) * 100.0) / 100.0);

            } else if ((result instanceof OverdueLoansByNumber)) {

                OverdueLoansByNumber nl = (OverdueLoansByNumber) result;

                s.get(0).add(month.size()-1, nl.getNumberPar1());
                s.get(1).add(month.size()-1, nl.getNumberPar30());
                s.get(2).add(month.size()-1, nl.getNumberPar60());
                s.get(3).add(month.size()-1, nl.getNumberPar90());
                s.get(4).add(month.size()-1, nl.getNumberOnDefaulted());

            } else if ((result instanceof OverdueLoansByValue)) {

                OverdueLoansByValue nl = (OverdueLoansByValue) result;

                if (s.size() < 3) {
                    s.get(0).add(month.size()-1, Math.round((nl.getOutstandingOnDefaulted()) * 100.0) / 100.0);
                    s.get(1).add(month.size()-1, Math.round((nl.getOutstandingOnDefaulted() / 2) * 100.0) / 100.0);

                } else {

                    s.get(0).add(month.size()-1, Math.round(nl.getOutstandingPar1() * 100.0) / 100.0);
                    s.get(1).add(month.size()-1, Math.round(nl.getOutstandingPar30() * 100.0) / 100.0);
                    s.get(2).add(month.size()-1, Math.round(nl.getOutstandingPar60() * 100.0) / 100.0);
                    s.get(3).add(month.size()-1, Math.round(nl.getOutstandingPar90() * 100.0) / 100.0);
                    s.get(4).add(month.size()-1, Math.round(nl.getOutstandingOnDefaulted() * 100.0) / 100.0);
                }

            } else if ((result instanceof LoanPerformance)) {

                LoanPerformance nl = (LoanPerformance) result;
                s.get(0).add(month.size()-1, Math.round((nl.getPaymentsWithin() / 1000000) * 100.0) / 100.0);
                s.get(1).add(month.size()-1, Math.round((nl.getPaymentsBehind() / 1000000) * 100.0) / 100.0);
                s.get(2).add(month.size()-1, Math.round((nl.getOutstandingWithin() / 1000000) * 100.0) / 100.0);
                s.get(3).add(month.size()-1, Math.round((nl.getOutstandingOverdue() / 1000000) * 100.0) / 100.0);
                s.get(4).add(month.size()-1, Math.round((nl.getDefaultedAmount() / 1000000) * 100.0) / 100.0);
                s.get(5).add(month.size()-1, Math.round((nl.getDiscountedAmount() / 1000000) * 100.0) / 100.0);

            } else if ((result instanceof RestructuredLoans)) {

                RestructuredLoans nl = (RestructuredLoans) result;

                if (s.size() > 1) {
                    s.get(0).add(month.size()-1, Math.round((nl.getOutstandingRestructured() / 1000000) * 100.0) / 100.0);
                    s.get(1).add(month.size()-1, Math.round((nl.getOutstandingOverdueRestructured() / 1000000) * 100.0) / 100.0);
                } else {
                    s.get(0).add(month.size()-1, nl.getNumberRestructured());

                }
            }
       // else brace}
    }

}
