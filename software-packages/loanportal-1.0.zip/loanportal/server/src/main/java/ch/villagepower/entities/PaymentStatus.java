/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import io.swagger.annotations.ApiModel;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Entity
@Table(name = "Payment_Status")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PaymentStatus.findAll", query = "SELECT p FROM PaymentStatus p"),
    @NamedQuery(name = "PaymentStatus.findByBatchid", query = "SELECT p FROM PaymentStatus p WHERE p.batchid = :batchid"),
    @NamedQuery(name = "PaymentStatus.findByWithin", query = "SELECT p FROM PaymentStatus p WHERE p.within = :within"),
    @NamedQuery(name = "PaymentStatus.findByPaidUp", query = "SELECT p FROM PaymentStatus p WHERE p.paidUp = :paidUp"),
    @NamedQuery(name = "PaymentStatus.findByOverDue", query = "SELECT p FROM PaymentStatus p WHERE p.overDue = :overDue"),
    @NamedQuery(name = "PaymentStatus.findByClosed", query = "SELECT p FROM PaymentStatus p WHERE p.closed = :closed"),
    @NamedQuery(name = "PaymentStatus.findByMonth", query = "SELECT p FROM PaymentStatus p WHERE p.month = :month"),
    @NamedQuery(name = "PaymentStatus.findByDateCreated", query = "SELECT p FROM PaymentStatus p WHERE p.dateCreated = :dateCreated"),
    @NamedQuery(name = "PaymentStatus.findByIdPaymentStatus", query = "SELECT p FROM PaymentStatus p WHERE p.idPaymentStatus = :idPaymentStatus")})
@ApiModel
public class PaymentStatus implements Serializable {

    @Column(name = "discounted_amount")
    private Double discountedAmount;

    @Column(name = "collected")
    private Double collected;

    private static final long serialVersionUID = 1L;
    @Column(name = "Batch_id")
    private Integer batchid;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "within")
    private Double within;
    @Column(name = "paid_up")
    private Double paidUp;
    @Column(name = "over_due")
    private Double overDue;
    @Column(name = "closed")
    private Double closed;
    @Size(max = 45)
    @Column(name = "month")
    private String month;
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idPayment_Status")
    private Integer idPaymentStatus;

    public PaymentStatus() {
    }

    public PaymentStatus(Integer idPaymentStatus) {
        this.idPaymentStatus = idPaymentStatus;
    }

    public Integer getBatchid() {
        return batchid;
    }

    public void setBatchid(Integer batchid) {
        this.batchid = batchid;
    }

    public Double getWithin() {
        return within;
    }

    public void setWithin(Double within) {
        this.within = within;
    }

    public Double getPaidUp() {
        return paidUp;
    }

    public void setPaidUp(Double paidUp) {
        this.paidUp = paidUp;
    }

    public Double getOverDue() {
        return overDue;
    }

    public void setOverDue(Double overDue) {
        this.overDue = overDue;
    }

    public Double getClosed() {
        return closed;
    }

    public void setClosed(Double closed) {
        this.closed = closed;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Integer getIdPaymentStatus() {
        return idPaymentStatus;
    }

    public void setIdPaymentStatus(Integer idPaymentStatus) {
        this.idPaymentStatus = idPaymentStatus;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPaymentStatus != null ? idPaymentStatus.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PaymentStatus)) {
            return false;
        }
        PaymentStatus other = (PaymentStatus) object;
        if ((this.idPaymentStatus == null && other.idPaymentStatus != null) || (this.idPaymentStatus != null && !this.idPaymentStatus.equals(other.idPaymentStatus))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.PaymentStatus[ idPaymentStatus=" + idPaymentStatus + " ]";
    }

    public Double getCollected() {
        return collected;
    }

    public void setCollected(Double collected) {
        this.collected = collected;
    }

    public Double getDiscountedAmount() {
        return discountedAmount;
    }

    public void setDiscountedAmount(Double discountedAmount) {
        this.discountedAmount = discountedAmount;
    }

}
