/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import io.swagger.annotations.ApiModel;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author root
 */
@Entity
@Table(name = "percentage")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Percentage.findAll", query = "SELECT p FROM Percentage p"),
    @NamedQuery(name = "Percentage.findByIdpercentage", query = "SELECT p FROM Percentage p WHERE p.idpercentage = :idpercentage"),
    @NamedQuery(name = "Percentage.findByPercentage", query = "SELECT p FROM Percentage p WHERE p.percentage = :percentage"),
    @NamedQuery(name = "Percentage.findByDay", query = "SELECT p FROM Percentage p WHERE p.day = :day")})
@ApiModel
public class Percentage implements Serializable {

    @Column(name = "previous_payment")
    private Double previousPayment;
    @Column(name = "model_total")
    private Double modelTotal;

    @JoinColumn(name = "Batch_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Batch batchid;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idpercentage")
    private Integer idpercentage;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "percentage")
    private Double percentage;
    @Column(name = "day")
    private Integer day;
    @JoinColumn(name = "Loan_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Loan loanid;

    //cater for infinity values
//    @PrePersist  
//    @PreUpdate  
//    private void resetPercentage() {
//
//            if(percentage == Double.POSITIVE_INFINITY)
//                percentage = Double.MAX_VALUE;
//            else if(percentage == Double.NEGATIVE_INFINITY)
//                percentage = Double.MIN_VALUE;
//       
//    }
    public Percentage() {
    }

    public Percentage(Integer idpercentage) {
        this.idpercentage = idpercentage;
    }

    public Integer getIdpercentage() {
        return idpercentage;
    }

    public void setIdpercentage(Integer idpercentage) {
        this.idpercentage = idpercentage;
    }

    public Double getPercentage() {
        return percentage;
    }

    public void setPercentage(Double percentage) {

        if (percentage == Double.POSITIVE_INFINITY) {
            this.percentage = Double.MAX_VALUE;
        } else if (percentage == Double.NEGATIVE_INFINITY) {
            this.percentage = Double.MIN_VALUE;
        } else {
            this.percentage = percentage;
        }
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public Loan getLoanid() {
        return loanid;
    }

    public void setLoanid(Loan loanid) {
        this.loanid = loanid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idpercentage != null ? idpercentage.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Percentage)) {
            return false;
        }
        Percentage other = (Percentage) object;
        if ((this.idpercentage == null && other.idpercentage != null) || (this.idpercentage != null && !this.idpercentage.equals(other.idpercentage))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.Percentage[ idpercentage=" + idpercentage + " ]";
    }

    public Batch getBatchid() {
        return batchid;
    }

    public void setBatchid(Batch batchid) {
        this.batchid = batchid;
    }

    public Double getPreviousPayment() {
        return previousPayment;
    }

    public void setPreviousPayment(Double previousPayment) {
        this.previousPayment = previousPayment;
    }

    public Double getModelTotal() {
        return modelTotal;
    }

    public void setModelTotal(Double modelTotal) {
        this.modelTotal = modelTotal;
    }

}
