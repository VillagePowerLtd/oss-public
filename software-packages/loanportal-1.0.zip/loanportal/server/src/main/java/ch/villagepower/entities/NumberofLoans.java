/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import io.swagger.annotations.ApiModel;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Entity
@Table(name = "Number_of_Loans")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "NumberofLoans.findAll", query = "SELECT n FROM NumberofLoans n"),
    @NamedQuery(name = "NumberofLoans.findByBatchid", query = "SELECT n FROM NumberofLoans n WHERE n.batchid = :batchid"),
    @NamedQuery(name = "NumberofLoans.findByWithin", query = "SELECT n FROM NumberofLoans n WHERE n.within = :within"),
    @NamedQuery(name = "NumberofLoans.findByPaidUp", query = "SELECT n FROM NumberofLoans n WHERE n.paidUp = :paidUp"),
    @NamedQuery(name = "NumberofLoans.findByOverDue", query = "SELECT n FROM NumberofLoans n WHERE n.overDue = :overDue"),
    @NamedQuery(name = "NumberofLoans.findByClosed", query = "SELECT n FROM NumberofLoans n WHERE n.closed = :closed"),
    @NamedQuery(name = "NumberofLoans.findByDateCreated", query = "SELECT n FROM NumberofLoans n WHERE n.dateCreated = :dateCreated"),
    @NamedQuery(name = "NumberofLoans.findByMonth", query = "SELECT n FROM NumberofLoans n WHERE n.month = :month"),
    @NamedQuery(name = "NumberofLoans.findByIdNumberofLoans", query = "SELECT n FROM NumberofLoans n WHERE n.idNumberofLoans = :idNumberofLoans")})
@ApiModel
public class NumberofLoans implements Serializable {

    @Column(name = "recovered")
    private Double recovered;

    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "Batch_id")
    private Integer batchid;
    @Column(name = "within")
    private Double within;
    @Column(name = "paid_up")
    private Double paidUp;
    @Column(name = "over_due")
    private Double overDue;
    @Column(name = "closed")
    private Double closed;
    private static final long serialVersionUID = 1L;
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    @Size(max = 45)
    @Column(name = "month")
    private String month;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idNumber_of_Loans")
    private Integer idNumberofLoans;

    public NumberofLoans() {
    }

    public NumberofLoans(Integer idNumberofLoans) {
        this.idNumberofLoans = idNumberofLoans;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Integer getIdNumberofLoans() {
        return idNumberofLoans;
    }

    public void setIdNumberofLoans(Integer idNumberofLoans) {
        this.idNumberofLoans = idNumberofLoans;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idNumberofLoans != null ? idNumberofLoans.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof NumberofLoans)) {
            return false;
        }
        NumberofLoans other = (NumberofLoans) object;
        if ((this.idNumberofLoans == null && other.idNumberofLoans != null) || (this.idNumberofLoans != null && !this.idNumberofLoans.equals(other.idNumberofLoans))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.NumberofLoans[ idNumberofLoans=" + idNumberofLoans + " ]";
    }

    public Double getWithin() {
        return within;
    }

    public void setWithin(Double within) {
        this.within = within;
    }

    public Double getPaidUp() {
        return paidUp;
    }

    public void setPaidUp(Double paidUp) {
        this.paidUp = paidUp;
    }

    public Double getOverDue() {
        return overDue;
    }

    public void setOverDue(Double overDue) {
        this.overDue = overDue;
    }

    public Double getClosed() {
        return closed;
    }

    public void setClosed(Double closed) {
        this.closed = closed;
    }

    public Integer getBatchid() {
        return batchid;
    }

    public void setBatchid(Integer batchid) {
        this.batchid = batchid;
    }

    public Double getRecovered() {
        return recovered;
    }

    public void setRecovered(Double recovered) {
        this.recovered = recovered;
    }

}
