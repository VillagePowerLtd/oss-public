/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;


/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
import ch.villagepower.entities.Batch;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.apache.log4j.Logger;

@Stateless
public class BatchService {

    @PersistenceContext
    private EntityManager em;

    final static Logger log = Logger.getLogger(BatchService.class.getName());

    public List<Batch> findAll() {

        List<Batch> batches;

        Query q = em.createQuery("from Batch", Batch.class);

        batches = q.getResultList();

        return batches;

    }

    //return batch byt id
    public Batch batchById(Integer id) {

        Batch batch = em.find(Batch.class, id);

        return batch;
    }

}
