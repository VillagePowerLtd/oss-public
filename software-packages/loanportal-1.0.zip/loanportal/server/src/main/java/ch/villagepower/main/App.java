/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.main;


/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
import ch.villagepower.shiro.HashGenerator;
import ch.villagepower.utils.PrintJson;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Days;
import org.joda.time.LocalDate;

public class App {

    static final Logger log = Logger.getLogger(App.class.getName());

    private App() {
        throw new IllegalAccessError("App Utility class");
    }

    public static void main(String[] args) throws ParseException {
        log.info("");

        HashGenerator hashGenerator = new HashGenerator();

        String word = "1qaz2wsx#";
        String salt = hashGenerator.generateSalt();
        String saltedPass = hashGenerator.saltHashPassword(word, salt);

        log.info("password        : " + word);
        log.info("random salt     : " + salt);
        log.info("salted password : " + saltedPass);
        SimpleDateFormat date = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");

        date.setTimeZone(TimeZone.getTimeZone("Africa/Kampala"));
        //"Mon Aug 08 17:38:26 EAT 2016";
        log.info("" + new Date());

        DateTimeZone timeZoneKla = DateTimeZone.forID("Africa/Kampala");

        DateTime nowKla = DateTime.now(timeZoneKla);

        Date d = nowKla.toDate();
        log.info("------------" + d);

        SimpleDateFormat formatter;

        String dateInString = "18-02-17";

        formatter = new SimpleDateFormat("dd-MM-yy");
        Date date1 = formatter.parse(dateInString);
        formatter = new SimpleDateFormat("yyyy-MM-dd");
        dateInString = formatter.format(date1);
        Date NextPaymentDate = formatter.parse(dateInString);

        long days = 0;

        days = PrintJson.timeZoneKla().getTime() - NextPaymentDate.getTime();
        days = days / (24 * 60 * 60 * 1000);
        log.info("********diff time*******" + days);

        log.info("********Long to Int*******" + (int) (long) days);

        org.joda.time.DateTime contractDate = new DateTime(NextPaymentDate.getTime());
        int day = Days.daysBetween(new LocalDate(contractDate), new DateTime().toLocalDate()).getDays();
        System.out.println("new date" + new DateTime().toLocalDate());

        log.info("daysbetween " + day);

        String dateTime = "2017-01-04 08:22:27";

        formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        Date dateTime1 = formatter.parse(dateTime);

        org.joda.time.DateTime ate = new DateTime(dateTime1.getTime());

        log.info("date string " + dateTime1.toString());

        log.info("minus hours " + ate.minusHours(7));

        log.info("======================================");

        DateTimeZone kla = DateTimeZone.forID("America/Sao_Paulo");
        DateTime start = new DateTime(2017, 02, 18, 5, 0, 0, kla);
        DateTime end = new DateTime(2017, 02, 18, 13, 0, 0, kla);
        System.out.println("startofday" + Days.daysBetween(start.withTimeAtStartOfDay(),
                end.withTimeAtStartOfDay()).getDays());
        // prints 0
        System.out.println("anytime" + Days.daysBetween(start.toLocalDate(),
                end.toLocalDate()).getDays());

        System.out.println("yesterday: " + PrintJson.timeZoneDateTimeKla().toDateTime(DateTimeZone.forID("Africa/Kampala")).minusDays(1));

    }

}
