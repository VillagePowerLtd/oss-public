/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;


import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.log4j.Logger;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Stateless
public class SaveService {

    @PersistenceContext
    private EntityManager em;

    final static Logger log = Logger.getLogger(SaveService.class.getName());

    public void updateObject(Object obj) {

        em.merge(obj);
    }

    //SAVE OBJECT
    public void saveObject(Object o) {
        //log.info("=====================:saveObject");
        em.persist(o);
        //log.info("object" + o.toString());

    }

    public void deleteObject(Object obj) {

        em.remove(em.contains(obj) ? obj : em.merge(obj));
    }

}
