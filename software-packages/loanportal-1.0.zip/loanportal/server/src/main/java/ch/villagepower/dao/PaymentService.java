/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;


import ch.villagepower.entities.ActualPercentage;
import ch.villagepower.entities.Batch;
import ch.villagepower.entities.Loan;
import ch.villagepower.entities.Payments;
import ch.villagepower.entities.Percentage;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author root
 */
@Stateless
public class PaymentService {

    @PersistenceContext
    private EntityManager em;

    public List<Payments> findPaymentsByLoan(Loan l) {

        Query query = em.createQuery("SELECT p FROM Payments p WHERE p.loanid = :b");
        query.setParameter("b", l);

        return query.getResultList();

    }

    public List<Percentage> findPercentageByLoan(Loan l, int day, Batch b) {

        Query query = em.createQuery("SELECT p FROM Percentage p WHERE p.loanid = :b AND p.day=:a AND p.batchid=:c");
        query.setParameter("b", l);
        query.setParameter("a", day);
        query.setParameter("c", b);

        return query.getResultList();

    }

    
    public List<Percentage> findPercentageByLoanOnly(Loan l) {

        Query query = em.createQuery("SELECT p FROM Percentage p WHERE p.loanid = :b");
        query.setParameter("b", l);


        return query.getResultList();

    }
    public int deletePayments() {

        Query query = em.createNativeQuery("TRUNCATE TABLE payments");
        

        int x = query.executeUpdate();
        

        return x;

    }
    
    
    public int deletePercents() {

        
        Query query1 = em.createNativeQuery("TRUNCATE TABLE percentage");

        
        int y = query1.executeUpdate();

        return y;

    }


    public List<Percentage> findAllWithDay(int x, int y) {

        Query query = em.createQuery("SELECT a FROM Percentage a WHERE a.day >= :a AND a.day < :b");
        query.setParameter("a", x);
        query.setParameter("b", y);

        return query.getResultList();

    }

    public List<Percentage> findAllWithDayOne(int x) {

        Query query = em.createQuery("SELECT a FROM Percentage a WHERE a.day = :a");
        query.setParameter("a", x);

        return query.getResultList();

    }

    public List<Percentage> findByLoanDay(int x, Loan l) {

        Query query = em.createQuery("SELECT p FROM Percentage p WHERE p.day = :a AND p.loanid = :b");
        query.setParameter("a", x);
        query.setParameter("b", l);

        return query.getResultList();

    }

    public List<ActualPercentage> findPercent() {

        Query q = em.createQuery("from ActualPercentage", ActualPercentage.class);

        return q.getResultList();

    }

    public List<ActualPercentage> findPercentByBatch(int batch) {

        Query q = em.createQuery("SELECT p FROM ActualPercentage p WHERE p.batchid = :b");
        q.setParameter("b", batch);

        return q.getResultList();

    }

    public List<ActualPercentage> findPercentByDay(int day) {

        Query query = em.createQuery("SELECT p FROM ActualPercentage p WHERE p.actualDay = :b");
        query.setParameter("b", day);

        return query.getResultList();

    }

    public List<ActualPercentage> findPercentByDayBatch(int day, int batch) {

        Query query = em.createQuery("SELECT p FROM ActualPercentage p WHERE p.actualDay = :b AND p.batchid = :a");
        query.setParameter("b", day);
        query.setParameter("a", batch);

        return query.getResultList();

    }

}
