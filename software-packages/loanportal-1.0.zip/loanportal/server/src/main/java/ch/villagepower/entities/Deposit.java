/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import io.swagger.annotations.ApiModel;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Entity
@Table(name = "Deposit")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Deposit.findAll", query = "SELECT d FROM Deposit d"),
    @NamedQuery(name = "Deposit.findByIdDeposit", query = "SELECT d FROM Deposit d WHERE d.idDeposit = :idDeposit"),
    @NamedQuery(name = "Deposit.findBySystemCost", query = "SELECT d FROM Deposit d WHERE d.systemCost = :systemCost"),
    @NamedQuery(name = "Deposit.findByUpfront", query = "SELECT d FROM Deposit d WHERE d.upfront = :upfront"),
    @NamedQuery(name = "Deposit.findByDaily", query = "SELECT d FROM Deposit d WHERE d.daily = :daily"),
    //@NamedQuery(name = "Deposit.findByWeekly", query = "SELECT d FROM Deposit d WHERE d.weekly = :weekly"),
    //@NamedQuery(name = "Deposit.findByMonthly", query = "SELECT d FROM Deposit d WHERE d.monthly = :monthly"),
    @NamedQuery(name = "Deposit.findByTotal", query = "SELECT d FROM Deposit d WHERE d.total = :total"),
    @NamedQuery(name = "Deposit.findByFinal1", query = "SELECT d FROM Deposit d WHERE d.final1 = :final1"),
    @NamedQuery(name = "Deposit.findByInitialPaytWindow", query = "SELECT d FROM Deposit d WHERE d.initialPaytWindow = :initialPaytWindow"),
    @NamedQuery(name = "Deposit.findByPaytPerirod", query = "SELECT d FROM Deposit d WHERE d.paytPerirod = :paytPerirod"), //@NamedQuery(name = "Deposit.findByDefaltRateOnInstallments", query = "SELECT d FROM Deposit d WHERE d.defaltRateOnInstallments = :defaltRateOnInstallments")
})
@ApiModel
public class Deposit implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;

    @Column(name = "weekly")
    private Double weekly;
    @Column(name = "monthly")
    private Double monthly;
    @Column(name = "defalt_rate_on_installments")
    private Integer defaltRateOnInstallments;
    @Size(max = 45)
    @Column(name = "version")
    private String version;

    @Column(name = "20percent")
    private Double percent;

    @Column(name = "grace_period_upfront")
    private Double gracePeriodUpfront;
    @Column(name = "upfront_payment")
    private Double upfrontPayment;
    @Column(name = "penguin_total")
    private Double penguinTotal;

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Size(min = 1, max = 10)
    @Column(name = "idDeposit")
    private String idDeposit;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "systemCost")
    private Double systemCost;
    @Column(name = "upfront")
    private Double upfront;
    @Column(name = "daily")
    private Double daily;
    //@Column(name = "weekly")
    //private Double weekly;
    //@Column(name = "monthly")
    //private Double monthly;
    @Column(name = "total")
    private Double total;
    @Column(name = "final")
    private Double final1;
    @Column(name = "initial_payt_window")
    private Integer initialPaytWindow;
    @Column(name = "payt_perirod")
    private Integer paytPerirod;
    //@Column(name = "defalt_rate_on_installments")
    //private Integer defaltRateOnInstallments;

    public Deposit() {
    }

    public Deposit(String idDeposit) {
        this.idDeposit = idDeposit;
    }

    public String getIdDeposit() {
        return idDeposit;
    }

    public void setIdDeposit(String idDeposit) {
        this.idDeposit = idDeposit;
    }

    public Double getSystemCost() {
        return systemCost;
    }

    public void setSystemCost(Double systemCost) {
        this.systemCost = systemCost;
    }

    public Double getUpfront() {
        return upfront;
    }

    public void setUpfront(Double upfront) {
        this.upfront = upfront;
    }

    public Double getDaily() {
        return daily;
    }

    public void setDaily(Double daily) {
        this.daily = daily;
    }

    /* public Double getWeekly() {
        return weekly;
    }

    public void setWeekly(Double weekly) {
        this.weekly = weekly;
    }

    public Double getMonthly() {
        return monthly;
    }

    public void setMonthly(Double monthly) {
        this.monthly = monthly;
    }*/
    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public Double getFinal1() {
        return final1;
    }

    public void setFinal1(Double final1) {
        this.final1 = final1;
    }

    public Integer getInitialPaytWindow() {
        return initialPaytWindow;
    }

    public void setInitialPaytWindow(Integer initialPaytWindow) {
        this.initialPaytWindow = initialPaytWindow;
    }

    public Integer getPaytPerirod() {
        return paytPerirod;
    }

    public void setPaytPerirod(Integer paytPerirod) {
        this.paytPerirod = paytPerirod;
    }

    /* public Integer getDefaltRateOnInstallments() {
        return defaltRateOnInstallments;
    }

    public void setDefaltRateOnInstallments(Integer defaltRateOnInstallments) {
        this.defaltRateOnInstallments = defaltRateOnInstallments;
    }*/
    public Double getGracePeriodUpfront() {
        return gracePeriodUpfront;
    }

    public void setGracePeriodUpfront(Double gracePeriodUpfront) {
        this.gracePeriodUpfront = gracePeriodUpfront;
    }

    public Double getUpfrontPayment() {
        return upfrontPayment;
    }

    public void setUpfrontPayment(Double upfrontPayment) {
        this.upfrontPayment = upfrontPayment;
    }

    public Double getPenguinTotal() {
        return penguinTotal;
    }

    public void setPenguinTotal(Double penguinTotal) {
        this.penguinTotal = penguinTotal;
    }

    public Double getPercent() {
        return percent;
    }

    public void setPercent(Double percent) {
        this.percent = percent;
    }

    public Double getWeekly() {
        return weekly;
    }

    public void setWeekly(Double weekly) {
        this.weekly = weekly;
    }

    public Double getMonthly() {
        return monthly;
    }

    public void setMonthly(Double monthly) {
        this.monthly = monthly;
    }

    public Integer getDefaltRateOnInstallments() {
        return defaltRateOnInstallments;
    }

    public void setDefaltRateOnInstallments(Integer defaltRateOnInstallments) {
        this.defaltRateOnInstallments = defaltRateOnInstallments;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Deposit(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Deposit)) {
            return false;
        }
        Deposit other = (Deposit) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.Deposit[ id=" + id + " ]";
    }

}
