/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.rest;

import ch.villagepower.dao.BatchLoanService;
import ch.villagepower.dao.BatchService;
import ch.villagepower.dao.DepositService;
import ch.villagepower.dao.LoanService;
import ch.villagepower.dao.SaveService;
import ch.villagepower.entities.Batch;
import ch.villagepower.entities.BatchhasLoan;
import ch.villagepower.entities.BatchhasLoanPK;
import ch.villagepower.entities.Loan;
import ch.villagepower.entities.Portfolio;
import ch.villagepower.filter.AuthorizationFilter;
import ch.villagepower.filter.JWTAuthFilter;
import ch.villagepower.utils.Collection;
import ch.villagepower.utils.HibernateProxyTypeAdapter;
import ch.villagepower.utils.JsonInput;
import ch.villagepower.utils.JsonReply;
import ch.villagepower.utils.Nummber;
import ch.villagepower.utils.PrintJson;
import ch.villagepower.utils.Repayment;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import org.apache.log4j.Logger;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.jboss.shrinkwrap.resolver.api.maven.Maven;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@RunWith(Arquillian.class)
public class BatchResourceTest {

    final static Logger log = Logger.getLogger(LoanResourceTest.class.getName());

    private static Integer id = 3;
    JsonReply reply;
    JsonInput mInput;
    Gson gson;

    @Deployment
    public static WebArchive createDeployment() {

        // Import Maven runtime dependencies
        File[] files = Maven.resolver().loadPomFromFile("pom.xml")
                .importRuntimeDependencies().resolve().withTransitivity().asFile();

        return ShrinkWrap
                .create(WebArchive.class, "loan-test.war").addPackages(true, "ch.villagepower")
                .addClasses(LoanService.class, ApplicationConfig.class, AuthorizationFilter.class, HibernateProxyTypeAdapter.class,
                        JWTAuthFilter.class, SaveService.class, AuthenticationResource.class, BatchResource.class, Loan.class, JsonReply.class, JsonInput.class,
                        BatchService.class, DepositService.class, BatchLoanService.class, BatchhasLoan.class, PrintJson.class, Batch.class, Portfolio.class,
                        BatchhasLoanPK.class, LoanResource.class, NewCrossOriginResourceSharingFilter.class, PortfolioResource.class, UserResource.class)
                .addAsWebInfResource("test-beans.xml", "beans.xml")
                .addAsWebInfResource("test-persistence-web.xml", "web.xml")
                //.addAsWebInfResource("glassfish-resources.xml", "setup/glassfish-resources.xml")
                .addAsResource("test-persistence.xml", "META-INF/persistence.xml")
                .addAsResource("hibernate.cfg.xml", "hibernate.cfg.xml")
                //.addAsDirectory("src/main/resources")
                .addAsLibraries(files);
    }

    @Test
    //@InSequence(1)
    public void testSummaryOfLoans() throws Exception {
        reply = new JsonReply("testSummaryOfLoans");
        gson = new GsonBuilder().registerTypeAdapterFactory(HibernateProxyTypeAdapter.FACTORY).setDateFormat("dd/MM/yyyy HH:mm").setPrettyPrinting().create();
        mInput = new JsonInput();
        WebTarget target = ClientBuilder.newClient()
                .target("http://localhost:8080/loa-1.0-SNAPSHOT/webresources/");

        Batch batch = new Batch();
        batch.setId(16);
        mInput.batch = batch;

        /* try{*/
        Response r = target.path("batch/summaryOfLoans").request("application/json").post(Entity.json(mInput));
        //if (r.getStatus() == 200) {
        assertEquals(200, r.getStatus());

        reply = gson.fromJson(r.readEntity(String.class), JsonReply.class);
        if (!reply.result) {
            //assertEquals("No loans found", reply.errorMessage);
            assertEquals(false, reply.result);
        } else {
            assertEquals("Found Summary", reply.message);
            assertEquals(true, reply.result);

            //Collections
            List<Collection> colList = new ArrayList<>();
            Collection col = new Collection();
            col.setLabel("Outstanding");
            col.setValue("2453700.0");

            Collection col1 = new Collection();
            col1.setLabel("Collected");
            col1.setValue("282000.0");

            colList.add(col);
            colList.add(col1);

            //Number of loans
            List<Nummber> num = new ArrayList<>();
            Nummber numb = new Nummber();
            numb.setLabel("Within");
            numb.setValue("0.0");

            Nummber numb1 = new Nummber();
            numb.setLabel("Paid Up");
            numb.setValue("0.0");

            Nummber numb2 = new Nummber();
            numb.setLabel("Overdue");
            numb.setValue("2.0");

            Nummber numb3 = new Nummber();
            numb.setLabel("Closed");
            numb.setValue("0.0");

            num.add(0, numb);
            num.add(1, numb1);
            num.add(2, numb2);
            num.add(3, numb3);

            //Repayments
            List<Repayment> repayments = new ArrayList<>();
            Repayment re = new Repayment();
            re.setLabel("Within");
            re.setValue("0.0");

            Repayment re1 = new Repayment();
            re1.setLabel("Paid Up");
            re1.setValue("0.0");

            Repayment re2 = new Repayment();
            re2.setLabel("Overdue");
            re2.setValue("2735700.0");

            Repayment re3 = new Repayment();
            re3.setLabel("Closed");
            re3.setValue("0.0");

            repayments.add(re);
            repayments.add(re1);
            repayments.add(re2);
            repayments.add(re3);

            //numbers within
            /*assertEquals(reply.loanDonutChart.getNumbers().get(0).getLabel(), num.get(3).getLabel());
                assertEquals(reply.loanDonutChart.getNumbers().get(0).getValue(), num.get(3).getValue());
                //numbers paid up
                assertEquals(reply.loanDonutChart.getNumbers().get(1).getLabel(), num.get(1).getLabel());
                assertEquals(reply.loanDonutChart.getNumbers().get(1).getValue(), num.get(1).getValue());
                
                //numbers overdue
                assertEquals(reply.loanDonutChart.getNumbers().get(2).getLabel(), num.get(2).getLabel());
                assertEquals(reply.loanDonutChart.getNumbers().get(2).getValue(), num.get(2).getValue());*/
            //numbers clossed
            assertEquals(reply.loanDonutChart.getNumbers().get(3).getLabel(), num.get(0).getLabel());
            assertEquals(reply.loanDonutChart.getNumbers().get(3).getValue(), num.get(0).getValue());

            /*
                //repayments within
                assertEquals(reply.loanDonutChart.getRepayments().get(0).getLabel(), repayments.get(0).getLabel());
                assertEquals(reply.loanDonutChart.getRepayments().get(0).getValue(), repayments.get(0).getValue());
                
                //repayments paid up
                assertEquals(reply.loanDonutChart.getRepayments().get(2).getLabel(), repayments.get(2).getLabel());
                assertEquals(reply.loanDonutChart.getRepayments().get(2).getValue(), repayments.get(2).getValue());

                //repayments overdue
                assertEquals(reply.loanDonutChart.getRepayments().get(1).getLabel(), repayments.get(1).getLabel());
                assertEquals(reply.loanDonutChart.getRepayments().get(1).getValue(), repayments.get(1).getValue());

                //repayments clossed
                assertEquals(reply.loanDonutChart.getRepayments().get(3).getLabel(), repayments.get(3).getLabel());
                assertEquals(reply.loanDonutChart.getRepayments().get(3).getValue(), repayments.get(3).getValue());
                
                //collected outstanding
                assertEquals(reply.loanDonutChart.getCollections().get(0).getLabel(), colList.get(0).getLabel());
                assertEquals(reply.loanDonutChart.getCollections().get(0).getValue(), colList.get(0).getValue());

                //repayments clossed
                assertEquals(reply.loanDonutChart.getCollections().get(1).getLabel(), colList.get(1).getLabel());
                assertEquals(reply.loanDonutChart.getCollections().get(1).getValue(), colList.get(1).getValue());*/
        }
        // }
        /*   
         }catch (Exception ex) {
         log.error("Server Error:"+ ex.getMessage());
            
         }*/

    }

    /*
     @Test
     //@InSequence(1)
     public void testCreateBatch() {
     reply = new JsonReply("testCreateBatch");
     gson = new Gson();
     mInput = new JsonInput();
     WebTarget target = ClientBuilder.newClient()
     .target("http://localhost:8080/loa/webresources/");
        
     Batch batch = new Batch();
     //Integer id=1;
     batch.setId(id);
     mInput.batch = batch;
        

                    
     Response r = target.path("batch/createBatch").request("application/json").post(Entity.json(mInput));
     if(r.getStatus() == 200){
     assertEquals(200, r.getStatus());

     reply =gson.fromJson(r.readEntity(String.class), JsonReply.class);
     if(!reply.result){
                    
     assertEquals(false, reply.result);
     }else{
     assertEquals("Batch created", reply.message);
     assertEquals("true", reply.result);
                    
     }
     }

     }
    
    
     @Test
     //@InSequence(1)
     //Test that aloan is already assigned to batch
     public void testassignLoanToBatch() {
     reply = new JsonReply("testassignLoanToBatch");
     gson = new Gson();
     mInput = new JsonInput();
     WebTarget target = ClientBuilder.newClient()
     .target("http://localhost:8080/loa/webresources/");
        
     Batch batch = new Batch();
     Loan loan = new Loan();
     BatchhasLoan bhl = new BatchhasLoan();
     loan.setId(140);
     //Integer id=1;
     batch.setId(3);
     bhl.setBatch(batch);
     bhl.setLoan(loan);
     List<BatchhasLoan> batchLoans = new ArrayList();
     batchLoans.add(bhl);
        
     mInput.batchLoans = batchLoans;
        

                    
     Response r = target.path("batch/assignLoanBatch").request("application/json").post(Entity.json(mInput));
     if(r.getStatus() == 200){
     assertEquals(200, r.getStatus());

     reply =gson.fromJson(r.readEntity(String.class), JsonReply.class);

                    
     assertEquals(false, reply.result);
     assertEquals("Loan already assigned to batch", reply.errorMessage);

     }

     }
    
     */
    @Test
    //@InSequence(1)
    //Test returned data for graphs
    public void testfindBatchChart() {
        reply = new JsonReply("testfindBatchChart");
        gson = new Gson();
        mInput = new JsonInput();
        WebTarget target = ClientBuilder.newClient()
                .target("http://localhost:8080/loa-1.0-SNAPSHOT/webresources/");

        Batch batch = new Batch();

        //Integer id=1;
        batch.setId(16);

        mInput.batch = batch;

        Response r = target.path("batch/batchChart").request("application/json").post(Entity.json(mInput));
        //if(r.getStatus() == 200){
        assertEquals(200, r.getStatus());

        reply = gson.fromJson(r.readEntity(String.class), JsonReply.class);

        /*
                    
     assertEquals(true, reply.result);
     assertEquals("Graph exists", reply.message);
     
     //active loans, numbers
     Double[] series1 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
     Double[] series2 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.0, 0.0, 0.0, 0.0, 0.0};
     Double[] series3 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
     Double[] series4 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
     
     assertArrayEquals(reply.loanBarGraph.getNumbers().getSeries().get(0).getSeries(), series1);
     assertArrayEquals(reply.loanBarGraph.getNumbers().getSeries().get(1).getSeries(), series2);
     assertArrayEquals(reply.loanBarGraph.getNumbers().getSeries().get(2).getSeries(), series3);
     assertArrayEquals(reply.loanBarGraph.getNumbers().getSeries().get(3).getSeries(), series4);
     
     //amount of overdue loans byt value
     series1 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
     series2 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
     series3 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
     series4 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.4537, 0.0, 0.0, 0.0, 0.0};
   
         Assert.assertArrayEquals(reply.loanBarGraph.getAmountOfOverdueLoan().getSeries().get(0).getSeries(), series1);
         Assert.assertArrayEquals(reply.loanBarGraph.getAmountOfOverdueLoan().getSeries().get(1).getSeries(), series2);
         Assert.assertArrayEquals(reply.loanBarGraph.getAmountOfOverdueLoan().getSeries().get(2).getSeries(), series3);
         Assert.assertArrayEquals(reply.loanBarGraph.getAmountOfOverdueLoan().getSeries().get(3).getSeries(), series4);
     
         //payment status, Repayments
         series1 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
         series2 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2735700.0, 0.0, 0.0, 0.0, 0.0};
         series3 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
         series4 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};

         Assert.assertArrayEquals(reply.loanBarGraph.getRepayments().getSeries().get(0).getSeries(), series1);
         Assert.assertArrayEquals(reply.loanBarGraph.getRepayments().getSeries().get(1).getSeries(), series2);
         Assert.assertArrayEquals(reply.loanBarGraph.getRepayments().getSeries().get(2).getSeries(), series3);
         Assert.assertArrayEquals(reply.loanBarGraph.getRepayments().getSeries().get(3).getSeries(), series4);
         
    
         
         //Collections, Loan Performance
         series1 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 282000.0, 0.0, 0.0, 0.0, 0.0};
         series2 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2453700.0, 0.0, 0.0, 0.0, 0.0};


         Assert.assertArrayEquals(reply.loanBarGraph.getCollections().getSeries().get(0).getSeries(), series1);
         Assert.assertArrayEquals(reply.loanBarGraph.getCollections().getSeries().get(1).getSeries(), series2);
         
         
         //number of overdue loans
         series1 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
         series2 = new Double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};


         Assert.assertArrayEquals(reply.loanBarGraph.getNumberOfOverdueLoans().getSeries().get(0).getSeries(), series1);
         Assert.assertArrayEquals(reply.loanBarGraph.getNumberOfOverdueLoans().getSeries().get(1).getSeries(), series2);


         
         /*assertEquals(reply.loanBarGraph.getAmountOfOverdueLoan().getSeries(), series2);
     assertEquals(reply.loanBarGraph.getCollections().getSeries(), series3);
     assertEquals(reply.loanBarGraph.getNumberOfOverdueLoans().getSeries(), series4);*/
    }

    // }
}
