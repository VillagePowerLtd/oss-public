/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.rest;

import ch.villagepower.dao.BatchLoanService;
import ch.villagepower.dao.BatchService;
import ch.villagepower.dao.DepositService;
import ch.villagepower.dao.LoanService;
import ch.villagepower.dao.SaveService;
import ch.villagepower.entities.Batch;
import ch.villagepower.entities.BatchhasLoan;
import ch.villagepower.entities.BatchhasLoanPK;
import ch.villagepower.entities.Loan;
import ch.villagepower.entities.Portfolio;
import ch.villagepower.filter.AuthorizationFilter;
import ch.villagepower.filter.JWTAuthFilter;
import ch.villagepower.utils.HibernateProxyTypeAdapter;
import ch.villagepower.utils.JsonInput;
import ch.villagepower.utils.JsonReply;
import ch.villagepower.utils.PrintJson;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.File;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import org.apache.log4j.Logger;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.jboss.shrinkwrap.resolver.api.maven.Maven;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(Arquillian.class)
public class LoanResourceTest {

    final static Logger log = Logger.getLogger(LoanResourceTest.class.getName());

    private static Integer id;
    JsonReply reply;
    JsonInput mInput;
    Gson gson;

    @Deployment
    public static WebArchive createDeployment() {

        // Import Maven runtime dependencies
        File[] files = Maven.resolver().loadPomFromFile("pom.xml")
                .importRuntimeDependencies().resolve().withTransitivity().asFile();

        return ShrinkWrap
                .create(WebArchive.class, "loan-test.war").addPackages(true, "ch.villagepower")
                .addClasses(LoanService.class, ApplicationConfig.class, AuthorizationFilter.class, HibernateProxyTypeAdapter.class,
                        JWTAuthFilter.class, SaveService.class, AuthenticationResource.class, BatchResource.class, Loan.class, JsonReply.class, JsonInput.class,
                        BatchService.class, DepositService.class, BatchLoanService.class, BatchhasLoan.class, PrintJson.class, Batch.class, Portfolio.class,
                        BatchhasLoanPK.class, LoanResource.class, NewCrossOriginResourceSharingFilter.class, PortfolioResource.class, UserResource.class)
                .addAsWebInfResource("test-beans.xml", "beans.xml")
                .addAsWebInfResource("test-persistence-web.xml", "web.xml")
                //.addAsWebInfResource("glassfish-resources.xml", "setup/glassfish-resources.xml")
                .addAsResource("test-persistence.xml", "META-INF/persistence.xml")
                .addAsResource("hibernate.cfg.xml", "hibernate.cfg.xml")
                //.addAsDirectory("src/main/resources")
                .addAsLibraries(files);
    }

    /*@Test
    //@InSequence(1)
    public void testCsvUpload() {
        reply = new JsonReply("csvTest");
        gson = new GsonBuilder().registerTypeAdapterFactory(HibernateProxyTypeAdapter.FACTORY).setDateFormat("dd/MM/yyyy HH:mm").setPrettyPrinting().create();
        WebTarget target = ClientBuilder.newClient().register(MultiPartFeature.class)
                .target("http://localhost:8080/loa-1.0-SNAPSHOT/webresources/");

        final FileDataBodyPart filePart = new FileDataBodyPart("file", new File("/var/www/html/test/UNCDFDataTest.csv"));
        FormDataMultiPart formDataMultiPart = new FormDataMultiPart();
        final FormDataMultiPart multipart = (FormDataMultiPart) formDataMultiPart.field("file", filePart.getFileEntity(), MediaType.WILDCARD_TYPE).bodyPart(filePart);

        //final WebTarget target = client.target("http://localhost:10001/JerseyFileUpload/rest/upload/pdf");
        //Mreply response = target.request().post(Entity.entity(multipart, multipart.getMediaType()),JsonReply.class);
        Response resp = target.path("loan/csvUpload").request().post(Entity.entity(multipart, multipart.getMediaType()));
       // if (resp.getStatus() == 200) {
            assertEquals(200, resp.getStatus());

            reply = gson.fromJson(resp.readEntity(String.class), JsonReply.class);

            assertEquals("Upload Done 2 Loans", reply.message);
       // }

    }*/
    @Test
    //@InSequence(2)
    public void testFindAll() {
        reply = new JsonReply("testFindAllLoans");
        gson = new GsonBuilder().registerTypeAdapterFactory(HibernateProxyTypeAdapter.FACTORY).setDateFormat("dd/MM/yyyy HH:mm").setPrettyPrinting().create();
        WebTarget target = ClientBuilder.newClient()
                .target("http://localhost:8080/loa-1.0-SNAPSHOT/webresources/");

        Response r = target.path("loan/allLoans").request("application/json").get();
        //if (r.getStatus() == 200) {
        assertEquals(200, r.getStatus());

        reply = gson.fromJson(r.readEntity(String.class), JsonReply.class);
        if (!reply.result) {
            assertEquals("No loans found", reply.errorMessage);
            assertEquals(false, reply.result);
        } else {
            assertEquals("Found loans", reply.message);
            assertEquals(true, reply.result);
        }
        //}

    }
}
