$(function(){
	
	if (typeof $.cookie('loginToken') == 'undefined') {
		window.location.replace("login.jsp");
	}

	if (typeof $.cookie('userRole') == 'undefined') {
		window.location.replace("login.jsp");
	} else {
		if ($.cookie('userRole') == 'administrator') {

		} else if ($.cookie('userRole') == 'investor') { 
			$('#portfolio_menu').addClass("hidden");
			$('#batch_menu').addClass("hidden");
			$('#loans_menu').addClass("hidden");
			$('#payment_model_menu').addClass("hidden");
			$('#loan_repayment_curve_input').addClass("hidden");
			$('#profile_menu').addClass("hidden");
			
			var graphs= $.cookie('graphs').split(',');
			
			
			var displayPortfolioDevelopmentOverTimeTab=false;
			var displayRestructuredLoansTab=false;
			var displayLoanRepaymentsCurveTab=false;
			
			for(var graph=0;graph<=graphs.length;graph++){
				 
				if(graphs[graph]=='Portfolio Summary Statistics'){
					
				}
				 if(graphs[graph]=='Portfolio development over time'){
					displayPortfolioDevelopmentOverTimeTab=true;
				}
				 if(graphs[graph]=='Restructured loans'){
					displayRestructuredLoansTab=true;
				}
				 if(graphs[graph]=='Loan repayment curve'){
					displayLoanRepaymentsCurveTab=true;
				} 
				
			}
			
			if(displayPortfolioDevelopmentOverTimeTab==false){
				$('#portfolio_development_over_time_tab').addClass("hidden");
			}
			
			if(displayRestructuredLoansTab==false){
				$('#restructured_loans_tab').addClass("hidden");
			}
			
			if(displayLoanRepaymentsCurveTab==false){
				$('#loan_repayments_curve_tab').addClass("hidden");
			}
			
		}

	}
	
	
});