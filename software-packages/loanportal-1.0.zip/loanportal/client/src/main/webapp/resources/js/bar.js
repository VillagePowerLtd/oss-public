/**
 * Theme: Adminto Dashboard Author: Coderthemes Chartist chart
 */

// smil-animations Chart
// Stacked bar chart
$(function() {
	$("#logged_in_user").html($.cookie('userName'));
	loadBatchCombo();
	var chart;
	loadGraphs(); 

});

function loadBatchCombo() {

	$
			.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json',
					'Authorization' : $.cookie('loginToken')

				},
				type : "GET",
				url : RETRIEVE_BATCH,
				dataType : "json",
				success : function(data, status) {

					if (data.result == true) {
						var options = '';
						for ( var batchCount = 0; batchCount < data.batches.length; batchCount++) {
							options += ' <option value="'
									+ data.batches[batchCount].id + '">'
									+ data.batches[batchCount].name
									+ '</option>';
						}
						$('#batch').html(options);
					} else {

					}
				},
				error : function(jqXHR, textStatus, errorThrown) {

					if (errorThrown == 'Unauthorized') {

						onSessionTimeOut();
					}
				}

			});
}

function loadGraphs(chart) {

	console.log("loading testing graph data");

	var $number_of_restructured_loans_bar_graph = {
		labels : [ 'Jan', 'Feb', 'Mar', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug',
				'Sep', 'Oct', 'Nov', 'Dec' ],
		series : [ [ 0, 0, 0, 4, 7, 0, 0, 0, 0, 0, 0, 0 ] ]
	};

	chart = new Chartist.Bar('#number_of_restructured_loans',
			$number_of_restructured_loans_bar_graph, {
				stackBars : true,
				plugins : [ Chartist.plugins.tooltip() ]
			}).on('draw', function(data) {
		if (data.type === 'bar') {
			data.element.attr({
				style : 'stroke-width: 30px'
			});
		}
	});

	var $amount_of_restructured_loans_bar_graph = {
		labels : [ 'Jan', 'Feb', 'Mar', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug',
				'Sep', 'Oct', 'Nov', 'Dec' ],
		series : [ [ 0, 0, 0, 2.5, 3.5, 0, 0, 0, 0, 0, 0, 0 ] ]
	};

	chart = new Chartist.Bar('#amount_of_restructured_loans',
			$number_of_restructured_loans_bar_graph, {
				stackBars : true,
				plugins : [ Chartist.plugins.tooltip() ]
			}).on('draw', function(data) {
		if (data.type === 'bar') {
			data.element.attr({
				style : 'stroke-width: 30px'
			});
		}
	});
	
	
$('ul.nav a').on('shown.bs.tab', function (e) {
	chart.redraw();
	console.log('Loading Charts on Tab Entry....')
});

	var batch = {
		"batch" : {
			id : 17
		}
	};

	var batchJSONString = JSON.stringify(batch);

	retrieveVisualizeDonutChartsData(batchJSONString);

	$
			.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json',
					'Authorization' : $.cookie('loginToken')
				},
				type : "POST",
				url : RETRIEVE_DASH_BOARD_BAR_GRAPH_DATA,
				data : batchJSONString,
				async : false,
				dataType : "json",
				success : function(jsonData) {

					if (jsonData.result == true) {

						var BarGraph = function(labels, series) {
							this.labels = labels;
							this.series = series;
						};

						var $number_of_loans_in_portfolio_labels = [];
						var $number_of_loans_in_portfolio_series = [];

						$number_of_loans_in_portfolio_labels = jsonData.loanBarGraph.numbers.labels;

						for ( var i = 0; i < jsonData.loanBarGraph.numbers.series.length; i++) {

							$number_of_loans_in_portfolio_series[i] = jsonData.loanBarGraph.numbers.series[i].series;
						}

						var $number_of_loans_in_portfolio_bar_graph = new BarGraph(
								$number_of_loans_in_portfolio_labels,
								$number_of_loans_in_portfolio_series);

						chart = new Chartist.Bar('#numbers',
								$number_of_loans_in_portfolio_bar_graph, {
									stackBars : true,
									plugins : [ Chartist.plugins.tooltip() ]
								}).on('draw', function(data) {
							if (data.type === 'bar') {
								data.element.attr({
									style : 'stroke-width: 30px;'
								});
							}
						});

						/*
						 * Definition of the Loan repayment status bar-graph
						 * 
						 */

						var $loan_repayment_status_labels = [];
						var $loan_repayment_status_series = [];

						$loan_repayment_status_labels = jsonData.loanBarGraph.repayments.labels;

						for ( var i = 0; i < jsonData.loanBarGraph.repayments.series.length; i++) {

							$loan_repayment_status_series[i] = jsonData.loanBarGraph.repayments.series[i].series;
							console.log("Loading==>> Charts==>: " + i)
						}

						var $loan_repayment_status_bar_graph = new BarGraph(
								$loan_repayment_status_labels,
								$loan_repayment_status_series);

						chart = new Chartist.Bar('#repayments',
								$loan_repayment_status_bar_graph, {
									stackBars : true,
									plugins : [ Chartist.plugins.tooltip() ]
								}).on('draw', function(data) {
							if (data.type === 'bar') {
								data.element.attr({
									style : 'stroke-width: 30px'
								});
							}
						});

						/*
						 * Definition of the Collections (UGX - Millions)
						 * bargraph
						 * 
						 */

						var $collections_labels = [];
						var $collections_series = [];

						$collections_labels = jsonData.loanBarGraph.collections.labels;

						for ( var i = 0; i < jsonData.loanBarGraph.collections.series.length; i++) {

							$collections_series[i] = jsonData.loanBarGraph.collections.series[i].series;
						}

						var $collections_bar_graph = new BarGraph(
								$collections_labels, $collections_series);

						chart = new Chartist.Bar('#collections',
								$collections_bar_graph, {
									stackBars : true,
									plugins : [ Chartist.plugins.tooltip() ]
								}).on('draw', function(data) {
							if (data.type === 'bar') {
								data.element.attr({
									style : 'stroke-width: 30px'
								});
							}
						});

						$("#portfolio_development_over_time_tab").click(
								function() {
									chart.update();
								});

						/*
						 * Definition of the Overdue Loans (M UGX) bar-graph
						 * 
						 */

						var $amount_of_overdue_loans_labels = [];
						var $mount_of_overdue_loans_series = [];

						$amount_of_overdue_loans_labels = jsonData.loanBarGraph.amountOfOverdueLoan.labels;

						for ( var i = 0; i < jsonData.loanBarGraph.amountOfOverdueLoan.series.length; i++) {

							$mount_of_overdue_loans_series[i] = jsonData.loanBarGraph.amountOfOverdueLoan.series[i].series;
						}

						var $mount_of_overdue_loans_bar_graph = new BarGraph(
								$amount_of_overdue_loans_labels,
								$mount_of_overdue_loans_series);

						chart = new Chartist.Bar('#overdue_loans_amounts',
								$mount_of_overdue_loans_bar_graph, {
									stackBars : true,
									plugins : [ Chartist.plugins.tooltip() ]
								}).on('draw', function(data) {
							if (data.type === 'bar') {
								data.element.attr({
									style : 'stroke-width: 30px'
								});
							}
						});

						/*
						 * Definition of the Overdue Loans (Number of loans)
						 * bar-graph
						 * 
						 */

						var $number_of_overdue_loans_labels = [];
						var $number_of_overdue_loans_series = [];

						$number_of_overdue_loans_labels = jsonData.loanBarGraph.numberOfOverdueLoans.labels;

						for ( var i = 0; i < jsonData.loanBarGraph.numberOfOverdueLoans.series.length; i++) {

							$number_of_overdue_loans_series[i] = jsonData.loanBarGraph.numberOfOverdueLoans.series[i].series;
						}

						var $number_of_overdue_loans_bar_graph = new BarGraph(
								$number_of_overdue_loans_labels,
								$number_of_overdue_loans_series);

						new Chartist.Bar('#overdue_loans_numbers',
								$number_of_overdue_loans_bar_graph, {
									stackBars : true,
									plugins : [ Chartist.plugins.tooltip() ]
								}).on('draw', function(data) {
							if (data.type === 'bar') {
								data.element.attr({
									style : 'stroke-width: 30px'
								});
							}
						});

						/*
						 * Definition of the Write Offs & Recovery (M UGX)
						 * bar-graph
						 * 
						 */

						var $write_offs_recovery_labels = [];
						var $write_offs_recovery_series = [];

						$write_offs_recovery_labels = jsonData.loanBarGraph.writeOffsRecovery.labels;

						for ( var i = 0; i < jsonData.loanBarGraph.writeOffsRecovery.series.length; i++) {

							$write_offs_recovery_series[i] = jsonData.loanBarGraph.writeOffsRecovery.series[i].series;
							console.log("Write offs:==>> " + i);
						}

						var $write_offs_recovery_bar_graph = new BarGraph(
								$write_offs_recovery_labels,
								$write_offs_recovery_series);

						var data = $write_offs_recovery_bar_graph;

						var options = {
							seriesBarDistance : 10,
							plugins : [ Chartist.plugins.tooltip() ]
						};

						var responsiveOptions = [ [
								'screen and (max-width: 640px)',
								{
									seriesBarDistance : 5,
									axisX : {
										labelInterpolationFnc : function(value) {
											return value[2];
										}
									}
								} ] ];

						new Chartist.Bar('#write-offs-recovery', data, options,
								responsiveOptions).on('draw', function(data) {
							if (data.type === 'bar') {
								data.element.attr({
									style : 'stroke-width: 15px'
								});
							}
						});

						// Loan Repayment Curve

						var $repayment_curve_labels;
						var $repayment_expected_curve_series;
						var $repayment_actual_curve_series;

						$repayment_curve_labels = jsonData.loanBarGraph.restructured.labels;
						$repayment_expected_curve_series = jsonData.loanBarGraph.restructured.expected;
						$repayment_actual_curve_series = jsonData.loanBarGraph.restructured.actual;

						loadRepaymentCurve($repayment_curve_labels,
								$repayment_expected_curve_series,
								$repayment_actual_curve_series);

					} else {

						showServerResponse("ERROR",
								"No Loans to Analyse in this Batch.", "error");
					}

				},
				error : function(jqXHR, textStatus, errorThrown) {

					if (errorThrown == 'Unauthorized') {

						onSessionTimeOut();
					}
				}

			});

}

function retrieveVisualizeDonutChartsData(batchJSONString) {

	var $numberDonutData;
	var $repaymentDonutData;
	var $collectionDonutData;
	var $lastupdated;

	var $totalCollections;
	var $totalRepayments;
	var $totalLoans;
	var $numberOverdueLoans;
	var $writeOffAmount;
	var $recoveryAmount;
	var $outStanding;

	console.log("Loading DonutChartsData");

	$.ajax({
		headers : {
			'Accept' : 'application/json',
			'Content-Type' : 'application/json',
			'Authorization' : $.cookie('loginToken')
		},
		type : "POST",
		url : LOAD_DONUT_CHARTS,
		data : batchJSONString,
		async : false,
		dataType : "json",
		success : function(jsonData) {
			$numberDonutData = jsonData.loanDonutChart.numbers;
			$repaymentDonutData = jsonData.loanDonutChart.repayments;
			$collectionDonutData = jsonData.loanDonutChart.collections;
			$lastupdated = jsonData.loanDonutChart.latsUpdated;

			$totalCollections = jsonData.loanDonutChart.totalCollections;
			$totalRepayments = jsonData.loanDonutChart.totalRepayments;
			$totalLoans = jsonData.loanDonutChart.totalLoans;
			$numberOverdueLoans = jsonData.loanDonutChart.numberOverdueLoans;
			$writeOffAmount = jsonData.loanDonutChart.writeOffAmount;
			$recoveryAmount = jsonData.loanDonutChart.recoveryAmount;
			$outStanding = jsonData.loanDonutChart.outstanding;

		},
		error : function(jqXHR, textStatus, errorThrown) {

			if (errorThrown == 'Unauthorized') {

				onSessionTimeOut();
			}
		}
	})

	loadCharts($numberDonutData, $repaymentDonutData, $collectionDonutData,
			$lastupdated, $totalCollections, $totalRepayments, $totalLoans,
			$numberOverdueLoans, $writeOffAmount, $recoveryAmount, $outStanding);

}

function loadCharts(numberDonutData, repaymentDonutData, collectionDonutData,
		lastupdated, totalCollections, totalRepayments, totalLoans,
		numberOverdueLoans, writeOffAmount, recoveryAmount, outStanding) {

	$("#number").empty()
	$("#repayment").empty();
	$("#collection").empty();
	/* $("#last_updated").html(' last update: '+lastupdated); */
	/* $('#datepicker').val(getDate(new Date(lastupdated))); */
	$('#datepicker').val(lastupdated);

	$("#number_of_loans_in_Portfolio").html(
			totalLoans.toLocaleString("en") + " Loans");
	$("#portfolio_summary_statistics_loan_repayment_status").html(
			totalRepayments.toLocaleString("en") + " UGX");
	$("#portfolio_summary_statistics_collections").html(
			totalCollections.toLocaleString("en") + " UGX");

	$("#overdue_accounts_number").html(numberOverdueLoans.toLocaleString("en"));
	$("#overdue_accounts_balance").html(outStanding.toLocaleString("en"));

	$("#overdue_accounts_write_off").html(writeOffAmount.toLocaleString("en"));
	$("#overdue_accounts_recovered").html(recoveryAmount.toLocaleString("en"));

	var Dashboard1 = function() {
		this.$realData = []
	};

	// creates Donut chart
	Dashboard1.prototype.createDonutChart = function(element, data, colors) {
		Morris.Donut({
			element : element,
			data : data,
			resize : true, // defaulted to true
			colors : colors
		});
	},

	Dashboard1.prototype.init = function() {

		// Number of Loans Donut Chart
		$.Dashboard1.createDonutChart('number', numberDonutData, [ '#34a853',
				'#000000', "#ffc000", "#ea4335" ]);

		// Repayment Status Donut Chart
		$.Dashboard1.createDonutChart('repayment', repaymentDonutData, [
				'#34a853', '#ea4335', '#ffc000', "#000000", "#4285f4" ]);

		// Collections Donut Chart
		$.Dashboard1.createDonutChart('collection', collectionDonutData, [
				'#919293', '#4285f4' ]);

	},

	// init
	$.Dashboard1 = new Dashboard1, $.Dashboard1.Constructor = Dashboard1

	$.Dashboard1.init();

}

function loadRepaymentCurve($repayment_curve_labels,
		$repayment_expected_curve_series, $repayment_actual_curve_series) {

	new Chartist.Line('#loan_repayment_curve', {
		labels : $repayment_curve_labels,
		series : [ {
			name : 'Projected Curve',
			data : $repayment_expected_curve_series
		}, {
			name : 'Batch Curve',
			data : $repayment_actual_curve_series
		} ]
	}, {
		plugins : [ Chartist.plugins.tooltip() ]
	});

	var $chart = $('#loan_repayment_curve');

	var $toolTip = $chart.append('<div class="tooltip"></div>')
			.find('.tooltip').hide();

	$chart
			.on(
					'mouseenter',
					'.ct-point',
					function() {
						var $point = $(this), value = $point.attr('ct:value'), seriesName = $point
								.parent().attr('ct:series-name');
						$toolTip.html(seriesName + '<br>' + value).show();
					});

	$chart.on('mouseleave', '.ct-point', function() {
		$toolTip.hide();
	});

	$chart.on('mousemove', function(event) {
		$toolTip.css({
			left : (event.offsetX || event.originalEvent.layerX)
					- $toolTip.width() / 2 - 10,
			top : (event.offsetY || event.originalEvent.layerY)
					- $toolTip.height() - 40
		});
	});

}

function showServerResponse(title, msg, type) {
	var $toastlast;

	var shortCutFunction = false;
	var $showDuration = "300";
	var $hideDuration = "1000";
	var $timeOut = "5000";
	var $extendedTimeOut = "1000";
	var $showEasing = "swing";
	var $hideEasing = "linear";
	var $showMethod = "fadeIn";
	var $hideMethod = "fadeOut";

	toastr.options = {
		closeButton : false,
		debug : false,
		newestOnTop : false,
		progressBar : false,
		positionClass : "toast-top-right",
		preventDuplicates : false,
		onclick : null
	};

	// var $toast = toastr["success"](msg, title);
	var $toast = toastr[type](msg, title);
	$toastlast = $toast;

}
