$(function() {
	$("#logged_in_user").html($.cookie('userName')); 
	loadBathesTable();

	$('#new_batch_button').click(function() {
		loadPortfoliosCombo();
	});

	$('#save_batch').click(function() {
		//var $portfolio = $('#portfolio');
		var $batchName = $('#batch_name');
		var $batchDescription = $('#batch_description');

		var batch = {
			"type" : "object",
			"batch" : {
				name : $batchName.val(),
				description : $batchDescription.val(),
				portfolioid : {
					id : 15
				}
			}
		};

		var batchJSONString = JSON.stringify(batch);

		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json',
			'Authorization': $.cookie('loginToken')
			},
			type : "POST",
			url : CREATE_BATCH,
			data : batchJSONString,
			dataType : "json",
			success : function(data, status) {
				
				if(data.result){
					showServerResponse("Success", data.message,"success")
					loadBathesTable();
				}else{
					showServerResponse("ERROR", data.errorMessage,"error")
					loadBathesTable();
				}
				
			},
			error : function(jqXHR, textStatus,
					errorThrown) {
				loader.hideLoading();
				if (errorThrown == 'Unauthorized') {

					onSessionTimeOut();
				}
			}
		});

	});

	function loadBathesTable() {

		var loader;
		var table;

		loader = loader || (function() {
			var loaderDiv = $("#loading-modal");
			return {
				showLoading : function() {
					loaderDiv.modal();
				},
				hideLoading : function() {
					loaderDiv.modal('hide');
				}
			};
		})();

		loader.showLoading();
		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json',
					'Authorization': $.cookie('loginToken')
					},
					type : "GET",
					url : RETRIEVE_BATCH,
					dataType : "json",
					success : function(data, status) {

						table = $('#batch_table')
								.DataTable(
										{
											buttons: [
										        'copy', 'excel', 'pdf'
										    ],
											destroy : true,
											data : data.batches,
											
											columns : [
									            null,    
											{
											data : "id"
											}, 
											{
												data : "name"
											}, {
												data : "description"
											}, {
												data : "updateDate"
											}, null

											],
											columnDefs : [
													{
														orderable : false,
														targets : 0,
														defaultContent : "",
												        className: 'select-checkbox',
													},
													{
														targets : -1,
														data : null,
														defaultContent : " <a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit-batch-modal'></i></a><a href='#' class='on-default remove-row'><i class='fa fa-trash-o'></i></a>"
													}, {
														targets : [ 1 ],
														visible : false
													} ],
													
											select: {
									            style:    'os',
									            selector: 'td:first-child'
									        },

											order : [ [ 1, 'asc' ] ]

										});
						
						$('#batch_table').on('page.dt', function() {
							updateBatch(table);
							
							deleteBatch(table);
							
							});
							
							
							$('#batch_table').on('draw.dt', function() {
								updateBatch(table);
								
								deleteBatch(table);
							});

						loader.hideLoading();
						
						updateBatch(table);
						
						deleteBatch(table);
					},
					error : function(jqXHR, textStatus,
							errorThrown) {
						loader.hideLoading();
						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}
				});

		$('#share_loan_portfolio_button').click(function() {
			loadInvestorsToShareBatches();
		});

		$('#share_button')
				.click(
						function() {

							loader.showLoading();

							var $investors = $('#investors').val() || [];

							var sharedBatches = [];
							var sharedBatcheCount = 0;
							
							var rowData = table.rows( { selected: true } ).data().toArray();
							
							for ( var selectedInvestor = 0; selectedInvestor < $investors.length; selectedInvestor++) {

								for ( var i = 0; i < rowData.length; i++) {
									var sharedBatch = {
										batchid : {
											id : rowData[i].id
										},
										usersuserId : {
											userId : $investors[selectedInvestor]
										}
									}
									sharedBatches[sharedBatcheCount] = sharedBatch;
									sharedBatcheCount++;
								}
							}

							var investorBatches = {
								type : "object",
								userBatches : sharedBatches
							}

							var investorBatchesJSONString = JSON
									.stringify(investorBatches);

							$
									.ajax({
										headers : {
											'Accept' : 'application/json',
											'Content-Type' : 'application/json',
										'Authorization': $.cookie('loginToken')
										},
										type : "POST",
										url : SHARE_LOANS_WITH_INVESTORS,
										data : investorBatchesJSONString,
										dataType : "json",
										success : function(data, status) {
											
											loader.hideLoading();
											if(data.result){
												showServerResponse("Success",
														data.message,"success");
											}else{
												showServerResponse("ERROR",
														data.message,"error");
											}
											

										},
										error : function(jqXHR, textStatus,
												errorThrown) {
											loader.hideLoading();
											if (errorThrown == 'Unauthorized') {

												onSessionTimeOut();
											}
										}
									});

						});

	}

	function loadPortfoliosCombo() {
		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json',
					'Authorization': $.cookie('loginToken')
					},
					type : "GET",
					url : RETRIEVE_PORTFOLIOS,
					dataType : "json",
					success : function(data, status) {

						
						var options = '';
						for ( var portfolioCount = 0; portfolioCount < data.portfolios.length; portfolioCount++) {
							console.log("Portfolios Id: "+data.portfolios[portfolioCount].id)
							console.log("Portfolios Name: "+data.portfolios[portfolioCount].name)
							options += ' <option value="'
									+ data.portfolios[portfolioCount].id + '">'
									+ data.portfolios[portfolioCount].name
									+ '</option>';
						}
						$('#portfolio').html(options);
					}

				});
	}

	function loadInvestorsToShareBatches() {
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json',
			'Authorization': $.cookie('loginToken')
			},
			type : "GET",
			url : RETRIEVE_INVESTORS,
			dataType : "json",
			success : function(data, status) {

				var options = '';
				for ( var i = 0; i < data.users.length; i++) {
					options += ' <option value="' + data.users[i].userId + '">'
							+ data.users[i].firstname+' '+ data.users[i].lastname+ '</option>';
				}
				$('#investors').html(options);

			},
			error : function(jqXHR, textStatus,
					errorThrown) {
				loader.hideLoading();
				if (errorThrown == 'Unauthorized') {

					onSessionTimeOut();
				}
			}

		});
	}
	
	function updateBatch(table){
		$('a.edit-row').click(function (){
			var selectedBatch = table.row( { selected: true } ).data();
			
			$("#edit_batch_name").val(selectedBatch.name);
			$("#edit_batch_description").val(selectedBatch.description);
			
			$('#update_batch').click(function() {
				
				var $batchName = $('#edit_batch_name');
				var $batchDescription = $('#edit_batch_description');
				
				
				var batch = {
					"type" : "object",
					"batch" : {
						id:selectedBatch.id,
						name : $batchName.val(),
						description : $batchDescription.val(),
						/*updateDate:selectedBatch.updateDate,
						portfolioid : {
							id : 15
						}*/
						
					}
				};

				var batchJSONString = JSON.stringify(batch);
				
				console.log("loading update batch: "+batchJSONString);
				
				$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json',
					'Authorization': $.cookie('loginToken')
					},
					type : "POST",
					url : UPDATE_BATCH,
					data : batchJSONString,
					dataType : "json",
					success : function(data, status) {
						
						if(data.result){
							showServerResponse("Success", data.message,"success")
							loadBathesTable();
						}else{
							showServerResponse("ERROR", data.errorMessage,"error")
							loadBathesTable();
						}
						
					},
					error : function(jqXHR, textStatus,
							errorThrown) {
						loader.hideLoading();
						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}
				});

			});
		});
	}
	
	function deleteBatch(table){
		$('a.remove-row').click(function (){
			var selectedBatch = table.row( { selected: true } ).data();
			
				var batch = {
					"type" : "object",
					"batch" : {
						id:selectedBatch.id,
						name : selectedBatch.name,
						description :selectedBatch.description,
						/*updateDate:selectedBatch.updateDate,
						portfolioid : {
							id : 15
						}*/
						
					}
				};

				var batchJSONString = JSON.stringify(batch);

				$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json',
					'Authorization': $.cookie('loginToken')
					},
					type : "POST",
					url : DELETE_BATCH,
					data : batchJSONString,
					dataType : "json",
					success : function(data, status) {
						
						if(data.result){
							showServerResponse("Success", data.message,"success")
							loadBathesTable();
						}else{
							showServerResponse("ERROR", data.errorMessage,"error")
							loadBathesTable();
						}
						
					},
					error : function(jqXHR, textStatus,
							errorThrown) {
						loader.hideLoading();
						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}
				});

			
		});
	}


	function showServerResponse(title, msg,type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}

});