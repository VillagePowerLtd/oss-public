$(function(){
	
	$("#logged_in_user").html($.cookie('userName')); 
	
	loadBatchCombo();
	newButtonClicked();
	uploadSubmitButtonClicked();
	getBatchAnalysis();
	
	function newButtonClicked(){
		
		$('#new_batch_analysis_button').click(function (){
			console.log('Loading new_batch_analysis_button data')
			$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json',
				'Authorization': $.cookie('loginToken')
				},
				type : "GET",
				url : RETRIEVE_BATCH,
				dataType : "json",
				success : function(data, status) {

					var options = '';
					for ( var batchCount = 0; batchCount < data.batches.length; batchCount++) {
						options += ' <option value="'
								+ data.batches[batchCount].id + '">'
								+ data.batches[batchCount].name
								+ '</option>';
					}
					$('#batch_combo').html(options);
				},
				error : function(jqXHR, textStatus,
					errorThrown) {

				if (errorThrown == 'Unauthorized') {

					onSessionTimeOut();
				}
			}

			});
		});
		
		$('#save_new_batch_analysis_period_button').click(function(){

			var $batch = $('#batch_combo');
			var $analysisDays = $('#analysis_days');

			var batchAnalysis = {
				"type" : "object",
				"batchAnalysis" : {
					analysisDays: $analysisDays.val(),
					batchid : {
						id : $batch.val()
					}
				}
			};

			
			var batchAnalysisJSONString = JSON.stringify(batchAnalysis);
			
			console.log('batchAnalysis: '+batchAnalysisJSONString);

			$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json',
				'Authorization': $.cookie('loginToken')
				},
				type : "POST",
				url : ADD_BATCH_ANALYSIS,
				data : batchAnalysisJSONString,
				dataType : "json",
				success : function(data, status) {
					
					if(data.result){
						showServerResponse("Success", data.message,"success")
						loadBatchAnalysis(data);
					}else{
						showServerResponse("ERROR", data.errorMessage,"error")
						loadBatchAnalysis(data);
					}
					
				},
				error : function(jqXHR, textStatus,
						errorThrown) {
					loader.hideLoading();
					if (errorThrown == 'Unauthorized') {

						onSessionTimeOut();
					}
				}
			});
		
		});
		
		
	}
	
	function loadBatchCombo() {
		$.ajax({headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json',
					'Authorization': $.cookie('loginToken')
					},
					type : "GET",
					url : RETRIEVE_BATCH,
					dataType : "json",
					success : function(data, status) {

						var options = '';
						options += ' <option value="'
							+ '' + '">'
							+ 'Select Batch'
							+ '</option>';
						for ( var batchCount = 0; batchCount < data.batches.length; batchCount++) {
							options += ' <option value="'
									+ data.batches[batchCount].id + '">'
									+ data.batches[batchCount].name
									+ '</option>';
						}
						$('#batch').html(options);
					},
					error : function(jqXHR, textStatus,
						errorThrown) {

					if (errorThrown == 'Unauthorized') {

						onSessionTimeOut();
					}
				}

				});
	}
	
	function loadBatchAnalysis(data){

		var table = $('#batch_analysis_period_table')
				.DataTable(
						{
							destroy : true,
							data : data.batchAnalysises,
							
							columns : [
					            null,    
							{
							data : "idbatchAnalysis"
							}, 
							{
								data : "batchid.name"
							}, {
								data : "analysisDays"
							}, {
								data : "displayType"
							}, null

							],
							columnDefs : [
									{
										orderable : false,
										targets : 0,
										defaultContent : "",
								        className: 'select-checkbox',
									},
									{
										targets : -1,
										data : null,
										defaultContent : " <a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit-batch-modal'></i></a><a href='#' class='on-default remove-row'><i class='fa fa-trash-o'></i></a>"
									}, {
										targets : [ 1 ],
										visible : false
									} ],
									
							select: {
					            style:    'os',
					            selector: 'td:first-child'
					        },

							order : [ [ 1, 'asc' ] ]

						});
		$('#batch_analysis_period_table').on('page.dt', function() {
			  
			deleteBatchAnalysis(table);
			
			});
			
			
			$('#batch_analysis_period_table').on('draw.dt', function() {
				  
				deleteBatchAnalysis(table);
			});
		
			deleteBatchAnalysis(table);
	
	}
	
	function getBatchAnalysis(){
		$.ajax({headers : {
			'Accept' : 'application/json',
			'Content-Type' : 'application/json',
		'Authorization': $.cookie('loginToken')
		},
		type : "GET",
		url : GET_BATCH_ANALYSIS,
		dataType : "json",
		success : function(data, status) {
			loadBatchAnalysis(data);
		},
		error : function(jqXHR, textStatus,
			errorThrown) {

		if (errorThrown == 'Unauthorized') {

			onSessionTimeOut();
		}
	}
	});
	}
	

	function uploadSubmitButtonClicked() {
		
		$('#upload_file_button').click(function(){
			var batch=$('#batch').val();
			uploadFile(document.getElementById('fileinput').files[0],batch);
		});


	}
		
	
	function uploadFile(file,batch){
	    var url = 'http://104.236.194.94:9090/loa-1.0-SNAPSHOT/webresources/portfolio/addBatchProjectedData';
	    var xhr = new XMLHttpRequest();
	    var fd = new FormData();
	    xhr.open("POST", url, true);
	    xhr.onreadystatechange = function() {
	        if (xhr.readyState == 4 && xhr.status == 200) {
	            // Every thing ok, file uploaded
	            // handle response.
	            var data=JSON.parse(xhr.responseText);
	            console.log(data);
	            if(data.result==true){
	            	showServerResponse("Success", data.message,"success")
	            }else{
	            	showServerResponse("Success", data.errorMessage,"error")
	            }
	            
	        }
	    };
	    
	    console.log('Uploading file Batch:'+batch);
	    
	    fd.append("file", file);
	    fd.append("batch", batch);
	    xhr.send(fd);
	}
	
	function deleteBatchAnalysis(table){
		$('a.remove-row').click(function (){
			var selectedBatch = table.row( { selected: true } ).data();
			
				var batchAnalysis = {
					"type" : "object",
					"batchAnalysis" : {
						idbatchAnalysis:selectedBatch.idbatchAnalysis
					}
				};

				
				var batchAnalysisJSONString = JSON.stringify(batchAnalysis);
				
				console.log("batchAnalysisJSONString: ==> "+batchAnalysisJSONString);

				$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json',
					'Authorization': $.cookie('loginToken')
					},
					type : "POST",
					url : DELETE_BATCH_ANALYSIS,
					data : batchAnalysisJSONString,
					dataType : "json",
					success : function(data, status) {
						
						if(data.result){
							showServerResponse("Success", data.message,"success")
							getBatchAnalysis();
						}else{
							showServerResponse("ERROR", data.errorMessage,"error")
							getBatchAnalysis();
						}
						
					},
					error : function(jqXHR, textStatus,
							errorThrown) {
						loader.hideLoading();
						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}
				});

			
		});
	}

	
	
	
	function showServerResponse(title, msg,type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}
	
});