var SERVER_PATH='http://104.236.194.94:9090/loa-1.0-SNAPSHOT/';

var CREATE_BATCH=SERVER_PATH+'webresources/batch/createBatch';

var UPDATE_BATCH=SERVER_PATH+'webresources/portfolio/updateBatch';

var DELETE_BATCH=SERVER_PATH+'webresources/portfolio/deleteBatch';

var RETRIEVE_BATCH=SERVER_PATH+'webresources/batch/allBatches';

var RETRIEVE_BATCH_PORTFOLIO=SERVER_PATH+'webresources/portfolio/allBatchesInPortfolio';

var RETRIEVE_PORTFOLIOS=SERVER_PATH+'webresources/portfolio/allPortfolioes';

var CREATE_PORTFOLIOS=SERVER_PATH+'webresources/portfolio/createPortfolio';

var RETRIEVE_LOANS=SERVER_PATH+'webresources/loan/allLoans';

var ASSIGN_LOAN_TO_BATCH=SERVER_PATH+'webresources/batch/assignLoanBatch';

var UN_ASSIGN_LOAN_TO_BATCH=SERVER_PATH+'webresources/loan/unAssignLoanBatch';

var RETRIEVE_ASSIGNED_LOAN_TO_BATCH=SERVER_PATH+'webresources/batch/allLoansInBatches';

var RETRIEVE_DASH_BOARD_BAR_GRAPH_DATA=SERVER_PATH+'webresources/batch/batchChart';

var UPDATE_DASH_BOARD_DONUT_CHART=SERVER_PATH+'webresources/batch/updateBarGraph';

var CREATE_PROFILE=SERVER_PATH+'webresources/users/add';

var RETRIEVE_PROFILE=SERVER_PATH+'webresources/users/allUsers';

var RETRIEVE_INVESTORS=SERVER_PATH+'webresources/users/allInvestors';

var LOGIN=SERVER_PATH+'webresources/auth/login';

var LOAD_DONUT_CHARTS=SERVER_PATH+'webresources/batch/summaryOfLoans';

var LOG_OUT=SERVER_PATH+'webresources/auth/logout';

var SHARE_LOANS_WITH_INVESTORS=SERVER_PATH+'webresources/loan/assignBatchToInvestor';

var UN_SHARE_LOANS_WITH_INVESTORS=SERVER_PATH+'webresources/loan/unAssignBatchUser';

var DELETE_PROFILE=SERVER_PATH+'webresources/users/delete';

var UPDATE_PROFILE_ROLE=SERVER_PATH+'webresources/users/updateProfile';

var UPDATE_PROFILE=SERVER_PATH+'webresources/users/update';

var FOR_GOT_PASSWORD=SERVER_PATH+'webresources/users/forgotPassword';

var SHARE_GRAPHS_WITH_INVESTORS=SERVER_PATH+'webresources/loan/assignGraphToInvestor';

var UN_SHARE_GRAPHS_WITH_INVESTORS=SERVER_PATH+'webresources/loan/unAssignGraphUser';

var GRAPHS_SHARED_WITH_INVESTOR=SERVER_PATH+'webresources/users/userBatchGraphs';

var CREATE_PAYMENT_MODEL=SERVER_PATH+'webresources/portfolio/createDeposit';

var UPDATE_PAYMENT_MODEL=SERVER_PATH+'webresources/portfolio/updatePlan';

var DELETE_PAYMENT_MODEL=SERVER_PATH+'webresources/portfolio/deletePlan';

var GET_PAYMENT_MODELS=SERVER_PATH+'webresources/loan/allDeposits';

var SEARCH_LOANS=SERVER_PATH+'webresources/loan/searchLoans';

var ADD_BATCH_ANALYSIS=SERVER_PATH+'webresources/portfolio/addBatchAnalysis';

var DELETE_BATCH_ANALYSIS=SERVER_PATH+'webresources/portfolio/deleteBatchAnalysis';

var GET_BATCH_ANALYSIS=SERVER_PATH+'webresources/portfolio/allBatchAnalyses';

