$(function() {
	
	console.log("#un_assign_loans first load");

	$('#datatable_loan_portfolio_batch tfoot th').each(function() {
		var title = $(this).text();
		$(this).html('<input type="text" placeholder="Search ' + '" />');
	});
	
	getLoans();
	loadBatchCombo();
	//loadPortfolioCombo();
	//onPortfolioSelected();
	updateDashboard();
	
	unAssignLoansFromBatch();

	var $table;
	
	
	function loadBatchLoads(loader){
  
		loader.showLoading();

		var $selected_batch = $('#loan_portfolio_batch_combo');

		var batch = {
			"type" : "object",
			"batch" : {
				id : $selected_batch.val()

			}
		};

		var batchJSONString = JSON.stringify(batch);
		
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json',
				'Authorization': $.cookie('loginToken')
			},
			type : "POST",
			url : RETRIEVE_ASSIGNED_LOAN_TO_BATCH,
			data : batchJSONString,
			dataType : "json",
			success : function(data, status) {
				
				if(data.result){
			$table=	$('#datatable_loan_portfolio_batch').DataTable({
					destroy : true,
					data : data.batchhasLoans,
					
					columns : [ null, {
						data : "loan.id"
					}, {
						data : "loan.totalAmountValue"
					}, {
						data : "loan.downPaymentDate"
					}, {
						data : "loan.balance"
					}, {
						data : "loan.status"
					}, {
						data : "loan.uploadDate"
					},
					{
						data : "loan.modelPurchased"
					},
					{
						data : "loan.salesAgent"
					},
					{
						data : "loan.distributionAgent"
					},
					{
						data : "loan.store"
					},
					 
					{
						data : "loan.historyStatus"
					} ,
					{
						data : "loan.district"
					},
					{
						data : "loan.subcounty"
					},
					{
						data : "loan.parish"
					}
					,
					{
						data : "loan.village"
					}
					],

					columnDefs : [ {
						orderable : false,
						targets : 0,
						defaultContent : "",
						orderable : false,
						targets : 0,
						defaultContent : "",
				        className: 'select-checkbox',
					},
					

					 {
						targets : [ 11 ],
						visible : false
					} ],
					
					select: {
			            style:    'multi',
			            selector: 'td:first-child'
			        },

					order : [ [ 1, 'asc' ] ],
					
					dom: 'Bfrtip',
			        select: true,
			        lengthMenu: [
			            [ 10, 25, 50,100,200,300,400,500 -1 ],
			            [ '10 rows', '25 rows', '50 rows','100 rows','200 rows','300 rows','400 rows','500 rows', 'Show all' ]
			        ],
			        buttons: [
			        	'pageLength',
			            {
			                text: 'Select all',
			                action: function () {
			                	//$table.rows().select();
			                	$table.rows({ page: 'current' }).select();
			                }
			            },
			            {
			                text: 'Select none',
			                action: function () {
			                	$table.rows().deselect();
			                }
			            },
			            
			            
			        ],
			        
			        select: {
			            style:    'multi',
			            selector: 'td:first-child'
			        }

				});
				}else{
					$table=	$('#datatable_loan_portfolio_batch').DataTable({
						destroy : true,
						data : []});
				}
				
				loader.hideLoading();

				
				$table.columns().every(function() {
					var that = this;

					$('input', this.footer()).on('keyup change', function() {
						if (that.search() !== this.value) {
							that.search(this.value).draw();
						}
					});
				});	
				
			},
			error : function(jqXHR, textStatus,
					errorThrown) {

				if (errorThrown == 'Unauthorized') {

					onSessionTimeOut();
				}
			}
		});

	
	}
	function getLoans() {
		$('#load_loan_portfolio_batch').click(function() {
			var loader;
			loader = loader || (function() {
				var loaderDiv = $("#loading-modal");
				return {
					showLoading : function() {
						loaderDiv.modal();
					},
					hideLoading : function() {
						loaderDiv.modal('hide');
					}
				};
			})();
			
			loadBatchLoads(loader);
		});

	}
	
	function unAssignLoansFromBatch(){
		
		$('#un_assign_loans').click(function(){
			
			console.log("unAssignLoans Button Clicked:");
			
			var loader;
					loader = loader || (function() {
						var loaderDiv = $("#loading-modal");
						return {
							showLoading : function() {
								loaderDiv.modal();
							},
							hideLoading : function() {
								loaderDiv.modal('hide');
							}
						};
					})();

					loader.showLoading();
			
			var $selected_batch = $('#loan_portfolio_batch_combo');

			var loans = [];

			var rowData = $table.rows( { selected: true } ).data().toArray();
			
			if(rowData.length>0){
				for ( var i = 0; i < rowData.length; i++) {
			
				console.log("rowData " +rowData[i].loan.id);
				
				var batchhasLoan = {
					loan : {
						id : rowData[i].loan.id
					},
					batch : {
						id : $selected_batch.val()
					}
				};

				loans[i] = batchhasLoan;
			}

			var batchLoanObject = {
				"type" : "object",
				"batchLoans" : loans
			}

			var batchJSONString = JSON.stringify(batchLoanObject);
			console.log("LoanBatch Submission JSON: "+ batchJSONString);
							$.ajax({
							headers : {
								'Accept' : 'application/json',
								'Content-Type' : 'application/json',
								'Authorization' : $
										.cookie('loginToken')
							},
							type : "POST",
							url : UN_ASSIGN_LOAN_TO_BATCH,
							data : batchJSONString,
							dataType : "json",
							success : function(data, status) {
								 
								if(data.result){
									loadBatchLoads(loader);
								 
									showServerResponse("Success","Loans unassigned from batch successfully","success");
									console.log("LoanBatch Submission Feedback: "+ data.message);
								}else{
								 
									showServerResponse("ERROR","An error Occured while un-assigning loans from batch","error");
								}
								

							},
							error : function(jqXHR, textStatus,
									errorThrown) {
							loader.hideLoading();
							showServerResponse("ERROR","An error Occured while un-assigning loans from batch "+textStatus,"error");
								if (errorThrown == 'Unauthorized') {

									onSessionTimeOut();
								}
							}
						});
			}else{
			loader.hideLoading();
			showServerResponse("ERROR","Please Select Loans to be unassigned from batch","error");
			}

			
			});
	}

	function loadBatchCombo() {
		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json',
					'Authorization': $.cookie('loginToken')
					},
					type : "GET",
					url : RETRIEVE_BATCH,
					dataType : "json",
					success : function(data, status) {

						var options = '';
						for ( var batchCount = 0; batchCount < data.batches.length; batchCount++) {
							options += ' <option value="'
									+ data.batches[batchCount].id + '">'
									+ data.batches[batchCount].name
									+ '</option>';
						}
						$('#loan_portfolio_batch_combo').html(options);
					},
					error : function(jqXHR, textStatus,
						errorThrown) {

					if (errorThrown == 'Unauthorized') {

						onSessionTimeOut();
					}
				}

				});
	}

	function updateDashboard() {
		$("#update_dashboard").click(function() {

			var loader;
			loader = loader || (function() {
				var loaderDiv = $("#loading-modal");
				return {
					showLoading : function() {
						loaderDiv.modal();
					},
					hideLoading : function() {
						loaderDiv.modal('hide');
					}
				};
			})();

			loader.showLoading();

			var $selected_batch = $('#loan_portfolio_batch_combo');

			var batch = {
				"type" : "object",
				"batch" : {
					id : $selected_batch.val()

				}
			};

			var batchJSONString = JSON.stringify(batch);

			$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json',
				'Authorization': $.cookie('loginToken')
				},
				type : "POST",
				url : UPDATE_DASH_BOARD_DONUT_CHART,
				dataType : "json",
				data : batchJSONString,
				success : function(data, status) {
					loader.hideLoading();
					showServerResponse("Success", data.message,"success");
				},
				error : function(jqXHR, textStatus,errorThrown) {
					loader.hideLoading();
			if (errorThrown == 'Unauthorized') {

				onSessionTimeOut();
			}
		}

			});

		});

	}
	
	function loadPortfolioCombo() {
		$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json',
						'Authorization' : $.cookie('loginToken')
					},
					type : "GET",
					url : RETRIEVE_PORTFOLIOS,
					dataType : "json",
					success : function(data, status) {

						var options = '';
						for ( var portfolioCount = 0; portfolioCount < data.portfolios.length; portfolioCount++) {
							options += ' <option value="'
									+ data.portfolios[portfolioCount].id + '">'
									+ data.portfolios[portfolioCount].name
									+ '</option>';
						}
						$('#loan_portfolio_combo').html(options);
					},
					error : function(jqXHR, textStatus, errorThrown) {

						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}

				});
	}
	
	function onPortfolioSelected(){
		$('#loan_portfolio_combo').change(function (){
			
			var $selected_portfolio = $('#loan_portfolio_combo');
			
			var portfolio = {
					"type" : "object",
					"portfolio" : {
						id : $selected_portfolio.val()
					}
				};

			var portfolioDataJSONString = JSON.stringify(portfolio);
			
			$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json',
					'Authorization' : $.cookie('loginToken')
				},
				type : "POST",
				url : RETRIEVE_BATCH_PORTFOLIO,
				data : portfolioDataJSONString,
				dataType : "json",
				success : function(data, status) {
					
					console.log("Loaded Batches==>> "+data);
					var options = '';
					if(data.result){
						for ( var batchCount = 0; batchCount < data.batches.length; batchCount++) {
							options += ' <option value="'
									+ data.batches[batchCount].id + '">'
									+ data.batches[batchCount].name
									+ '</option>';
						}
						$('#loan_portfolio_batch_combo').html(options);
					}else{
						$('#loan_portfolio_batch_combo').html(options);
					}
					
				},
				error : function(jqXHR, textStatus, errorThrown) {

					if (errorThrown == 'Unauthorized') {

						onSessionTimeOut();
					}
				}

			});
			
		});
	}
	


	function showServerResponse(title, msg,type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}

});