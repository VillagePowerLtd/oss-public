[
 {"numbers": 
	{
"labels": [ "January","February", "March","April","May"],

"series": [ 
          {"within": [
                      {"month":"January","value":5000},
                      {"month":"February","value":5000},
                      {"month":"March","value":4700},
                      {"month":"April","value":4450},
                      {"month":"May","value":4270}
                      
                      ]},
          {"overdue": [
                       {"month":"January","value":0},
                       {"month":"February","value":0},
                       {"month":"March","value":200},
                       {"month":"April","value":300},
                       {"month":"May","value":400}]},
          {"closed": [
                      {"month":"January","value":0},
                      {"month":"February","value":0},
                      {"month":"March","value":100},
                      {"month":"April","value":200},
                      {"month":"May","value":250}]},
          {"paidup": [ 
                       {"month":"January","value":0},
                       {"month":"February","value":0},
                       {"month":"March","value":0},
                       {"month":"April","value":50},
                       {"month":"May","value":80}]}
        ]
}
},
 

{"repayments": 
{
"labels": [ "January","February", "March","April","May"],

"series": [ 
      {"within": [
                  {"month":"January","value":200},
                  {"month":"February","value":200},
                  {"month":"March","value":188},
                  {"month":"April","value":178},
                  {"month":"May","value":170.8}
                  
                  ]},
      {"overdue": [
                   {"month":"January","value":0},
                   {"month":"February","value":0},
                   {"month":"March","value":8},
                   {"month":"April","value":12},
                   {"month":"May","value":16}]},
      {"closed": [
                  {"month":"January","value":0},
                  {"month":"February","value":0},
                  {"month":"March","value":0},
                  {"month":"April","value":2},
                  {"month":"May","value":3.2}]},
      {"paidup": [ 
                   {"month":"January","value":0},
                   {"month":"February","value":0},
                   {"month":"March","value":4},
                   {"month":"April","value":8},
                   {"month":"May","value":10}]}
    ]
}
},

{"collections": 
{
"labels": [ "January","February", "March","April","May"],

"series": [ 
      {"outstanding": [
                  {"month":"January","value":180},
                  {"month":"February","value":170},
                  {"month":"March","value":160},
                  {"month":"April","value":150},
                  {"month":"May","value":140}
                  
                  ]},
      {"collected": [ 
                   {"month":"January","value":20},
                   {"month":"February","value":30},
                   {"month":"March","value":40},
                   {"month":"April","value":50},
                   {"month":"May","value":60}]}
    ]
}
},

{"amountsOfOverdueLoans": 
{
"labels": [ "January","February", "March","April","May"],

"series": [ 
      {"amountsAtRisk": [
                  {"month":"January","value":0},
                  {"month":"February","value":0},
                  {"month":"March","value":6},
                  {"month":"April","value":6},
                  {"month":"May","value":6}
                  
                  ]},
	  {"AmountsReposessed": [
	                   {"month":"January","value":0},
	                   {"month":"February","value":0},
	                   {"month":"March","value":2},
	                   {"month":"April","value":2},
	                   {"month":"May","value":2}
	                   
	                   ]},       
      {"AmountDefauted": [ 
                   {"month":"January","value":0},
                   {"month":"February","value":0},
                   {"month":"March","value":2},
                   {"month":"April","value":2},
                   {"month":"May","value":2}]}
    ]
}
},

{"numberOfOverdueLoans": 
{
"labels": [ "January","February", "March","April","May"],

"series": [ 
      {"amountsAtRisk": [
                  {"month":"January","value":0},
                  {"month":"February","value":0},
                  {"month":"March","value":150},
                  {"month":"April","value":150},
                  {"month":"May","value":150}
                  
                  ]},
	  {"AmountsReposessed": [
	                   {"month":"January","value":0},
	                   {"month":"February","value":0},
	                   {"month":"March","value":50},
	                   {"month":"April","value":50},
	                   {"month":"May","value":50}
	                   
	                   ]},       
      {"AmountDefauted": [ 
                   {"month":"January","value":0},
                   {"month":"February","value":0},
                   {"month":"March","value":50},
                   {"month":"April","value":50},
                   {"month":"May","value":50}]}
    ]
}
},

{"writeoffs&Recovery": 
{
"labels": [ "January","February", "March","April","May"],

"series": [ 
      {"valueOfWriteOffs": [
                  {"month":"January","value":0},
                  {"month":"February","value":0},
                  {"month":"March","value":0},
                  {"month":"April","value":2},
                  {"month":"May","value":3.2}
                  
                  ]},
                  
      {"valueOfRecovery": [ 
                   {"month":"January","value":0},
                   {"month":"February","value":0},
                   {"month":"March","value":0},
                   {"month":"April","value":1.5},
                   {"month":"May","value":3}]}
    ]
}
}

]