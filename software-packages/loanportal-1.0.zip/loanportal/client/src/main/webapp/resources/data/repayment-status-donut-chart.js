[
{
	"label": "Within", 
	"value": 170800000
},
{
	"label": "Paid Up", 
	"value": 10000000
},
{
	"label": "Overdue", 
	"value": 16000000
},
{
	"label": "Closed", 
	"value": 3200000
 }
]