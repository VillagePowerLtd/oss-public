/**
 * Theme: Adminto Admin Template Author: Coderthemes Dashboard
 */

 $(function(){
 
	function retrieveDonutChartsData() {
		
		var $numberDonutData;
		var $repaymentDonutData;
		var $collectionDonutData;
		
		var $batch = $('#batch');

		var batch = {
			"batch" : {
				id : $batch.val()
			}
		};

		console.log("Loading Kasoma");

		var batchJSONString = JSON.stringify(batch);
		
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "POST",
			url : 'http://104.236.194.94:9090/loa-1.0-SNAPSHOT/webresources/batch/summaryNumberOfLoans',
			data : batchJSONString,
			async : false,
			dataType : "json",
			success : function(jsonData) {
				$numberDonutData = jsonData.number;

				
			}
		})
		
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "POST",
			url : 'http://104.236.194.94:9090/loa-1.0-SNAPSHOT/webresources/batch/summaryRepayments',
			data : batchJSONString,
			async : false,
			dataType : "json",
			success : function(jsonData) {
				$repaymentDonutData = jsonData.repayment;

				
			}
		})
		
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "POST",
			url : 'http://104.236.194.94:9090/loa-1.0-SNAPSHOT/webresources/batch/summaryCollections',
			data : batchJSONString,
			async : false,
			dataType : "json",
			success : function(jsonData) {
				$collectionDonutData = jsonData.collection;
				
			}
		})
		
		loadCharts($numberDonutData,$repaymentDonutData,$collectionDonutData);
		
	 
	}
	
	
	
	function loadCharts(numberDonutData,repaymentDonutData,collectionDonutData){
		

		$("#number").empty()
		$("#repayment").empty();
		$("#collection").empty();
	
		var Dashboard1 = function() {
			this.$realData = []
		     };
		     
		  // creates Donut chart
			Dashboard1.prototype.createDonutChart = function(element, data, colors) {
				Morris.Donut({
					element : element,
					data : data,
					resize : true, // defaulted to true
					colors : colors
				});
			},

			Dashboard1.prototype.init = function() { 
				
				// Number of Loans Donut Chart
				$.Dashboard1.createDonutChart('number', numberDonutData,['#000000', '#34a853', "#919293", "#ef081d"]);

				// Repayment Status Donut Chart
				$.Dashboard1.createDonutChart('repayment', repaymentDonutData, [ '#000000', '#34a853', "#919293", "#ef081d"]);

				// Collections Donut Chart
				$.Dashboard1.createDonutChart('collection', collectionDonutData, ['#34a853', '#ea4335' ]);
					
			},
			
			// init 
		  $.Dashboard1 = new Dashboard1, $.Dashboard1.Constructor = Dashboard1
			
		 $.Dashboard1.init();
		 
		
	}
	 
 })
