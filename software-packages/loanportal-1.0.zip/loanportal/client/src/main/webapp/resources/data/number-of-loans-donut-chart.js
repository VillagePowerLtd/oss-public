[{
	"numbers":[
				{
					"label": "Within", 
					"value": 4270
				},
				{
					"label": "Paid Up", 
					"value": 400
				},
				{
					"label": "Overdue", 
					"value": 250
				},
				{
					"label": "Closed", 
					"value": 80
				 }
			],
			
"collections":[
				{
					"label": "Outstanding", 
					"value": 140000000
				},
				{
					"label": "Collected", 
					"value": 60000000
				}
			],


"repayments":[
				{
					"label": "Within", 
					"value": 170800000
				},
				{
					"label": "Paid Up", 
					"value": 10000000
				},
				{
					"label": "Overdue", 
					"value": 16000000
				},
				{
					"label": "Closed", 
					"value": 3200000
				 }
]

}
]