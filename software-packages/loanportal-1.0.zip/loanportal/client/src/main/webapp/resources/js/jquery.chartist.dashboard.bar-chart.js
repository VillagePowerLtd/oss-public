/**
 * Theme: Adminto Dashboard Author: Coderthemes Chartist chart
 */

// smil-animations Chart
// Stacked bar chart
$(function() {
	$("#logged_in_user").html($.cookie('userName'));
	loadBatchCombo();
	loadGraphs();
	
});

function loadBatchCombo() {

	$
			.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json',
					'Authorization' : $.cookie('loginToken')

				},
				type : "GET",
				url : RETRIEVE_BATCH,
				dataType : "json",
				success : function(data, status) {

					if (data.result == true) {
						var options = '';
						for ( var batchCount = 0; batchCount < data.batches.length; batchCount++) {
							options += ' <option value="'
									+ data.batches[batchCount].id + '">'
									+ data.batches[batchCount].name
									+ '</option>';
						}
						$('#batch').html(options);
					} else {

					}
				},
				error : function(jqXHR, textStatus, errorThrown) {

					if (errorThrown == 'Unauthorized') {

						onSessionTimeOut();
					}
				}

			});
}

function loadGraphs() {
	$('#loan_graphs')
			.click(
					function() {

						var loader = loader || (function() {
							var loaderDiv = $("#loading-modal");
							return {
								showLoading : function() {
									loaderDiv.modal();
								},
								hideLoading : function() {
									loaderDiv.modal('hide');
								}
							};
						})();

						var $batch = $('#batch');

						var batch = {
							"batch" : {
								id : $batch.val()
							}
						};

						var batchJSONString = JSON.stringify(batch);
						

						loader.showLoading();
						retrieveVisualizeDonutChartsData(batchJSONString,loader);

						$
								.ajax({
									headers : {
										'Accept' : 'application/json',
										'Content-Type' : 'application/json',
										'Authorization' : $
												.cookie('loginToken')
									},
									type : "POST",
									url : RETRIEVE_DASH_BOARD_BAR_GRAPH_DATA,
									data : batchJSONString,
									async : false,
									dataType : "json",
									success : function(jsonData) {

										if (jsonData.result == true) {

											var BarGraph = function(labels,
													series) {
												this.labels = labels;
												this.series = series;
											};

											var $number_of_loans_in_portfolio_labels = [];
											var $number_of_loans_in_portfolio_series = [];

											$number_of_loans_in_portfolio_labels = jsonData.loanBarGraph.numbers.labels;

											for ( var i = 0; i < jsonData.loanBarGraph.numbers.series.length; i++) {

												$number_of_loans_in_portfolio_series[i] = jsonData.loanBarGraph.numbers.series[i].series;
											}

											var $number_of_loans_in_portfolio_bar_graph = new BarGraph(
													$number_of_loans_in_portfolio_labels,
													$number_of_loans_in_portfolio_series);
											
											//function call
											numberOfLoansInPortfolioBarGraph($number_of_loans_in_portfolio_bar_graph); 
												
											
											/*
											 * Definition of the Loan repayment
											 * status bar-graph
											 * 
											 */

											var $loan_repayment_status_labels = [];
											var $loan_repayment_status_series = [];

											$loan_repayment_status_labels = jsonData.loanBarGraph.repayments.labels;

											for ( var i = 0; i < jsonData.loanBarGraph.repayments.series.length; i++) {

												$loan_repayment_status_series[i] = jsonData.loanBarGraph.repayments.series[i].series;
												 
											}

											var $loan_repayment_status_bar_graph = new BarGraph(
													$loan_repayment_status_labels,
													$loan_repayment_status_series);
											
											//function call
											loanRepaymentStatusBarGraph($loan_repayment_status_bar_graph);
											 

											/*
											 * Definition of the Collections
											 * (UGX - Millions) bargraph
											 * 
											 */

											var $collections_labels = [];
											var $collections_series = [];

											$collections_labels = jsonData.loanBarGraph.collections.labels;

											for ( var i = 0; i < jsonData.loanBarGraph.collections.series.length; i++) {

												$collections_series[i] = jsonData.loanBarGraph.collections.series[i].series;
											}

											var $collections_bar_graph = new BarGraph(
													$collections_labels,
													$collections_series);
											
											//function call
											collectionBbarGraph($collections_bar_graph); 


											/*
											 * Definition of the Overdue Loans
											 * (M UGX) bar-graph
											 * 
											 */

											var $amount_of_overdue_loans_labels = [];
											var $mount_of_overdue_loans_series = [];

											$amount_of_overdue_loans_labels = jsonData.loanBarGraph.amountOfOverdueLoan.labels;

											for ( var i = 0; i < jsonData.loanBarGraph.amountOfOverdueLoan.series.length; i++) {

												$mount_of_overdue_loans_series[i] = jsonData.loanBarGraph.amountOfOverdueLoan.series[i].series;
											}

											var $mount_of_overdue_loans_bar_graph = new BarGraph(
													$amount_of_overdue_loans_labels,
													$mount_of_overdue_loans_series);

											//function call
											amountOfOverdueLoansBarGraph($mount_of_overdue_loans_bar_graph); 
											

											/*
											 * Definition of the Overdue Loans
											 * (Number of loans) bar-graph
											 * 
											 */

											var $number_of_overdue_loans_labels = [];
											var $number_of_overdue_loans_series = [];

											$number_of_overdue_loans_labels = jsonData.loanBarGraph.numberOfOverdueLoans.labels;

											for ( var i = 0; i < jsonData.loanBarGraph.numberOfOverdueLoans.series.length; i++) {

												$number_of_overdue_loans_series[i] = jsonData.loanBarGraph.numberOfOverdueLoans.series[i].series;
											}

											var $number_of_overdue_loans_bar_graph = new BarGraph(
													$number_of_overdue_loans_labels,
													$number_of_overdue_loans_series);

											//function call
											numberOfOverdueLoansBarGraph($number_of_overdue_loans_bar_graph); 

											/*
											 * Definition of the Write Offs &
											 * Recovery (M UGX) bar-graph
											 * 
											 */

											var $write_offs_recovery_labels = [];
											var $write_offs_recovery_series = [];

											$write_offs_recovery_labels = jsonData.loanBarGraph.writeOffsRecovery.labels;

											for ( var i = 0; i < jsonData.loanBarGraph.writeOffsRecovery.series.length; i++) {

												$write_offs_recovery_series[i] = jsonData.loanBarGraph.writeOffsRecovery.series[i].series;
												console.log("Write offs:==>> "
														+ i);
											}

											var $write_offs_recovery_bar_graph = new BarGraph(
													$write_offs_recovery_labels,
													$write_offs_recovery_series);

											var data = $write_offs_recovery_bar_graph;

											var options = {
												seriesBarDistance : 10,
												plugins : [ Chartist.plugins
														.tooltip() ]
											};

											var responsiveOptions = [ [
													'screen and (max-width: 640px)',
													{
														seriesBarDistance : 5,
														axisX : {
															labelInterpolationFnc : function(
																	value) {
																return value[2];
															}
														}
													} ] ];
											
											//function call
											writeOffsecovery(data,options,responsiveOptions);
																				

											// Loan Repayment Curve

											var $repayment_curve_labels;
											var $repayment_expected_curve_series;
											var $repayment_actual_curve_series;

											if (!(jsonData.loanBarGraph.restructured==undefined)) {
												console.log("loading loan repayment curve");
												if(!(jsonData.loanBarGraph.restructured.labels==undefined)){
													console.log("loading loan repayment curve labels");
													$repayment_curve_labels = jsonData.loanBarGraph.restructured.labels;
												}
												
												if(!(jsonData.loanBarGraph.restructured.expected==undefined)){
													console.log("loading loan repayment curve expected");
													$repayment_expected_curve_series = jsonData.loanBarGraph.restructured.expected;
												}
												
												if(!(jsonData.loanBarGraph.restructured.actual==undefined)){
													console.log("loading loan repayment curve actual");
													$repayment_actual_curve_series = jsonData.loanBarGraph.restructured.actual;
												}
											}
											
											
											
											// Number of Restructured loans
											var $number_of_restructured_loans_labels = [];
											var $number_of_restructured_loans_series = [];

											if(!(jsonData.loanBarGraph.restructuredLoanNumber==undefined)){
												
												if(!(jsonData.loanBarGraph.restructuredLoanNumber.labels==undefined)){
													$number_of_restructured_loans_labels = jsonData.loanBarGraph.restructuredLoanNumber.labels;
												}
												
											}
											 
											
											 for ( var i = 0; i < jsonData.loanBarGraph.restructuredLoanNumber.series.length; i++) {

												$number_of_restructured_loans_series[i] = jsonData.loanBarGraph.restructuredLoanNumber.series[i].series;
												
												console.log("$number_of_restructured_loans_series: loading.."+$number_of_restructured_loans_series);
											} 

											var $number_of_restructured_loans_bar_graph = new BarGraph(
													$number_of_restructured_loans_labels,
													$number_of_restructured_loans_series);
											
											//function call
											numberOfRestructuredLoansBarGraph($number_of_restructured_loans_bar_graph);
											
											
											// value of Restructured loans
											var $amount_of_restructured_loans_labels = [];
											var $amount_of_restructured_loans_series = [];

											$amount_of_restructured_loans_labels = jsonData.loanBarGraph.restructuredLoanValue.labels;

											for ( var i = 0; i < jsonData.loanBarGraph.restructuredLoanValue.series.length; i++) {

												$amount_of_restructured_loans_series[i] = jsonData.loanBarGraph.restructuredLoanValue.series[i].series;
												 
											}

											var $amount_of_restructured_loans_bar_graph = new BarGraph(
													$amount_of_restructured_loans_labels,
													$amount_of_restructured_loans_series);
											
											//function call
											amountOfRestructuredLoansBarGraph($amount_of_restructured_loans_bar_graph);

									
									//loading/updating graphs on first data loading.
									numberOfLoansInPortfolioBarGraph($number_of_loans_in_portfolio_bar_graph);
									loanRepaymentStatusBarGraph($loan_repayment_status_bar_graph);
									collectionBbarGraph($collections_bar_graph);
									amountOfOverdueLoansBarGraph($mount_of_overdue_loans_bar_graph);
									numberOfOverdueLoansBarGraph($number_of_overdue_loans_bar_graph);
									writeOffsecovery(data,options,responsiveOptions);
									loadRepaymentCurve( $repayment_curve_labels, $repayment_expected_curve_series, $repayment_actual_curve_series);
									numberOfRestructuredLoansBarGraph($number_of_restructured_loans_bar_graph);
									amountOfRestructuredLoansBarGraph($amount_of_restructured_loans_bar_graph);
									
									// Redrawing the graphs on clicking tabs
									$('ul.nav a').on('shown.bs.tab',
									function(e) {
										numberOfLoansInPortfolioBarGraph($number_of_loans_in_portfolio_bar_graph);
										loanRepaymentStatusBarGraph($loan_repayment_status_bar_graph);
										collectionBbarGraph($collections_bar_graph);
										amountOfOverdueLoansBarGraph($mount_of_overdue_loans_bar_graph);
										numberOfOverdueLoansBarGraph($number_of_overdue_loans_bar_graph);
										writeOffsecovery(data,options,responsiveOptions);
										loadRepaymentCurve( $repayment_curve_labels, $repayment_expected_curve_series, $repayment_actual_curve_series);
										numberOfRestructuredLoansBarGraph($number_of_restructured_loans_bar_graph);
										amountOfRestructuredLoansBarGraph($amount_of_restructured_loans_bar_graph);
								});
									
									

											loader.hideLoading();
										} else {
											loader.hideLoading();
											showServerResponse(
													"ERROR",
													"No Loans to Analyse in this Batch.",
													"error");
										}

									},
									error : function(jqXHR, textStatus,
											errorThrown) {
										loader.hideLoading();
										if (errorThrown == 'Unauthorized') {

											onSessionTimeOut();
										}
									}

								}); 
								

						/*var $number_of_restructured_loans_bar_graph = {
							labels : [  'Apr', 'May' ],
							series : [ [  4, 7] ]
						};*/

						//function call
						//numberOfRestructuredLoansBarGraph($number_of_restructured_loans_bar_graph);
						 
						/*var $amount_of_restructured_loans_bar_graph = {
							labels : [ 'Jan', 'Feb', 'Mar', 'Apr', 'May',
									'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov',
									'Dec' ],
							series : [ [ 0, 0, 0, 2.5, 3.5, 0, 0, 0, 0, 0, 0, 0 ] ]
						};*/
						
						//function call
//						amountOfRestructuredLoansBarGraph($amount_of_restructured_loans_bar_graph);
						
						
						$('ul.nav a').on('shown.bs.tab', function(e) { 
							 
							 //numberOfRestructuredLoansBarGraph($number_of_restructured_loans_bar_graph);
							 //amountOfRestructuredLoansBarGraph($amount_of_restructured_loans_bar_graph);
							 
						});												
					});

}

function retrieveVisualizeDonutChartsData(batchJSONString,loader) {
 
	var $numberDonutData;
	var $repaymentDonutData;
	var $collectionDonutData;
	var $lastupdated;

	var $totalCollections;
	var $totalRepayments;
	var $totalLoans;
	var $numberOverdueLoans;
	var $writeOffAmount;
	var $recoveryAmount;
	var $outStanding;
	var $accountsDefaulted;
	var $accountsRepossessed;

	console.log("Loading DonutChartsData");
	console.log("Loading DonutChartsData"+batchJSONString);

	$.ajax({
		headers : {
			'Accept' : 'application/json',
			'Content-Type' : 'application/json',
			'Authorization' : $.cookie('loginToken')
		},
		type : "POST",
		url : LOAD_DONUT_CHARTS,
		data : batchJSONString,
		async : false,
		dataType : "json",
		success : function(jsonData) {
			
			if(jsonData.result==true){
				
			
		
			$numberDonutData = jsonData.loanDonutChart.numbers;
			$repaymentDonutData = jsonData.loanDonutChart.repayments;
			$collectionDonutData = jsonData.loanDonutChart.collections;
			
			$lastupdated = jsonData.loanDonutChart.latsUpdated;

			$totalCollections = jsonData.loanDonutChart.totalCollections;
			$totalRepayments = jsonData.loanDonutChart.totalRepayments;
			$totalLoans = jsonData.loanDonutChart.totalLoans;
			$numberOverdueLoans = jsonData.loanDonutChart.numberOverdueLoans;
			$writeOffAmount = jsonData.loanDonutChart.writeOffAmount;
			$recoveryAmount = jsonData.loanDonutChart.recoveryAmount;
			$outStanding = jsonData.loanDonutChart.outstanding;
			$accountsDefaulted= jsonData.loanDonutChart.accountsDefaulted;
			$accountsRepossessed= jsonData.loanDonutChart.accountsReposessed;
			
			loader.hideLoading();
			
			}else{
				loader.hideLoading();
				showServerResponse(
						"ERROR",
						"No Loans to Analyse in this Batch.",
						"error");
			}

		},
		error : function(jqXHR, textStatus, errorThrown) {

			if (errorThrown == 'Unauthorized') {

				onSessionTimeOut();
			}
		}
	})

	//$repaymentDonutData== Value of loans in portfolio
	loadCharts($numberDonutData, $repaymentDonutData, $collectionDonutData,
			$lastupdated, $totalCollections, $totalRepayments, $totalLoans,
			$numberOverdueLoans, $writeOffAmount, $recoveryAmount, $outStanding,$accountsDefaulted,$accountsRepossessed);

}

function loadCharts(numberDonutData, repaymentDonutData, collectionDonutData,
		lastupdated, totalCollections, totalRepayments, totalLoans,
		numberOverdueLoans, writeOffAmount, recoveryAmount, outStanding,accountsDefaulted,accountsRepossessed) {

	$("#number").empty()
	$("#repayment").empty();
	$("#collection").empty(); 
	
	
	$('#datepicker').val(lastupdated+":EAT");
	
	console.log("lastupdated: ==> "+lastupdated);

	$("#number_of_loans_in_Portfolio").html(
			totalLoans.toLocaleString("en") + " Loans");
	$("#portfolio_summary_statistics_loan_repayment_status").html(
			totalRepayments.toLocaleString("en") + " UGX");
	$("#portfolio_summary_statistics_collections").html(
			totalCollections.toLocaleString("en") + " UGX");

	$("#overdue_accounts_number").html(numberOverdueLoans.toLocaleString("en")+ " %");
	$("#overdue_accounts_balance").html(outStanding.toLocaleString("en")+ " %");
	
	$("#accounts_defaulted").html(accountsDefaulted.toLocaleString("en"));
	$("#accounts_repossessed").html(accountsRepossessed.toLocaleString("en"));

	$("#overdue_accounts_write_off").html(writeOffAmount.toLocaleString("en"));
	$("#overdue_accounts_recovered").html(recoveryAmount.toLocaleString("en"));
	
	
	var Dashboard1 = function() {
		this.$realData = []
	};

	// creates Donut chart
	Dashboard1.prototype.createDonutChart = function(element, data, colors) {
		Morris.Donut({
			element : element,
			data : data,
			resize : true, // defaulted to true
			colors : colors
		});
	},

	Dashboard1.prototype.init = function() {

		// Number of Loans Donut Chart
		$.Dashboard1.createDonutChart('number', numberDonutData, [ '#34a853',
				'#000000', "#ffc000", "#ea4335" ]);

		// Value of Loans Donut Chart
		$.Dashboard1.createDonutChart('repayment', repaymentDonutData, [
				'#34a853', '#ea4335', '#ffc000', "#000000", "#4285f4","#808080" ]);

		// Performance of loans in batch
		$.Dashboard1.createDonutChart('collection', collectionDonutData, [
				'#00af4f', '#90cf4e', '#ffc000', "#ec792c", "#ff0000", "#808080"]);

	},

	// init
	$.Dashboard1 = new Dashboard1, $.Dashboard1.Constructor = Dashboard1

	$.Dashboard1.init();
	

	// Redrawing Donuts on clicking tab
	$('ul.nav a').on('shown.bs.tab', function(e) {
		$("#number").empty()
		$("#repayment").empty();
		$("#collection").empty();
		$.Dashboard1.init();
	});


}

function loadRepaymentCurve($repayment_curve_labels,
		$repayment_expected_curve_series, $repayment_actual_curve_series) {

	new Chartist.Line('#loan_repayment_curve', {
		labels : $repayment_curve_labels,
		series : [ {
			name : 'Projected Curve',
			data : $repayment_expected_curve_series
		}, {
			name : 'Batch Curve',
			data : $repayment_actual_curve_series
		} ]
	}, 
	{
		  high: 100,
		  low: 0,
		  // As this is axis specific we need to tell Chartist to use whole numbers only on the concerned axis
		  axisY: {
		    onlyInteger: true,
		    offset: 20
		  },
		  plugins : [ Chartist.plugins.tooltip() ]
	});

	var $chart = $('#loan_repayment_curve');

	var $toolTip = $chart.append('<div class="tooltip"></div>')
			.find('.tooltip').hide();

	$chart
			.on(
					'mouseenter',
					'.ct-point',
					function() {
						var $point = $(this), value = $point.attr('ct:value'), seriesName = $point
								.parent().attr('ct:series-name');
						$toolTip.html(seriesName + '<br>' + value).show();
					});

	$chart.on('mouseleave', '.ct-point', function() {
		$toolTip.hide();
	});

	$chart.on('mousemove', function(event) {
		$toolTip.css({
			left : (event.offsetX || event.originalEvent.layerX)
					- $toolTip.width() / 2 - 10,
			top : (event.offsetY || event.originalEvent.layerY)
					- $toolTip.height() - 40
		});
	});
	
	
			

}


function numberOfLoansInPortfolioBarGraph(
		$number_of_loans_in_portfolio_bar_graph) {

	var chart = new Chartist.Bar('#numbers',
			$number_of_loans_in_portfolio_bar_graph, {
				stackBars : true,
				plugins : [ Chartist.plugins.tooltip() ]
			}).on('draw', function(data) {
		if (data.type === 'bar') {
			data.element.attr({
				style : 'stroke-width: 20px;'
			});
		}
	});
}

function loanRepaymentStatusBarGraph($loan_repayment_status_bar_graph){
	var chart = new Chartist.Bar('#portfolio_over_time_repayments',
			$loan_repayment_status_bar_graph, {
				stackBars : true,
				plugins : [ Chartist.plugins.tooltip() ]
			}).on('draw', function(data) {
		if (data.type === 'bar') {
			data.element.attr({
				style : 'stroke-width: 20px'
			});
		}
	});
}

function collectionBbarGraph($collections_bar_graph){
	var chart = new Chartist.Bar('#portfolio_over_time_collections', $collections_bar_graph, {
		stackBars : true,
		plugins : [ Chartist.plugins.tooltip() ]
	}).on('draw', function(data) {
		if (data.type === 'bar') {
			data.element.attr({
				style : 'stroke-width: 20px'
			});
		}
	});
}

function amountOfOverdueLoansBarGraph($mount_of_overdue_loans_bar_graph){
	var chart = new Chartist.Bar('#overdue_loans_amounts',
			$mount_of_overdue_loans_bar_graph, {
				stackBars : true,
				plugins : [ Chartist.plugins.tooltip() ]
			}).on('draw', function(data) {
		if (data.type === 'bar') {
			data.element.attr({
				style : 'stroke-width: 20px'
			});
		}
	});
}

function numberOfOverdueLoansBarGraph($number_of_overdue_loans_bar_graph){
	new Chartist.Bar('#overdue_loans_numbers',
			$number_of_overdue_loans_bar_graph, {
				stackBars : true,
				plugins : [ Chartist.plugins.tooltip() ]
			}).on('draw', function(data) {
		if (data.type === 'bar') {
			data.element.attr({
				style : 'stroke-width: 20px'
			});
		}
	});
}

function writeOffsecovery(data,options,responsiveOptions){
	new Chartist.Bar('#write-offs-recovery', data, options, responsiveOptions)
			.on('draw', function(data) {
				if (data.type === 'bar') {
					data.element.attr({
						style : 'stroke-width: 15px'
					});
				}
			});
}

function numberOfRestructuredLoansBarGraph($number_of_restructured_loans_bar_graph){
	var chart = new Chartist.Bar('#number_of_restructured_loans',
			$number_of_restructured_loans_bar_graph, {
				stackBars : true,
				plugins : [ Chartist.plugins.tooltip() ]
			}).on('draw', function(data) {
		if (data.type === 'bar') {
			data.element.attr({
				style : 'stroke-width: 20px'
			});
		}
	});
}

function amountOfRestructuredLoansBarGraph($amount_of_restructured_loans_bar_graph){
	var chart = new Chartist.Bar('#amount_of_restructured_loans',
	$amount_of_restructured_loans_bar_graph, {
				stackBars : true,
				plugins : [ Chartist.plugins.tooltip() ]
			}).on('draw', function(data) {
		if (data.type === 'bar') {
			data.element.attr({
				style : 'stroke-width: 20px'
			});
		}
	}); 
}

function showServerResponse(title, msg, type) {
	var $toastlast;

	var shortCutFunction = false;
	var $showDuration = "300";
	var $hideDuration = "1000";
	var $timeOut = "5000";
	var $extendedTimeOut = "1000";
	var $showEasing = "swing";
	var $hideEasing = "linear";
	var $showMethod = "fadeIn";
	var $hideMethod = "fadeOut";

	toastr.options = {
		closeButton : false,
		debug : false,
		newestOnTop : false,
		progressBar : false,
		positionClass : "toast-top-full-width",
		preventDuplicates : false,
		onclick : null
	};

	// var $toast = toastr["success"](msg, title);
	var $toast = toastr[type](msg, title);
	$toastlast = $toast;

}

/* formats date into the specified format */
function getDate(date) {
	var year = "" + date.getFullYear();
	var month = "" + (date.getMonth() + 1);
	if (month.length == 1) {
		month = "0" + month;
	}
	var day = "" + date.getDate();
	if (day.length == 1) {
		day = "0" + day;
	}
	var hour = "" + date.getHours();
	if (hour.length == 1) {
		hour = "0" + hour;
	}
	var minute = "" + date.getMinutes();
	if (minute.length == 1) {
		minute = "0" + minute;
	}
	var second = "" + date.getSeconds();
	if (second.length == 1) {
		second = "0" + second;
	}
	return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":"
			+ second;
}
