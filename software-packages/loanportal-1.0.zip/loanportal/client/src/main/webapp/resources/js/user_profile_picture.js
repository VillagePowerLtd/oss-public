$(function(){
	$('#upload_company_logo_button').click(function(){
		
		var $profilePicture=$('#profile_picture_url');
		alert($profilePicture.val())
	});


});