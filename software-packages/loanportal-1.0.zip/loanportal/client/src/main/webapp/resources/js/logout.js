$(function (){
	$('#log_out').click(function (){
		
		$.ajax({
			headers : {
			'Accept' : 'application/json',
			'Content-Type' : 'application/json'
		},
		type : "GET",
		url : LOG_OUT,
		dataType : "json",
		success : function(data, status){
			  $.removeCookie("loginToken");
			  $.removeCookie("userRole");
			  $.removeCookie("userName");
			  $.removeCookie("graphs");
			  window.location.replace("login.jsp"); // redirect to login page
		}
		});
	});
});