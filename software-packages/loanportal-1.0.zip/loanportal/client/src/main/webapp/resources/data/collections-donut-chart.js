[
{
	"label": "Outstanding", 
	"value": 140000000
},
{
	"label": "Collected", 
	"value": 60000000
}
]