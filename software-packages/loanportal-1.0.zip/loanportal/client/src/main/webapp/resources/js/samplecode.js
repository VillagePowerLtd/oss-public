.ajax({
	headers : {
		'Accept' : 'application/json',
		'Content-Type' : 'application/json',
	'Authorization': $.cookie('loginToken')
	},
	type : "GET",
	url : 'http://localhost:9090/loa-1.0-SNAPSHOT/webresources/batch/allBatches',
	dataType : "json",
	success : function(data, status) {
		// code executed on success
	},
	error : function(jqXHR, textStatus,
		//code executed on failure
	}
				});
	
	
	
	var $batchName = $('#batch_name');
	var $batchDescription = $('#batch_description');

	var batch = {
		"type" : "object",
		"batch" : {
			name : $batchName.val(),
			description : $batchDescription.val()			 
		}
	};

	var batchJSONString = JSON.stringify(batch);
	
	
	
	$.ajax({
		headers : {
			'Accept' : 'application/json',
			'Content-Type' : 'application/json',
		'Authorization': $.cookie('loginToken')
		},
		type : "POST",
		url : 'http://localhost:9090/loa-1.0-SNAPSHOT/webresources/batch/createBatch',,
		data : batchJSONString,
		dataType : "json",
		success : function(data, status) {
		// code executed on success
			
		},
		error : function(jqXHR, textStatus,
				errorThrown) {
		// code executed on failure
		}
	});
	
	