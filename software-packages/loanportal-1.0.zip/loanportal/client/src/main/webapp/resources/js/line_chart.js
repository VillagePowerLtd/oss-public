//Loan Repayment Graph

$(function(){
	console.log("SERRIES--->> loading line charts");
	
$.ajax({ 
	type : "GET",
	url : "resources/data/line-chart.JSON",
	async : false,
	dataType : "json",
	success : function(jsonData) {	
		
		var $repayment_curve_labels;
		var $repayment_expected_curve_series;
		var $repayment_actual_curve_series;
		
		$repayment_curve_labels=jsonData.labels;
		$repayment_expected_curve_series=jsonData.expected;
		$repayment_actual_curve_series=jsonData.actual;
		
		new Chartist.Line('#loan_repayment_curve', {
			labels: $repayment_curve_labels,
			series: [
			       {
			        name: 'Projected Curve',
			        data: $repayment_expected_curve_series
			       },
			       {
			        name: 'Batch Curve',
			        data: $repayment_actual_curve_series
			       }
			  ]},
			    {
			  plugins: [
			    Chartist.plugins.tooltip()
			  ]
			}
			);

			var $chart = $('#loan_repayment_curve');
			
			var $toolTip = $chart
			  .append('<div class="tooltip"></div>')
			  .find('.tooltip')
			  .hide();
			
			$chart.on('mouseenter', '.ct-point', function() {
			  var $point = $(this),
			    value = $point.attr('ct:value'),
			    seriesName = $point.parent().attr('ct:series-name');
			  $toolTip.html(seriesName + '<br>' + value).show();
			});
			
			$chart.on('mouseleave', '.ct-point', function() {
			  $toolTip.hide();
			});
			
			$chart.on('mousemove', function(event) {
			  $toolTip.css({
			    left: (event.offsetX || event.originalEvent.layerX) - $toolTip.width() / 2 - 10,
			    top: (event.offsetY || event.originalEvent.layerY) - $toolTip.height() - 40
			  });
			}); 
			
	},
		error : function(jqXHR, textStatus, errorThrown) {
			console.log("Line chart errorThrown: "+errorThrown);
			 
		}
});
})


