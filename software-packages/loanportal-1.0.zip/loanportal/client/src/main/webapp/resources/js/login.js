$(function() {

	$("#login_button").click(function() {
		var $userName = $("#user_name");
		var $password = $("#password");

		var user = {
			"username" : $userName.val(),
			"password" : $password.val(),
			"rememberMe" : "false"
		}
		
		var userJSONString = JSON.stringify(user);
		
		$.ajax({
			headers : {
			'Accept' : 'application/json',
			'Content-Type' : 'application/json'
		},
		type : "POST",
		url : LOGIN,
		data : userJSONString,
		dataType : "json",
		success : function(data, status){
			 
			  if(data.result==true){
				  $.cookie("loginToken", data.jwt);
				  $.cookie("userRole", data.role);
				  $.cookie("userName", data.user.firstname+' '+data.user.lastname);
				 
				  if(($.cookie('userRole') == 'administrator')){
					  
				  }
				  else{
				  var graphs='';
				  console.log('data.usergraph.length:'+data.usergraph.length);
				  for(var graphCounter=0;graphCounter<data.usergraph.length;graphCounter++){
					  
					  graphs+=data.usergraph[graphCounter].graphs;
					  if(graphCounter==(data.usergraph.length-1)){
						  
					  }else{
						  graphs+=',' ;
					  }
				  }
				  $.cookie("graphs", graphs);
					  }
				  window.location.replace("index.jsp");
			  }else{ 
				  $( "#error" ).removeClass( "hidden")
				  $('#error').addClass("show_error");
				  showServerResponse("ERROR","The username and/or password entered has not been recognised. Please enter your credentials again or reset your password","error");
				  console.log('ERROR Login');
			  }
			 
		}
		});
	});
	

function showServerResponse(title, msg, type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}

});