$(function() {
	
	loadAllDeposits();
	
	$('#save_payment_model').click(function() {

		var $percent = $("#down_payment");
		//var $gracePeriodUpfront = $("#grace_period_amount");
		var $penguinTotal = $("#total_loan_amount");
		var $idDeposit = $("#system_model");  
		var $daily = $("#daily_payments");     
		var $paytPerirod = $("#payment_period"); 
		var $system_model_version = $("#system_model_version"); 

		var deposit = {
			"type" : "object",
			"deposit" : {
				percent : $percent.val(),
				initialPaytWindow : '14', 
				penguinTotal : $penguinTotal.val(),
				final1:$penguinTotal.val(),
				idDeposit : $idDeposit.val(), 
				daily : $daily.val(),
				paytPerirod : $paytPerirod.val(),
				version : $system_model_version.val()
				 
			}
		};
		
		var depositDataJSONString = JSON.stringify(deposit);
		
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json',
			 'Authorization': $.cookie('loginToken')
					
			},
			type : "POST",
			url : CREATE_PAYMENT_MODEL,
			data : depositDataJSONString,
			dataType : "json",
			success : function(data, status) {
				
				if(data.result){
					showServerResponse("Success","Successfully created","success");
					
					getPaymentModel(data);	
				}else{
					showServerResponse("ERROR","ERROR: NOT created. Please again.","error");
				}
				
			},
			error : function(jqXHR, textStatus, errorThrown) {

				if (errorThrown == 'Unauthorized') {

					onSessionTimeOut();
				}
			}
		});
	});
	
	function loadAllDeposits(){
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json',
			 'Authorization': $.cookie('loginToken')
					
			},
			type : "GET",
			url : GET_PAYMENT_MODELS,
			dataType : "json",
			success : function(data, status) {
				
				getPaymentModel(data);
			},
			error : function(jqXHR, textStatus, errorThrown) {

				if (errorThrown == 'Unauthorized') {

					onSessionTimeOut();
				}
			}
		});
	}
	
	
	function getPaymentModel(paymentModels) {
		
		var loader;
			loader = loader || (function() {
			var loaderDiv = $("#loading-modal");
			return {
				showLoading : function() {
				loaderDiv.modal();
					},
				hideLoading : function() {
				loaderDiv.modal('hide');
						}};})();
			
			loader.showLoading();
			
			var table = $('#payment_model_table')
			.DataTable(
					{
						destroy : true,
						data : paymentModels.deposits,
						columns : [null, {
							data : "idDeposit"
						}, 
						{
							data : "version"
						},
						{
							data : "percent"
						}, {
							data : "initialPaytWindow"
						}, 
						{
							data : "penguinTotal"
						},
						{
							data : "daily"
						},
						{
							data : "paytPerirod"
						},null

						],
						columnDefs : [ {
							targets : -1,
							data : null,
							defaultContent : "<a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#update-payment-plan-modal'></i></a><a href='#' class='on-default remove-row'><i class='fa fa-trash-o'></i></a>"
						},
						{
							orderable : false,
							targets : 0,
							defaultContent : "",
					        className: 'select-checkbox',
						}
						, {
							targets : [ 4 ],
							visible : false
						}
						],
						select: {
				            style:    'os',
				            selector: 'td:first-child'
				        },

						order : [ [ 1, 'asc' ] ],
						


						"drawCallback": function( settings ) {
                            var api = this.api();
                             
                            //updatePaymentPlan(table);
        					
        					//deletePaymentPlan(table);
                             
                          }
					});
			
				$('#payment_model_table').on('page.dt', function() {
				updatePaymentPlan(table);
	
				deletePaymentPlan(table);
				
				});
				
				
				$('#payment_model_table').on('draw.dt', function() {
					updatePaymentPlan(table);
					
					deletePaymentPlan(table);
				});
				
	
				loader.hideLoading();
		
				updatePaymentPlan(table);
		
				deletePaymentPlan(table);
				 
		}
	
	function updatePaymentPlan(table){
		$('a.edit-row').click(function (){
			
			var selectedPaymentPlan = table.row( { selected: true } ).data();
			//var selectedPaymentPlan = table.row($(this).parents('tr')).data();
			console.log("selectedPaymentPlan: "+selectedPaymentPlan);
			
			$("#edit_system_model").val(selectedPaymentPlan.idDeposit);
			
			$("#edit_down_payment").val(selectedPaymentPlan.percent);
			
			//$("#edit_grace_period_amount").val(selectedPaymentPlan.initialPaytWindow);
			
			$("#edit_total_loan_amount").val(selectedPaymentPlan.penguinTotal);
			
			$("#edit_daily_payments").val(selectedPaymentPlan.daily);
			
			$("#edit_payment_period").val(selectedPaymentPlan.paytPerirod);
			
			$("#edit_system_model_version").val(selectedPaymentPlan.version); 
			
			$('#update_payment_model').click(function() {

				var $percent = $("#edit_down_payment");
				//var $gracePeriodUpfront = $("#edit_grace_period_amount");
				var $penguinTotal = $("#edit_total_loan_amount");
				var $idDeposit = $("#edit_system_model");  
				var $daily = $("#edit_daily_payments");     
				var $paytPerirod = $("#edit_payment_period"); 
				
				var $system_model_version = $("#edit_system_model_version");

				var deposit = {
					"type" : "object",
					"deposit" : {
						percent : $percent.val(),
						initialPaytWindow : '14', 
						penguinTotal : $penguinTotal.val(),
						idDeposit : $idDeposit.val(), 
						final1:$penguinTotal.val(),
						daily : $daily.val(),
						paytPerirod : $paytPerirod.val(),
						version:$system_model_version.val()
						 
					}
				};
				
				var depositDataJSONString = JSON.stringify(deposit);
				
				$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json',
					 'Authorization': $.cookie('loginToken')
							
					},
					type : "POST",
					url : UPDATE_PAYMENT_MODEL,
					data : depositDataJSONString,
					dataType : "json",
					success : function(data, status) {
						
						if(data.result){
							showServerResponse("Success","Successfully Updated","success");
							
							getPaymentModel(data);	
						}else{
							showServerResponse("ERROR","Not Updated Please try again","error");
						}
						
					},
					error : function(jqXHR, textStatus, errorThrown) {

						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}
				});
			});
			
		});
	}
	
	function deletePaymentPlan(table){
		$('a.remove-row').click(function (){
			
			var selectedPaymentPlan = table.row( { selected: true } ).data();

				var deposit = {
					"type" : "object",
					"deposit" : {
						percent : selectedPaymentPlan.percent,
						initialPaytWindow : selectedPaymentPlan.initialPaytWindow, 
						penguinTotal : selectedPaymentPlan.penguinTotal,
						idDeposit : selectedPaymentPlan.idDeposit,
						final1:selectedPaymentPlan.final1,
						daily :selectedPaymentPlan.daily,
						paytPerirod : selectedPaymentPlan.paytPerirod,
						 
					}
				};
				
				var depositDataJSONString = JSON.stringify(deposit);
				
				$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json',
					 'Authorization': $.cookie('loginToken')
							
					},
					type : "POST",
					url : DELETE_PAYMENT_MODEL,
					data : depositDataJSONString,
					dataType : "json",
					success : function(data, status) {
						
						if(data.result){
							showServerResponse("Success","Successfully Deleted","success");
							
							getPaymentModel(data);	
						}else{
							showServerResponse("ERROR","Not Deleted Please try again","error");
						}
						
					},
					error : function(jqXHR, textStatus, errorThrown) {

						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}
				});
			 
			
		});
	}

	
	
	function showServerResponse(title,msg,type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title); 
		$toastlast = $toast;

	}
});