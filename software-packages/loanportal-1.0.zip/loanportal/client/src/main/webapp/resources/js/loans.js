$(function() {
	$("#logged_in_user").html($.cookie('userName')); 
	$('#datatable_uploaded_portfolio tfoot th').each(function() {
		var title = $(this).text();
		$(this).html('<input type="text" placeholder="Search ' + '" />');
	});
	
	var table=null;
	
	getLoans();
	loadBatchCombo();
	//loadPortfolioCombo();
	//onPortfolioSelected();
	updateDashboard();
	advancedSearch();
	refreshLoans();
	assignLoansToBatch();
	
	function getLoans() {

		var loader;
		loader = loader || (function() {
			var loaderDiv = $("#loading-modal");
			return {
				showLoading : function() {
					loaderDiv.modal();
				},
				hideLoading : function() {
					loaderDiv.modal('hide');
				}
			};
		})();

		loader.showLoading();
 
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json',
				'Authorization' : $.cookie('loginToken')
			},
			type : "GET",
			url : RETRIEVE_LOANS,
			dataType : "json",
			success : function(data, status) {
				
				console.log(data);
				
				table = $('#datatable_uploaded_portfolio').DataTable({
					
					destroy : true,
					data : data.loans,
					
					columns : [ null, {
						data : "id"
					}, {
						data : "totalAmountValue"
					}, {
						data : "downPaymentDate"
					}, {
						data : "balance"
					}, {
						data : "status"
					}, {
						data : "uploadDate"
					}, 
					{
						data : "modelPurchased"
					},
					{
						data : "salesAgent"
					},
					{
						data : "distributionAgent"
					},
					{
						data : "store"
					},
					
					{
						data : "historyStatus"
					},
					
					{
						data : "district"
					},
					{
						data : "subcounty"
					},
					{
						data : "parish"
					}
					,
					{
						data : "village"
					}

					],

					columnDefs : [ 
						
					{
						orderable : false,
						targets : 0,
						defaultContent : "",
				        className: 'select-checkbox',
				        
					},

					{
						targets : [ 11 ],
						visible : false
					},
					{
					    targets: 3,
					    data: "downPaymentDate",
					    render: function ( data, type, full, meta ) {
					        return getDate(data);
					      }
					}
					
					],
					
					order : [ [ 1, 'asc' ] ],
					
					 
						dom: 'Bfrtip',
				        select: true,
				        language: {
				            "lengthMenu": "Display _MENU_ records"
				          },
				        lengthMenu: [
				            [ 10, 25, 50,100,200,300,400,500 -1 ],
				            [ '10 rows', '25 rows', '50 rows','100 rows','200 rows','300 rows','400 rows','500 rows', 'Show all' ]
				        ],
				        
				        buttons: [
				        	'pageLength',
				            {
				                text: 'Select all',
				                action: function () {
				                    //table.rows().select();
				                    table.rows({ page: 'current' }).select();
				                }
				            },
				            {
				                text: 'Select none',
				                action: function () {
				                    table.rows().deselect();
				                }
				            },
				            
				            
				        ],
				        
					select: {
			            style:    'multi',
			            selector: 'td:first-child'
			        }
				      
				});
				 
				loader.hideLoading();
				

				table.columns().every(function() {
					var that = this;

					$('input', this.footer()).on('keyup change', function() {
						if (that.search() !== this.value) {
							that.search(this.value).draw();
						}
					});
				});

			},
			error : function(jqXHR, textStatus, errorThrown) {
				loader.hideLoading();
				if (errorThrown == 'Unauthorized') {

					onSessionTimeOut();
				}
			}
		});
	}
	
	function assignLoansToBatch(){
		$('#assign_loans')
				.click(
						function() {

							loader.showLoading();

							var $selected_batch = $('#batch');

							var loans = [];
							
							var rowData = table.rows({ selected: true }).data().toArray();

							for ( var i = 0; i < rowData.length; i++) {

								var batchhasLoan = {
									loan : {
										id : rowData[i].id
									},
									batch : {
										id : $selected_batch.val()
									}
								};

								loans[i] = batchhasLoan;
							}

							var batchLoanObject = {
								"type" : "object",
								"batchLoans" : loans
							}

							var batchJSONString = JSON
									.stringify(batchLoanObject);

							 console.log("LoanBatch Submission Feedback: "+batchJSONString);

							$
									.ajax({
										headers : {
											'Accept' : 'application/json',
											'Content-Type' : 'application/json',
											'Authorization' : $
													.cookie('loginToken')
										},
										type : "POST",
										url : ASSIGN_LOAN_TO_BATCH,
										data : batchJSONString,
										dataType : "json",
										success : function(data, status) {
											loader.hideLoading();
											if(data.result){
												showServerResponse("Success",
												"Loans assigned to batch successfully","success");
										console
												.log("LoanBatch Submission Feedback: "
														+ data.message);
											}else{
												showServerResponse("ERROR",
												"An error Occured while assigning loans to batch","error");
											}
											

										},
										error : function(jqXHR, textStatus,
												errorThrown) {

											if (errorThrown == 'Unauthorized') {

												onSessionTimeOut();
											}
										}
									});
						});

	}
	
	function updateDashboard() {
		$("#update_Batch_dashboard").click(function() {

			var loader;
			loader = loader || (function() {
				var loaderDiv = $("#loading-modal");
				return {
					showLoading : function() {
						loaderDiv.modal();
					},
					hideLoading : function() {
						loaderDiv.modal('hide');
					}
				};
			})();

			loader.showLoading();

			var $selected_batch = $('#batch');

			var batch = {
				"type" : "object",
				"batch" : {
					id : $selected_batch.val()

				}
			};

			var batchJSONString = JSON.stringify(batch);

			$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json',
				'Authorization': $.cookie('loginToken')
				},
				type : "POST",
				url : UPDATE_DASH_BOARD_DONUT_CHART,
				dataType : "json",
				data : batchJSONString,
				success : function(data, status) {
					loader.hideLoading();
					showServerResponse("Success", data.message,"success");
				},
				error : function(jqXHR, textStatus,errorThrown) {
					loader.hideLoading();
			if (errorThrown == 'Unauthorized') {

				onSessionTimeOut();
			}
		}

			});

		});

	}

	function loadBatchCombo() {
		$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json',
						'Authorization' : $.cookie('loginToken')
					},
					type : "GET",
					url : RETRIEVE_BATCH,
					dataType : "json",
					success : function(data, status) {

						var options = '';
						for ( var batchCount = 0; batchCount < data.batches.length; batchCount++) {
							options += ' <option value="'
									+ data.batches[batchCount].id + '">'
									+ data.batches[batchCount].name
									+ '</option>';
						}
						$('#batch').html(options);
					},
					error : function(jqXHR, textStatus, errorThrown) {

						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}

				});
	}
	
	function loadPortfolioCombo() {
		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json',
						'Authorization' : $.cookie('loginToken')
					},
					type : "GET",
					url : RETRIEVE_PORTFOLIOS,
					dataType : "json",
					success : function(data, status) {

						var options = '';
						for ( var portfolioCount = 0; portfolioCount < data.portfolios.length; portfolioCount++) {
							options += ' <option value="'
									+ data.portfolios[portfolioCount].id + '">'
									+ data.portfolios[portfolioCount].name
									+ '</option>';
						}
						$('#portfolio').html(options);
					},
					error : function(jqXHR, textStatus, errorThrown) {

						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}

				});
	}
	
	function onPortfolioSelected(){
		$('#portfolio').change(function (){
			
			var $selected_portfolio = $('#portfolio');
			
			var portfolio = {
					"type" : "object",
					"portfolio" : {
						id : $selected_portfolio.val()
					}
				};

			var portfolioDataJSONString = JSON.stringify(portfolio);
			
			$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json',
					'Authorization' : $.cookie('loginToken')
				},
				type : "POST",
				url : RETRIEVE_BATCH_PORTFOLIO,
				data : portfolioDataJSONString,
				dataType : "json",
				success : function(data, status) {
					var options = '';
					if(data.result){
						console.log("Loaded Batches==>> "+data);
						
						for ( var batchCount = 0; batchCount < data.batches.length; batchCount++) {
							options += ' <option value="'
									+ data.batches[batchCount].id + '">'
									+ data.batches[batchCount].name
									+ '</option>';
						}
						$('#batch').html(options);
					}else{
						$('#batch').html(options);
					}
					
				},
				error : function(jqXHR, textStatus, errorThrown) {

					if (errorThrown == 'Unauthorized') {

						onSessionTimeOut();
					}
				}

			});
			
		});
	}
	
	function advancedSearch(){
		$('#search').click(function (){
			
			var loader;
			loader = loader || (function() {
				var loaderDiv = $("#loading-modal");
				return {
					showLoading : function() {
						loaderDiv.modal();
					},
					hideLoading : function() {
						loaderDiv.modal('hide');
					}
				};
			})();

			loader.showLoading();
			
			var $downPaymentDate=$('#from');
			var $nextPaymentDate=$('#to');
			var $salesAgent=$('#sales_agent');
			var $distributionAgent=$('#distribution_agent');
			var $installationAddress=$('#installation_address');
			var $store=$('#store');
			
			var $accountsFrom=$('#accountsFrom');
			var $accountsTo=$('#accountsTo');
			
			var loan=null;
			
			if($downPaymentDate.val()==''){
				console.log("Loading ALL Input NOT downPaymentDate");
				loan = {
						"type" : "object",
						"loan" : {
							salesAgent:$salesAgent.val(),
							distributionAgent:$distributionAgent.val(),
							installationAddress:$installationAddress.val(),
							store:$store.val()
						},
						rangeOne:$accountsFrom.val(),
						rangeTwo:$accountsTo.val()
					};
				
			}else if($nextPaymentDate.val()==''){
				
				console.log("Loading ALL Input NOT nextPaymentDate");
				
				loan = {
						"type" : "object",
						"loan" : {
							salesAgent:$salesAgent.val(),
							distributionAgent:$distributionAgent.val(),
							installationAddress:$installationAddress.val(),
							store:$store.val()
						},
						rangeOne:$accountsFrom.val(),
						rangeTwo:$accountsTo.val()
					};
			}else if($nextPaymentDate.val()==''&& $downPaymentDate.val()==''){
				console.log("Loading ALL Input NOT");
				loan = {
						"type" : "object",
						"loan" : {
							salesAgent:$salesAgent.val(),
							distributionAgent:$distributionAgent.val(),
							installationAddress:$installationAddress.val(),
							store:$store.val()
						},
						rangeOne:$accountsFrom.val(),
						rangeTwo:$accountsTo.val()
					};
			}
			
			else if($nextPaymentDate.val()==''&& $downPaymentDate.val()==''&&$salesAgent.val()==''&&$distributionAgent.val()==''&&$installationAddress.val()==''&&$store.val()==''){
				console.log("Loading ALL ONLY account ranges");
				loan = {
						"type" : "object",
						"loan" : {
							salesAgent:"",
							distributionAgent:"",
							installationAddress:"",
							store:""
						},
						rangeOne:$accountsFrom.val(),
						rangeTwo:$accountsTo.val()
					};
			}
			
			else{
				console.log("Loading ALL Input");
				loan = {
						"type" : "object",
						"loan" : {
							downPaymentDate : $downPaymentDate.val(),
							nextPaymentDate:$nextPaymentDate.val(),
							salesAgent:$salesAgent.val(),
							distributionAgent:$distributionAgent.val(),
							installationAddress:$installationAddress.val(),
							store:$store.val()
						},
						rangeOne:$accountsFrom.val(),
						rangeTwo:$accountsTo.val()
					};
			}
			
			 if($downPaymentDate.val()==''&&$nextPaymentDate.val()==''&&$salesAgent.val()==''&&$distributionAgent.val()==''&&$installationAddress.val()==''&&$store.val()==''&&$accountsFrom.val()==''&&$accountsTo.val()==''){
				 getAllLoans(loader);
			 }else{

			var loanDataJSONString = JSON.stringify(loan);
			
			$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json',
					'Authorization' : $.cookie('loginToken')
				},
				type : "POST",
				url : SEARCH_LOANS,
				data : loanDataJSONString,
				dataType : "json",
				success : function(data, status) {
					
					console.log(data);
					  
					 
					console.log(data.message);
					
					table = $('#datatable_uploaded_portfolio').DataTable({
						
						destroy : true,
						data : data.loans,
						
						columns : [ null, {
							data : "id"
						}, {
							data : "totalAmountValue"
						}, {
							data : "downPaymentDate"
						}, {
							data : "balance"
						}, {
							data : "status"
						}, {
							data : "uploadDate"
						}, 
						{
							data : "modelPurchased"
						},
						{
							data : "salesAgent"
						},
						{
							data : "distributionAgent"
						},
						{
							data : "store"
						},
						 
						 {
							data : "historyStatus"
						},
						{
							data : "district"
						},
						{
							data : "subcounty"
						},
						{
							data : "parish"
						}
						,
						{
							data : "village"
						}

						],

						columnDefs : [ {
							orderable : false,
							targets : 0,
							defaultContent : "",
					        className: 'select-checkbox',
					        
						},

						{
							targets : [ 11 ],
							visible : false
						} ],
						
						order : [ [ 1, 'asc' ] ],
						
						 
							dom: 'Bfrtip',
					        select: true,
					        language: {
					            "lengthMenu": "Display _MENU_ records"
					          },
					        lengthMenu: [
					            [ 10, 25, 50,100,200,300,400,500 -1 ],
					            [ '10 rows', '25 rows', '50 rows','100 rows','200 rows','300 rows','400 rows','500 rows', 'Show all' ]
					        ],
					        
					        buttons: [
					        	'pageLength',
					            {
					                text: 'Select all',
					                action: function () {
					                    //table.rows().select();
					                    table.rows({ page: 'current' }).select();
					                }
					            },
					            {
					                text: 'Select none',
					                action: function () {
					                    table.rows().deselect();
					                }
					            },
					            
					            
					        ],
					        
						select: {
				            style:    'multi',
				            selector: 'td:first-child'
				        }
					      
					});
					
					loader.hideLoading(); 
					  

					table.columns().every(function() {
						var that = this;

						$('input', this.footer()).on('keyup change', function() {
							if (that.search() !== this.value) {
								that.search(this.value).draw();
							}
						});
					});

				},
				error : function(jqXHR, textStatus, errorThrown) {
					loader.hideLoading(); 
					if (errorThrown == 'Unauthorized') {

						onSessionTimeOut();
					}
				}
			});
			
		}
		});
	}
	
	function getAllLoans(loader){
		 
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json',
				'Authorization' : $.cookie('loginToken')
			},
			type : "GET",
			url : RETRIEVE_LOANS,
			dataType : "json",
			success : function(data, status) {
				
				console.log(data);
				
				table = $('#datatable_uploaded_portfolio').DataTable({
					
					destroy : true,
					data : data.loans,
					
					columns : [ null, {
						data : "id"
					}, {
						data : "totalAmountValue"
					}, {
						data : "downPaymentDate"
					}, {
						data : "balance"
					}, {
						data : "status"
					}, {
						data : "uploadDate"
					}, 
					{
						data : "modelPurchased"
					},
					{
						data : "salesAgent"
					},
					{
						data : "distributionAgent"
					},
					{
						data : "store"
					},
					
					{
						data : "historyStatus"
					},
					
					{
						data : "district"
					},
					{
						data : "subcounty"
					},
					{
						data : "parish"
					}
					,
					{
						data : "village"
					}

					],

					columnDefs : [ 
						
					{
						orderable : false,
						targets : 0,
						defaultContent : "",
				        className: 'select-checkbox',
				        
					},

					{
						targets : [ 11 ],
						visible : false
					},
					{
					    targets: 3,
					    data: "downPaymentDate",
					    render: function ( data, type, full, meta ) {
					        return getDate(data);
					      }
					}
					
					],
					
					order : [ [ 1, 'asc' ] ],
					
					 
						dom: 'Bfrtip',
				        select: true,
				        language: {
				            "lengthMenu": "Display _MENU_ records"
				          },
				        lengthMenu: [
				            [ 10, 25, 50,100,200,300,400,500 -1 ],
				            [ '10 rows', '25 rows', '50 rows','100 rows','200 rows','300 rows','400 rows','500 rows', 'Show all' ]
				        ],
				        
				        buttons: [
				        	'pageLength',
				            {
				                text: 'Select all',
				                action: function () {
				                    
				                    table.rows({ page: 'current' }).select();
				                }
				            },
				            {
				                text: 'Select none',
				                action: function () {
				                    table.rows().deselect();
				                }
				            },
				            
				            
				        ],
				        
					select: {
			            style:    'multi',
			            selector: 'td:first-child'
			        }
				      
				});
				
				loader.hideLoading();
				 
				table.columns().every(function() {
					var that = this;

					$('input', this.footer()).on('keyup change', function() {
						if (that.search() !== this.value) {
							that.search(this.value).draw();
						}
					});
				});

			},
			error : function(jqXHR, textStatus, errorThrown) {
				loader.hideLoading();
				if (errorThrown == 'Unauthorized') {

					onSessionTimeOut();
				}
			}
		});
	}
	
	
	function refreshLoans(){
		$('#refresh_loans_button').click(function (){
			getLoans() ;
		});
	}
	
	
	function handCheckBoxClick(table) {
		
		console.log("Check Box Clicked: loading 1");
 
	}

	function assignLoansToBatch() {
		var table = $('#datatable_uploaded_portfolio').DataTable();
		$('#assign_loans').click(function() {
			alert(table.rows('.selected').data().length + ' row(s) selected');
		});
	}

	function showServerResponse(title, msg,type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}
	
	/* formats date into the specified format */
	function getDate(data) {
		var date = new Date(data);
        var month = date.getMonth() + 1;
        //return (month.length > 1 ? month : "0" + month) + "/" + date.getDate() + "/" + date.getFullYear();
        return data ;
	}

});