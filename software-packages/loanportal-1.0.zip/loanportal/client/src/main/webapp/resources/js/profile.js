$(function() {
	$("#logged_in_user").html($.cookie('userName')); 
	loadProfilesTable();

	$('#new_profile_button').click(function() {
		loadRoleCombo();
	});
	
	$('#share_graph_button').click(function() {
		loadGraphsToShareBatches();
	});
	
	$('#addNewGraphButton').click(function(){
		loadGraphsToShareBatchesEdit();
	});
	
	 

	$('#save_profile').click(function() {
		var $email = $('#email');
		var $confirmEmail = $('#confirm_email');
		var $role = $('#role');
		var $firstName=$('#first_name');
		var $lastName=$('#last_name');
		var $organisation=$('#organisation');

		if ($email.val() == $confirmEmail.val()) {
			var profile = {
				"type" : "object",
				"users" : {
					email : $email.val(),
					role : $role.val(),
					firstname:$firstName.val(),
					lastname:$lastName.val(),
					company:$organisation.val()
				}
			};

			var profileJSONString = JSON.stringify(profile);

			$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json',
					'Authorization' : $.cookie('loginToken')
				},
				type : "POST",
				url : CREATE_PROFILE,
				data : profileJSONString,
				dataType : "json",
				success : function(data, status) {
					
					
					if(data.result==true){
						showServerResponse("Success", "New Profile Added Successfully","success");
					}else{
					showServerResponse("Success","An Error Occured while Adding Profile. Please try again","error");
					}
					
					loadProfilesTable();
				},
						error : function(jqXHR, textStatus, errorThrown) {

							if (errorThrown == 'Unauthorized') {

								onSessionTimeOut();
							}
						}
			});
		}else{
			showServerResponse("ERROR", "Email do not match. Please Confirm your email.","error")
		}

	});



	function loadProfilesTable() {

		var loader;
		loader = loader || (function() {
			var loaderDiv = $("#loading-modal");
			return {
				showLoading : function() {
					loaderDiv.modal();
				},
				hideLoading : function() {
					loaderDiv.modal('hide');
				}
			};
		})();
		loader.showLoading();
		
		$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json',
						'Authorization' : $.cookie('loginToken')
					},
					type : "GET",
					url : RETRIEVE_PROFILE,
					dataType : "json",
					success : function(data, status) {

						var table = $('#profile_table')
								.DataTable(
										{
											destroy : true,
											data : data.users,
											columns : [ 
											           null,
											{
												data : "userId"
											},
											{
												data : "firstname"
											},
											{
												data : "lastname"
											},
											{
												data : "company"
											},
										    {
												data : "email"
											}, {
												data : "role"
											}, null

											],
											columnDefs : [
												{
													orderable : false,
													targets : 0,
													defaultContent : "",
											        className: 'select-checkbox',
												},
												{
														targets : 7,
														data : null,
														defaultContent : '<button type="button" class="btn btn-default btn-sm" data-toggle="modal" href="#display_investor_permissions" id="'+data.id+'"><span class="glyphicon glyphicon-th-list"></span></button>'
													},
													{
														targets : 8,
														data : null,
														defaultContent : " <a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#update-user-profile-modal'></i></a><a href='#' class='on-default remove-row'><i class='fa fa-trash-o'></i></a>"
													},
													{
														targets : [ 1 ],
														visible : false
													},
													{
														targets : [ 7],
														defaultContent : ""
													},
													],
										
											select: {
											          style:    'os',
											          selector: 'td:first-child'
											       },
								        
								        order : [ [ 1, 'asc' ] ]
								                  

										});  
								
						// Since We cant access the table outside this ajax call, the we shall have this function in here

						shareGraphs(table);
						
						loadUserAssignedPermisions(table);
						
						loader.hideLoading();
						
						deleteUser(table);
						
						updateUser(table);
						
						
						$('#profile_table').on('page.dt', function() {
							  
							shareGraphs(table);
							
							loadUserAssignedPermisions(table); 
							
							deleteUser(table);
							
							updateUser(table);
							
							});
							
							
							$('#profile_table').on('draw.dt', function() {
								  
								shareGraphs(table);
								
								loadUserAssignedPermisions(table); 
								
								deleteUser(table);
								
								updateUser(table);
							});
						
						
					},
					error : function(jqXHR, textStatus, errorThrown) {
						loader.hideLoading();
						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}
				});
	}
	
	function deleteUser(table){ 
			
			$('#profile_table').on('click', 'a.remove-row', function (){
				
				console.log("profile_table delete:--");
				
				var selectedProfile = table.row( { selected: true } ).data();
				
					var profile = {
						"type" : "object",
						"users" : {
							userId:selectedProfile.userId
						}
					};
					 

					var profileJSONString = JSON.stringify(profile);
					console.log("profile_table delete:--"+profileJSONString);

					$.ajax({
						headers : {
							'Accept' : 'application/json',
							'Content-Type' : 'application/json',
						'Authorization': $.cookie('loginToken')
						},
						type : "POST",
						url : DELETE_PROFILE,
						data : profileJSONString,
						dataType : "json",
						success : function(data, status) {
							
							if(data.result){
								showServerResponse("Success", data.message,"success")
								loadBathesTable();
							}else{
								showServerResponse("ERROR", data.errorMessage,"error")
								loadBathesTable();
							}
							
						},
						error : function(jqXHR, textStatus,
								errorThrown) {
							loader.hideLoading();
							if (errorThrown == 'Unauthorized') {

								onSessionTimeOut();
							}
						}
					});

				
			});
		 

	
		
	}
	
	function updateUser(table){

		$('a.edit-row').click(function (){
			
		loadRoleComboEdit();
		
		$('#update_profile').click(function (){
			
			console.log("profile_table Edit:--");
			
			var $role = $('#edit_role');
			
			var selectedProfile = table.row( { selected: true } ).data();
			
				var profile = {
					"type" : "object",
					"users" : {
						userId:selectedProfile.userId,
						role:$role.val()
					}
				};
				 

				var profileJSONString = JSON.stringify(profile);
				console.log("profile_table delete:--"+profileJSONString);

				$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json',
					'Authorization': $.cookie('loginToken')
					},
					type : "POST",
					url : UPDATE_PROFILE_ROLE,
					data : profileJSONString,
					dataType : "json",
					success : function(data, status) {
						
						if(data.result){
							showServerResponse("Success", data.message,"success")
							loadBathesTable();
						}else{
							showServerResponse("ERROR", data.errorMessage,"error")
							loadBathesTable();
						}
						
					},
					error : function(jqXHR, textStatus,
							errorThrown) {
						loader.hideLoading();
						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}
				});

			
		});
	
	});
		
	}

	function loadRoleCombo() {

		var options = '';

		options += ' <option value="administrator">Administrator</option>';
		options += ' <option value="investor">Investor</option>';

		$('#role').html(options);
	}
	
	function loadRoleComboEdit() {

		var options = '';

		options += ' <option value="administrator">Administrator</option>';
		options += ' <option value="investor">Investor</option>';

		$('#edit_role').html(options);
	}
	
	
	function loadGraphsToShareBatches() {
		var options = '';
		var graphs=['Portfolio Summary Statistics','Portfolio development over time','Restructured loans','Loan repayment curve']
		for ( var i = 0; i < graphs.length; i++) {
			options += ' <option value="' + graphs[i] + '">'
					+ graphs[i] + '</option>';
		}
		$('#graphs').html(options);
	}
	
	function loadGraphsToShareBatchesEdit() {
		var options = '';
		var graphs=['Portfolio Summary Statistics','Portfolio development over time','Restructured loans','Loan repayment curve']
		for ( var i = 0; i < graphs.length; i++) {
			options += ' <option value="' + graphs[i] + '">'
					+ graphs[i] + '</option>';
		}
		$('#graphs_edit').html(options);
	}
	
	
	
function shareGraphs(table){
		$('#share_graph_button_done').click(function (){
			
		
		var loader;
		loader = loader || (function() {
			var loaderDiv = $("#loading-modal");
			return {
				showLoading : function() {
					loaderDiv.modal();
				},
				hideLoading : function() {
					loaderDiv.modal('hide');
				}
			};
		})();
		
		loader.showLoading();
			
	var $graphs = $('#graphs').val() || [];
	var sharedGraphs = [];
	var sharedGraphCount = 0;
	
	var rowData = table.rows( { selected: true } ).data().toArray();
	
for ( var selectedGraph = 0; selectedGraph < $graphs.length; selectedGraph++) {
	
	for(var i=0;i<rowData.length;i++){
		
		var sharedGraph = {
			usersuserId : {
			        	userId : rowData[i].userId
							},
						graphs:$graphs[selectedGraph]
						}
		
		sharedGraphs[sharedGraphCount] = sharedGraph;
		sharedGraphCount++;
		
		console.log("User To share ==>> "+rowData[i].userId);
		
		}
}	
		var investorGraphs = {
					type : "object",
		userGraphs : sharedGraphs
							}
		

		var investorGraphsJSONString = JSON
									.stringify(investorGraphs);
		$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json',
				'Authorization': $.cookie('loginToken')
				},
				type : "POST",
				url : SHARE_GRAPHS_WITH_INVESTORS,
				data : investorGraphsJSONString,
				dataType : "json",
				success : function(data, status) {
					
					loader.hideLoading();
					
					if(data.result==true){
					showServerResponse("Success","Graphs Shared Successfully","success");
					}else{
					showServerResponse("Success","An Error Occured while Sharing Graphs. Please try again","error");
					}
					

				},
				error : function(jqXHR, textStatus, errorThrown) {
					loader.hideLoading();
					if (errorThrown == 'Unauthorized') {

						onSessionTimeOut();
					}
				}
				
			});
	

			
		});
	}

function loadUserAssignedPermisions(table){
	
	$('#profile_table tbody').on( 'click', 'button', function () {
        
	      var data = table.row( { selected: true } ).data();
	        
	        console.log("loadUserAssignedPermisions "+data.userId);
	        
	        var user={
	        	users:{
	        		userId:data.userId
	        			}
	        		}
	        
			var userJSONString = JSON.stringify(user);
					
	        $.ajax({
						headers : {
								'Accept' : 'application/json',
								'Content-Type' : 'application/json',
								'Authorization' : $
										.cookie('loginToken')
							},
							type : "POST",
							url : GRAPHS_SHARED_WITH_INVESTOR,
							data : userJSONString,
							dataType : "json",
							success : function(data, status) {

								if (data.result == true) {
									
									console.log(data.userGraphbatches[0].userBatchs.length);
									
									var batchList = '<ul class="list-unstyled task-list" id="batchList">';
									for ( var batchCount = 0; batchCount < data.userGraphbatches[0].userBatchs.length; batchCount++) {
										console.log(data.userGraphbatches[0].userBatchs[batchCount].batchid.name);
										batchList += ' <li><div class="card-box kanban-box"><div class="kanban-detail"><a href="#" class="label label-danger pull-right batch" id="'+data.userGraphbatches[0].userBatchs[batchCount].batchid.id+'">Remove</a><h4>'
												+ data.userGraphbatches[0].userBatchs[batchCount].batchid.name 
												+ '</h4></div></div></li>';
									}
									batchList+"</ul>";
									$('#batchs_shared').html(batchList);
									
									var graphList = '<ul class="list-unstyled task-list" id="graphList">';
									
									for ( var graphCount = 0; graphCount < data.userGraphbatches[0].userGraphs.length; graphCount++) {
										
										graphList += ' <li><div class="card-box kanban-box"><div class="kanban-detail"><a href="#" class="label label-danger pull-right graph" id="'+data.userGraphbatches[0].userGraphs[graphCount].graphs+'">Remove</a><h4>'
												+ data.userGraphbatches[0].userGraphs[graphCount].graphs 
												+ '</h4></div></div></li>';
									}
									graphList+"</ul>";
									
									$('#graphs_shared').html(graphList);
									
									
									removeBatchFromInvestor(table);
									
									removeGraphFromInvestor(table);
									
								} else {
									showServerResponse(
											"Success",
											"An Error Occured while Sharing Graphs. Please try again",
											"error");
								}

							},
							error : function(jqXHR, textStatus,
									errorThrown) {
								loader.hideLoading();
								if (errorThrown == 'Unauthorized') {

									onSessionTimeOut();
								}
							}

});
	        
	    } );
	  
}

function removeBatchFromInvestor(table){
	$('a.batch').click(function(){
		
		 var batchId = $(this).attr('id');
		 
			var sharedBatches = [];
			
			var selectedInvestor = table.row( { selected: true } ).data();;
	
			var sharedBatch = {
				batchid : {
					id : batchId
				},
				usersuserId : {
					userId :selectedInvestor.userId
				}
			}
			
			sharedBatches[0] = sharedBatch;
					
				
			var investorBatches = {
				type : "object",
				userBatches : sharedBatches
			}

			var investorBatchesJSONString = JSON
					.stringify(investorBatches);
			
			console.log("Unassigning Batch from Investor: "+investorBatchesJSONString);

			$
					.ajax({
						headers : {
							'Accept' : 'application/json',
							'Content-Type' : 'application/json',
						'Authorization': $.cookie('loginToken')
						},
						type : "POST",
						url : UN_SHARE_LOANS_WITH_INVESTORS,
						data : investorBatchesJSONString,
						dataType : "json",
						success : function(data, status) {
						
							if(data.result==true){
								showServerResponse("Success",
										data.message,"success");
							}else{
								showServerResponse("ERROR",
										data.message,"error");
							}
							

						}
					});

		
	})
}

function removeGraphFromInvestor(table){

	$('a.graph').click(function(){
		
		 var graphId = $(this).attr('id');
		 
			var sharedGraphs = [];
			
			var selectedInvestor = table.row( { selected: true } ).data();
	
			
			var sharedGraph = {
					usersuserId : {
					        	userId : selectedInvestor.userId
									},
								graphs:graphId
								}
				
				sharedGraphs[0] = sharedGraph;
				
				
			var investorGraphs = {
					type : "object",
					userGraphs : sharedGraphs
							}
		
		var investorGraphsJSONString = JSON.stringify(investorGraphs);
			
			
			console.log("Unassigning Graph from Investor: "+investorGraphsJSONString);

			$.ajax({
						headers : {
							'Accept' : 'application/json',
							'Content-Type' : 'application/json',
						'Authorization': $.cookie('loginToken')
						},
						type : "POST",
						url : UN_SHARE_GRAPHS_WITH_INVESTORS,
						data : investorGraphsJSONString,
						dataType : "json",
						success : function(data, status) {
						
							if(data.result==true){
								$("#"+graphId).addClass("hidden");
								showServerResponse("Success",
										data.message,"success");
								
							}else{
								showServerResponse("ERROR",
										data.message,"error");
							}
							

						}
					});

	})

}

	function showServerResponse(title, msg,type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}

});