$(function() {
	$('#reset_password')
			.click(
					function() {  
						
						var $email = $('#email'); 

						console.log("for got password");
						
							var profile = {
								"type" : "object",
								"users" : {
									email : $email.val()
								}
							};

							var profileJSONString = JSON.stringify(profile);

							$.ajax({
										headers : {
											'Accept' : 'application/json',
											'Content-Type' : 'application/json'
										},
										type : "POST",
										url : FOR_GOT_PASSWORD,
										data : profileJSONString,
										dataType : "json",
										success : function(data, status) {
											if (data.result) {
												showServerResponse("Message", "Check your email for reset password link","success");
												//window.location.replace("login.html");
											} else {
												console
														.log("User Profile Password Update ERROR: "
																+ data.errorMessage);
											}

										}
									});

						 
					});
			

		function showServerResponse(title, msg,type) {
		var $toastlast;
		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "20000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";
		
		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		//var $toast = toastr["success"](msg, title);
		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}
})