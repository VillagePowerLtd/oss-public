function onSessionTimeOut() {
	$.removeCookie("loginToken");
	$.removeCookie("userRole");
	$.removeCookie("userName");
	$.removeCookie("graphs");
	window.location.replace("login.jsp");

}