$(function() {
	$("#logged_in_user").html($.cookie('userName')); 
	getPortfolios();
	
	$('#save_portfolio').click(function() {

		var $name = $("#portfolio_name");
		var $description = $("#portfolio_description");

		var portfolio = {
			"type" : "object",
			"portfolio" : {
				name : $name.val(),
				description : $description.val()
			}
		};

		var portfolioDataJSONString = JSON.stringify(portfolio);

		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json',
			 'Authorization': $.cookie('loginToken')
					
			},
			type : "POST",
			url : CREATE_PORTFOLIOS,
			data : portfolioDataJSONString,
			dataType : "json",
			success : function(data, status) {
				showServerResponse("Success","Portfolio Successfully created","success");
				getPortfolios();
			},
			error : function(jqXHR, textStatus, errorThrown) {

				if (errorThrown == 'Unauthorized') {

					onSessionTimeOut();
				}
			}
		});

	});

	function getPortfolios() {
		
	var loader;
		loader = loader || (function() {
		var loaderDiv = $("#loading-modal");
		return {
			showLoading : function() {
			loaderDiv.modal();
				},
			hideLoading : function() {
			loaderDiv.modal('hide');
					}};})();
					 loader.showLoading();
		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json',
					'Authorization': $.cookie('loginToken')
							
							
					},
					type : "GET",
					url : RETRIEVE_PORTFOLIOS,
					dataType : "json",
					success : function(data, status) {

						var table = $('#portfolio_table')
								.DataTable(
										{
											destroy : true,
											data : data.portfolios,
											columns : [ {
												data : "name"
											}, {
												data : "description"
											}, {
												data : "lastUpdated"
											}, null

											],
											columnDefs : [ {
												targets : -1,
												data : null,
												defaultContent : "<a href='#' class='hidden on-editing save-row'><i class='fa fa-save'></i></a> <a href='#' class='hidden on-editing cancel-row'><iclass='fa fa-times'></i></a> <a href='#' class='on-default edit-row'><i class='fa fa-pencil'></i></a><a href='#' class='on-default remove-row'><i class='fa fa-trash-o'></i></a>"
											} ]

										});
										loader.hideLoading();
					},
					error : function(jqXHR, textStatus, errorThrown) {

						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}
				});
	}

	function showServerResponse(title,msg,type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title); 
		$toastlast = $toast;

	}

});