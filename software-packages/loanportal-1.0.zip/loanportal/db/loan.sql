-- MySQL Workbench Synchronization
-- Generated: 2017-06-03 04:03
-- Model: New Model
-- Version: 1.0
-- Project: Name of the project
-- Author: isaac t

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

ALTER SCHEMA `loan`  DEFAULT CHARACTER SET latin1  DEFAULT COLLATE latin1_swedish_ci ;

CREATE TABLE IF NOT EXISTS `loan`.`Batch` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `upload_date` DATETIME NULL DEFAULT NULL,
  `status` VARCHAR(45) NULL DEFAULT NULL,
  `name` VARCHAR(50) NULL DEFAULT NULL,
  `description` VARCHAR(145) NULL DEFAULT NULL,
  `update_date` DATETIME NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `Portfolio_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Batch_Portfolio1_idx` (`Portfolio_id` ASC),
  CONSTRAINT `fk_Batch_Portfolio1`
    FOREIGN KEY (`Portfolio_id`)
    REFERENCES `loan`.`Portfolio` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 20
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`Batch_has_Loan` (
  `Batch_id` INT(11) NOT NULL,
  `Batch_Portfolio_id` INT(11) NOT NULL,
  `Loan_id` INT(11) NOT NULL,
  PRIMARY KEY (`Batch_id`, `Batch_Portfolio_id`, `Loan_id`),
  INDEX `fk_Batch_has_Loan_Batch1_idx` (`Batch_id` ASC, `Batch_Portfolio_id` ASC),
  INDEX `fk_Batch_has_Loan_Loan1_idx` (`Loan_id` ASC),
  CONSTRAINT `fk_Batch_has_Loan_Batch1`
    FOREIGN KEY (`Batch_id`)
    REFERENCES `loan`.`Batch` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Batch_has_Loan_Loan1`
    FOREIGN KEY (`Loan_id`)
    REFERENCES `loan`.`Loan` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`Deposit` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `idDeposit` VARCHAR(10) NOT NULL,
  `systemCost` DOUBLE NULL DEFAULT '0',
  `upfront` DOUBLE NULL DEFAULT '0',
  `daily` DOUBLE NULL DEFAULT '0',
  `weekly` DOUBLE NULL DEFAULT '0',
  `monthly` DOUBLE NULL DEFAULT '0',
  `total` DOUBLE NULL DEFAULT '0',
  `final` DOUBLE NULL DEFAULT '0',
  `initial_payt_window` INT(11) NULL DEFAULT '14',
  `payt_perirod` INT(11) NULL DEFAULT '365',
  `upfront_payment` DOUBLE NULL DEFAULT '0',
  `defalt_rate_on_installments` INT(11) NULL DEFAULT '5',
  `grace_period_upfront` DOUBLE NULL DEFAULT '0',
  `penguin_total` DOUBLE NULL DEFAULT '0',
  `20percent` DOUBLE NULL DEFAULT '0',
  `version` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`Loan` (
  `status` VARCHAR(145) NULL DEFAULT NULL,
  `id` INT(11) NOT NULL,
  `total_amount_value` DOUBLE NULL DEFAULT NULL,
  `balance` DOUBLE NULL DEFAULT NULL,
  `full_payment_date` DATETIME NULL DEFAULT NULL,
  `next_payment_date` DATETIME NULL DEFAULT NULL,
  `model_purchased` VARCHAR(100) NULL DEFAULT NULL,
  `history_status` VARCHAR(45) NULL DEFAULT NULL,
  `upload_date` DATETIME NULL DEFAULT NULL,
  `installments_paid` DOUBLE NULL DEFAULT NULL,
  `total_value_loan` DOUBLE NULL DEFAULT NULL,
  `days_overdue` INT(11) NULL DEFAULT NULL,
  `par` VARCHAR(45) NULL DEFAULT NULL,
  `down_payment_date` DATETIME NULL DEFAULT NULL,
  `sales_agent` VARCHAR(145) NULL DEFAULT NULL,
  `distribution_agent` VARCHAR(145) NULL DEFAULT NULL,
  `store` VARCHAR(145) NULL DEFAULT NULL,
  `installation_address` VARCHAR(145) NULL DEFAULT NULL,
  `assigned` TINYINT(1) NULL DEFAULT '0',
  `number_batch_assined` INT(11) NULL DEFAULT '0',
  `day` INT(11) NULL DEFAULT NULL,
  `percentage` DOUBLE NULL DEFAULT NULL,
  `payments_within` DOUBLE NULL DEFAULT 0,
  `payments_behind` DOUBLE NULL DEFAULT 0,
  `balance_due_to_date` DOUBLE NULL DEFAULT 0,
  `amount_paid_to_date` DOUBLE NULL DEFAULT 0,
  `outstanding_overdue` DOUBLE NULL DEFAULT 0,
  `outstanding_within` DOUBLE NULL DEFAULT 0,
  `defaulted_amount` DOUBLE NULL DEFAULT 0,
  `discounted_amount` DOUBLE NULL DEFAULT 0,
  `district` VARCHAR(100) NULL DEFAULT NULL,
  `subcounty` VARCHAR(100) NULL DEFAULT NULL,
  `parish` VARCHAR(100) NULL DEFAULT NULL,
  `village` VARCHAR(100) NULL DEFAULT NULL,
  `version` VARCHAR(45) NULL DEFAULT NULL,
  `restructured` TINYINT(1) NULL DEFAULT 0,
  `restructured_overdue` VARCHAR(145) NULL DEFAULT 0,
  `restructured_outstanding` INT(11) NULL DEFAULT 0,
  `value_overdue_restructuring` DOUBLE NULL DEFAULT 0.0,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`Loan_Performance` (
  `Batch_id` INT(11) NULL DEFAULT NULL,
  `outstanding` DOUBLE NULL DEFAULT NULL,
  `collected` DOUBLE NULL DEFAULT NULL,
  `month` VARCHAR(45) NULL DEFAULT NULL,
  `idLoan_Performance` INT(11) NOT NULL AUTO_INCREMENT,
  `payments_within` DOUBLE NULL DEFAULT 0,
  `payments_behind` DOUBLE NULL DEFAULT 0,
  `balance_due_to_date` DOUBLE NULL DEFAULT 0,
  `amount_paid_to_date` DOUBLE NULL DEFAULT 0,
  `outstanding_overdue` DOUBLE NULL DEFAULT 0,
  `outstanding_within` DOUBLE NULL DEFAULT 0,
  `defaulted_amount` DOUBLE NULL DEFAULT 0,
  `discounted_amount` DOUBLE NULL DEFAULT 0,
  `date_created` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`idLoan_Performance`))
ENGINE = InnoDB
AUTO_INCREMENT = 205
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`Number_of_Loans` (
  `Batch_id` INT(11) NULL DEFAULT NULL,
  `within` DOUBLE NULL DEFAULT NULL,
  `paid_up` DOUBLE NULL DEFAULT NULL,
  `over_due` DOUBLE NULL DEFAULT NULL,
  `closed` DOUBLE NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `month` VARCHAR(45) NULL DEFAULT NULL,
  `idNumber_of_Loans` INT(11) NOT NULL AUTO_INCREMENT,
  `recovered` DOUBLE NULL DEFAULT 0.0,
  PRIMARY KEY (`idNumber_of_Loans`))
ENGINE = InnoDB
AUTO_INCREMENT = 205
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`Payment_Status` (
  `Batch_id` INT(11) NULL DEFAULT NULL,
  `within` DOUBLE NULL DEFAULT NULL,
  `paid_up` DOUBLE NULL DEFAULT NULL,
  `over_due` DOUBLE NULL DEFAULT NULL,
  `closed` DOUBLE NULL DEFAULT NULL,
  `month` VARCHAR(45) NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `idPayment_Status` INT(11) NOT NULL AUTO_INCREMENT,
  `collected` DOUBLE NULL DEFAULT NULL,
  `discounted_amount` DOUBLE NULL DEFAULT 0,
  PRIMARY KEY (`idPayment_Status`))
ENGINE = InnoDB
AUTO_INCREMENT = 205
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`Portfolio` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(145) NULL DEFAULT NULL,
  `last_updated` DATETIME NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `description` VARCHAR(145) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 18
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`actual_percentage` (
  `idactual_percentage` INT(11) NOT NULL AUTO_INCREMENT,
  `actual_day` INT(11) NULL DEFAULT NULL,
  `actual_percent` DECIMAL(30,15) NULL DEFAULT NULL,
  `Batch_id` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`idactual_percentage`))
ENGINE = InnoDB
AUTO_INCREMENT = 53
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`overdue_loans_by_number` (
  `idoverdue_loans_by_number` INT(11) NOT NULL AUTO_INCREMENT,
  `number_par1` DOUBLE NULL DEFAULT NULL,
  `number_par30` DOUBLE NULL DEFAULT NULL,
  `number_par60` DOUBLE NULL DEFAULT NULL,
  `number_par90` DOUBLE NULL DEFAULT NULL,
  `number_on_defaulted` DOUBLE NULL DEFAULT NULL,
  `number_on_reposessed` DOUBLE NULL DEFAULT NULL,
  `number_within_paid_up` DOUBLE NULL DEFAULT NULL,
  `par_by_number` DOUBLE NULL DEFAULT NULL,
  `par_defaulted_number` DOUBLE NULL DEFAULT NULL,
  `par_reposessed_number` DOUBLE NULL DEFAULT NULL,
  `Batch_id` INT(11) NULL DEFAULT NULL,
  `month` VARCHAR(45) NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`idoverdue_loans_by_number`))
ENGINE = InnoDB
AUTO_INCREMENT = 174
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`overdue_loans_by_value` (
  `idoverdue_loans_by_value` INT(11) NOT NULL AUTO_INCREMENT,
  `outstanding_par1` DOUBLE NULL DEFAULT NULL,
  `outstanding_par30` DOUBLE NULL DEFAULT NULL,
  `outstanding_par60` DOUBLE NULL DEFAULT NULL,
  `outstanding_par90` DOUBLE NULL DEFAULT NULL,
  `outstanding_on_defaulted` DOUBLE NULL DEFAULT NULL,
  `outstanding_on_reposessed` DOUBLE NULL DEFAULT NULL,
  `outstanding_within_paid_up` DOUBLE NULL DEFAULT NULL,
  `par_by_value` DOUBLE NULL DEFAULT NULL,
  `par_defaulted_value` DOUBLE NULL DEFAULT NULL,
  `par_reposessed_value` DOUBLE NULL DEFAULT NULL,
  `Batch_id` INT(11) NULL DEFAULT NULL,
  `month` VARCHAR(45) NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `recovery_amount` DOUBLE NULL DEFAULT 0,
  PRIMARY KEY (`idoverdue_loans_by_value`))
ENGINE = InnoDB
AUTO_INCREMENT = 174
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`payments` (
  `idpayment` INT(11) NOT NULL AUTO_INCREMENT,
  `contract_date` DATETIME NULL DEFAULT NULL,
  `payment_amount` DOUBLE NULL DEFAULT NULL,
  `payment_date` DATETIME NULL DEFAULT NULL,
  `Loan_id` INT(11) NOT NULL,
  `contract_day_of_payment` INT(11) NULL DEFAULT 0,
  `balance_due_by_payment` DOUBLE NULL DEFAULT 0,
  `total_paid_by_payment` DOUBLE NULL DEFAULT 0,
  `status_of_payment` VARCHAR(45) NULL DEFAULT '\"\"',
  `date_created` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`idpayment`),
  INDEX `FK_brih2ks7a0rh8bi9y1kcjjphw` (`Loan_id` ASC),
  CONSTRAINT `FK_brih2ks7a0rh8bi9y1kcjjphw`
    FOREIGN KEY (`Loan_id`)
    REFERENCES `loan`.`Loan` (`id`)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT)
ENGINE = InnoDB
AUTO_INCREMENT = 46
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`percentage` (
  `idpercentage` INT(11) NOT NULL AUTO_INCREMENT,
  `day` INT(11) NULL DEFAULT NULL,
  `percentage` DOUBLE NULL DEFAULT NULL,
  `Loan_id` INT(11) NOT NULL,
  `Batch_id` INT(11) NOT NULL,
  PRIMARY KEY (`idpercentage`),
  INDEX `FK_hb5etcnqo5emirhxnktuf0v42` (`Loan_id` ASC),
  INDEX `fk_percentage_Batch1_idx` (`Batch_id` ASC),
  CONSTRAINT `FK_hb5etcnqo5emirhxnktuf0v42`
    FOREIGN KEY (`Loan_id`)
    REFERENCES `loan`.`Loan` (`id`),
  CONSTRAINT `fk_percentage_Batch1`
    FOREIGN KEY (`Batch_id`)
    REFERENCES `loan`.`Batch` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2079
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`role` (
  `roleId` INT(11) NOT NULL AUTO_INCREMENT,
  `creation` DATETIME NULL DEFAULT NULL,
  `description` VARCHAR(255) NULL DEFAULT NULL,
  `enabled` BIT(1) NULL DEFAULT NULL,
  `name` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`roleId`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`role_permission` (
  `permissionId` INT(11) NOT NULL AUTO_INCREMENT,
  `permission` VARCHAR(255) NULL DEFAULT NULL,
  `roleId` INT(11) NOT NULL,
  PRIMARY KEY (`permissionId`),
  INDEX `FK_fv36v7t1j8wkyv2hf9qlt9pdq` (`roleId` ASC),
  CONSTRAINT `FK_fv36v7t1j8wkyv2hf9qlt9pdq`
    FOREIGN KEY (`roleId`)
    REFERENCES `loan`.`role` (`roleId`))
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`user_batch` (
  `iduser_batch` INT(11) NOT NULL AUTO_INCREMENT,
  `Batch_id` INT(11) NOT NULL,
  `users_userId` INT(11) NOT NULL,
  PRIMARY KEY (`iduser_batch`),
  INDEX `fk_user_batch_Batch1_idx` (`Batch_id` ASC),
  INDEX `fk_user_batch_users1_idx` (`users_userId` ASC),
  CONSTRAINT `FK_92h1al5dwe2h5bxck5qywj9w4`
    FOREIGN KEY (`users_userId`)
    REFERENCES `loan`.`users` (`userId`),
  CONSTRAINT `FK_bc60snlr4mdaqe4y97fsykyxa`
    FOREIGN KEY (`Batch_id`)
    REFERENCES `loan`.`Batch` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 63
DEFAULT CHARACTER SET = latin1;

CREATE TABLE IF NOT EXISTS `loan`.`user_graph` (
  `idGraph` INT(11) NOT NULL AUTO_INCREMENT,
  `graphs` VARCHAR(255) NOT NULL,
  `users_userId` INT(11) NOT NULL,
  PRIMARY KEY (`idGraph`),
  INDEX `FK_qif42v1c1xfoj7tert6s1x492` (`users_userId` ASC),
  CONSTRAINT `FK_qif42v1c1xfoj7tert6s1x492`
    FOREIGN KEY (`users_userId`)
    REFERENCES `loan`.`users` (`userId`))
ENGINE = InnoDB
AUTO_INCREMENT = 37
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`user_roles` (
  `userId` INT(11) NOT NULL,
  `user_rolesId` INT(11) NOT NULL AUTO_INCREMENT,
  `roleId` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`user_rolesId`),
  INDEX `fk_table1_users1_idx` (`userId` ASC),
  CONSTRAINT `FK_lbvvqmh536gyici9px18cunf6`
    FOREIGN KEY (`userId`)
    REFERENCES `loan`.`users` (`userId`))
ENGINE = InnoDB
AUTO_INCREMENT = 25
DEFAULT CHARACTER SET = latin1;

CREATE TABLE IF NOT EXISTS `loan`.`users` (
  `userId` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(255) NULL DEFAULT NULL,
  `enabled` TINYINT(1) NULL DEFAULT NULL,
  `password` VARCHAR(255) NULL DEFAULT NULL,
  `role` VARCHAR(255) NULL DEFAULT NULL,
  `salt` VARCHAR(255) NULL DEFAULT NULL,
  `username` VARCHAR(255) NULL DEFAULT NULL,
  `version` DATETIME NULL DEFAULT NULL,
  `company` VARCHAR(255) NULL DEFAULT NULL,
  `firstname` VARCHAR(255) NULL DEFAULT NULL,
  `image_url` VARCHAR(255) NULL DEFAULT NULL,
  `lastname` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`userId`))
ENGINE = InnoDB
AUTO_INCREMENT = 33
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `loan`.`batch_analysis` (
  `idbatch_analysis` INT(11) NOT NULL AUTO_INCREMENT,
  `analysis_days` INT(11) NULL DEFAULT NULL,
  `display_type` ENUM('weeks', 'days', 'months', 'years') NULL DEFAULT NULL,
  `Batch_id` INT(11) NOT NULL,
  PRIMARY KEY (`idbatch_analysis`),
  INDEX `fk_batch_analysis_Batch1_idx` (`Batch_id` ASC),
  CONSTRAINT `fk_batch_analysis_Batch1`
    FOREIGN KEY (`Batch_id`)
    REFERENCES `loan`.`Batch` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE TABLE IF NOT EXISTS `loan`.`batch_projected_curve` (
  `idbatch_projected_curve` INT(11) NOT NULL AUTO_INCREMENT,
  `projected_value` DOUBLE NULL DEFAULT NULL,
  `projected_time` INT(11) NULL DEFAULT NULL,
  `Batch_id` INT(11) NOT NULL,
  PRIMARY KEY (`idbatch_projected_curve`),
  INDEX `fk_batch_projected_curve_Batch1_idx` (`Batch_id` ASC),
  CONSTRAINT `fk_batch_projected_curve_Batch1`
    FOREIGN KEY (`Batch_id`)
    REFERENCES `loan`.`Batch` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE TABLE IF NOT EXISTS `loan`.`restructured_loans` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `number_restructured` INT(11) NULL DEFAULT NULL,
  `outstanding_restructured` DOUBLE NULL DEFAULT NULL,
  `Batch_id` INT(11) NULL DEFAULT NULL,
  `month` VARCHAR(45) NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `outstanding_overdue_restructured` DOUBLE NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
