create table installation (id int not null auto_increment, customer_id int, barcode varchar(50), photo_inst_report mediumblob, photo_system mediumblob, photo_panel mediumblob, installation_lat double, installation_lng double, installation_datetime datetime, location_descr mediumtext, intended_use_of_system varchar(255), name_referrer varchar(255), contact_referrer varchar(255), details_referrer varchar(255), index(id), index(customer_id));

create table kit_collection (id int not null auto_increment, customer_id int, barcode varchar(50), photo_inst_report mediumblob, name_referrer varchar(255), contact_referrer varchar(255), details_referrer varchar(255), pickup_lat double, pickup_lng double, pickup_datetime datetime, index(id), index(customer_id));

create table sales_contract (id int not null auto_increment, customer_id int, photo_face mediumblob, photo_id mediumblob, age int, employment_type varchar(255), occupation varchar(255), monthly_income int, num_household int, num_income_earners int, method_heard_vp varchar(255), index(id));

create table odk_data_transfer(table varchar(50), last_id int);
