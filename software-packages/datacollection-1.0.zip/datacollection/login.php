<?php
/* 
 * Copyright (C) 2017 Village-Power AG
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU Lesser General Public License for more details.
 *
 *     You should have received a copy of the GNU Lesser General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
  ini_set('display_errors',1);

  require_once("defines.php");
  require_once('functions.php'); 
  $api = new _un();
  session_start();
?>
<?php
  if ((isset($_POST["SUBMIT"])) && ($_POST["SUBMIT"] == "LOGIN")) {
    $email = strip_tags($_POST['email']);
    $password = strip_tags($_POST['password']);

    $email = $uncdf->real_escape_string($email);
    $password = $uncdf->real_escape_string($password);

    $query = $uncdf->query("SELECT name, email, role, password FROM users WHERE email='$email'");
    $row=$query->fetch_array();

    $count = $query->num_rows;

    if (password_verify($password, $row['password']) && $count==1) {
      $_SESSION['user_email'] = $row['email'];
      $_SESSION['user_role'] = $row['role'];
      $_SESSION['user_name'] = $row['name'];
      
      header("Location: index.php");
      exit();
    } else {
    $msg = "<div class='alert alert-danger text-center'>
       <span class='glyphicon glyphicon-info-sign'></span> &nbsp; Invalid Username or Password !
      </div>";
    }
  }
?>
<!DOCTYPE html>
  <html>
  <head>
    <title></title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">

    <link rel="stylesheet" type="text/css" href="assets/data-tables/media/css/dataTables.bootstrap.css">

    <!-- Fancybox CSS -->
    <link rel="stylesheet" type="text/css" href="assets/fancybox/source/jquery.fancybox.css?v=2.1.5" media="screen" />
    <link rel="stylesheet" type="text/css" href="assets/fancybox/source/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
    <link rel="stylesheet" type="text/css" href="assets/fancybox/source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" />

    <link rel="stylesheet" type="text/css" href="assets/css/mine.css">
  </head>
  <body>
    <div class = "container">
      <div class="wrapper">
        <form action="" method="post" name="Login_Form" class="form-signin"> 
          <div class="row text-center bol"><i class="fa fa-circle"></i></div>
          <h3 class="form-signin-heading text-center">Verification Portal</h3>
          <hr class="spartan">
          <?php if(isset($msg)) { echo $msg;}?>
          <div class="input-group">
            <span class="input-group-addon" id="sizing-addon1">
              <i class="fa fa-user"></i>
            </span>
            <input type="email" class="form-control specific" name="email" placeholder="Email" required />
          </div>
          <div class="input-group">
            <span class="input-group-addon" id="sizing-addon1">
              <i class="fa fa-lock"></i>
            </span>
            <input type="password" class="form-control specific" name="password" placeholder="Password" required/> 
          </div>
          <button class="btn btn-lg btn-primary btn-block"  name="SUBMIT" value="LOGIN" type="Submit">Login</button>        
        </form>     
      </div>
    </div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <!--<script src="assets/js/mine.js"></script>-->

    <!-- Fancybox JS -->
    <script type="text/javascript" src="assets/fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script>
    <script type="text/javascript" src="assets/fancybox/source/jquery.fancybox.js?v=2.1.5"></script>
    <script type="text/javascript" src="assets/fancybox/source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>
    <script type="text/javascript" src="assets/fancybox/source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>
    <script type="text/javascript" src="assets/fancybox/source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>

    <script type="text/javascript" src="assets/data-tables/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="assets/data-tables/media/js/dataTables.bootstrap.js"></script>
  </body>
</html>