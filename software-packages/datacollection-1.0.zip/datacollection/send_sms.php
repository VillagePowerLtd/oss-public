<?php
/* 
 * Copyright (C) 2017 Village-Power AG
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU Lesser General Public License for more details.
 *
 *     You should have received a copy of the GNU Lesser General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
  ini_set('display_errors',1);

  require_once("defines.php");
  require_once('functions.php');
  $api = new _un();
?>
<?php
    //Check if there are any tables with images
    //send_new_sms($sender,$reciepient,$message);
	$check_notification = $uncdf->query("SELECT * FROM notifications WHERE sent=0");
	if (mysqli_num_rows($check_notification) > 0) {
		$ids = array();
    	while($row = $check_notification->fetch_assoc()) {
    		$id = $row['id'];
    		$form = $row['form'];
    		$user = str_replace("_"," ", $row['user']);
    		$submission_date = $row['submission_date'];
    		$sent = $row['sent'];
    		$dept = $row['dept'];
    		array_push($ids, $id);
		}
		
		$check_users = $uncdf->query("SELECT * FROM users WHERE role IN ('".$dept."', 'admin')");
		if (mysqli_num_rows($check_users) > 0) {
			while($row_not = $check_users->fetch_assoc()) {
				$name = $row_not['name'];
				$phone[$name] = $row_not['phone'];
			}
		}

		foreach ($phone as $name=>$phone) {
			$reciepient = $phone;
			$sender = 'VP_UGANDA';
			$message = "Dear ".$name.", ".$user." has sent through a ".$form." on ".$submission_date."";
			$api->send_new_sms($sender,$reciepient,$message);
		}

		foreach ($ids as $id) {
			$update = $uncdf->query("UPDATE notifications SET sent=1 WHERE id=".$id."");
		}
	}
?>