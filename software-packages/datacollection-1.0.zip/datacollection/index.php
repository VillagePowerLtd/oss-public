<?php
 /* 
  * Copyright (C) 2017 Village-Power AG
  *
  *     This program is free software: you can redistribute it and/or modify
  *     it under the terms of the GNU Lesser General Public License as published by
  *     the Free Software Foundation, either version 3 of the License, or
  *     (at your option) any later version.
  *
  *     This program is distributed in the hope that it will be useful,
  *     but WITHOUT ANY WARRANTY; without even the implied warranty of
  *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *     GNU Lesser General Public License for more details.
  *
  *     You should have received a copy of the GNU Lesser General Public License
  *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  */
  ini_set('display_errors',1);

  require_once("defines.php");
  require_once("forms.php");
  require_once('functions.php');
  include('check.php'); 
  $api = new _un();
?>
<?php
  $role = $_SESSION['user_role'];
?>
<!DOCTYPE html>
  <html>
  <head>
    <title></title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">

    <link rel="stylesheet" type="text/css" href="assets/data-tables/media/css/dataTables.bootstrap.css">

    <!-- select css -->
    <link rel="stylesheet" href="assets/select/select2.css">

    <!-- Fancybox CSS -->
    <link rel="stylesheet" type="text/css" href="assets/fancybox/source/jquery.fancybox.css?v=2.1.5" media="screen" />
    <link rel="stylesheet" type="text/css" href="assets/fancybox/source/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
    <link rel="stylesheet" type="text/css" href="assets/fancybox/source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" />

    <link rel="stylesheet" type="text/css" href="assets/toast/toastr.css"/>
    <link rel="stylesheet" type="text/css" href="assets/toast/toastr.min.css"/>
    <link rel="stylesheet" type="text/css" href="assets/css/mine.css">

    <style type="text/css">
      .table-responsive {
        overflow: auto;
      }
      .fancybox-custom .fancybox-skin {
        box-shadow: 0 0 50px #222;
      }
      .box-content {
        padding: 12px
      }
      th, tr td{
        white-space: nowrap;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <h3>The forms shown below are as submited to the ODK Aggregate Server</h3>
        <div class="controls pull-right">
          <?php if ($role=='admin') {?>
          <a"><button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#view_users">View Users</button></a>
          <a"><button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#add_new_user">Add New User</button></a><?php } ?>
          <a href="logout.php"><button class="btn btn-primary btn-sm">Logout</button></a>
        </div>
      <hr>
      <p>Authoured by <a>Village Power (U) Limited</a></p>

      <!-- Add User Modal -->
      <div class="modal fade" id="add_new_user" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">
                <span aria-hidden="true">&times;</span>
                <span class="sr-only">Close</span>
              </button>
              <h4 class="modal-title" id="myModalLabel">Add a new user</h4>
            </div>
            <!-- Modal Body -->

            <form class="form-horizontal" id="new_user">
              <fieldset>
                <div class="modal-body">
                    <div class="form-group">
                      <label class="col-sm-2 control-label" for="name">Name:</label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" id="name" name="name" placeholder="Full name" required/>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-2 control-label" for="email">Email:</label>
                      <div class="col-sm-10">
                        <input type="email" class="form-control" id="email" name="email" placeholder="Email" required/>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-2 control-label" for="email">Phone:</label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone" required/>
                      </div>
                    </div>
                    <!--<div class="form-group">
                      <label class="col-sm-2 control-label" for="inputPassword3">Password:</label>
                      <div class="col-sm-10">
                        <input type="password" class="form-control" id="password" name="password" placeholder="Password" />
                      </div>
                    </div>-->
                    <div class="form-group">
                      <label class="col-sm-2 control-label" for="name">Role:</label>
                      <div class="col-sm-10">
                        <select name="role" id="role" class="form-control" style="width:100%" required>
                          <option></option>
                          <option value="sales">Sales</option>
                          <option value="technical">Technical</option>
                          <option value="customer_care">Customer Care</option>
                          <option value="admin">Administrator</option>
                        </select>
                      </div>
                    </div>
                </div>
              </fieldset>
            </form>

            <!-- Modal Footer -->
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" id="submit_new_user" class="btn btn-primary">Save changes</button>
            </div>
          </div>
        </div>
      </div>
      <!--End of Add User Modal -->

      <!-- View Users -->
      <div class="modal fade" id="view_users" tabindex="-1" role="dialog" aria-labelledby="view_users" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">
                <span aria-hidden="true">&times;</span>
                <span class="sr-only">Close</span>
              </button>
              <h4 class="modal-title text-center" id="myModalLabel">Users</h4>
            </div>
            <!-- Modal Body -->

            
            <div class="modal-body">
              <div style="border:0">
                <table id="users" class="nowrap table table-bordered table-striped" style="width:100%">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Name</th>
                      <th>Phone</th>
                      <th>Email</th>
                      <th>Role</th>
                    </tr>
                  </thead>
                </table>
              </div>
            </div>

            <!-- Modal Footer -->
            <div class="modal-footer">
              
            </div>
            
          </div>
        </div>
      </div>
      <!--End of Add User Modal -->

      <div class="row">
        <?php
          $forms=array();
          
          $form_arr = array();
          switch ($role) {
            case 'user_group_1':
              $form_arr = array(form_1);
              break;
            case 'user_group_2':
              $form_arr = array(form_2,form_3,form_4);
              break;
            case 'user_group_3':
              $form_arr = array(form_5,form_6);
              break;
            default:
              $form_arr = array(form_1,form_2,form_3,form_4,form_5,form_6);
              break;
          }
          $form = "'".implode("','", $form_arr)."'";

          //echo "SELECT * FROM _form_info LEFT JOIN _form_info_fileset ON _form_info._URI = _form_info_fileset._PARENT_AURI WHERE _form_info.FORM_ID IN ($forms)";
          $odk_table_result=$uncdf->query("SELECT _form_info_fileset.FORM_NAME, _form_info.FORM_ID FROM _form_info LEFT JOIN _form_info_fileset ON _form_info._URI = _form_info_fileset._PARENT_AURI WHERE _form_info.FORM_ID IN ($form)");
          while($table=$odk_table_result->fetch_assoc()) {
            $forms[]=$table;
          }

          $start=1;
          foreach($forms as $row){
            $table_prefix = strtoupper(preg_replace('/[^\da-z]/i', '_', $row['FORM_ID']));
            
            $columns = array();
            $default_form_name = $row['FORM_NAME'];
            $form_name = str_replace('_',' ', $default_form_name);

            //echo '<br>'.$row.'<br>';
            echo '<div class="panel panel-primary">
                    <div class="panel-heading">
                      <h3 class="panel-title">'.$form_name.'</h3>
                    </div>';

            //To know the columns to be selected
            $table_head_num=$uncdf->query("DESCRIBE ". $table_prefix."_CORE");
            
            while($table_heads=$table_head_num->fetch_assoc()) {
              //if (substr($table_heads['Field'], 0, 1) != "_") {  //Was removing those that start with underscores
              $columns[$table_heads['Field']] = $table_heads['Field'];
              //}
            }
            
            $new_columns = array();

            if ($default_form_name == form_1) {
              if (array_key_exists(f1_column_1, $columns)) {
                array_push($new_columns, f2_column_1);
              }

              if (array_key_exists(f1_column_2, $columns)) {
                array_push($new_columns, f1_column_2);
              }

              if (array_key_exists(f1_column_3, $columns)) {
                array_push($new_columns, f1_column_3);
              }

              if (array_key_exists(f1_column_4, $columns)) {
                array_push($new_columns, f1_column_4);
              }

              if (array_key_exists(f1_column_5, $columns)) {
                array_push($new_columns, f1_column_5);
              }

              array_push($new_columns, 'META_INSTANCE_ID'); 
            }

            if ($default_form_name == form_2) {
              if (array_key_exists(f2_column_1, $columns)) {
                array_push($new_columns, f2_column_1);
              }

              if (array_key_exists(f2_column_2, $columns)) {
                array_push($new_columns, f2_column_2);
              }

              if (array_key_exists(f2_column_3, $columns)) {
                array_push($new_columns, f2_column_3);
              }

              if (array_key_exists(f2_column_4, $columns)) {
                array_push($new_columns, f2_column_4);
              }

              if (array_key_exists(f2_column_5, $columns)) {
                array_push($new_columns, f2_column_5);
              }

              array_push($new_columns, 'META_INSTANCE_ID'); 
            }

            if ($default_form_name == form_3) {
              if (array_key_exists(f3_column_1, $columns)) {
                array_push($new_columns, f3_column_1);
              }

              if (array_key_exists(f3_column_2, $columns)) {
                array_push($new_columns, f3_column_2);
              }

              if (array_key_exists(f3_column_3, $columns)) {
                array_push($new_columns, f3_column_3);
              }

              if (array_key_exists(f3_column_4, $columns)) {
                array_push($new_columns, f3_column_4);
              }

              if (array_key_exists(f3_column_5, $columns)) {
                array_push($new_columns, f3_column_5);
              }

              array_push($new_columns, 'META_INSTANCE_ID'); 
            }

            if ($default_form_name == form_4) {
              if (array_key_exists(f4_column_1, $columns)) {
                array_push($new_columns, f4_column_1);
              }

              if (array_key_exists(f4_column_2, $columns)) {
                array_push($new_columns, f4_column_2);
              }

              if (array_key_exists(f4_column_3, $columns)) {
                array_push($new_columns, f4_column_3);
              }

              if (array_key_exists(f4_column_4, $columns)) {
                array_push($new_columns, f4_column_4);
              }

              if (array_key_exists(f4_column_5, $columns)) {
                array_push($new_columns, f4_column_5);
              }

              array_push($new_columns, 'META_INSTANCE_ID'); 
            }

            if ($default_form_name == form_5) {
              if (array_key_exists(f5_column_1, $columns)) {
                array_push($new_columns, f5_column_1);
              }

              if (array_key_exists(f5_column_2, $columns)) {
                array_push($new_columns, f5_column_2);
              }

              if (array_key_exists(f5_column_3, $columns)) {
                array_push($new_columns, f5_column_3);
              }

              if (array_key_exists(f5_column_4, $columns)) {
                array_push($new_columns, f5_column_4);
              }

              if (array_key_exists(f5_column_5, $columns)) {
                array_push($new_columns, f5_column_5);
              }

              array_push($new_columns, 'META_INSTANCE_ID'); 
            }

            if ($default_form_name == form_6) {
              if (array_key_exists(f6_column_1, $columns)) {
                array_push($new_columns, f6_column_1);
              }

              if (array_key_exists(f6_column_2, $columns)) {
                array_push($new_columns, f6_column_2);
              }

              if (array_key_exists(f6_column_3, $columns)) {
                array_push($new_columns, f6_column_3);
              }

              if (array_key_exists(f6_column_4, $columns)) {
                array_push($new_columns, f6_column_4);
              }

              if (array_key_exists(f6_column_5, $columns)) {
                array_push($new_columns, f6_column_5);
              }

              array_push($new_columns, 'META_INSTANCE_ID'); 
            }

            $column_names = implode(", ", $new_columns);

            $column_join = "";
            $selected_columns = "";

            $join_array = array();
            $column_array = array();
            //Check if there are any tables with images
            $table_image=$uncdf->query("SHOW TABLES LIKE '".$table_prefix."%BLB'");

            if (mysqli_num_rows($table_image) > 0) {
              $db = $api->getDatabase();
              $blb = 'blb';
              $x = 0;
              while($table_heads=$table_image->fetch_assoc()) {
                $x++;
                $raw_image_column = $table_heads["Tables_in_$db ($table_prefix%BLB)"];
                $alias = "column_".$x;
                $selected_column = $raw_image_column.".VALUE AS ".$alias;
                $to_join = "LEFT JOIN ".$raw_image_column." ON ".$table_prefix."_CORE.META_INSTANCE_ID = ".$raw_image_column."._TOP_LEVEL_AURI";
                
                array_push($join_array, $to_join);
                array_push($column_array, $selected_column);
              }
              $fields_joins = implode(',', $column_array);
              $fields_join = $fields_joins.",";
            }

            $column_join = implode(" ", $join_array).'<br>';

            //Selecting table headers
            $table_head=$uncdf->query("DESCRIBE ". $table_prefix."_CORE");
            
            //Selecting table contents
            $table_content=$uncdf->query("SELECT ".$column_names." FROM ".$table_prefix."_CORE ORDER BY ".$table_prefix."_CORE._SUBMISSION_DATE DESC");
            //echo "SELECT ".$column_names." FROM ".$table_prefix."_CORE";
            
            if (mysqli_num_rows($table_content) > 0) {
              echo '
              <div class="clearfix"></div><div class="table-responsive box-content"><table id="table_'.$start.'" class="table table-bordered table-condensed custom">
                <thead>
                  <tr>';
                  echo '<th class="text-center">#</th>';

                  if ($default_form_name == form_1) {
                    if (array_key_exists(f1_column_1, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f1_column_1).'</th>';
                    }

                    if (array_key_exists(f1_column_2, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f1_column_2).'</th>';
                    }

                    if (array_key_exists(f1_column_3, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f1_column_3).'</th>';
                    }

                    if (array_key_exists(f1_column_4, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f1_column_4).'</th>';
                    }

                    if (array_key_exists(f1_column_5, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f1_column_5).'</th>';
                    }
                  }

                  if ($default_form_name == form_2) {
                    if (array_key_exists(f2_column_1, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f2_column_1).'</th>';
                    }

                    if (array_key_exists(f2_column_2, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f2_column_2).'</th>';
                    }

                    if (array_key_exists(f2_column_3, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f2_column_3).'</th>';
                    }

                    if (array_key_exists(f2_column_4, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f2_column_4).'</th>';
                    }

                    if (array_key_exists(f2_column_5, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f2_column_5).'</th>';
                    }
                  }

                  if ($default_form_name == form_3) {
                    if (array_key_exists(f3_column_1, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f3_column_1).'</th>';
                    }

                    if (array_key_exists(f3_column_2, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f3_column_2).'</th>';
                    }

                    if (array_key_exists(f3_column_3, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f3_column_3).'</th>';
                    }

                    if (array_key_exists(f3_column_4, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f3_column_4).'</th>';
                    }

                    if (array_key_exists(f3_column_5, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f3_column_5).'</th>';
                    }
                  }

                  if ($default_form_name == form_4) {
                    if (array_key_exists(f4_column_1, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f4_column_1).'</th>';
                    }

                    if (array_key_exists(f4_column_2, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f4_column_2).'</th>';
                    }

                    if (array_key_exists(f4_column_3, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f4_column_3).'</th>';
                    }

                    if (array_key_exists(f4_column_4, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f4_column_4).'</th>';
                    }

                    if (array_key_exists(f4_column_5, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f4_column_5).'</th>';
                    }
                  }

                  if ($default_form_name == form_5) {
                    if (array_key_exists(f5_column_1, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f5_column_1).'</th>';
                    }

                    if (array_key_exists(f5_column_2, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f5_column_2).'</th>';
                    }

                    if (array_key_exists(f5_column_3, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f5_column_3).'</th>';
                    }

                    if (array_key_exists(f5_column_4, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f5_column_4).'</th>';
                    }

                    if (array_key_exists(f5_column_5, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f5_column_5).'</th>';
                    }
                  }

                  if ($default_form_name == form_6) {
                    if (array_key_exists(f6_column_1, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f6_column_1).'</th>';
                    }

                    if (array_key_exists(f6_column_2, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f6_column_2).'</th>';
                    }

                    if (array_key_exists(f6_column_3, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f6_column_3).'</th>';
                    }

                    if (array_key_exists(f6_column_4, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f6_column_4).'</th>';
                    }

                    if (array_key_exists(f6_column_5, $columns)) {
                      echo '<th class="text-center">'.str_replace('_',' ', f6_column_5).'</th>';
                    }
                  }
                  
                  echo '</tr>
                </thead>
                <tbody>';

                $i = 0;
                while($table_rows=$table_content->fetch_assoc()) {
                  $i++;
                  echo '<tr><td class="text-center"><a class="fancybox fancybox.iframe" href="details.php?id='.$table_rows['META_INSTANCE_ID'].'&form='.$table_prefix.'" title = "Details view for Form '.str_replace("_", " ", $table_prefix).' '.$i.'">'.$i.'</a></td>';
                  $string = "column_";
                  
                  $p=0;
                  foreach ($table_rows as $value) {
                    $p++;
                    if ($p<6) {
                      echo '<td class="text-center">'.str_replace('_',' ',$value).'</td>';
                    }
                  }
                  
                  echo '</tr>';
                }
              echo '</tbody></table></div>';
            }else{
              //echo $i;
              echo '<div class="text-center"><b>No forms submited at the moment</b></div>';
            }
            echo '</div>';
            $start++;
          }
        ?>
      </div>
    </div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <!--<script src="assets/js/mine.js"></script>-->

    <!-- Fancybox JS -->
    <script type="text/javascript" src="assets/fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script>
    <script type="text/javascript" src="assets/fancybox/source/jquery.fancybox.js?v=2.1.5"></script>
    <script type="text/javascript" src="assets/fancybox/source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>
    <script type="text/javascript" src="assets/fancybox/source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>
    <script type="text/javascript" src="assets/fancybox/source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>
    
    <script type="text/javascript" src="assets/data-tables/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="assets/data-tables/media/js/dataTables.bootstrap.js"></script>

    <!-- Notifications -->
    <script type="text/javascript" src="assets/toast/toastr.min.js"></script>

    <script src="assets/select/select2.js"></script>

    <script type="text/javascript">
      $(document).ready(function() {
        var url = "users_json.php";

        var table = $('#users').DataTable({
          "lengthMenu": [[5,10, 25, 50, -1], [5,10, 25, 50, "All"]],
          "ordering": false,
          "ajax": {
            "url": url,
            "dataSrc": ""
          }
        });
        
        $('.custom').each(function(){
          $id = this.id;
          $($('#'+$id)).DataTable({
            "lengthMenu": [[5,10, 25, 50, -1], [5,10, 25, 50, "All"]],
            "ordering": false
          });
        });

        $("#role").select2({
          placeholder: "Choose Role"
          //allowClear: true
        });

        $(function() {
          $("button#submit_new_user").click(function(){
            $.ajax({
              type: "POST",
              url: "process.php",
              data: $('form#new_user').serialize(),
              success: function(msg){
                        //$("#thanks").html(msg)
                        toastr["success"]("Success", msg+"'s account' has successfully be created");
                        $("#add_new_user").modal('hide');
                        $("#new_user")[0].reset();
                        table.ajax.reload();
                      },

              error: function(){
                      alert("failure");
                    }
            });
          });
        });

        toastr.options = {
          "closeButton": true,
          "debug": false,
          "newestOnTop": false,
          "progressBar": false,
          "positionClass": "toast-top-right",
          "preventDuplicates": true,
          "onclick": null,
          "showDuration": "300",
          "hideDuration": "1000",
          "timeOut": "5000",
          "extendedTimeOut": "1000",
          "showEasing": "swing",
          "hideEasing": "linear",
          "showMethod": "fadeIn",
          "hideMethod": "fadeOut"
        };

        $('.fancybox').fancybox({
          fitToView: false,
          autoSize: false,
          autoDimensions: false,
          //width: "60%",
          height: "100%",
        });

        // Change title type, overlay closing speed
        $(".fancybox-effects-a").fancybox({
          helpers: {
            title : {
              type : 'outside'
            },
            overlay : {
              speedOut : 0
            }
          }
        });

        // Disable opening and closing animations, change title type
        $(".fancybox-effects-b").fancybox({
          openEffect  : 'none',
          closeEffect : 'none',

          helpers : {
            title : {
              type : 'over'
            }
          }
        });

        // Set custom style, close if clicked, change title type and overlay color
        $(".fancybox-effects-c").fancybox({
          wrapCSS    : 'fancybox-custom',
          closeClick : true,

          openEffect : 'none',

          helpers : {
            title : {
              type : 'inside'
            },
            overlay : {
              css : {
                'background' : 'rgba(238,238,238,0.85)'
              }
            }
          }
        });

        // Remove padding, set opening and closing animations, close if clicked and disable overlay
        $(".fancybox-effects-d").fancybox({
          padding: 0,

          openEffect : 'elastic',
          openSpeed  : 150,

          closeEffect : 'elastic',
          closeSpeed  : 150,

          closeClick : true,

          helpers : {
            overlay : null
          }
        });

        /*
         *  Button helper. Disable animations, hide close button, change title type and content
         */

        $('.fancybox-buttons').fancybox({
          openEffect  : 'none',
          closeEffect : 'none',

          prevEffect : 'none',
          nextEffect : 'none',

          closeBtn  : false,

          helpers : {
            title : {
              type : 'inside'
            },
            buttons : {}
          },

          afterLoad : function() {
            this.title = 'Image ' + (this.index + 1) + ' of ' + this.group.length + (this.title ? ' - ' + this.title : '');
          }
        });


        /*
         *  Thumbnail helper. Disable animations, hide close button, arrows and slide to next gallery item if clicked
         */

        $('.fancybox-thumbs').fancybox({
          prevEffect : 'none',
          nextEffect : 'none',

          closeBtn  : false,
          arrows    : false,
          nextClick : true,

          helpers : {
            thumbs : {
              width  : 50,
              height : 50
            }
          }
        });

        /*
         *  Media helper. Group items, disable animations, hide arrows, enable media and button helpers.
        */
        $('.fancybox-media')
          .attr('rel', 'media-gallery')
          .fancybox({
            openEffect : 'none',
            closeEffect : 'none',
            prevEffect : 'none',
            nextEffect : 'none',

            arrows : false,
            helpers : {
              media : {},
              buttons : {}
            }
          });

        /*
         *  Open manually
         */

        $("#fancybox-manual-a").click(function() {
          $.fancybox.open('1_b.jpg');
        });

        $("#fancybox-manual-b").click(function() {
          $.fancybox.open({
            href : 'iframe.html',
            type : 'iframe',
            padding : 5
          });
        });

        $("#fancybox-manual-c").click(function() {
          $.fancybox.open([
            {
              href : '1_b.jpg',
              title : 'My title'
            }, {
              href : '2_b.jpg',
              title : '2nd title'
            }, {
              href : '3_b.jpg'
            }
          ], {
            helpers : {
              thumbs : {
                width: 75,
                height: 50
              }
            }
          });
        });
      });
    </script>
  </body>
</html>