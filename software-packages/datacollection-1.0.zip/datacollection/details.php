<?php
/* 
 * Copyright (C) 2017 Village-Power AG
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU Lesser General Public License for more details.
 *
 *     You should have received a copy of the GNU Lesser General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
  include('check.php'); 
  if(isset($_GET['id'])){
    $meta_id =  $_GET['id'];
    $table_prefix = $_GET['form'];
    $link = "delete.php?id=".$meta_id."&form=".$table_prefix;
  }
?>
<?php
  $role = $_SESSION['user_role'];
?>
	<html>
	<head>
    <title></title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    
    <link rel="stylesheet" href="assets/data-tables/media/css/dataTables.bootstrap.css" />

    <!--<link rel="stylesheet" type="text/css" href="assets/css/mine.css">-->
    <link rel="stylesheet" href="assets/fancybox/source/jquery.fancybox.css?v=2.1.5" type="text/css" media="screen" />
    <!-- Add Button helper (this is optional) -->
    <link rel="stylesheet" type="text/css" href="assets/fancybox/source/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
    <!-- Add Thumbnail helper (this is optional) -->
    <link rel="stylesheet" type="text/css" href="assets/fancybox/source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" />
    <!--<link rel="stylesheet" type="text/css" href="assets/css/mine.css">-->

    <style type="text/css">
      .table-responsive {
        overflow: auto;
      }
      tbody td:nth-child(2), thead th{
        text-align: center;
      }
    </style>
	</head>
	<body>
		<div class="container table-responsive">
      <div id="loading" class="text-center">
        <i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>
        <span class="sr-only">Loading...</span>
        <p>Please wait a bit as the data is being loaded...</p>
      </div>
      <form enctype="multipart/form-data" method="POST" action="<?php echo url; ?>">
        <fieldset>
          <table id="example" class="table table-condensed table-bordered" cellspacing="0" width="100%">
          </table>
        </fieldset>
        <hr>
        <div class="col-sm-4 col-sm-offset-5 col-lg-10 col-lg-offset-2">
          <button id="<?php echo $table_prefix; ?>" name="<?php echo $table_prefix; ?>" value="SUBMIT" type="submit" class="text-center btn btn-primary"><i class="fa fa-check"></i>&nbsp Submit</button>
  		    <?php if ($role=='admin') {?><a href="<?php echo $link; ?>" id="delete_link"></a><?php } ?>
        </div>
      </form>

      <!-- Creates the bootstrap modal where the image will appear -->
      <div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">              
            <div class="modal-body">
              <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
              <img src="" class="imagepreview" style="width: 100%;" >
            </div>
          </div>
        </div>
      </div>
    
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/data-tables/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="assets/data-tables/media/js/dataTables.bootstrap.js"></script>

    <script type="text/javascript" src="assets/fancybox/source/jquery.fancybox.pack.js?v=2.1.5"></script>
    <!-- Add Button helper (this is optional) -->
    <script type="text/javascript" src="assets/fancybox/source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>
    <!-- Add Thumbnail helper (this is optional) -->
    <script type="text/javascript" src="assets/fancybox/source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>

    <script type="text/javascript">
      $(document).ready(function() {
        var id = '<?php echo $meta_id; ?>';
        var form = '<?php echo $table_prefix; ?>';
        var url = "data.php?id="+id+"&form="+form;

        $.ajax({
          dataType: "json",
          url: url,
          beforeSend: function(){
            $("#loading").show();
            $('#'+form).attr('disabled',true);
          },
          complete: function(){
            $("#loading").hide();
            $('#'+form).attr('disabled',false);
            $("<button id='delete' type='button' class='text-center btn btn-danger'><i class='fa fa-trash'></i>&nbsp DELETE</button>" ).prependTo( "#delete_link" );
          },
          success: function (json) {
            var columns = [];
            $('#example').dataTable({
              "searching": false,
              "paging":   false,
              "ordering": false,
              "info":     false,
              "processing": true,
              "columns": json.columns,
              "data": json.data
            });

            tableTransform($("#example"));
            $.each(json.extras, function(key,value){
              $("#example").append(value);
            });
          }
        });

        /*$('#example').on("click", '#pop', function(){
          $('.imagepreview').attr('src', $(this).find('img').attr('src'));
          $('#imagemodal').modal('show');
        });*/

        function tableTransform(objTable) {
          objTable.each(function () {
            var $this = $(this);
            var newrows = [];
            $this.find("tbody tr, thead tr").each(function () {
              var i = 0;
              $(this).find("td, th").each(function () {
                i++;
                if (newrows[i] === undefined) {
                  newrows[i] = $("<tr></tr>");
                }
                newrows[i].append($(this));
              });
            });
            $this.find("tr").remove();
            $.each(newrows, function () {
              $this.append(this);
            });
          });
          //switch old th to td
          objTable.find('th').wrapInner('<td />').contents().unwrap();
          //move first tr into thead
          var thead = objTable.find("thead");
          var thRows = objTable.find("tr:first");
          var copy = thRows.clone(true).appendTo("thead");
          thRows.remove();
          //switch td in thead into th
          objTable.find('thead tr td').wrapInner('<th />').contents().unwrap();
          //add tr back into tfoot
          objTable.find('tfoot').append("<tr></tr>");
          //add tds into tfoot
          objTable.find('tbody tr:first td').each(function () {
            objTable.find('tfoot tr').append("<td>&nbsp;</td>");
          });
          return false;
        }
        //tableTransform($("#example"));
      });
    </script>
    <script type="text/javascript">
      $('.fancybox-buttons').fancybox({
        openEffect  : 'none',
        closeEffect : 'none',

        prevEffect : 'none',
        nextEffect : 'none',

        closeBtn  : false,

        helpers : {
          title : {
            type : 'inside'
          },
          buttons : {}
        },

        afterLoad : function() {
          //this.title = 'Page ' + (this.index + 1) + ' of ' + this.group.length + (this.title ? ' - ' + this.title : '');
        }
      });
    </script>
	</body>
</html