<?php
/* 
 * Copyright (C) 2017 Village-Power AG
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU Lesser General Public License for more details.
 *
 *     You should have received a copy of the GNU Lesser General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
  ini_set('display_errors',1);

  require_once("defines.php");
  require_once('functions.php');
  include('check.php'); 
  //$api = new _un();
?>
<?php
  $query=$uncdf->query("SELECT name,phone,email,role FROM users");
  
  $data = array();
  $i=0;
  while($row=$query->fetch_assoc()) {
    $i++;
    $table_stuff = array();
    array_push($table_stuff, $i);
    array_push($table_stuff, $row['name']);
    array_push($table_stuff, $row['phone']);
    array_push($table_stuff, $row['email']);
    switch ($row['role']) {
      case 'admin':
        $role = "Admin";
        break;
      case 'sales':
        $role = "Sales";
        break;
      case 'technical':
        $role = "Technical";
        break;
      case 'customer_care':
        $role = "Customer Care";
        break;
    }
    array_push($table_stuff, $role);

    array_push($data, $table_stuff);
  }
  echo json_encode($data);
?>