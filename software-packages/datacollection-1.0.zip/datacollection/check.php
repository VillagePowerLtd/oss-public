<?php
/* 
 * Copyright (C) 2017 Village-Power AG
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU Lesser General Public License for more details.
 *
 *     You should have received a copy of the GNU Lesser General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
	require_once("defines.php");
	session_start();
	$user_check=$_SESSION['user_email'];
	 
	$sql = $uncdf->query("SELECT email FROM users WHERE name='$user_check'");
	$row=$sql->fetch_assoc();
	 
	$login_email=$row['email'];
	 
	if(!isset($user_check)){
		session_destroy();
		header("Location: login.php");
	}
?>