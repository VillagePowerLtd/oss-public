<?php
/* 
 * Copyright (C) 2017 Village-Power AG
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU Lesser General Public License for more details.
 *
 *     You should have received a copy of the GNU Lesser General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
	require_once("defines.php");
	
	class _un{
		function __construct() {
	        $this->db = new mysqli(DBHOST, DBUSER, DBPASS, DBNAME);
	    }

		function getStringBetween($str,$from,$to){
		    $sub = substr($str, strpos($str,$from)+strlen($from),strlen($str));
		    return substr($sub,0,strpos($sub,$to));
		}

		function getDatabase(){
			$db_query = $this->db->query("SELECT database() AS the_db");
			$db = $db_query->fetch_assoc();
			$db_name = $db['the_db'];
			return $db_name;
		}

		function strpos_arr($haystack, $needle) {
		    if(!is_array($needle)) $needle = array($needle);
		    foreach($needle as $what) {
		        if(($pos = strpos($haystack, $what))!==false) return $pos;
		    }
		    return false;
		}

		function send_json_new($url,$data){
			$content = json_encode($data);
			$curl = curl_init($url);
			curl_setopt($curl, CURLOPT_HEADER, false);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($curl, CURLOPT_HTTPHEADER,
				array("Content-type: application/json",'Authorization: Basic '. base64_encode(credentials))
			);
			curl_setopt($curl, CURLOPT_POST, true);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
			 
			$result = curl_exec($curl);
			if(is_array($result)){
				$response = json_decode($result);
			}else{
				$response = $result;
			}
			//var_dump($response);
			curl_close($curl);
			return $response;
		}

		function send_new_sms($sender,$reciepient,$message){
			$host = 'https://api.infobip.com/sms/1/text/single';
			$feed = $this->send_json_new($host,array("from"=>$sender,"to"=>$reciepient,"text"=>$message));
			
			return $feed;
		}

		public function send_email_notification($email,$message){
       	 	require_once'assets/PHPMailer/PHPMailerAutoload.php';
			require_once("assets/PHPMailer/class.phpmailer.php");//PHPMailer Object
			$mail = new PHPMailer;
			$mail->isSMTP();
			$mail->Host = 'smtp.udag.de';
			$mail->SMTPSecure = 'tls';
			$mail->Port = 587;
			$mail->SMTPAuth = true;
			$mail->Username= host;
			$mail->Password = password;

			//From email address and name
			$mail->From = host;
			$mail->FromName = "ODK Verification Portal";

			$mail->addAddress($email); //Recipient name is optional
			$mail->Subject = "User Registration details";
			$mail->Body = $message;
			//$mail->addAttachment($path);
			//$mail->AddCC('joshua@village-power.ug');

			if(!$mail->send()) {
				echo "Mailer Error: " . $mail->ErrorInfo;
			}else{
				//echo "Password reset link has been sent to your e-mail.";
			}
      	}

		function random_password($length) {
		    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+;:,.?";
		    $password = substr( str_shuffle( $chars ), 0, $length );
		    return $password;
		}
	}