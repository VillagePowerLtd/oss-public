// Shorthand for $( document ).ready()
$(function() {
   
   $( "#btn-edit-validate-account" ).click(function() {

   $( "#edit-block" ).removeClass("hidden");  
   $( "#btn-edit-validate-account" ).addClass("hidden");
   $( "#mobile" ).attr("readonly","true")

});

   $( "#btn-topup-validate-account" ).click(function() {

   $( "#topup-block" ).removeClass("hidden");  
   $( "#btn-topup-validate-account" ).addClass("hidden");
   $( "#mobile" ).attr("readonly","true")

});

});