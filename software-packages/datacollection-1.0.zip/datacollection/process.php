<?php
/* 
 * Copyright (C) 2017 Village-Power AG
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU Lesser General Public License for more details.
 *
 *     You should have received a copy of the GNU Lesser General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
	ini_set('display_errors',1);

	require_once("defines.php");
	require_once('functions.php');
	include('check.php'); 
	$api = new _un();

	$role = $_SESSION['user_role'];
?>
<?php
	if (isset($_POST['name'])) {
		$name = strip_tags($_POST['name']);
		$email = strip_tags($_POST['email']);
		$phone = strip_tags($_POST['phone']);
		//$password = strip_tags($_POST['password']);
		$role = strip_tags($_POST['role']);
		$sender = 'ODK';

		//Automatically generate password
		$password = $api->random_password(8);
		$hashed_password = password_hash($password, PASSWORD_DEFAULT);
		echo $name;

		$message = "Dear ".$name.", Please find your account details below.\n\nLink: http://104.236.194.94/verify/ \nEmail: ".$email."\nPassword:  ".$password."\n\nCheers.";
		$api->send_email_notification($email,$message);
		$api->send_new_sms($sender,$phone,$message);
		$uncdf->query("INSERT INTO users(`name`,`password`,`phone`,`email`,`role`) VALUES('".$name."','".$hashed_password."','".$phone."','".$email."','".$role."')");
	}
?>