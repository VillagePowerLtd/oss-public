<?php
/* 
 * Copyright (C) 2017 Village-Power AG
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU Lesser General Public License for more details.
 *
 *     You should have received a copy of the GNU Lesser General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
	ini_set('display_errors',1);

	require_once("defines.php");
	require_once('functions.php'); 
	include('check.php'); 
	$api = new _un();
?>
<?php
	if(isset($_GET['id'])){
	    $meta_id =  $_GET['id'];
	    $table_prefix = $_GET['form'];

	    //Check if there are any tables with images
		$form_tables = $uncdf->query("SHOW TABLES LIKE '".$table_prefix."%'");
		if (mysqli_num_rows($form_tables) > 0) {
	    	while($table_row = $form_tables->fetch_assoc()) {
	    		foreach ($table_row as $row) {
					if (strpos(strtoupper($row), 'CORE') !== false) {
						$check_table = $uncdf->query("SELECT * FROM ".$row." WHERE _URI = '".$meta_id."'");
						if (mysqli_num_rows($check_table) > 0) {
							$check_table = $uncdf->query("DELETE FROM ".$row." WHERE _URI = '".$meta_id."'");
						}
					}else{
						$check_table = $uncdf->query("SELECT * FROM ".$row." WHERE _TOP_LEVEL_AURI = '".$meta_id."'");
						if (mysqli_num_rows($check_table) > 0) {
							//echo "SELECT * FROM ".$row." WHERE _TOP_LEVEL_AURI = '".$meta_id."'<br>";
							$check_table = $uncdf->query("DELETE FROM ".$row." WHERE _TOP_LEVEL_AURI = '".$meta_id."'");
						}
					}
	    		}
	    	}
	    }
	}
	echo "<script type='text/javascript'>window.top.location.reload();</script>";
?>