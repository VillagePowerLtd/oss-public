<?php
/* 
 * Copyright (C) 2017 Village-Power AG
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU Lesser General Public License for more details.
 *
 *     You should have received a copy of the GNU Lesser General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
  ini_set('display_errors',1);

  require_once("defines.php");
  require_once("forms.php");
  require_once('functions.php'); 
  include('check.php'); 
  $api = new _un();
?>
<?php
  if(isset($_GET['id'])){
    $meta_id =  $_GET['id'];
    $table_prefix = $_GET['form'];

    $columns = array();

    //To know the columns to be selected
    $table_head_num=$uncdf->query("DESCRIBE ". $table_prefix."_CORE");
    
    while($table_heads=$table_head_num->fetch_assoc()) {    
      if (stripos($table_heads['Field'], exclude) === false) {
        if (substr($table_heads['Field'], 0, 1) != "_") {
          $columns[] = $table_heads['Field'];
        }
        if (substr($table_heads['Field'], 0, 16) == "_SUBMISSION_DATE") {
          $columns[] = $table_heads['Field'];
        }
      }
    }

    $column_names = implode(", ", $columns);
    $column_join = "";
    $selected_columns = "";

    $join_array = array();
    $column_array = array();

    //Check if there are any tables with images
    $table_image=$uncdf->query("SHOW TABLES LIKE '".$table_prefix."%BLB'");

    if (mysqli_num_rows($table_image) > 0) {
      $db = $api->getDatabase();
      $blb = 'blb';
      $x = 0;
      while($table_heads=$table_image->fetch_assoc()) {
        $x++;
        $raw_image_column = $table_heads["Tables_in_$db ($table_prefix%BLB)"];
        $alias = "column_".$x;
        $selected_column = $raw_image_column.".VALUE AS ".$alias;
        $to_join = "LEFT JOIN ".$raw_image_column." ON ".$table_prefix."_CORE.META_INSTANCE_ID = ".$raw_image_column."._TOP_LEVEL_AURI";
        
        array_push($join_array, $to_join);
        array_push($column_array, $selected_column);
      }
      //$fields_joins = implode(',', $column_array);
      //$fields_join = $fields_joins.",";
    }
    //End of check for images

    //Check for other tables other than images
    $db = $api->getDatabase();
    $table_others=$uncdf->query("SHOW TABLES WHERE `Tables_in_$db` LIKE '".$table_prefix."_%' AND NOT `Tables_in_$db` LIKE '".$table_prefix."_%BLB' AND NOT `Tables_in_$db` LIKE '".$table_prefix."_%BN' AND NOT `Tables_in_$db` LIKE '".$table_prefix."_%REF' AND NOT `Tables_in_$db` LIKE '".$table_prefix."_%CORE'");

    if (mysqli_num_rows($table_others) > 0) {
      $db = $api->getDatabase();
      $x = 0;
      while($table_other=$table_others->fetch_assoc()) {
        $x++;
        $other_table = $table_other["Tables_in_$db"];
        $alias = "others_".$x;
        $selected_column = "ox.".$alias;
        $to_join = "LEFT JOIN (SELECT _TOP_LEVEL_AURI,GROUP_CONCAT(value SEPARATOR ', ') AS '".$alias."' FROM ".$other_table." WHERE 1 GROUP BY _TOP_LEVEL_AURI) ox ON ".$table_prefix."_CORE.META_INSTANCE_ID = ox._TOP_LEVEL_AURI";

        array_push($join_array, $to_join);
        array_push($column_array, $selected_column);
      }
    }

    if (mysqli_num_rows($table_image) > 0 || mysqli_num_rows($table_others) > 0) {
      $fields_joins = implode(',', $column_array);
      $fields_join = $fields_joins.",";
    }
    //End of check for others

    $column_join = implode(" ", $join_array);
    
    //Selecting table headers
    $table_head=$uncdf->query("DESCRIBE ". $table_prefix."_CORE");
		//Selecting table contents
    $table_content=$uncdf->query("SELECT ".$fields_join."".$table_prefix."_CORE.".$column_names." FROM ". $table_prefix."_CORE ". $column_join." WHERE META_INSTANCE_ID ='".$meta_id."'");

    //echo "SELECT ".$fields_join."".$table_prefix."_CORE.".$column_names." FROM ". $table_prefix."_CORE ". $column_join." WHERE META_INSTANCE_ID ='".$meta_id."'"."<br>";

    if (mysqli_num_rows($table_content) > 0) {
      $table_titles = array();
      $number['title'] = 'Label';
		  array_push($table_titles, $number);
                        
      //Check whether there are image rows
      $table_image=$uncdf->query("SHOW TABLES LIKE '".$table_prefix."%BLB'");
      if (mysqli_num_rows($table_image) > 0) {

        $db = $api->getDatabase();
        
        while($table_heads=$table_image->fetch_assoc()) {
          $raw_image_columns = $table_heads["Tables_in_$db ($table_prefix%BLB)"];
          $blb = strtoupper($raw_image_columns) == $raw_image_columns ? 'BLB' : 'blb';
          $image_col = $api->getStringBetween($raw_image_columns,$table_prefix.'_','_'.$blb);
          $image_columns['title'] = strtoupper(str_replace('_',' ',$image_col));
          array_push($table_titles, $image_columns);
        }
      }

      //Check whether there are other columns
      $table_others=$uncdf->query("SHOW TABLES WHERE `Tables_in_$db` LIKE '".$table_prefix."_%' AND NOT `Tables_in_$db` LIKE '".$table_prefix."_%BLB' AND NOT `Tables_in_$db` LIKE '".$table_prefix."_%BN' AND NOT `Tables_in_$db` LIKE '".$table_prefix."_%REF' AND NOT `Tables_in_$db` LIKE '".$table_prefix."_%CORE'");
      if (mysqli_num_rows($table_others) > 0) {
        $db = $api->getDatabase();
        
        while($table_other=$table_others->fetch_assoc()) {
          $other_table = str_replace(strtolower($table_prefix), '', $table_other["Tables_in_$db"]);

          $other_columns['title'] = strtoupper(str_replace('_',' ',$other_table));
          array_push($table_titles, $other_columns);
        }
      }

      while($table_headers=$table_head->fetch_assoc()) {
        if (stripos($table_headers['Field'], 'SUB_COUNTY_') === false) {
          if (substr($table_headers['Field'], 0, 1) != "_") {
            $hr['title'] = str_replace('_',' ',$table_headers['Field']);
            array_push($table_titles, $hr);
          }
          
          if ($table_headers['Field'] == "_SUBMISSION_DATE") {
            $hr['title'] = str_replace('_',' ',$table_headers['Field']);
            array_push($table_titles, $hr);
          }
        }
      }

      //Add Extra Info for Validator
      foreach (add_field as $value) {
        if (strtoupper($value[0]) == $table_prefix) {
          $cust['title'] = $value[1];
          array_push($table_titles, $cust);
        }
      }
      
      $verifier['title'] = "To be verified By";
      array_push($table_titles, $verifier);

      $table_stuff = array();
      $table_extras = array();
      while($table_rows=$table_content->fetch_assoc()) {
        array_push($table_stuff, "Content");
        $string = "column_";
        
        $i=0;

        foreach ($table_rows as $key=>$value) {
          $i++;
          $word = "column_";
          if (strrpos($key, $word) !== FALSE) {
            if ($value != NULL) {
              $data = "data:image/jpeg;base64,".base64_encode($value);
              
              array_push($table_stuff, '<a id="pop" class="fancybox-buttons" data-fancybox-group="buttons'.$i.'" href="data:image/jpeg;base64,'.base64_encode($value).'"><img src="data:image/jpeg;base64,'.base64_encode($value).'" name="field_'.$i.'" id="field_'.$i.'" width="180" height="180" alt="Image preview" class="thumbnail" style="display: inline;"></a><input type="hidden" name="field_'.$i.'" id="field_'.$i.'" value="'.base64_encode($value).'" />');
            }else{
              array_push($table_stuff, '<span name="field_'.$i.'" id="field_'.$i.'">Not Captured</span>');
            }
          }elseif($key == 'USER'){
            array_push($table_stuff, '<input type="text" value="'.str_replace('_', ' ', $value).'" name="field_'.$i.'" id="field_'.$i.'" class="form-control"/>');
          }elseif($key == 'client_id'){
            array_push($table_stuff, '<input type="text" value="'.str_replace('_', ' ', $value).'" name="field_'.$i.'" id="field_'.$i.'" class="form-control" required/>');
          }else{
            array_push($table_stuff, '<input type="text" value="'.ucfirst(str_replace('_', ' ', $value)).'" name="field_'.$i.'" id="field_'.$i.'" class="form-control"/>');
          }
        }

        $i++;

        foreach (add_field as $value) {
          if (strtoupper($value[0]) == $table_prefix) {
            array_push($table_stuff, '<input type='.$value[2].' value="" name="field_'.$i.'" id="field_'.$i.'" class="form-control" required/>');
            $i++;
          }
        }

        /*if ($table_prefix == "TROUBLESHOOTING_VISIT_FORM") {
          array_push($table_stuff, '<input type="text" value="" name="field_'.$i.'" id="field_'.$i.'" class="form-control" required/>');
        }
        */

        array_push($table_stuff, '<input type="text" value="'.$_SESSION['user_name'].'" name="field_'.$i.'" id="field_'.$i.'" class="form-control" readonly />');
        
        //Form and Meta Instance ID
        array_push($table_extras, '<input type="hidden" value="'.$meta_id.'" name="meta_id" id="meta_id"/>');
        array_push($table_extras, '<input type="hidden" value="'.$table_prefix.'" name="form_id" id="form_id"/>');
      }
      
      $all_content = array();
      $new_array = array();
      $extras = array();
      array_push($new_array, $table_stuff);
      array_push($extras, $table_extras);
      $all_content['columns'] = $table_titles;
      $all_content['data'] = $new_array;
      $all_content['extras'] = $extras;
      //var_dump($all_content);
      echo json_encode($all_content);
			}
    }
	?>