<?php
/* 
 * Copyright (C) 2017 Village-Power AG
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU Lesser General Public License for more details.
 *
 *     You should have received a copy of the GNU Lesser General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

	//Forms defined
	define( 'form_1', 'Sales_Contract');
	define( 'form_2', 'Installation_Form');
	define( 'form_3', 'Reposession_Form');
	define( 'form_4', 'Troubleshooting_Visit_Form');
	define( 'form_5', 'Kit_collection_Form');
	define( 'form_6', 'Restructuring_Form');

	//Users defined
	define( 'user_group_1', 'sales');
	define( 'user_group_2', 'technical');
	define( 'user_group_3', 'customer_care');

	//Columns to display - Form 1
	define( 'f1_column_1', 'USER');
	define( 'f1_column_2', 'CUSTOMER_DEMOGRAPHICS_EMPLOYMENT_STATUS');
	define( 'f1_column_3', 'CUSTOMER_DEMOGRAPHICS_PEOPLE_IN_HOUSEHOLD');
	define( 'f1_column_4', 'CUSTOMER_DEMOGRAPHICS_OCCUPATION');
	define( 'f1_column_5', '_SUBMISSION_DATE');

	//Columns to display - Form 2
	define( 'f2_column_1', 'USER');
	define( 'f2_column_2', 'CLIENT_ID');
	define( 'f2_column_3', 'BAR_CODE');
	define( 'f2_column_4', 'INSTALLATION_DATE');
	define( 'f2_column_5', '_SUBMISSION_DATE');


	//Columns to display - Form 3
	define( 'f3_column_1', 'USER');
	define( 'f3_column_2', 'CUSTOMER_ID');
	define( 'f3_column_3', 'BAR_CODE');
	define( 'f3_column_4', 'REPOSESSION_DATE');
	define( 'f3_column_5', '_SUBMISSION_DATE');

	//Columns to display - Form 4
	define( 'f4_column_1', 'USER');
	define( 'f4_column_2', 'CUST_ID');
	define( 'f4_column_3', 'BAR_CODE');
	define( 'f4_column_4', 'VISIT_DATE');
	define( 'f4_column_5', '_SUBMISSION_DATE');

	//Columns to display - Form 5
	define( 'f5_column_1', 'USER');
	define( 'f5_column_2', 'CUST_ID');
	define( 'f5_column_3', 'BAR_CODE');
	define( 'f5_column_4', 'COLLECTION_DATE');
	define( 'f5_column_5', '_SUBMISSION_DATE');

	//Columns to display - Form 6
	define( 'f6_column_1', 'USER');
	define( 'f6_column_2', 'CLIENT_ID');
	define( 'f6_column_3', 'BAR_CODE');
	define( 'f6_column_4', 'RESTRUCTURE_DATE');
	define( 'f6_column_5', '_SUBMISSION_DATE');

	//To include at bottom of form view (details.php)
	$field = array(form_1, 'Customer ID<br><i>(To be input by validator after new account generated in the VP database)</i>', 'number');
	$field_2 = array(form_1, 'Date of Birth', 'date');
	$field_3 = array(form_4, 'TRQ ID<br><i>(To be input by validator from the TRQ ID generated in the VP database)</i>','number');
	$field_4 = array(form_4, 'Joshua</i>','number');

	$fields = array($field,$field_2,$field_3,$field_4);
	define('add_field',$fields);

	/**Repeatitive not include (Mostly repeats from when referring to media in radio ceck boxes) under data.php **/
	define('exclude', 'SUB_COUNTY_');
