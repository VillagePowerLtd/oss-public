-- MySQL Workbench Synchronization
-- Generated: 2017-06-03 04:02
-- Model: New Model
-- Version: 1.0
-- Project: Name of the project
-- Author: isaac t

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE TABLE IF NOT EXISTS `market`.`Sales_Summary` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `upload_date` DATETIME NULL DEFAULT NULL,
  `systems_sold` INT(11) NULL DEFAULT NULL,
  `defaulted_loans` INT(11) NULL DEFAULT NULL,
  `quality_verified_systems_sold` INT(11) NULL DEFAULT NULL,
  `installed_capacity` INT(11) NULL DEFAULT NULL,
  `sold_on_payg` INT(11) NULL DEFAULT NULL,
  `sold_on_commercial` INT(11) NULL DEFAULT NULL,
  `portfolio_at_risk` INT(11) NULL DEFAULT NULL,
  `reposessed_systems` INT(11) NULL DEFAULT NULL,
  `last_updated` DATETIME NULL DEFAULT NULL,
  `company_id` INT(11) NOT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Sales_Summary_company1_idx` (`company_id` ASC),
  CONSTRAINT `fk_Sales_Summary_company1`
    FOREIGN KEY (`company_id`)
    REFERENCES `market`.`company` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`company` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(145) NULL DEFAULT NULL,
  `Address` VARCHAR(45) NULL DEFAULT NULL,
  `Phone` VARCHAR(45) NULL DEFAULT NULL,
  `Email` VARCHAR(45) NULL DEFAULT NULL,
  `Postal_Address` VARCHAR(45) NULL DEFAULT NULL,
  `last_updated` DATETIME NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `contact` VARCHAR(145) NULL DEFAULT NULL,
  `companycol` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 10
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`country` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `country_name` VARCHAR(145) NULL DEFAULT NULL,
  `country_code` VARCHAR(45) NULL DEFAULT NULL,
  `country_short_name` VARCHAR(45) NULL DEFAULT NULL,
  `latitude` MEDIUMTEXT NULL DEFAULT NULL,
  `longitude` MEDIUMTEXT NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`country_summary` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `country_id` INT(11) NULL DEFAULT NULL,
  `systems_sold` INT(11) NULL DEFAULT NULL,
  `quality_verified` INT(11) NULL DEFAULT NULL,
  `installed_capacity` INT(11) NULL DEFAULT NULL,
  `systems_on_paygo` INT(11) NULL DEFAULT NULL,
  `par30` DOUBLE NULL DEFAULT NULL,
  `default_rate` DOUBLE NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`country_system_sold` (
  `id` INT(11) NOT NULL,
  `capacity_installed_number` INT(11) NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `default_rate` DOUBLE NULL DEFAULT NULL,
  `defaulted` INT(11) NULL DEFAULT NULL,
  `PAR_amount` DOUBLE NULL DEFAULT NULL,
  `PAR_number` DOUBLE NULL DEFAULT NULL,
  `quality_verified_number` INT(11) NULL DEFAULT NULL,
  `systems_on_pay_go_amount` DOUBLE NULL DEFAULT NULL,
  `systems_on_pay_go_number` INT(11) NULL DEFAULT NULL,
  `systems_sold_amount` DOUBLE NULL DEFAULT NULL,
  `systems_sold_number` INT(11) NULL DEFAULT NULL,
  `county_id` INT(11) NOT NULL,
  `displayable` TINYINT(1) NULL DEFAULT 0,
  `flag` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_hbygga30rrcmm820hpuefnkkd` (`county_id` ASC),
  CONSTRAINT `FK_hbygga30rrcmm820hpuefnkkd`
    FOREIGN KEY (`county_id`)
    REFERENCES `market`.`county` (`id`),
  CONSTRAINT `FK_jlv6txnwnqiwq1ij5jh7t2uhu`
    FOREIGN KEY (`id`)
    REFERENCES `market`.`county` (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`county` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(45) NULL DEFAULT NULL,
  `county_name` VARCHAR(145) NULL DEFAULT NULL,
  `latitude` DOUBLE NULL DEFAULT NULL,
  `longitude` DOUBLE NULL DEFAULT NULL,
  `last_updated` DATETIME NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `district_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_country_district1_idx` (`district_id` ASC),
  CONSTRAINT `fk_country_district1`
    FOREIGN KEY (`district_id`)
    REFERENCES `market`.`district` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`county_summary` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `district_id` INT(11) NULL DEFAULT NULL,
  `systems_sold` INT(11) NULL DEFAULT NULL,
  `quality_verified` INT(11) NULL DEFAULT NULL,
  `installed_capacity` INT(11) NULL DEFAULT NULL,
  `systems_on_paygo` INT(11) NULL DEFAULT NULL,
  `par30` DOUBLE NULL DEFAULT NULL,
  `default_rate` DOUBLE NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`county_system_sold` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `systems_sold_number` INT(11) NULL DEFAULT NULL,
  `system_sold_amount` DOUBLE NULL DEFAULT NULL,
  `qulaity_verified_number` INT(11) NULL DEFAULT NULL,
  `capacity_installed_number` INT(11) NULL DEFAULT NULL,
  `systems_on_pay_go_amount` DOUBLE NULL DEFAULT NULL,
  `PAR_number` DOUBLE NULL DEFAULT NULL,
  `PAR_amount` INT(11) NULL DEFAULT NULL,
  `systems_on_pay_go_number` INT(11) NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `default_rate` DOUBLE NULL DEFAULT '0',
  `defaulted` INT(11) NULL DEFAULT NULL,
  `county_id` INT(11) NOT NULL,
  `displayable` VARCHAR(45) NULL DEFAULT 0,
  `flagPAR` VARCHAR(45) NULL DEFAULT NULL,
  `displayableVerified` VARCHAR(45) NULL DEFAULT NULL,
  `displayablePAYG` VARCHAR(45) NULL DEFAULT NULL,
  `displayableSales` VARCHAR(45) NULL DEFAULT NULL,
  `flagDefaulted` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_districts_system_sold_copy1_county1_idx` (`county_id` ASC),
  CONSTRAINT `fk_districts_system_sold_copy1_county1`
    FOREIGN KEY (`county_id`)
    REFERENCES `market`.`county` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`device_supported` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(45) NULL DEFAULT NULL,
  `description` VARCHAR(245) NULL DEFAULT NULL,
  `devices_name` VARCHAR(45) NULL DEFAULT NULL,
  `last_updated` DATETIME NULL DEFAULT NULL,
  `company_id` INT(11) NOT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `master` TINYINT(1) NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  INDEX `fk_device_supported_company1_idx` (`company_id` ASC),
  CONSTRAINT `fk_device_supported_company1`
    FOREIGN KEY (`company_id`)
    REFERENCES `market`.`company` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 12
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`district` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `district_name` VARCHAR(145) NULL DEFAULT NULL,
  `latitude` MEDIUMTEXT NULL DEFAULT NULL,
  `longitude` MEDIUMTEXT NULL DEFAULT NULL,
  `last_updated` DATETIME NULL DEFAULT NULL,
  `code` VARCHAR(45) NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `string_cordinate` VARCHAR(145) NULL DEFAULT NULL,
  `country_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_district_country1_idx` (`country_id` ASC),
  CONSTRAINT `fk_district_country1`
    FOREIGN KEY (`country_id`)
    REFERENCES `market`.`country` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 117
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`districts_system_sold` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `systems_sold_number` INT(11) NULL DEFAULT NULL,
  `system_sold_amount` DOUBLE NULL DEFAULT NULL,
  `qulaity_verified_number` INT(11) NULL DEFAULT NULL,
  `capacity_installed_number` INT(11) NULL DEFAULT NULL,
  `systems_on_pay_go_amount` DOUBLE NULL DEFAULT NULL,
  `PAR_number` DOUBLE NULL DEFAULT NULL,
  `PAR_amount` INT(11) NULL DEFAULT NULL,
  `systems_on_pay_go_number` INT(11) NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `default_rate` DOUBLE NULL DEFAULT '0',
  `defaulted` INT(11) NULL DEFAULT NULL,
  `district_id` INT(11) NOT NULL,
  `displayable` VARCHAR(45) NULL DEFAULT 0,
  `flagPAR` VARCHAR(45) NULL DEFAULT NULL,
  `displayableVerified` VARCHAR(45) NULL DEFAULT NULL,
  `displayablePAYG` VARCHAR(45) NULL DEFAULT NULL,
  `displayableSales` VARCHAR(45) NULL DEFAULT NULL,
  `flagDefaulted` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_districts_system_sold_district1_idx` (`district_id` ASC),
  CONSTRAINT `fk_districts_system_sold_district1`
    FOREIGN KEY (`district_id`)
    REFERENCES `market`.`district` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 124
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`loan` (
  `id` INT(11) NOT NULL,
  `original_outstanding_balance` DOUBLE NULL DEFAULT NULL,
  `current_outstanding_balance` DOUBLE NULL DEFAULT NULL,
  `days_overdue` INT(11) NULL DEFAULT NULL,
  `total_days_overdue` INT(11) NULL DEFAULT NULL,
  `location` VARCHAR(145) NULL DEFAULT NULL,
  `model` VARCHAR(45) NULL DEFAULT NULL,
  `installed` TINYINT(1) NULL DEFAULT NULL,
  `status` VARCHAR(45) NULL DEFAULT NULL,
  `type_of_loan` VARCHAR(145) NULL DEFAULT NULL,
  `last_updated` DATETIME NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `sales_mode` VARCHAR(45) NULL DEFAULT NULL,
  `district` VARCHAR(145) NULL DEFAULT NULL,
  `country` VARCHAR(245) NULL DEFAULT NULL,
  `county` VARCHAR(145) NULL DEFAULT NULL,
  `sub_county` VARCHAR(145) NULL DEFAULT NULL,
  `parish` VARCHAR(145) NULL DEFAULT NULL,
  `village` VARCHAR(145) NULL DEFAULT NULL,
  `next_payment_date` DATETIME NULL DEFAULT NULL,
  `company_id` INT(11) NULL DEFAULT NULL,
  `defaulted` VARCHAR(145) NULL DEFAULT NULL,
  `par` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`parish` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `parish_name` VARCHAR(145) NULL DEFAULT NULL,
  `latitude` DOUBLE NULL DEFAULT NULL,
  `longitude` DOUBLE NULL DEFAULT NULL,
  `last_updated` DATETIME NULL DEFAULT NULL,
  `sub_county_id` INT(11) NOT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_parish_sub_county1_idx` (`sub_county_id` ASC),
  CONSTRAINT `fk_parish_sub_county1`
    FOREIGN KEY (`sub_county_id`)
    REFERENCES `market`.`sub_county` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`role` (
  `roleId` INT(11) NOT NULL AUTO_INCREMENT,
  `creation` DATETIME NULL DEFAULT NULL,
  `description` VARCHAR(255) NULL DEFAULT NULL,
  `enabled` BIT(1) NULL DEFAULT NULL,
  `name` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`roleId`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`specification` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `model` VARCHAR(45) NULL DEFAULT NULL,
  `quality_verified` TINYINT(1) NULL DEFAULT NULL,
  `Wp` INT(11) NULL DEFAULT NULL,
  `max_power_output` DOUBLE NULL DEFAULT NULL,
  `device_supported` INT(11) NULL DEFAULT NULL,
  `last_updated` DATETIME NULL DEFAULT NULL,
  `company_id` INT(11) NOT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `quantity` INT(11) NULL DEFAULT NULL,
  `current` VARCHAR(145) NULL DEFAULT NULL,
  `installed` VARCHAR(45) NULL DEFAULT 'NO',
  PRIMARY KEY (`id`),
  INDEX `fk_specification_company1_idx` (`company_id` ASC),
  CONSTRAINT `fk_specification_company1`
    FOREIGN KEY (`company_id`)
    REFERENCES `market`.`company` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 13
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`specification_device` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `date_created` DATETIME NULL DEFAULT NULL,
  `date_updated` DATETIME NULL DEFAULT NULL,
  `quantity` INT(11) NULL DEFAULT NULL,
  `specification` INT(11) NOT NULL,
  `device_supported_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_specification_device_specification1_idx` (`specification` ASC),
  INDEX `fk_specification_device_device_supported1_idx` (`device_supported_id` ASC),
  CONSTRAINT `fk_specification_device_device_supported1`
    FOREIGN KEY (`device_supported_id`)
    REFERENCES `market`.`device_supported` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_specification_device_specification1`
    FOREIGN KEY (`specification`)
    REFERENCES `market`.`specification` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 62
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`sub_county` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `sub_county_code` VARCHAR(45) NULL DEFAULT NULL,
  `sub_county_name` VARCHAR(145) NULL DEFAULT NULL,
  `latitude` DOUBLE NULL DEFAULT NULL,
  `longitude` DOUBLE NULL DEFAULT NULL,
  `last_updated` DATETIME NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `county_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_sub_county_county1_idx` (`county_id` ASC),
  CONSTRAINT `fk_sub_county_county1`
    FOREIGN KEY (`county_id`)
    REFERENCES `market`.`county` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`sub_county_summary` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `county_id` INT(11) NULL DEFAULT NULL,
  `systems_sold` INT(11) NULL DEFAULT NULL,
  `quality_verified` INT(11) NULL DEFAULT NULL,
  `installed_capacity` INT(11) NULL DEFAULT NULL,
  `systems_on_paygo` INT(11) NULL DEFAULT NULL,
  `par30` DOUBLE NULL DEFAULT NULL,
  `default_rate` DOUBLE NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`sub_county_system_sold` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `systems_sold_number` INT(11) NULL DEFAULT NULL,
  `system_sold_amount` DOUBLE NULL DEFAULT NULL,
  `qulaity_verified_number` INT(11) NULL DEFAULT NULL,
  `capacity_installed_number` INT(11) NULL DEFAULT NULL,
  `systems_on_pay_go_amount` DOUBLE NULL DEFAULT NULL,
  `PAR_number` DOUBLE NULL DEFAULT NULL,
  `PAR_amount` INT(11) NULL DEFAULT NULL,
  `systems_on_pay_go_number` INT(11) NULL DEFAULT NULL,
  `date_created` DATETIME NULL DEFAULT NULL,
  `default_rate` DOUBLE NULL DEFAULT '0',
  `defaulted` INT(11) NULL DEFAULT NULL,
  `sub_county_id` INT(11) NOT NULL,
  `displayable` VARCHAR(45) NULL DEFAULT 0,
  `flagPAR` VARCHAR(45) NULL DEFAULT NULL,
  `displayableVerified` VARCHAR(45) NULL DEFAULT NULL,
  `displayablePAYG` VARCHAR(45) NULL DEFAULT NULL,
  `displayableSales` VARCHAR(45) NULL DEFAULT NULL,
  `flagDefaulted` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_districts_system_sold_copy1_sub_county1_idx` (`sub_county_id` ASC),
  CONSTRAINT `fk_districts_system_sold_copy1_sub_county1`
    FOREIGN KEY (`sub_county_id`)
    REFERENCES `market`.`sub_county` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `market`.`user_roles` (
  `user_rolesId` INT(11) NOT NULL AUTO_INCREMENT,
  `userId` INT(11) NOT NULL,
  `roleId` INT(11) NULL DEFAULT NULL,
  `role_roleId` INT(11) NOT NULL,
  PRIMARY KEY (`user_rolesId`),
  INDEX `fk_user_roles_users1_idx` (`userId` ASC),
  INDEX `fk_user_roles_role1_idx` (`role_roleId` ASC),
  CONSTRAINT `fk_user_roles_users1`
    FOREIGN KEY (`userId`)
    REFERENCES `market`.`users` (`userId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_user_roles_role1`
    FOREIGN KEY (`role_roleId`)
    REFERENCES `market`.`role` (`roleId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 25
DEFAULT CHARACTER SET = latin1;

CREATE TABLE IF NOT EXISTS `market`.`users` (
  `userId` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(255) NULL DEFAULT NULL,
  `enabled` TINYINT(1) NULL DEFAULT NULL,
  `password` VARCHAR(255) NULL DEFAULT NULL,
  `role` VARCHAR(255) NULL DEFAULT NULL,
  `salt` VARCHAR(255) NULL DEFAULT NULL,
  `username` VARCHAR(255) NULL DEFAULT NULL,
  `version` DATETIME NULL DEFAULT NULL,
  `company` VARCHAR(255) NULL DEFAULT NULL,
  `firstname` VARCHAR(255) NULL DEFAULT NULL,
  `image_url` VARCHAR(255) NULL DEFAULT NULL,
  `lastname` VARCHAR(255) NULL DEFAULT NULL,
  `company_id` INT(11) NOT NULL,
  PRIMARY KEY (`userId`),
  INDEX `fk_users_company1_idx` (`company_id` ASC),
  CONSTRAINT `fk_users_company1`
    FOREIGN KEY (`company_id`)
    REFERENCES `market`.`company` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 33
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
