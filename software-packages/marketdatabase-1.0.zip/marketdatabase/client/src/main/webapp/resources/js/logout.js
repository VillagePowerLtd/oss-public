$(function() {

	logoutTest();

	function logout() {
		$('#log_out').click(function() {

			$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json'
				},
				type : "GET",
				url : LOG_OUT,
				dataType : "json",
				success : function(data, status) {
					$.removeCookie("loginToken");
					$.removeCookie("userRole");
					$.removeCookie("userName");
					$.removeCookie("logedInUserCompany");
					window.location.replace("login.jsp"); // redirect to login
					// page
				}
			});
		});
	}

	function logoutTest() {
		$('#log_out').click(function() {

			$.removeCookie("loginToken");
			$.removeCookie("userRole");
			$.removeCookie("userName");
			$.removeCookie("logedInUserCompany");
			window.location.replace("login.jsp"); // redirect to login page

		});

	}
});