$(function() {
	
	var $logedInUserCompany=$.cookie('logedInUserCompany');
	
	var $userRole=$.cookie('userRole');
	//retrieveLoans();
	retrieveLoansByLogedInUserCompany();
	loadCompanyCombo();
	
	if($userRole=='Overall admin'){
		$("#company_combo").prop('disabled', false);
		$("#load_loans_button").prop('disabled', false);
	}else{
		$("#company_combo").prop('disabled', true);
		$("#load_loans_button").prop('disabled', true);
	}
	
	$('#load_loans_button').click(function(){
		retrieveLoansBySelectedCompany();
	});
	
	function loadCompanyCombo() {
		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "GET",
					url : RETRIEVE_COMPANY,
					dataType : "json",
					success : function(data, status) {

						var options = '';
						for (var companyCount = 0; companyCount < data.companies.length; companyCount++) {
							
							console.log('company Id: '+data.companies[companyCount].id);
							 
							var companyId=data.companies[companyCount].id;
							
							if(companyId==$logedInUserCompany){
								options += ' <option value="'
									+ companyId + '"'+' selected="'+companyId+'">'
									+ data.companies[companyCount].name
									+ '</option>';
							}else{
								options += ' <option value="'
									+ companyId + '">'
									+ data.companies[companyCount].name
									+ '</option>';
							}
							
						}
						$('#company_combo').html(options);
					}

				});
	}

	function retrieveLoans() {
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "GET",
			url : RETRIEVE_LOANS,
			dataType : "json",
			success : function(data, status) {

				if (data.result) {
					loadCompanyLoans(data);
				} else {
					showServerResponse("ERROR", data.errorMessage, "error")

				}

			},
			error : function(jqXHR, textStatus, errorThrown) {
				loader.hideLoading();
				if (errorThrown == 'Unauthorized') {

					// onSessionTimeOut();
				}
			}
		});
	}
	
	
	function retrieveLoansByLogedInUserCompany() {
		
		var $companyId =  $logedInUserCompany;

		var company = {
			"type" : "object",
			"company" : {
				id : $companyId,

			}
		};

		var companyDataJSONString = JSON.stringify(company);
		
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "POST",
			url : RETRIEVE_LOANS_BY_COMPANY,
			data:companyDataJSONString,
			dataType : "json",
			success : function(data, status) {

				if (data.result) {
					loadCompanyLoans(data);
				} else {
					showServerResponse("ERROR", data.errorMessage, "error")

				}

			},
			error : function(jqXHR, textStatus, errorThrown) {
				loader.hideLoading();
				if (errorThrown == 'Unauthorized') {

					// onSessionTimeOut();
				}
			}
		});
	}
	
	
	function retrieveLoansBySelectedCompany() {
		
		var $companyId =  $('#company_combo');

		var company = {
			"type" : "object",
			"company" : {
				id : $companyId.val(),

			}
		};

		var companyDataJSONString = JSON.stringify(company);
		
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "POST",
			url : RETRIEVE_LOANS_BY_COMPANY,
			data:companyDataJSONString,
			dataType : "json",
			success : function(data, status) {

				if (data.result) {
					loadCompanyLoans(data);
				} else {
					showServerResponse("ERROR", data.errorMessage, "error")

				}

			},
			error : function(jqXHR, textStatus, errorThrown) {
				loader.hideLoading();
				if (errorThrown == 'Unauthorized') {

					// onSessionTimeOut();
				}
			}
		});
	}
	
/*function loadCompanyLoans(data) {
		

		var table = $('#loans_table')
				.DataTable(
						{
							buttons : [ 'copy', 'excel', 'pdf' ],
							destroy : true,
							data : data.loans,
							pageLength: 5524 ,
							dom: 'Bfrtip',
							processing: true,
							buttons: [
								'pageLength',
								'copyFlash',
								'csvFlash',
								'excelFlash',
								'pdfFlash'
							],
							columns : [ 
							{
								data : "companyId"
							}, {
								data : "id"
							}, {
								data : "model"
							}, {
								data : "salesMode"
							}, {
								data : "typeOfLoan"
							},{
								data : "country"
							},{
								data : "district"
							},
							{
								data : "county"
							},

							{
								data : "subCounty"
							},

							{
								data : "parish"
							},

							{
								data : "village"
							},
							null,
							null,
							{
								data : "nextPaymentDate"
							},
							{
								data : "status"
							},
							{
								data : "currentOutstandingBalance"
							} 
							],
							columnDefs : [
								{
									targets : [11,12],
									defaultContent : ""
								}],
						});

	}*/


	function loadCompanyLoans(data) {
		 
			var loansList = [];
			for(var i=0;i<data.loans.length;i++){
				
				var $status;
				var $NP;
				if (data.loans[i].defaulted === undefined) {
					$status = '';
				}else{
					$status=data.loans[i].defaulted;
				}
				
				if (data.loans[i].nextPaymentDate === undefined) {
					$NP = '';
				}else{
					$NP=data.loans[i].nextPaymentDate;
				}
				
				
				var loan = {
						companyId : data.loans[i].companyId,
						id : data.loans[i].id,
						model: data.loans[i].model,
						salesMode:data.loans[i].salesMode,
						typeOfLoan: data.loans[i].typeOfLoan,
						country: data.loans[i].country,
						district:data.loans[i].district,
						county:data.loans[i].county,
						subCounty:data.loans[i].subCounty,
						parish:data.loans[i].parish,
						village:data.loans[i].village,
						nextPaymentDate:$NP,
						status:$status,
						currentOutstandingBalance:data.loans[i].currentOutstandingBalance
						
						
					};
				loansList[i] = loan;
			}
		 

		var table = $('#loans_table')
				.DataTable(
						{ 
							destroy : true,
							data :loansList,
							pageLength: 10000,
							dom: 'Bfrtip',
							processing: true,
							buttons: [
								'pageLength', 
								'excelFlash',
								'pdfFlash'
							],
							columns : [ 
							{
								data : "companyId"
							}, {
								data : "id"
							}, {
								data : "model"
							}, {
								data : "salesMode"
							}, {
								data : "typeOfLoan"
							},{
								data : "country"
							},{
								data : "district"
							},
							{
								data : "county"
							},

							{
								data : "subCounty"
							},

							{
								data : "parish"
							},

							{
								data : "village"
							},
							{
								data : "nextPaymentDate"
							},
							{
								data : "status"
							},
							{
								data : "currentOutstandingBalance"
							} 
							]
						});

	}

});