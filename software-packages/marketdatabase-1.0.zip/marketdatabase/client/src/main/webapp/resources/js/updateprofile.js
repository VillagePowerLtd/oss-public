$(function() {
	
	var url = window.location.href;
	var mainurl = url.split("?");
	var parmetersURL = mainurl[1];

	var $userId = parmetersURL.split("&")[0].split("=")[1];
	var $hash = parmetersURL.split("&")[1].split("=")[1];
	var $email = parmetersURL.split("&")[2].split("=")[1];
	
	//Auto filling the email field from the verification email.
	$('#email').val($email);
	

	$('#update_profile')
			.click(
					function() {  
						
						var $password = $('#password');
						var $confirmPassword = $('#confirm_password');
						var $email = $('#email');

						if ($password.val() == $confirmPassword.val()) {

							var profile = {
								"type" : "object",
								"users" : {
									email : $email.val(),
									password : $password.val(),
									userId:$userId
								},
								 hash:$hash
							};

							var profileJSONString = JSON.stringify(profile);

							$
									.ajax({
										headers : {
											'Accept' : 'application/json',
											'Content-Type' : 'application/json'
										},
										type : "POST",
										url : UPDATE_PROFILE,
										data : profileJSONString,
										dataType : "json",
										success : function(data, status) {
											if (data.result) {
												window.location
												.replace("login.html");
												showServerResponse("Message", "Your New Password has been set successfully","success");
												
											} else {
												console
														.log("User Profile Password Update ERROR: "
																+ data.errorMessage);
											}

										}
									});

						} else {

						}
					});
			

		function showServerResponse(title, msg,type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		//var $toast = toastr["success"](msg, title);
		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}
})