$(function(){
	
	loadSummaryData();
	
	function loadSummaryData(){
		
		var $queryType='system';
        var $country=$.cookie('selectedCountry');
        var $district=$.cookie('selectedDistrict');
        var $county=$.cookie('selectedCounty');
        var $subcountycounty=$.cookie('selectedSubcounty');
        
        console.log('$country: '+$country);
        console.log('$district: '+$district);
        console.log('$county: '+$county);
        console.log('$subcountycounty: '+$subcountycounty);
        
        var query = {
				"type" : "object",
				"systemSoldQuery" : {
					queryType : $queryType,
					country : $country,
					district : $district,
					county:    $county,
					subcountycounty:$subcountycounty

				}
			};
        
        var queryJSONString = JSON.stringify(query);
        
         
        $.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "GET",
			url : ALL_SUB_COUNTY_SUMMERY_QUERY,
			dataType : "json",
			success : function(data, status) {

				if (data.result) {
					//showServerResponse("Success", data.message, "success")
					//console.log("Result: " + data);
					loadSummaryDataFile(data);
				} else {
					showServerResponse("ERROR", data.errorMessage, "error")
					// loadBathesTable();
				}

			},
			error : function(jqXHR, textStatus, errorThrown) {
				loader.hideLoading();
				if (errorThrown == 'Unauthorized') {

					// onSessionTimeOut();
				}
			}
		});
	
	}
	


function loadSummaryDataFile(data) {
	
	var counter=0;
	
	var queryDataArray = [];
	
	var $lastupdated;
	
	for(var i=0;i<data.subCountySystemSolds.length;i++){
		
		var $systemsSoldNumber=data.subCountySystemSolds[i].displayableSales;
		
		$lastupdated=data.subCountySystemSolds[i].dateCreated;
		 
		var queryData = {
				districtName:data.subCountySystemSolds[i].subCountyId.countyId.districtId.districtName,
				countyName : data.subCountySystemSolds[i].subCountyId.countyId.countyName, 
				subCountyName: data.subCountySystemSolds[i].subCountyId.subCountyName,
				systemsSoldNumber: $systemsSoldNumber
				
			};
		
		queryDataArray[i] = queryData;
	}
	
	$('#datepicker').val($lastupdated+" :EAT");
	
		var table = $('#systems_sold_query_table').DataTable({
			
			destroy : true,
			data : queryDataArray,
			pageLength: 100,
			dom: 'Bfrtip',
			buttons: [
				'pageLength', 
				'excelFlash',
				'pdfFlash'
			],
			columns : [ 
			{
				name : "district",
				title : "District",
				data : "districtName"
			}, {
				name : "countyName",
				title : "County",
				data:"countyName"
			}, {
				name : "subCountyName",
				title : "Sub county",
				data : "subCountyName"
			}, {
				name : "systemsSoldNumber",
				title : "Systems Sold",
				data : "systemsSoldNumber" 
			}
			],
			rowsGroup: [1, 0],
			 order: [[ 3, "asc" ]]

		});

	}

	function totalNumberOfSystemsSold(data) {

		
		var total = data.subCountySummary.systemsSold;
		return total;
	}
	
	
	function showServerResponse(title, msg,type) {
		var $toastlast; 

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}
});