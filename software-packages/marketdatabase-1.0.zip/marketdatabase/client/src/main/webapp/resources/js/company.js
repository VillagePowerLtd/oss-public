$(function() {
	
	var companyTable;
	retrieveCompanies();
	
	addNewCompany();
	updateCompany();
	deleteCompany();

	function addNewCompany() {
		$('#save_company_Button').click(function() {

			var $name = $('#company');
			var $phone = $('#telephone_no');
			var $address = $('#physical_address');
			var $postalAddress = $('#postal_address');
			var $email = $('#email');
			var $contact = $('#contact_person');

			var company = {
				"type" : "object",
				"company" : {
					name : $name.val(),
					phone : $phone.val(),
					address : $phone.val(),
					postalAddress : $phone.val(),
					email : $phone.val(),
					contact:$contact.val()

				}
			};

			var companyJSONString = JSON.stringify(company);

			console.log("Logging Compay Object: " + companyJSONString);

			$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json'
				},
				type : "POST",
				url : ADD_NEW_COMPANY,
				data : companyJSONString,
				dataType : "json",
				success : function(data, status) {

					if (data.result) {
						showServerResponse("Success", data.message, "success")
						console.log("Result: " + data);
						loadCompanies(data);
					} else {
						showServerResponse("ERROR", data.errorMessage, "error")
						// loadBathesTable();
					}

				},
				error : function(jqXHR, textStatus, errorThrown) {
					loader.hideLoading();
					if (errorThrown == 'Unauthorized') {

						// onSessionTimeOut();
					}
				}
			});

		});
	}

	function retrieveCompanies() {
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "GET",
			url : RETRIEVE_COMPANY,
			dataType : "json",
			success : function(data, status) {

				if (data.result) {
					loadCompanies(data);
				} else {
					showServerResponse("ERROR", data.errorMessage, "error")

				}

			},
			error : function(jqXHR, textStatus, errorThrown) {
				loader.hideLoading();
				if (errorThrown == 'Unauthorized') {

					// onSessionTimeOut();
				}
			}
		});
	}

	function loadCompanies(data) {

		companyTable = $('#company_list_table')
				.DataTable(
						{
							buttons : [ 'copy', 'excel', 'pdf' ],
							destroy : true,
							data : data.companies,

							columns : [ null, {
								data : "id"
							}, {
								data : "name"
							}, {
								data : "address"
							}, {
								data : "postalAddress"
							}, {
								data : "phone"
							}, {
								data : "email"
							}, {
								data : "contact"
							},
							 {
								data : "dateCreated"
							},
							null 

							],
							columnDefs : [
									{
										orderable : false,
										targets : 0,
										defaultContent : "",
										className : 'select-checkbox',
									},
									{
										targets : -1,
										data : null,
										defaultContent : " <a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit_company_modal'></i></a><a href='#' class='on-default remove-row'><i class='fa fa-trash-o'></i></a>"
									}, {
										targets : [ 1 ],
										visible : true
									} ],

							select : {
								style : 'os',
								selector : 'td:first-child'
							},

							order : [ [ 1, 'asc' ] ]

						});

	}
	
	function updateCompany(){ 

		$('#company_list_table').on('click', 'a.edit-row', function (){
			 
			
			var selectedRecord = companyTable.row( { selected: true } ).data();
			
			$("#edit_company").val(selectedRecord.name);
			$("#edit_telephone_no").val(selectedRecord.phone);
			$("#edit_physical_address").val(selectedRecord.address);
			$("#edit_postal_address").val(selectedRecord.postalAddress);
			$("#edit_email").val(selectedRecord.email);
			$("#edit_contact_person").val(selectedRecord.contact);
			
			
			$('#update_company_Button').click(function() {
				
				var $name = $('#edit_company');
				var $phone = $('#edit_telephone_no');
				var $address = $('#edit_physical_address');
				var $postalAddress = $('#edit_postal_address');
				var $email = $('#edit_email');
				var $contact = $('#edit_contact_person');

				var company = {
					"type" : "object",
					"company" : {
						id:selectedRecord.id,
						name : $name.val(),
						phone : $phone.val(),
						address : $phone.val(),
						postalAddress : $phone.val(),
						email : $phone.val(),
						contact:$contact.val()

					}
				};

				var companyJSONString = JSON.stringify(company);

				console.log("Logging Compay Object: " + companyJSONString);
				
				
				$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "PUT",
					url : UPDATE_COMPANY,
					data : companyJSONString,
					dataType : "json",
					success : function(data, status) {

						if (data.result) {
							showServerResponse("Success", data.message, "success") 
							loadCompanies(data);
						} else {
							showServerResponse("ERROR", data.errorMessage, "error")
							 
						}

					},
					error : function(jqXHR, textStatus, errorThrown) {
						loader.hideLoading();
						if (errorThrown == 'Unauthorized') {

							// onSessionTimeOut();
						}
					}
				});
				

			});
		});
	
		
	}
	
	function deleteCompany(){
		  
		$('#company_list_table').on('click', 'a.remove-row', function (){ 
			
			var selectedRecord = companyTable.row( { selected: true } ).data();
			
			var company = {
					"type" : "object",
					"company" : {
						id:selectedRecord.id
					}
				};

				var companyJSONString = JSON.stringify(company);
				
				console.log("loading DELETE Company: "+companyJSONString);
				
				$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "POST",
					url : DELETE_COMPANY,
					data : companyJSONString,
					dataType : "json",
					success : function(data, status) {
						
						if (data.result) {
							showServerResponse("Success", data.message, "success")
							console.log("Result: " + data);
							loadDevicesSupported(data);
							
						} else {
							showServerResponse("ERROR", data.errorMessage, "error")
							 
						}
						
					},
					error : function(jqXHR, textStatus,
							errorThrown) {
						loader.hideLoading();
						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}
				}); 
		});
	}

	function showServerResponse(title, msg, type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}
});