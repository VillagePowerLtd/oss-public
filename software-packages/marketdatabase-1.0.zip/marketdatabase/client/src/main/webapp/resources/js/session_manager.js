function onSessionTimeOut() {
	$.removeCookie("loginToken");  
	window.location.replace("login.jsp");

}