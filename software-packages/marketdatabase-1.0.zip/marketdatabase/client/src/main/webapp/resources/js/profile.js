$(function() {
	$("#logged_in_user").html($.cookie('userName')); 
	loadProfilesTable();

	$('#new_user_button').click(function() {
		loadRoleCombo();
		loadCompanyCombo();
	});
	
	updateUserProfile();
	deleteUserProfile();
	
	var $userProfileTable;

	$('#save_profile').click(function() {
		
		var $email = $('#email');
		var $confirmEmail = $('#confirm_email');
		var $role = $('#role');
		var $firstName=$('#first_name');
		var $lastName=$('#last_name');
		var $organisation=$('#user_company');

		if ($email.val() == $confirmEmail.val()) {
			var profile = {
				"type" : "object",
				"users" : {
					email : $email.val(),
					role : $role.val(),
					firstname:$firstName.val(),
					lastname:$lastName.val(),
					company:$organisation.val(),
					username: $email.val(),
				}
			};

			var profileJSONString = JSON.stringify(profile);

			$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json'
				},
				type : "POST",
				url : CREATE_PROFILE,
				data : profileJSONString,
				dataType : "json",
				success : function(data, status) {
					
					
					if(data.result==true){
						showServerResponse("Success", "New Profile Added Successfully","success");
						loadProfilesTable();
					}else{
					showServerResponse("ERROR","An Error Occured while Adding Profile. Please try again","error");
					}
					
					loadProfilesTable();
				},
						error : function(jqXHR, textStatus, errorThrown) {

							if (errorThrown == 'Unauthorized') {

								//onSessionTimeOut();
							}
						}
			});
		}else{
			showServerResponse("ERROR", "Email do not match. Please Confirm your email.","error")
		}

	});



	function loadProfilesTable() {
		
		
		
		$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "GET",
					url : RETRIEVE_PROFILE,
					dataType : "json",
					success : function(data, status) {

						$userProfileTable = $('#user_list_table')
								.DataTable(
										{
											destroy : true,
											data : data.users,
											columns : [ 
											           null,
											{
												data : "userId"
											},
											{
												data : "firstname"
											},
											{
												data : "lastname"
											},
											{
												data : "company"
											},
										    {
												data : "email"
											}, {
												data : "role"
											},
											null,

											],
											columnDefs : [
												{
													orderable : false,
													targets : 0,
													defaultContent : "",
											        className: 'select-checkbox',
												},
												{
													targets : -1,
													data : null,
													defaultContent : "<a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit_user_modal'></i></a><a href='#' class='on-default remove-row'><i class='fa fa-trash-o'></i></a>"
												},
												{
														targets : [ 1 ],
														visible : false
													}
												
													],
										
											select: {
											          style:    'os',
											          selector: 'td:first-child'
											       },
								        
								        order : [ [ 1, 'asc' ] ]
								                  

										});  
								
						// Since We cant access the table outside this ajax call, the we shall have this function in here

						//shareGraphs(table);
						
						//loadUserAssignedPermisions(table);
						
						//loader.hideLoading();
						
						console.log("Load Profiles Table true"); 
						
					},
					error : function(jqXHR, textStatus, errorThrown) {
						//loader.hideLoading();
						console.log("Load Profiles Table false");
						if (errorThrown == 'Unauthorized') {

							//onSessionTimeOut();
						}
					}
				});
	}

	function loadRoleCombo() {

		var options = '';

		options += ' <option value="Overall admin">Overall admin</option>';
		options += ' <option value="Company admin">Company admin</option>';
		options += ' <option value="User">User</option>';

		$('#role').html(options);
	}
	
	function loadEditRoleCombo() {

		var options = '';

		options += ' <option value="Overall admin">Overall admin</option>';
		options += ' <option value="Company admin">Company admin</option>';
		options += ' <option value="User">User</option>';

		$('#edit_role').html(options);
	}
	
	function loadCompanyCombo() {
		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "GET",
					url : RETRIEVE_COMPANY,
					dataType : "json",
					success : function(data, status) {

						var options = '';
						for (var companyCount = 0; companyCount < data.companies.length; companyCount++) {

							options += ' <option value="'
									+ data.companies[companyCount].name + '">'
									+ data.companies[companyCount].name
									+ '</option>';
						}
						$('#user_company').html(options);
					}

				});
	}
	
	function loadEditCompanyCombo() {
		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "GET",
					url : RETRIEVE_COMPANY,
					dataType : "json",
					success : function(data, status) {

						var options = '';
						for (var companyCount = 0; companyCount < data.companies.length; companyCount++) {

							options += ' <option value="'
									+ data.companies[companyCount].name + '">'
									+ data.companies[companyCount].name
									+ '</option>';
						}
						$('#edit_user_company').html(options);
					}

				});
	}

	function deleteUserProfile(){
		  
		$('#user_list_table').on('click', 'a.remove-row', function (){ 
			
			var selectedProfile = $userProfileTable.row( { selected: true } ).data();
			 
			var profile = {
					"type" : "object",
					"users" : {
						userId : selectedProfile.userId
					}
				};

			var profileJSONString = JSON.stringify(profile);
				
				console.log("loading DELETE Profile Id: "+selectedProfile.userId);
				
				$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "POST",
					url : DELETE_PROFILE,
					data : profileJSONString,
					dataType : "json",
					success : function(data, status) {
						
						if (data.result) {
							showServerResponse("Success", data.message, "success")
							console.log("Result: " + data);
							loadProfilesTable();
							
						} else {
							showServerResponse("ERROR", data.errorMessage, "error")
							 
						}
						
					},
					error : function(jqXHR, textStatus,
							errorThrown) {
						loader.hideLoading();
						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}
				}); 
		});
	}
	
	
	function updateUserProfile(){
		$('#user_list_table').on('click', 'a.edit-row', function (){ 
			loadEditRoleCombo();
			loadEditCompanyCombo();
			
			var selectedProfile = $userProfileTable.row( { selected: true } ).data();
			

			//$("#edit_company").val(selectedProfile.companyId.id);
			
			//console.log("Company Id: "+selectedDevice.companyId.id);
			  
			 $('#edit_email').val(selectedProfile.email);
			 $('#edit_confirm_email').val(selectedProfile.email);
			 $('#edit_role').val(selectedProfile.role);
			 $('#edit_first_name').val(selectedProfile.firstname);
			 $('#edit_last_name').val(selectedProfile.lastname);
			 $('#edit_user_company').val(selectedProfile.company);
			 
			 $("#edit_role").select2().select2('val',selectedProfile.role);
			 $("#edit_user_company").select2().select2('val',selectedProfile.company);
			
			
			$('#edit_profile_button').click(function() {
				
				var $email = $('#edit_email');
				var $confirmEmail = $('#edit_confirm_email');
				var $role = $('#edit_role');
				var $firstName=$('#edit_first_name');
				var $lastName=$('#edit_last_name');
				var $organisation=$('#edit_user_company');

				if ($email.val() == $confirmEmail.val()) {
					
					var profile = {
						"type" : "object",
						"users" : {
							userId:selectedProfile.userId,
							email : $email.val(),
							role : $role.val(),
							firstname:$firstName.val(),
							lastname:$lastName.val(),
							company:$organisation.val(),
							username: $email.val()
						}
					};

					var profileJSONString = JSON.stringify(profile);
					
					console.log("profileJSONString: "+profileJSONString)

					$.ajax({
						headers : {
							'Accept' : 'application/json',
							'Content-Type' : 'application/json'
						},
						type : "POST",
						url : UPDATE_USER_PROFILE,
						data : profileJSONString,
						dataType : "json",
						success : function(data, status) {
							
							
							if(data.result==true){
								showServerResponse("Success", "Profile updated Successfully","success");
								loadProfilesTable();
							}else{
							showServerResponse("ERROR","An Error Occured while updating Profile. Please try again","error");
							}
							
							loadProfilesTable();
						},
								error : function(jqXHR, textStatus, errorThrown) {

									if (errorThrown == 'Unauthorized') {

										//onSessionTimeOut();
									}
								}
					});
				}else{
					showServerResponse("ERROR", "Email do not match. Please Confirm your email.","error")
				}

			});
		});
	}
	

	function showServerResponse(title, msg,type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}

});