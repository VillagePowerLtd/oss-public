$(function() {

	var $logedInUserCompany=$.cookie('logedInUserCompany');
	
	var $userRole=$.cookie('userRole');
	
	var $table;
	
	loadCompanies();
	
	loadCompaySystems($logedInUserCompany);
	
	var $specificationTable;
	var $devicesSupportedTable;
	
	if($userRole=='superadministrator'){
		$("#company_combo").prop('disabled', false);
		$("#load_device_suported_batch").prop('disabled', false);
		$("#company").prop('disabled', false);
		
	}else{
		$("#company_combo").prop('disabled', true);
		$("#load_device_suported_batch").prop('disabled', true);
		$("#company").prop('disabled', true);
	}
	

	$('#new_device_suported_button').click(function() {
		// loadDevicesSupported();
		loadCompanyCombo();
		loadCompayDevices();

		$("#company").change(function() {
			
			loadCompayDevices();
		});

	});
	
	$('#load_device_suported_batch').click(function (){
		var $companyId =  $('#company_combo');
		console.log('$companyId: '+$companyId.val());
		loadCompaySystems($companyId.val());
	});
	

	function loadDevicesSupported() {
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json',

			},
			type : "GET",
			url : RETRIEVE_DEVICES_SUPPORTED,
			dataType : "json",
			success : function(data, status) {

				var options = '';
				for (var i = 0; i < data.devicesSupported.length; i++) {
					options += ' <option value="' + data.devicesSupported[i].id
							+ '">' + data.devicesSupported[i].devicesName
							+ '</option>';
				}
				$('#devices_supported').html(options);

			},
			error : function(jqXHR, textStatus, errorThrown) {
				// loader.hideLoading();
				if (errorThrown == 'Unauthorized') {

					onSessionTimeOut();
				}
			}

		});
	}
	
	

	function loadCompanyCombo() {
		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "GET",
					url : RETRIEVE_COMPANY,
					dataType : "json",
					success : function(data, status) {

						var options = '';
						for (var companyCount = 0; companyCount < data.companies.length; companyCount++) {
							
							console.log('company Id: '+data.companies[companyCount].id);
							
							var companyId=data.companies[companyCount].id;
							
							if(companyId==$logedInUserCompany){
								options += ' <option value="'
									+ companyId + '"'+' selected="'+companyId+'">'
									+ data.companies[companyCount].name
									+ '</option>';
							}else{
								options += ' <option value="'
									+ companyId + '">'
									+ data.companies[companyCount].name
									+ '</option>';
							}
							
						}
						$('#company').html(options);
					}

				});
	}
	
	
	function loadCompanies() {
		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "GET",
					url : RETRIEVE_COMPANY,
					dataType : "json",
					success : function(data, status) {

						var options = '';
						for (var companyCount = 0; companyCount < data.companies.length; companyCount++) {

							console.log('company Id: '+data.companies[companyCount].id);
							
							var companyId=data.companies[companyCount].id;
							
							if(companyId==$logedInUserCompany){
								options += ' <option value="'
									+ companyId + '"'+' selected="'+companyId+'">'
									+ data.companies[companyCount].name
									+ '</option>';
							}else{
								options += ' <option value="'
									+ companyId + '">'
									+ data.companies[companyCount].name
									+ '</option>';
							}
							
						}
						
						$('#company_combo').html(options);
						
					}

				});
	}

	function loadCompayDevices() {
		

		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "GET",
			url : RETRIEVE_DEVICES_SUPPORTED,
			dataType : "json",
			success : function(data, status) {
				var $table;
				
				if (data.result) {
					
					var devicesList = [];
					
					for(var i=0;i<data.devicesSupported.length;i++){
						
						var $companyName=data.devicesSupported[i].companyId.name;
						var $companyId=data.devicesSupported[i].companyId.id;
						
						if(data.devicesSupported[i].master){
							$companyName="Master list";
							$companyId="Master";
						}else{
							 
						}
						
						var device = {
								id : data.devicesSupported[i].id,
								code : data.devicesSupported[i].code,
								devicesName: data.devicesSupported[i].devicesName,
								description:data.devicesSupported[i].description,
								companyName: $companyName,
								companyId: $companyId,
								quantity:1
								
							};
						
							if($userRole=='superadministrator'){
								devicesList[i] = device;
							}else{
								
								//if not super administrator only give master list,and company devices.
								
								if($companyId=="Master"){
									
									devicesList[i] = device;
									
								}else{
									
									if($companyId==$logedInUserCompany){
										devicesList[i] = device;
									}else{
										
									}
								}
							}
						
							
					}
					
					//console.log("DevicesList: "+ JSON.stringify(devicesList));
					
					$table = $('#company_devices_supported_table').DataTable(
							{
								destroy : true,
								data : devicesList,
								
								columns : [
								null,
								{
									data : "id"
								},
								{
									data : "devicesName"
								}, {
									data : "quantity"
								},null
								],
								columnDefs : [
									{
										orderable : false,
										targets : 0,
										defaultContent : "",
										className : 'select-checkbox',
									},
									{
										targets : -1,
										data : null,
										defaultContent : "<a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit_devices_supported_quantity_modal'></i></a>"
									}, {
										targets : [ 1 ],
										visible : false
									} ],

							select : {
								style : 'os',
								selector : 'td:first-child'
							},

							order : [ [ 1, 'asc' ] ]
							});
					
					//$('#devices_supported_table').editableTableWidget().numericInputExample().find('td:first').focus();
					
					$('#company_devices_supported_table').on('page.dt', function() {
						  
						onUpdateDeviceQuantityButtonClicked($table); 
						
						});
						
						
						$('#company_devices_supported_table').on('draw.dt', function() {
							  
							onUpdateDeviceQuantityButtonClicked($table); 
						});
					 
						onUpdateDeviceQuantityButtonClicked($table);  
					
				} else {
					  console.log("DevicesList: ERROR ");
					
					  $table = $('#company_devices_supported_table').DataTable({
						destroy : true,
						data : []
					});

					// showServerResponse("ERROR", data.errorMessage, "error")

				}

				

				
			},
			error : function(jqXHR, textStatus, errorThrown) {

				if (errorThrown == 'Unauthorized') {

					// onSessionTimeOut();
				}
			}
		});
	}
	


 
function onNewSpecificationButtonClicked($table) {

		$('#save_specification_button')
				.click(
						function() {

							var $companyId = $('#company');
							var $model = $('#model');
							var $wp = $('#solar_panel');
							var $maxPowerOutput = $('#max_power_output');
							var $deviceSupported = $('#no_devices_supported');
							var $qualityVerified = $('#quality_verified');
							  
							
							if($companyId.val()==''){
								showServerResponse('ERROR', 'ERROR: Please Select Company','error');
							}
							else if($model.val()==''){
								showServerResponse('ERROR', 'ERROR: Please Enter Systems Model','error');
							}
							else if($maxPowerOutput.val()==''){
								showServerResponse('ERROR', 'ERROR: Please Enter Max power output (W) ','error');
							}
							else if($wp.val()==''){
								showServerResponse('ERROR', 'ERROR: Please Enter Solar panel (Wp)','error');
							}
							else if($deviceSupported.val()==''){
								showServerResponse('ERROR', 'ERROR: Please Enter No. Devices supported','error');
							}
							else if($qualityVerified.val()==''){
								showServerResponse('ERROR', 'ERROR: Please Select If system is quality verified','error');
							}
							else{

							var devices = [];

							var rowData = $table.rows().data().toArray();

							if (rowData.length > 0) {
								for (var i = 0; i < rowData.length; i++) {

									console.log("Quantity rowData ==> "+i+" :" + rowData[i].quantity);

									var device = {

										deviceSupportedId : {
											id : rowData[i].id
										},
										quantity : rowData[i].quantity

									};

									devices[i] = device;
								}

								var systemsModelSpecification = {
									"type" : "object",
									"specification" : {
										deviceSupported : $deviceSupported.val(),
										maxPowerOutput : $maxPowerOutput.val(),
										model : $model.val(),
										qualityVerified : $qualityVerified.val(),
										wp : $wp.val(),
										companyId : {
											id : $companyId.val()
										},
										"specificationDeviceList" : devices
									}

								}
							}

							var systemsModelSpecificationJSONString = JSON
									.stringify(systemsModelSpecification);

							console
									.log("Systems Model Specification Submission JSON: "
											+ systemsModelSpecificationJSONString);

							$.ajax({
										headers : {
											'Accept' : 'application/json',
											'Content-Type' : 'application/json'
										},
										type : "POST",
										url : SAVE_KIT_SPECIFICATION,
										data : systemsModelSpecificationJSONString,
										dataType : "json",
										success : function(data, status) {
											// loader.hideLoading();
											if (data.result) {
												// loader.hideLoading();
												showServerResponse(
														"Success",
														"Systems Specification added successfully",
														"success");
												console
														.log("Systems Specification Feedback: "
																+ data.message);
											} else {
												// loader.hideLoading();
												showServerResponse(
														"ERROR",
														"An error Occured while adding Systems Specification",
														"error");
											}

										},
										error : function(jqXHR, textStatus,
												errorThrown) {
											// loader.hideLoading();
											showServerResponse("ERROR",
													"An error Occured while adding Systems Specification "
															+ textStatus,
													"error");
											if (errorThrown == 'Unauthorized') {

												// onSessionTimeOut();
											}
										}
									});
						}
						});
	}

function loadCompaySystems($companyId) {
  
		var company = {
			"type" : "object",
			"company" : {
				id : $companyId,

			}
		};

		console.log('loadCompaySystems $companyId: '+$companyId);
		
		var companyDataJSONString = JSON.stringify(company);
		
		
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "POST",
			url : RETRIEVE_COMPANY_SPECIFICATIONS,
			data:companyDataJSONString,
			dataType : "json",
			success : function(data, status) {
				 
				if (data.result) {
					
					var columns = [ null,
					{
						"Id" : "Id"
					},
					{
						"title" : "SHS model"
					}, {
						"title" : "Installed Yes/No"
					}, {
						"title" : "# devices supported"
					}];
					
					for(var i=0;i<data.devicesSupported.length;i++){
						
						var column= {"title" : data.devicesSupported[i].devicesName};
						
						
						columns.push(column);
					}
					
					columns.push({"title" : "Quality verified (Yes/No)"});
					columns.push({"title" : "Solar panel (Wp)"});
					columns.push({"title" : "Max power output (W)"});
					columns.push({"title" : "Current (AC/DC)"});
					columns.push({"title" : "Last date of specification"});
					columns.push({"title" : "Edit/Delete"});
				
					
					var dataSet=[];
					
					for(var i=0;i<data.specifications.length;i++){
						
						var specData=[];
						specData.push(null);
						specData.push(data.specifications[i].id);
						specData.push(data.specifications[i].model);
						specData.push("Yes");
						specData.push(data.specifications[i].deviceSupported);
						 
						console.log("columns.length: "+columns.length);
						
						for(var j=0;j<data.devicesSupported.length;j++){
							
							var $quantity=getDeviceSupportedQuanity(data.specifications[i].specificationDeviceList,data.devicesSupported[j].id);
							specData.push($quantity);
						}
						
						if(data.specifications[i].qualityVerified='false'){
							//specData.push(data.specifications[i].qualityVerified);
							specData.push("No");
						}else{
							specData.push("Yes");
						}
						
						specData.push(data.specifications[i].wp);
						specData.push(data.specifications[i].maxPowerOutput);
						specData.push(data.specifications[i].current); 
						specData.push(data.specifications[i].dateCreated);
						specData.push(null);
						
						dataSet.push(specData);
					}

					
					$table = $('#specification_table').DataTable({
						destroy : true,
						data : dataSet,
						columns:columns,
						columnDefs : [
							{
								orderable : false,
								targets : 0,
								defaultContent : "",
								className : 'select-checkbox',
							},
							{
								targets : -1,
								data : null,
								defaultContent : "<a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit-specification-modal'></i></a>"
							} ],

					select : {
						style : 'os',
						selector : 'td:first-child'
					},

					order : [ [ 1, 'asc' ] ]
						
					});

					onEditSpecificationButtonClicked($table,data.devicesSupported.length);
					
					//onUpdateDeviceQuantityButtonClicked($table);

				} else {
					$table = $('#specification_table').DataTable({
						destroy : true,
						data : []
						
					});

				}

			},
			error : function(jqXHR, textStatus, errorThrown) {

				if (errorThrown == 'Unauthorized') {

					 
				}
			}
		});
	}
	
function getDeviceSupportedQuanity($specificationList,$deviceId){
	var $quantity=0;
		console.log("$specificationList: "+$specificationList.length);
		for(var i=0;i<$specificationList.length;i++){
			
			console.log("specificationDeviceList[i].deviceSupportedId.id: "+$specificationList[i].deviceSupportedId.id);
			console.log("deviceId: "+$deviceId);
			
			if($specificationList[i].deviceSupportedId.id==$deviceId){
				$quantity= $specificationList[i].quantity;
				console.log("Quantity: "+$quantity);
				
			}
		}
		
		return $quantity;
	}
	
function onUpdateDeviceQuantityButtonClicked($table,$specificationTable){
		$('#edit_update_device_quantity_button').click(function(){
			
			console.log("Update_device_quantity_button clicked:");
			
			var editedQuantity=$('#edit_quantity').val();
			//get selected row
			var selectedDevice = $table.row( { selected: true } ).data();
			  //get all data
			var rowData = $table.rows().data().toArray();
			
			var devices = [];

			if (rowData.length > 0) {
				for (var i = 0; i < rowData.length; i++) {

					var $quantity=0;
					
					if(rowData[i].id==selectedDevice.id){
						$quantity=editedQuantity
					}else{
						$quantity=rowData[i].quantity;
					}
					 
					var device = {
							id : rowData[i].id,
							code : rowData[i].code,
							devicesName: rowData[i].devicesName,
							description:rowData[i].description,
							companyName: rowData[i].companyName,
							companyId: rowData[i].companyId,
							quantity:$quantity
							
						};

					devices[i] = device;
				}
				
				$table = $('#company_devices_supported_table').DataTable(
						{
							destroy : true,
							data : devices,
							
							columns : [
							null,
							{
								data : "id"
							},
							{
								data : "devicesName"
							}, {
								data : "quantity"
							},null
							],
							columnDefs : [
								{
									orderable : false,
									targets : 0,
									defaultContent : "",
									className : 'select-checkbox',
								},
								{
									targets : -1,
									data : null,
									defaultContent : "<a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit_devices_supported_quantity_modal'></i></a>"
								}, {
									targets : [ 1 ],
									visible : false
								} ],

						select : {
							style : 'os',
							selector : 'td:first-child'
						},

						order : [ [ 1, 'asc' ] ]
						});
				onNewSpecificationButtonClicked($table);
				//onUpdateSpecificationButtonClicked($table,$specificationTable);
				onUpdateDeviceQuantityButtonClicked($table);
				
			}
		});
	}
	
function loadEditCompanyCombo() {
		$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "GET",
					url : RETRIEVE_COMPANY,
					dataType : "json",
					success : function(data, status) {

						var options = '';
						for (var companyCount = 0; companyCount < data.companies.length; companyCount++) {
							
							console.log('company Id: '+data.companies[companyCount].id);
							
							var companyId=data.companies[companyCount].id;
							
							if(companyId==$logedInUserCompany){
								options += ' <option value="'
									+ companyId + '"'+' selected="'+companyId+'">'
									+ data.companies[companyCount].name
									+ '</option>';
							}else{
								options += ' <option value="'
									+ companyId + '">'
									+ data.companies[companyCount].name
									+ '</option>';
							}
							
						}
						$('#edit_company').html(options);
					}

				});
	}

function loadEditCompayDevices() {
		

		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "GET",
			url : RETRIEVE_DEVICES_SUPPORTED,
			dataType : "json",
			success : function(data, status) {
				var $table;
				
				if (data.result) {
					
					var devicesList = [];
					
					for(var i=0;i<data.devicesSupported.length;i++){
						
						var $companyName=data.devicesSupported[i].companyId.name;
						var $companyId=data.devicesSupported[i].companyId.id;
						
						if(data.devicesSupported[i].master){
							$companyName="Master list";
							$companyId="Master";
						}else{
							 
						}
						
						var device = {
								id : data.devicesSupported[i].id,
								code : data.devicesSupported[i].code,
								devicesName: data.devicesSupported[i].devicesName,
								description:data.devicesSupported[i].description,
								companyName: $companyName,
								companyId: $companyId,
								quantity:1
								
							};
						
							if($userRole=='superadministrator'){
								devicesList[i] = device;
							}else{
								
								//if not super administrator only give master list,and company devices.
								
								if($companyId=="Master"){
									
									devicesList[i] = device;
									
								}else{
									
									if($companyId==$logedInUserCompany){
										devicesList[i] = device;
									}else{
										
									}
								}
							}
						
							
					}
					
					//console.log("DevicesList: "+ JSON.stringify(devicesList));
					
					$table = $('#edit_company_devices_supported_table').DataTable(
							{
								destroy : true,
								data : devicesList,
								
								columns : [
								null,
								{
									data : "id"
								},
								{
									data : "devicesName"
								}, {
									data : "quantity"
								},null
								],
								columnDefs : [
									{
										orderable : false,
										targets : 0,
										defaultContent : "",
										className : 'select-checkbox',
									},
									{
										targets : -1,
										data : null,
										defaultContent : "<a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit_devices_supported_quantity_modal'></i></a>"
									}, {
										targets : [ 1 ],
										visible : false
									} ],

							select : {
								style : 'os',
								selector : 'td:first-child'
							},

							order : [ [ 1, 'asc' ] ]
							});
					
					//$('#devices_supported_table').editableTableWidget().numericInputExample().find('td:first').focus();	
					 
					onEditSpecificationUpdateDeviceQuantityButtonClicked($table,$specificationTable)
					 
					
				} else {
					  console.log("DevicesList: ERROR ");
					
					  $table = $('#edit_company_devices_supported_table').DataTable({
						destroy : true,
						data : []
					});

					// showServerResponse("ERROR", data.errorMessage, "error")

				}

				

				
			},
			error : function(jqXHR, textStatus, errorThrown) {

				if (errorThrown == 'Unauthorized') {

					// onSessionTimeOut();
				}
			}
		});
	}
function loadToEditCompayDevices($selectedSpecificationId) {
		

		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "GET",
			url : RETRIEVE_DEVICES_SUPPORTED,
			dataType : "json",
			success : function(data, status) {
				var $table;
				
				if (data.result) {
					
					var devicesList = [];
					
					for(var i=0;i<data.devicesSupported.length;i++){
						
						var $companyName=data.devicesSupported[i].companyId.name;
						var $companyId=data.devicesSupported[i].companyId.id;
						
						if(data.devicesSupported[i].master){
							$companyName="Master list";
							$companyId="Master";
						}else{
							 
						}
						
						var device = {
								id : data.devicesSupported[i].id,
								code : data.devicesSupported[i].code,
								devicesName: data.devicesSupported[i].devicesName,
								description:data.devicesSupported[i].description,
								companyName: $companyName,
								companyId: $companyId,
								quantity:1
								
							};
						
							if($userRole=='superadministrator'){
								devicesList[i] = device;
							}else{
								
								//if not super administrator only give master list,and company devices.
								
								if($companyId=="Master"){
									
									devicesList[i] = device;
									
								}else{
									
									if($companyId==$logedInUserCompany){
										devicesList[i] = device;
									}else{
										
									}
								}
							}
						
							
					}
					
					//console.log("DevicesList: "+ JSON.stringify(devicesList));
					
					$table = $('#edit_company_devices_supported_table').DataTable(
							{
								destroy : true,
								data : devicesList,
								
								columns : [
								null,
								{
									data : "id"
								},
								{
									data : "devicesName"
								}, {
									data : "quantity"
								},null
								],
								columnDefs : [
									{
										orderable : false,
										targets : 0,
										defaultContent : "",
										className : 'select-checkbox',
									},
									{
										targets : -1,
										data : null,
										defaultContent : "<a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit_devices_supported_quantity_modal'></i></a>"
									}, {
										targets : [ 1 ],
										visible : false
									} ],

							select : {
								style : 'os',
								selector : 'td:first-child'
							},

							order : [ [ 1, 'asc' ] ]
							});
					
					//$('#devices_supported_table').editableTableWidget().numericInputExample().find('td:first').focus();	
					 
					onEditSpecificationUpdateDeviceQuantityButtonClicked($table,$selectedSpecificationId);
					 
					
				} else {
					  console.log("DevicesList: ERROR ");
					
					  $table = $('#company_devices_supported_table').DataTable({
						destroy : true,
						data : []
					});

					// showServerResponse("ERROR", data.errorMessage, "error")

				}

				

				
			},
			error : function(jqXHR, textStatus, errorThrown) {

				if (errorThrown == 'Unauthorized') {

					// onSessionTimeOut();
				}
			}
		});
	}

	
function onEditSpecificationUpdateDeviceQuantityButtonClicked($table,$selectedSpecificationId){
		$('#edit_update_device_quantity_button').click(function(){
			
			console.log("onEditSpecificationUpdateDeviceQuantityButtonClicked Update_device_quantity_button clicked:");
			
			var editedQuantity=$('#edit_quantity').val();
			//get selected row
			var selectedDevice = $table.row( { selected: true } ).data();
			  //get all data
			var rowData = $table.rows().data().toArray();
			
			var devices = [];

			if (rowData.length > 0) {
				for (var i = 0; i < rowData.length; i++) {

					var $quantity=0;
					
					if(rowData[i].id==selectedDevice.id){
						$quantity=editedQuantity
					}else{
						$quantity=rowData[i].quantity;
					}
					 
					var device = {
							id : rowData[i].id,
							code : rowData[i].code,
							devicesName: rowData[i].devicesName,
							description:rowData[i].description,
							companyName: rowData[i].companyName,
							companyId: rowData[i].companyId,
							quantity:$quantity
							
						};

					devices[i] = device;
				}
				
				$table = $('#edit_company_devices_supported_table').DataTable(
						{
							destroy : true,
							data : devices,
							
							columns : [
							null,
							{
								data : "id"
							},
							{
								data : "devicesName"
							}, {
								data : "quantity"
							},null
							],
							columnDefs : [
								{
									orderable : false,
									targets : 0,
									defaultContent : "",
									className : 'select-checkbox',
								},
								{
									targets : -1,
									data : null,
									defaultContent : "<a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit_devices_supported_quantity_modal'></i></a>"
								}, {
									targets : [ 1 ],
									visible : false
								} ],

						select : {
							style : 'os',
							selector : 'td:first-child'
						},

						order : [ [ 1, 'asc' ] ]
						}); 
				onUpdateSpecificationButtonClicked($table,$selectedSpecificationId);
				
			}
		});
	}
	
function onEditSpecificationButtonClicked($table,$noSupportedDevices){
		$('a.edit-row').click(function (){
			
			loadEditCompanyCombo();
			//loadEditCompayDevices();

			$("#edit_company").change(function() {
				
				loadEditCompayDevices();
			});
			
			var selectedSpecification = $table.row( { selected: true } ).data(); 
			
			console.log("selectedSpecification: "+  selectedSpecification);
			
			//$('#company').val(selectedSpecification.companyId.id);
			$('#edit_model').val(selectedSpecification[2]);
			$('#edit_solar_panel').val(selectedSpecification[5+$noSupportedDevices+1]);
			$('#edit_max_power_output').val(selectedSpecification[5+$noSupportedDevices+2]);
			$('#edit_no_devices_supported').val(selectedSpecification[4]);
			$('#edit_quality_verified').val(selectedSpecification[5+$noSupportedDevices]);
			
			var $selectedSpecificationId=selectedSpecification[1];
			
			loadToEditCompayDevices($selectedSpecificationId);
		});
	}
	
function onUpdateSpecificationButtonClicked($table,$selectedSpecificationId) {

		$('#edit_specification_button')
				.click(
						function() {
							
							console.log("edit_specification_button clicked");
							
							var selectedSpecification =$selectedSpecificationId;
							
							var $companyId = $('#edit_company');
							var $model = $('#edit_model');
							var $wp = $('#edit_solar_panel');
							var $maxPowerOutput = $('#edit_max_power_output');
							var $deviceSupported = $('#edit_no_devices_supported');
							var $qualityVerified = $('#edit_quality_verified');

							var devices = [];

							var rowData = $table.rows().data().toArray();

							if (rowData.length > 0) {
								for (var i = 0; i < rowData.length; i++) {

									console.log("edit_specification Quantity rowData ==> "+i+" :" + rowData[i].quantity);

									var device = {

										deviceSupportedId : {
											id : rowData[i].id
										},
										quantity : rowData[i].quantity

									};

									devices[i] = device;
								}

								var systemsModelSpecification = {
									"type" : "object",
									"specification" : {
										id:selectedSpecification,
										deviceSupported : $deviceSupported.val(),
										maxPowerOutput : $maxPowerOutput.val(),
										model : $model.val(),
										qualityVerified : $qualityVerified.val(),
										wp : $wp.val(),
										companyId : {
											id : $companyId.val()
										},
										"specificationDeviceList" : devices
									}

								}
							}

							var systemsModelSpecificationJSONString = JSON
									.stringify(systemsModelSpecification);

							console
									.log("Systems Model Specification Submission JSON: "
											+ systemsModelSpecificationJSONString);

							$.ajax({
										headers : {
											'Accept' : 'application/json',
											'Content-Type' : 'application/json'
										},
										type : "PUT",
										url : UPDATE_KIT_SPECIFICATION,
										data : systemsModelSpecificationJSONString,
										dataType : "json",
										success : function(data, status) {
											// loader.hideLoading();
											if (data.result) {
												// loader.hideLoading();
												showServerResponse(
														"Success",
														"Systems Specification added successfully",
														"success");
												console
														.log("Systems Specification Feedback: "
																+ data.message);
											} else {
												// loader.hideLoading();
												showServerResponse(
														"ERROR",
														"An error Occured while adding Systems Specification",
														"error");
											}

										},
										error : function(jqXHR, textStatus,
												errorThrown) {
											// loader.hideLoading();
											showServerResponse("ERROR",
													"An error Occured while adding Systems Specification "
															+ textStatus,
													"error");
											if (errorThrown == 'Unauthorized') {

												// onSessionTimeOut();
											}
										}
									});

						});
	}

	function showServerResponse(title, msg, type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}
});