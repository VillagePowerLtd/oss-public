$(function (){
	
	loadCompanyReporting();
	
	$('#save_config_button').click(function (){
		
		var $geographicSegment=$('#geographic_segment');
		var $minimum_number=$('#minimum_number');
		
		var reporting = {
				"type" : "object",
				"reporting" : {
					level : $geographicSegment.val(),
					minimum : $minimum_number.val()

				}
			};

			var reportingDataJSONString = JSON.stringify(reporting);
			
			$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json'
				},
				type : "POST",
				url : ADD_COMPANY_REPORTING,
				data : reportingDataJSONString,
				dataType : "json",
				success : function(data, status) {
					
					if(data.result=true){
						
						showServerResponse("Success", "Saved Successfully", "success");
						loadCompanyReporting();
						console.log(data);
					}else{
						showServerResponse("ERROR", "Not Saved", "error");
						
					}
										
				}
			});
		
		
	});
	
	function loadCompanyReporting(){
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "GET",
			url : RETRIEVE_COMPANY_REPORTING,
			dataType : "json",
			success : function(data, status) {

				var table = $('#company_reporting_table')
						.DataTable(
								{
									buttons : [ 'copy', 'excel', 'pdf' ],
									destroy : true,
									data : data.reporting,

									columns : [ null, {
										data : "id"
									}, {
										data : "level"
									}, {
										data : "minimum"
									}, null

									],
									columnDefs : [
											{
												orderable : false,
												targets : 0,
												defaultContent : "",
												className : 'select-checkbox',
											},
											{
												targets : -1,
												data : null,
												defaultContent : " <a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit_min_no_company_reporting_config_modal'></i></a><a href='#' class='on-default remove-row'><i class='fa fa-trash-o'></i></a>"
											}, {
												targets : [ 1 ],
												visible : false
											} ],

									select : {
										style : 'os',
										selector : 'td:first-child'
									},

									order : [ [ 1, 'asc' ] ]

								});
				
				updateMinReportingData(table);

			}
		});
	}
	
	function updateMinReportingData(table){
		
		$('a.edit-row').click(function (){ 
			
			console.log("updateMinReportingData: Clicked");
			
			var selectedRow = table.row( { selected: true } ).data();
			
			console.log("selectedRow: "+selectedRow);

			$("#edit_geographic_segment").val(selectedRow.level); 
			
			$("#edit_minimum_number").val(selectedRow.minimum);
			  
			
			$('#edit_config_button').click(function() {
				
				var $geographicSegment=$('#edit_geographic_segment');
				var $minimum_number=$('#edit_minimum_number');
				
				var reporting = {
						"type" : "object",
						"reporting" : {
							id:selectedRow.id,
							level : $geographicSegment.val(),
							minimum : $minimum_number.val()
							

						}
					};

					var reportingDataJSONString = JSON.stringify(reporting);
					
					console.log("reportingDataJSONString: "+reportingDataJSONString);
					
					$.ajax({
						headers : {
							'Accept' : 'application/json',
							'Content-Type' : 'application/json'
						},
						type : "PUT",
						url : UPDATE_COMPANY_REPORTING,
						data : reportingDataJSONString,
						dataType : "json",
						success : function(data, status) {
							
							if(data.result=true){
								
								showServerResponse("Success", "Updated Successfully", "success");
								loadCompanyReporting();
								console.log(data);
							}else{
								showServerResponse("ERROR", "Not Updated", "error");
								
							}
												
						}
					});
					
			});
		});
	}
	
	function showServerResponse(title, msg, type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}
});