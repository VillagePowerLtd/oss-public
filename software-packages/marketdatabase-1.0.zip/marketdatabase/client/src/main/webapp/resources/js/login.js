$(function() {

	login();
	
	function login(){
		$("#login_button").click(function() {
			var $userName = $("#user_name");
			var $password = $("#password");

			var user = {
				"username" : $userName.val(),
				"password" : $password.val(),
				"rememberMe" : "false"
			}
			
			var userJSONString = JSON.stringify(user);
			
			$.ajax({
				headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "POST",
			url : LOGIN,
			data : userJSONString,
			dataType : "json",
			success : function(data, status){
				 
				  if(data.result==true){
					  $.cookie("loginToken", data.jwt);
					  $.cookie("userRole", data.user.role);
					  $.cookie("userName", data.user.firstname+' '+data.user.lastname);
					  $.cookie("logedInUserCompany", data.user.companyId.id);
					  $.cookie("logedInUserId", data.user.userId);
					 
					  if(($.cookie('userRole') == 'Overall admin')){
						  
					  }else if(($.cookie('userRole') == 'Company admin')){
						  
					  }
	 				  else {
	 					  
						}
					  window.location.replace("index.html");
					  
				  }else{ 
					  $( "#error" ).removeClass( "hidden")
					  $('#error').addClass("show_error");
					  showServerResponse("ERROR","The username and/or password entered has not been recognised. Please enter your credentials again or reset your password","error");
					  console.log('ERROR Login');
				  }
				 
			}
			});
		});
		
	}
	
	function loginTest(){

		$("#login_button").click(function() {
			var $userName = $("#user_name");
			var $password = $("#password");

			 
			  if($userName.val()!=''&&$password.val()!=''){
				  
				  $.cookie("loginToken", '123');
				  $.cookie("userRole", $password.val());
				  $.cookie("userName", $userName.val());
				  $.cookie("logedInUserCompany", $userName.val());
				 
				  if(($.cookie('userRole') == 'overall admin')){
					  
				  }else if(($.cookie('userRole') == 'company admin')){
					  
				  }
 				  else {
 					  
					}
				  window.location.replace("index.html");
			  }else{ 
				  $( "#error" ).removeClass( "hidden")
				  $('#error').addClass("show_error");
				  showServerResponse("ERROR","The username and/or password entered has not been recognised. Please enter your credentials again or reset your password","error");
				  console.log('ERROR Login');
			  }
			 
		
			
			 
		});
		
	
	}
	

function showServerResponse(title, msg, type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}

});