$(function() {

	loadDistricts();
	loadCounties();
	loadSubcounties();

	uploadSubmitButtonClicked();

	function loadDistricts() {
		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "GET",
					url : RETRIEVE_DISTRICTS_QUERY,
					dataType : "json",
					success : function(data, status) {

						var table = $('#district_table')
								.DataTable(
										{
											buttons : [ 'copy', 'excel', 'pdf' ],
											destroy : true,
											data : data.districts,

											columns : [ null, {
												data : "id"
											}, {
												data : "districtName"
											}, {
												data : "latitude"
											}, {
												data : "longitude"
											}, null

											],
											columnDefs : [
													{
														orderable : false,
														targets : 0,
														defaultContent : "",
														className : 'select-checkbox',
													},
													{
														targets : -1,
														data : null,
														defaultContent : " <a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit-batch-modal'></i></a><a href='#' class='on-default remove-row'><i class='fa fa-trash-o'></i></a>"
													}, {
														targets : [ 1 ],
														visible : false
													} ],

											select : {
												style : 'os',
												selector : 'td:first-child'
											},

											order : [ [ 1, 'asc' ] ]

										});

					}
				});
	}

	function loadCounties() {

		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "GET",
					url : RETRIEVE_COUNTIES,
					dataType : "json",
					success : function(data, status) {

						var table = $('#counties_table')
								.DataTable(
										{
											buttons : [ 'copy', 'excel', 'pdf' ],
											destroy : true,
											data : data.counties,

											columns : [
													null,
													{
														data : "id"
													},
													{
														data : "districtId.districtName"
													}, {
														data : "countyName"
													}, {
														data : "latitude"
													}, {
														data : "longitude"
													}, null

											],
											columnDefs : [
													{
														orderable : false,
														targets : 0,
														defaultContent : "",
														className : 'select-checkbox',
													},
													{
														targets : -1,
														data : null,
														defaultContent : " <a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit-batch-modal'></i></a><a href='#' class='on-default remove-row'><i class='fa fa-trash-o'></i></a>"
													}, {
														targets : [ 1 ],
														visible : false
													} ],

											select : {
												style : 'os',
												selector : 'td:first-child'
											},

											order : [ [ 1, 'asc' ] ]

										});

					}
				});

	}
	function loadSubcounties() {

		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "GET",
					url : RETRIEVE_SUB_COUNTIES,
					dataType : "json",
					success : function(data, status) {

						var table = $('#subcounties_table')
								.DataTable(
										{
											buttons : [ 'copy', 'excel', 'pdf' ],
											destroy : true,
											data : data.subCounties,

											columns : [ null, {
												data : "id"
											}, {
												data : "countyId.countyName"
											}, {
												data : "subCountyName"
											}, {
												data : "latitude"
											}, {
												data : "longitude"
											}, null

											],
											columnDefs : [
													{
														orderable : false,
														targets : 0,
														defaultContent : "",
														className : 'select-checkbox',
													},
													{
														targets : -1,
														data : null,
														defaultContent : " <a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit-batch-modal'></i></a><a href='#' class='on-default remove-row'><i class='fa fa-trash-o'></i></a>"
													}, {
														targets : [ 1 ],
														visible : false
													} ],

											select : {
												style : 'os',
												selector : 'td:first-child'
											},

											order : [ [ 1, 'asc' ] ]

										});

					}
				});

	}
	function loadParishes() {
		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "GET",
					url : RETRIEVE_PARISHES,
					dataType : "json",
					success : function(data, status) {

						var table = $('#parishes_table')
								.DataTable(
										{
											buttons : [ 'copy', 'excel', 'pdf' ],
											destroy : true,
											data : data.districts,

											columns : [ null, {
												data : "id"
											}, {
												data : "districtName"
											}, {
												data : "districtName"
											}, {
												data : "districtName"
											}, {
												data : "districtName"
											}, null

											],
											columnDefs : [
													{
														orderable : false,
														targets : 0,
														defaultContent : "",
														className : 'select-checkbox',
													},
													{
														targets : -1,
														data : null,
														defaultContent : " <a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit-batch-modal'></i></a><a href='#' class='on-default remove-row'><i class='fa fa-trash-o'></i></a>"
													}, {
														targets : [ 1 ],
														visible : false
													} ],

											select : {
												style : 'os',
												selector : 'td:first-child'
											},

											order : [ [ 1, 'asc' ] ]

										});

					}
				});

	}
	function loadVillages() {

		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "GET",
					url : RETRIEVE_VILLAGES,
					dataType : "json",
					success : function(data, status) {

						var table = $('#village_table')
								.DataTable(
										{
											buttons : [ 'copy', 'excel', 'pdf' ],
											destroy : true,
											data : data.districts,

											columns : [ null, {
												data : "id"
											}, {
												data : "districtName"
											}, {
												data : "districtName"
											}, {
												data : "districtName"
											}, {
												data : "districtName"
											}, null

											],
											columnDefs : [
													{
														orderable : false,
														targets : 0,
														defaultContent : "",
														className : 'select-checkbox',
													},
													{
														targets : -1,
														data : null,
														defaultContent : " <a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit-batch-modal'></i></a><a href='#' class='on-default remove-row'><i class='fa fa-trash-o'></i></a>"
													}, {
														targets : [ 1 ],
														visible : false
													} ],

											select : {
												style : 'os',
												selector : 'td:first-child'
											},

											order : [ [ 1, 'asc' ] ]

										});

					}
				});
	}

	function uploadSubmitButtonClicked() {
		
		
		$('#district_upload_button').click(
				function() {

					console.log('District upload loading.');

					uploadDistrictsFile(document
							.getElementById('districtFileInput').files[0]);

				});
		

		$('#county_upload_button').click(
				function() {

					console.log('county upload loading.');

					uploadCountiesFile(document
							.getElementById('countyFileInput').files[0]);

				});

		$('#subcounty_upload_button').click(
				function() {

					uploadSubCountiesFile(document
							.getElementById('subcountyFileInput').files[0]);

				});

	}
	
	
	function uploadDistrictsFile(file) {
		var url = 'http://104.236.194.94:9090/marketDatabase-1.0-SNAPSHOT/webresources/loan/districtUpload';
		var xhr = new XMLHttpRequest();
		var fd = new FormData();
		xhr.open("POST", url, true);
		xhr.onreadystatechange = function() {
			if (xhr.readyState == 4 && xhr.status == 200) {
				// Every thing ok, file uploaded
				// handle response.
				var data = JSON.parse(xhr.responseText);
				console.log(data);
				if (data.result == true) {
					showServerResponse("Success", data.message, "success")
				} else {
					showServerResponse("Success", data.errorMessage, "error")
				}

			}
		};

		console.log('Uploading Counties file Batch:');

		fd.append("file", file);
		xhr.send(fd);
	}

	function uploadCountiesFile(file) {
		var url = 'http://104.236.194.94:9090/marketDatabase-1.0-SNAPSHOT/webresources/county/countyUpload';
		var xhr = new XMLHttpRequest();
		var fd = new FormData();
		xhr.open("POST", url, true);
		xhr.onreadystatechange = function() {
			if (xhr.readyState == 4 && xhr.status == 200) {
				// Every thing ok, file uploaded
				// handle response.
				var data = JSON.parse(xhr.responseText);
				console.log(data);
				if (data.result == true) {
					showServerResponse("Success", data.message, "success")
				} else {
					showServerResponse("Success", data.errorMessage, "error")
				}

			}
		};

		console.log('Uploading Counties file Batch:');

		fd.append("file", file);
		xhr.send(fd);
	}

	function uploadSubCountiesFile(file) {
		var url = 'http://104.236.194.94:9090/marketDatabase-1.0-SNAPSHOT/webresources/SubCounty/subCountyUpload';
		var xhr = new XMLHttpRequest();
		var fd = new FormData();
		xhr.open("POST", url, true);
		xhr.onreadystatechange = function() {
			if (xhr.readyState == 4 && xhr.status == 200) {
				// Every thing ok, file uploaded
				// handle response.
				var data = JSON.parse(xhr.responseText);
				console.log(data);
				if (data.result == true) {
					showServerResponse("Success", data.message, "success")
				} else {
					showServerResponse("Success", data.errorMessage, "error")
				}

			}
		};

		console.log('Uploading Sub-Counties file Batch:');

		fd.append("file", file);
		xhr.send(fd);
	}

	function showServerResponse(title, msg, type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}

});