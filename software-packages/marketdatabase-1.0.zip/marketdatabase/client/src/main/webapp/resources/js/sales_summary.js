$(function(){
	
	loadSummaryData();
	
	function loadSummaryData(){
		
		var $queryType='system';
        var $country=$.cookie('selectedCountry');
        var $district=$.cookie('selectedDistrict');
        
        console.log('$country: '+$country);
        console.log('$district: '+$district);
        
        var query = {
				"type" : "object",
				"systemSoldQuery" : {
					queryType : $queryType,
					country : $country,
					district : $district

				}
			};
        
        var queryJSONString = JSON.stringify(query);
        
         
        $.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "GET",
			url : RETRIEVE_SUBCOUNTY_SALES_SUMMARY_HISTORY, 
			dataType : "json",
			success : function(data, status) {

				if (data.result) {
					//showServerResponse("Success", data.message, "success")
					//console.log("Result: " + data);
					loadSummaryDataFile(data);
				} else {
					showServerResponse("ERROR", data.errorMessage, "error")
					// loadBathesTable();
				}

			},
			error : function(jqXHR, textStatus, errorThrown) {
				
				if (errorThrown == 'Unauthorized') {

					// onSessionTimeOut();
				}
			}
		});
	
	}
	


function loadSummaryDataFile(data) {
	
	var counter=0;
	
	var queryDataArray = [];
	
	var $lastupdated;
	
	for(var i=0;i<data.subCountySystemSoldHist.length;i++){
		
		$lastupdated=data.subCountySystemSoldHist[i].dateCreated;
		
		var queryData = {
				subCountyName: data.subCountySystemSoldHist[i].subCountyName,
				totalSystemSold : data.subCountySystemSoldHist[i].systemsSoldNumber,
				totalQualityVerifiedSystems : data.subCountySystemSoldHist[i].qulaityVerifiedNumber,
				totalInstalledCapacity: data.subCountySystemSoldHist[i].capacityInstalledNumber,
				totalPAYGoSystemsSold: data.subCountySystemSoldHist[i].systemsOnPayGoNumber,
				totalPAR30:data.subCountySystemSoldHist[i].pAR30number,
				totalDefualtRate:data.subCountySystemSoldHist[i].defaulted,
				lastupdated:$lastupdated
				
				
			};
		
		queryDataArray[i] = queryData;
	}
	
		var table = $('#sales_summary_table').DataTable({
			
			destroy : true,
			data : queryDataArray,
			pageLength: 100,
			dom: 'Bfrtip',
			buttons: [
				'pageLength'
			],
			columns : [ 
			{
				name : "UploadDate",
				title : "Upload date",
				data : "lastupdated"
			},
			{
				name : "subCountyName",
				title : "SubCounty",
				data : "subCountyName"
			},
			
			{
				name : "totalSystemsSold",
				title: "Total systems sold",
				data:	"totalSystemSold"
			}, {
				name : "totalQualityVerifiedSystems",
				title : "Total quality verified systems",
				data : "totalQualityVerifiedSystems"
			}, {
				name : "totalInstalledCapacity",
				title : "Total capacity installed",
				data : "totalInstalledCapacity" 
			},
			{
				name : "totalPAYGoSystemsSold",
				title : "Total systems sold on PAYG",
				data : "totalPAYGoSystemsSold" 
			},
			{
				name : "totalPAR30",
				title : "Portfolio at risk",
				data : "totalPAR30" 
			}
			,
			{
				name : "totalDefualtRate",
				title : "Default rate",
				data : "totalDefualtRate" 
			}
			]
		
		});

	}
	
	
	function showServerResponse(title, msg,type) {
		var $toastlast; 

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}
});