$(function() {
	
	var loginToken= $.cookie('loginToken');
	
	getLogedInUser(loginToken);

	//retrieveDevicesSupported();
	//addNewDeviceSupported();
	 
	
	$('#new_device_supported_button').click(function (){
		loadCompanyCombo();
	});
	
	
	
	function getLogedInUser(loginToken){
		
		var loginTokenJSON = {
				"token" : loginToken
			};

			
			var loginTokenJSONString = JSON.stringify(loginTokenJSON);
			
			console.log('loginTokenJSONString: '+loginTokenJSONString);

			$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json'
				},
				type : "POST",
				url : GET_LOGED_IN_USER,
				data : loginTokenJSONString,
				dataType : "json",
				success : function(data, status) { 
					if(data.result){ 
						console.log("data true: "+JSON.stringify(data));
						
						var $userRole=data.user.role;
						var $logedInUserCompany=data.user.companyId.id;
						var $logedInUserId=data.user.userId;
						
						retrieveDevicesSupported($userRole,$logedInUserCompany,$logedInUserId);
						addNewDeviceSupported($userRole,$logedInUserId,$logedInUserCompany);
						   
					}else{
						console.log("data false: "+JSON.stringify(data));
					}
					
				},
				error : function(jqXHR, textStatus,
						errorThrown) { 
					
					if (errorThrown == 'Unauthorized') {
	 
					}
				}
			});
	}

	function addNewDeviceSupported($userRole,$logedInUserId,$logedInUserCompany) {
		$('#save_device_button').click(function() {

			var $description = $('#description');
			var $code = $('#code');
			var $devicesName = $('#device');

			var $company = $('#company');

			//$company.val()
			
			var deviceSupported = {
				"type" : "object",
				"deviceSupported" : {
					description : $description.val(),
					code : $code.val(),
					devicesName : $devicesName.val(),
					companyId : {
						id : $logedInUserCompany
					}
				},
				"users":{
					userId:$logedInUserId
				}
			};

			var deviceSupportedJSONString = JSON.stringify(deviceSupported);

			console.log("Device Supported Json: " + deviceSupportedJSONString);

			$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json'
				},
				type : "POST",
				url : ADD_NEW_DEVICE_SUPPORTED,
				data : deviceSupportedJSONString,
				dataType : "json",
				success : function(data, status) {

					if (data.result) {
						showServerResponse("Success", data.message, "success")
						console.log("Result: " + data);
						//loadDevicesSupported(data);
						loadDevicesSupported(data,$userRole,$logedInUserCompany,$logedInUserId)
					} else {
						showServerResponse("ERROR", data.errorMessage, "error")
						// loadBathesTable();
					}

				},
				error : function(jqXHR, textStatus, errorThrown) {
					loader.hideLoading();
					if (errorThrown == 'Unauthorized') {

						// onSessionTimeOut();
					}
				}
			});

		});
	}

	function retrieveDevicesSupported($userRole,$logedInUserCompany,$logedInUserId) {
		$.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "GET",
			url : RETRIEVE_DEVICES_SUPPORTED,
			dataType : "json",
			success : function(data, status) {

				if (data.result) {

					//loadDevicesSupported(data);
					loadDevicesSupported(data,$userRole,$logedInUserCompany,$logedInUserId)

				} else {

					showServerResponse("ERROR", data.errorMessage, "error")

				}

			},
			error : function(jqXHR, textStatus, errorThrown) {

				if (errorThrown == 'Unauthorized') {

					// onSessionTimeOut();
				}
			}
		});
	}

	function loadDevicesSupported(data,$userRole,$logedInUserCompany,$logedInUserId) {
		
		
		var counter=0;
		
		var devicesList = [];
		
		for(var i=0;i<data.devicesSupported.length;i++){
			
			var $companyName=data.devicesSupported[i].companyId.name;
			var $companyId=data.devicesSupported[i].companyId.id;
			
			if(data.devicesSupported[i].master){
				$companyName="Master list";
				$companyId="Master";
			}else{
				 
			}
			
			
			var device = {
					id : data.devicesSupported[i].id,
					code : data.devicesSupported[i].code,
					devicesName: data.devicesSupported[i].devicesName,
					description:data.devicesSupported[i].description,
					companyName: $companyName,
					companyId: $companyId
					
				};
			
				if($userRole=='Overall admin'){
					devicesList[counter] = device;
					counter++;
					 
				}else{
					
					//if not super administrator only give master list,and company devices.
					
					
					if($companyId=="Master"){
						 
						devicesList[counter] = device;
						counter++;
						 
					}else{
						 
						
						if( $companyId==$logedInUserCompany){
							 
							devicesList[counter] = device;
							counter++;
						}else{
							
						}
					}
				}
			
				
		}
		
		console.log("logedInUserCompany device==> "+devicesList.length);
		
	 
		var table = $('#devices_supported_table')
				.DataTable(
						{
							buttons : [ 'copy', 'excel', 'pdf' ],
							destroy : true,
							data : devicesList,

							columns : [ null,
							{
								data : "id"
							},
							{
								data : "code"
							}, {
								data : "devicesName"
							}, {
								data : "description"
							}, {
								data : "companyName"
							},
							{
								data : "companyId"
							},
							null

							],
							columnDefs : [
									{
										orderable : false,
										targets : 0,
										defaultContent : "",
										className : 'select-checkbox',
									},
									{
										targets : -1,
										data : null,
										defaultContent : "<a href='#' class='on-default edit-row'><i class='fa fa-pencil' data-toggle='modal' data-target='#edit_devices_supported_modal'></i></a><a href='#' class='on-default remove-row'><i class='fa fa-trash-o'></i></a>"
									}, {
										targets : [ 1 ],
										visible : false
									} ],

							select : {
								style : 'os',
								selector : 'td:first-child'
							},

							order : [ [ 1, 'asc' ] ]

						});
		
		$('#devices_supported_table').on('page.dt', function() {
			  
			updateDeviceSupportedToEdit(table,$userRole,$logedInUserId);
			deleteDeviceSupported(table,$userRole,$logedInUserId);
			
			});
			
			
			$('#devices_supported_table').on('draw.dt', function() {
				  
				updateDeviceSupportedToEdit(table,$userRole,$logedInUserId);
				deleteDeviceSupported(table,$userRole,$logedInUserId);
			});
			
		updateDeviceSupportedToEdit(table,$userRole,$logedInUserId);
		deleteDeviceSupported(table,$userRole,$logedInUserId);

	}
	
	function loadCompanyCombo(){
		$
		.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "GET",
			url : RETRIEVE_COMPANY,
			dataType : "json",
			success : function(data, status) {

				var options = '';
				options += ' <option value="'
					+ 'master list' + '">'
					+ 'Master List' + '</option>';
				for ( var companyCount = 0; companyCount < data.companies.length; companyCount++) {
					 
					options += ' <option value="'
							+ data.companies[companyCount].id + '">'
							+ data.companies[companyCount].name
							+ '</option>';
				}
				$('#company').html(options);
				$("#company").select2().select2('val','master list');
			}

		});
		
	}
	
	function loadCompanyComboToEdit(){
		$
		.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "GET",
			url : RETRIEVE_COMPANY,
			dataType : "json",
			success : function(data, status) {

				var options = '';
				options += ' <option value="'
					+ 'master list' + '">'
					+ 'Master List' + '</option>';
				for ( var companyCount = 0; companyCount < data.companies.length; companyCount++) {
					 
					options += ' <option value="'
							+ data.companies[companyCount].id + '">'
							+ data.companies[companyCount].name
							+ '</option>';
				}
				$('#edit_company').html(options);
				$("#edit_company").select2().select2('val','master list');
			}

		});
		
	}
	
	
	function updateDeviceSupportedToEdit(table,$userRole,$logedInUserId,$logedInUserCompany){
		
		$('a.edit-row').click(function (){
			
			loadCompanyComboToEdit();
			
			var selectedDevice = table.row( { selected: true } ).data();
			

			$("#edit_company").val(selectedDevice.companyId);
			
			console.log("Company Id: "+selectedDevice.companyId);
			
			$("#edit_code").val(selectedDevice.code);
			$("#edit_device").val(selectedDevice.devicesName);
			$("#edit_description").val(selectedDevice.description);
			
			
			$('#update_device_button').click(function() {
				
				var $description = $('#edit_description');
				var $code = $('#edit_code');
				var $devicesName = $('#edit_device');
				var $company = $('#edit_company');

				var deviceSupported = {
					"type" : "object",
					"deviceSupported" : {
						id:selectedDevice.id,
						description : $description.val(),
						code : $code.val(),
						devicesName : $devicesName.val(),
						companyId : {
							id : $company.val()
						}
						
					},
					"users":{
						userId:$logedInUserId
					}
				
				};

				var deviceSupportedJSONString = JSON.stringify(deviceSupported);
				
				console.log("loading update batch: "+deviceSupportedJSONString);
				
				$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "PUT",
					url : UPDATE_DEVICE_SUPPORTED,
					data : deviceSupportedJSONString,
					dataType : "json",
					success : function(data, status) {
						
						if (data.result) {
							showServerResponse("Success", data.message, "success")
							console.log("Result: " + data);
							(data);
							
						} else {
							showServerResponse("ERROR", data.errorMessage, "error")
							 
						}
						
					},
					error : function(jqXHR, textStatus,
							errorThrown) {
						loader.hideLoading();
						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}
				});

			});
		});
	}
	
	function deleteDeviceSupported(table,$userRole,$logedInUserId,$logedInUserCompany){
		
		console.log("loading DELETE batch: OUT");
		
		$('#devices_supported_table').on('click', 'a.remove-row', function (){
			
			console.log("loading DELETE batch: IN");
			
			var selectedDevice = table.row( { selected: true } ).data();
			
				var deviceSupported = {
					"type" : "object",
					"deviceSupported" : {
						id:selectedDevice.id,
						description : selectedDevice.description,
						code : selectedDevice.code,
						devicesName : selectedDevice.devicesName,
						companyId : {
							id :selectedDevice.companyId.id
						}
					},
					"users":{
						userId:$logedInUserId
					}
				};

				var deviceSupportedJSONString = JSON.stringify(deviceSupported);
				
				console.log("loading DELETE batch: "+deviceSupportedJSONString);
				
				$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "POST",
					url : DELETE_DEVICE_SUPPORTED,
					data : deviceSupportedJSONString,
					dataType : "json",
					success : function(data, status) {
						
						if (data.result) {
							showServerResponse("Success", data.message, "success")
							console.log("Result: " + data); 
							
							loadDevicesSupported(data,$userRole,$logedInUserCompany,$logedInUserId)
							
						} else {
							showServerResponse("ERROR", data.errorMessage, "error")
							 
						}
						
					},
					error : function(jqXHR, textStatus,
							errorThrown) {
						loader.hideLoading();
						if (errorThrown == 'Unauthorized') {

							onSessionTimeOut();
						}
					}
				}); 
		});
	}

	function showServerResponse(title, msg, type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}
});