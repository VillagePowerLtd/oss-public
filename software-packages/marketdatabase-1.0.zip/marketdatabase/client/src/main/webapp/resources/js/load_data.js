$(function() {
	
	loadCountryCombo();
	loadDistrictCombo();
	loadCountyCombo()
	loadSubCountCombo();
	
	$("#district").change(function() {
		
		loadCountyComboByDistrict();
	});
	
	$("#county_combo").change(function() {
		
		loadSubCountComboByCounty();
	});
	
	 
	function loadCountryCombo() {
		$
				.ajax({
					type : "GET",
					url : 'https://restcountries.eu/rest/v1/all',
					dataType : "json",
					success : function(data, status) {

						var options = '';
						for (var countryCount = 0; countryCount < data.length; countryCount++) {
							
							
							
							if(data[countryCount].name=='Uganda'){
								
								options += ' <option value="'
									+ data[countryCount].name + '" selected="Uganda">'
									+ data[countryCount].name + '</option>'; 
								
								
							}else{
								
								options += ' <option value="'
									+ data[countryCount].name + '">'
									+ data[countryCount].name + '</option>';
							}
						}
						
						$("#country").val('Uganda');
						$('#country').html(options);
						$("#country").select2().select2('val',$('#country').val());
						
					}

				});
	}
	
	
	function loadDistrictCombo() {
		
		$
				.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "GET",
					url : RETRIEVE_DISTRICTS_QUERY,
					dataType : "json",
					success : function(data, status) {

						var options = '';
						
						options += ' <option value="'
							+ ' ' + '">'
							+ ' ' + '</option>';
						
						options += ' <option value="'
							+ 'All' + '">'
							+ 'All' + '</option>';
						for (var districtCount = 0; districtCount < data.districts.length; districtCount++) {
							
							options += ' <option value="'
									+ data.districts[districtCount].districtName + '">'
									+ data.districts[districtCount].districtName + '</option>';
							
						}
						 console.log("Loading districts data");
						$('#district').html(options);	
						
						
					}
				});
	}
	
function loadCountyCombo() {
		
		$.ajax({
					headers : {
						'Accept' : 'application/json',
						'Content-Type' : 'application/json'
					},
					type : "GET",
					url : RETRIEVE_COUNTIES,
					dataType : "json",
					success : function(data, status) {

						var options = '';
						options += ' <option value="' 
							+ ' ' + '">'
							+ ' ' + '</option>';
						
						options += ' <option value="' 
							+ 'All' + '">'
							+ 'All' + '</option>';
						for (var count = 0; count < data.counties.length; count++) {
							
							options += ' <option value="'
									+ data.counties[count].countyName + '">'
									+ data.counties[count].countyName + '</option>';
							
						}
						 console.log("Loading Counties data");
						$('#county_combo').html(options);
						
						
					}
				});
	}

function loadCountyComboByDistrict(){
	
	var $districtId = $('#district');

	var district = {
		"type" : "object",
		"district" : {
			districtName : $districtId.val(),

		}
	};

	var districtDataJSONString = JSON.stringify(district);

	
	$.ajax({
		headers : {
			'Accept' : 'application/json',
			'Content-Type' : 'application/json'
		},
		type : "POST",
		url : RETRIEVE_COUNTIES_BY_DISTRICT,
		data : districtDataJSONString,
		dataType : "json",
		success : function(data, status) {

			var options = '';
			options += ' <option value="' 
				+ ' ' + '">'
				+ ' ' + '</option>';
			options += ' <option value="' 
				+ 'All' + '">'
				+ 'All' + '</option>';
			for (var count = 0; count < data.counties.length; count++) {
				
				options += ' <option value="'
						+ data.counties[count].countyName + '">'
						+ data.counties[count].countyName + '</option>';
				
			}
			 console.log("Loading Counties data");
			$('#county_combo').html(options);
			 
		}
	});
}

function loadSubCountCombo() {
	
	$.ajax({
				headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json'
				},
				type : "GET",
				url : RETRIEVE_SUB_COUNTIES,
				dataType : "json",
				success : function(data, status) {

					var options = '';
					options += ' <option value="'
						+ ' ' + '">'
						+ ' ' + '</option>';
					options += ' <option value="'
						+ 'All' + '">'
						+ 'All' + '</option>';
					for (var count = 0; count < data.subCounties.length; count++) {
						
						options += ' <option value="'
								+ data.subCounties[count].subCountyName + '">'
								+ data.subCounties[count].subCountyName + '</option>';
						
					}
					 console.log("Loading subcounties data");
					$('#sub_county_combo').html(options);	
					
					
				}
			});
}

function loadSubCountComboByCounty() {
	
	var $countyId = $('#county_combo');

	var county = {
		"type" : "object",
		"county" : {
			countyName : $countyId.val(),

		}
	};

	var countyDataJSONString = JSON.stringify(county);
	
	$.ajax({headers : {
					'Accept' : 'application/json',
					'Content-Type' : 'application/json'
				},
				type : "POST",
				url : RETRIEVE_SUB_COUNTIES_BY_COUNTY,
				dataType : "json",
				data : countyDataJSONString,
				success : function(data, status) {

					var options = '';
					options += ' <option value="'
						+ ' ' + '">'
						+ ' ' + '</option>';
					options += ' <option value="'
						+ 'All' + '" selected="All">'
						+ 'All' + '</option>';
					for (var count = 0; count < data.subCounties.length; count++) {
						
						options += ' <option value="'
								+ data.subCounties[count].subCountyName + '">'
								+ data.subCounties[count].subCountyName + '</option>';
						
					}
					 console.log("Loading subcounties data");
					$('#sub_county_combo').html(options);
					
					
				}
			});
}
	
	
$('#loan_data').click(function() {
		console.log('Loading Button clicked');
		
		var $outPutOption = $('#out_put_option');
		
		console.log('Loading Button query: ' + $outPutOption.val());
		
		var $selectedQuery=$('#query_type_combo');
		
		var $selectedCountry=$('#country');
		
		var $selectedOption=$('#out_put_option');
		
		var $selectedDistrict=$('#district');
		
		var $selectedCounty=$('#county_combo');
		
		var $selectedSubcounty=$('#sub_county_combo');
		
		
		console.log('District selected: '+$selectedDistrict.val());
		
		if($selectedQuery.val()==''){
			
			showServerResponse('ERROR', 'ERROR: Please Select Query type','error');
			
		}else if($selectedCountry.val()==''){
			showServerResponse('ERROR', 'ERROR: Please Select Country','error');
			
		}else if($selectedDistrict.val()==' '){
			showServerResponse('ERROR', 'ERROR: Please select an option in the District, County, or Sub-County input fields','error');
		}else{

			$.cookie("selectedQuery", $selectedQuery.val());
			$.cookie("selectedCountry", $selectedCountry.val());
			$.cookie("selectedOption", $selectedOption.val());
			$.cookie("selectedDistrict", $selectedDistrict.val());
			$.cookie("selectedCounty", $selectedCounty.val());
			$.cookie("selectedSubcounty", $selectedSubcounty.val());

		if ($outPutOption.val() == 'table') {
			
			var $queryType = $('#query_type_combo');

			if ($queryType.val() == 'systems_sold') {
				
				console.log('Systems sold query')
				
				if($selectedDistrict.val()=='All'){
					
					if(($selectedCounty.val()==' ')&&($selectedSubcounty.val()==' ')){
						window.location.replace("systems_sold.jsp");
					}else{
						if($selectedCounty.val()=='All'){
							if($selectedSubcounty.val()==' '){
								window.location.replace("all_county_systems_sold.jsp");
							}else{
								if($selectedSubcounty.val()=='All'){
									
									window.location.replace("all_sub_county_systems_sold.jsp");
								}else{
									if($selectedSubcounty.val()==' '){
										//showServerResponse('ERROR', 'ERROR: Please Select Sub Country','error');
										window.location.replace("county_systems_sold.jsp");
									}else{
										window.location.replace("sub_county_systems_sold.jsp");
									}
								}
							}
						}else{
							if($selectedCounty.val()==' '){
								
							}else{
								if($selectedSubcounty.val()=='All'){
									window.location.replace("all_sub_county_systems_sold.jsp");
								}else{
								if($selectedSubcounty.val()==' '){
									
								}else{
									window.location.replace("sub_county_systems_sold.jsp");
								}
								}
							}
						}
					}
					
					
					
				} 	
				else{
					
					if($selectedDistrict.val()==' '){
						showServerResponse('ERROR', 'ERROR: Please Select District','error');
					}else{
						if(($selectedCounty.val()==' ')&&($selectedSubcounty.val()==' ')){
							
						}else{
							if($selectedSubcounty.val()==' '){
								window.location.replace("county_systems_sold.jsp");
							}else{
								if($selectedSubcounty.val()=='All'){
									window.location.replace("all_sub_county_systems_sold.jsp");
								}else{
									
									if($selectedSubcounty.val()==' '){
										//showServerResponse('ERROR', 'ERROR: Please Select Sub Country','error');
										window.location.replace("county_systems_sold.jsp");
									}else{
										window.location.replace("sub_county_systems_sold.jsp");
									}
								}
							}
						}
					}
						
				}
					
					
				}
				else if ($queryType.val() == 'quality_verified_systems_sold') {
				
					if($selectedDistrict.val()=='All'){
						
						if(($selectedCounty.val()==' ')&&($selectedSubcounty.val()==' ')){
							window.location.replace("quality_verified_systems_sold.jsp");
						}else{
							if($selectedCounty.val()=='All'){
								if($selectedSubcounty.val()==' '){
									window.location.replace("all_county_quality_verified_systems_sold.jsp");
								}else{
									if($selectedSubcounty.val()=='All'){
										
										window.location.replace("all_sub_county_quality_verified_systems_sold.jsp");
									}else{
										if($selectedSubcounty.val()==' '){
											//showServerResponse('ERROR', 'ERROR: Please Select Sub Country','error');
											window.location.replace("county_quality_verified_systems_sold.jsp");
										}else{
											window.location.replace("sub_county_quality_verified_systems_sold.jsp");
										}
									}
								}
							}else{
								if($selectedCounty.val()==' '){
									
								}else{
									if($selectedSubcounty.val()=='All'){
										window.location.replace("all_sub_county_quality_verified_systems_sold.jsp");
									}else{
									if($selectedSubcounty.val()==' '){
										
									}else{
										window.location.replace("sub_county_quality_verified_systems_sold.jsp");
									}
									}
								}
							}
						}
						
						
						
					} 	
					else{
						
						if($selectedDistrict.val()==' '){
							showServerResponse('ERROR', 'ERROR: Please Select District','error');
						}else{
							if(($selectedCounty.val()==' ')&&($selectedSubcounty.val()==' ')){
								
							}else{
								if($selectedSubcounty.val()==' '){
									window.location.replace("county_quality_verified_systems_sold.jsp");
								}else{
									if($selectedSubcounty.val()=='All'){
										window.location.replace("all_sub_county_systems_sold.jsp");
									}else{
										
										if($selectedSubcounty.val()==' '){
											//showServerResponse('ERROR', 'ERROR: Please Select Sub Country','error');
											window.location.replace("county_quality_verified_systems_sold.jsp");
										}else{
											window.location.replace("sub_county_quality_verified_systems_sold.jsp");
										}
									}
								}
							}
						}
							
					} 
				

			} else if ($queryType.val() == 'installed_capacity') {
				
				
				if($selectedDistrict.val()=='All'){
					
					if(($selectedCounty.val()==' ')&&($selectedSubcounty.val()==' ')){
						window.location.replace("installed_capacity.jsp");
					}else{
						if($selectedCounty.val()=='All'){
							if($selectedSubcounty.val()==' '){
								window.location.replace("all_county_installed_capacity.jsp");
							}else{
								if($selectedSubcounty.val()=='All'){
									
									window.location.replace("all_sub_county_installed_capacity.jsp");
									
								}else{
									if($selectedSubcounty.val()==' '){
										//showServerResponse('ERROR', 'ERROR: Please Select Sub Country','error');
										window.location.replace("county_installed_capacity.jsp");
									}else{
										window.location.replace("sub_county_installed_capacity.jsp");
									}
								}
							}
						}else{
							if($selectedCounty.val()==' '){
								
							}else{
								if($selectedSubcounty.val()=='All'){
									window.location.replace("all_sub_county_installed_capacity.jsp");
								}else{
								if($selectedSubcounty.val()==' '){
									
								}else{
									window.location.replace("sub_county_installed_capacity.jsp");
								}
								}
							}
						}
					}
					
					
					
				} 	
				else{
					
					if($selectedDistrict.val()==' '){
						showServerResponse('ERROR', 'ERROR: Please Select District','error');
					}else{
						if(($selectedCounty.val()==' ')&&($selectedSubcounty.val()==' ')){
							
						}else{
							if($selectedSubcounty.val()==' '){
								window.location.replace("county_installed_capacity.jsp");
							}else{
								if($selectedSubcounty.val()=='All'){
									window.location.replace("all_sub_county_installed_capacity.jsp");
								}else{
									
									if($selectedSubcounty.val()==' '){
										//showServerResponse('ERROR', 'ERROR: Please Select Sub Country','error');
										window.location.replace("county_installed_capacity.jsp");
									}else{
										window.location.replace("sub_county_installed_capacity.jsp");
									}
								}
							}
						}
					}
						
				} 
				 
					

			} else if ($queryType.val() == 'systems_sold_on_PayG') {
				
				
				if($selectedDistrict.val()=='All'){
					
					if(($selectedCounty.val()==' ')&&($selectedSubcounty.val()==' ')){
						window.location.replace("systems_sold_on_payG.jsp");
					}else{
						if($selectedCounty.val()=='All'){
							if($selectedSubcounty.val()==' '){
								window.location.replace("all_county_systems_sold_on_payG.jsp");
							}else{
								if($selectedSubcounty.val()=='All'){
									
									window.location.replace("all_sub_county_systems_sold_on_payG.jsp");
									
								}else{
									if($selectedSubcounty.val()==' '){
										//showServerResponse('ERROR', 'ERROR: Please Select Sub Country','error');
										window.location.replace("county_systems_sold_on_payG.jsp");
									}else{
										window.location.replace("sub_county_systems_sold_on_payG.jsp");
									}
								}
							}
						}else{
							if($selectedCounty.val()==' '){
								
							}else{
								if($selectedSubcounty.val()=='All'){
									window.location.replace("all_sub_county_systems_sold_on_payG.jsp");
								}else{
								if($selectedSubcounty.val()==' '){
									
								}else{
									window.location.replace("sub_county_systems_sold_on_payG.jsp");
								}
								}
							}
						}
					}
					
					
					
				} 	
				else{
					
					if($selectedDistrict.val()==' '){
						showServerResponse('ERROR', 'ERROR: Please Select District','error');
					}else{
						if(($selectedCounty.val()==' ')&&($selectedSubcounty.val()==' ')){
							
						}else{
							if($selectedSubcounty.val()==' '){
								window.location.replace("county_systems_sold_on_payG.jsp");
							}else{
								if($selectedSubcounty.val()=='All'){
									window.location.replace("all_sub_county_systems_sold_on_payG.jsp");
								}else{
									
									if($selectedSubcounty.val()==' '){
										//showServerResponse('ERROR', 'ERROR: Please Select Sub Country','error');
										window.location.replace("county_systems_sold_on_payG.jsp");
									}else{
										window.location.replace("sub_county_systems_sold_on_payG.jsp");
									}
								}
							}
						}
					}
						
				} 
				 
				 	
				 

			} else if ($queryType.val() == 'portfolio_at_risk') {
				
				
			if($selectedDistrict.val()=='All'){
					
					if(($selectedCounty.val()==' ')&&($selectedSubcounty.val()==' ')){
						window.location.replace("portfolio_at_risk.jsp");
					}else{
						if($selectedCounty.val()=='All'){
							if($selectedSubcounty.val()==' '){
								window.location.replace("all_county_portfolio_at_risk.jsp");
							}else{
								if($selectedSubcounty.val()=='All'){
									
									window.location.replace("all_sub_county_portfolio_at_risk.jsp");
									
								}else{
									if($selectedSubcounty.val()==' '){
										//showServerResponse('ERROR', 'ERROR: Please Select Sub Country','error');
										window.location.replace("county_portfolio_at_risk.jsp");
									}else{
										window.location.replace("sub_county_portfolio_at_risk.jsp");
									}
								}
							}
						}else{
							if($selectedCounty.val()==' '){
								
							}else{
								if($selectedSubcounty.val()=='All'){
									window.location.replace("all_sub_county_portfolio_at_risk.jsp");
								}else{
								if($selectedSubcounty.val()==' '){
									
								}else{
									window.location.replace("sub_county_portfolio_at_risk.jsp");
								}
								}
							}
						}
					}
					
					
					
				} 	
				else{
					
					if($selectedDistrict.val()==' '){
						showServerResponse('ERROR', 'ERROR: Please Select District','error');
					}else{
						if(($selectedCounty.val()==' ')&&($selectedSubcounty.val()==' ')){
							
						}else{
							if($selectedSubcounty.val()==' '){
								window.location.replace("county_portfolio_at_risk.jsp");
							}else{
								if($selectedSubcounty.val()=='All'){
									window.location.replace("all_sub_county_portfolio_at_risk.jsp");
								}else{
									
									if($selectedSubcounty.val()==' '){
										//showServerResponse('ERROR', 'ERROR: Please Select Sub Country','error');
										window.location.replace("county_portfolio_at_risk.jsp");
									}else{
										window.location.replace("sub_county_portfolio_at_risk.jsp");
									}
								}
							}
						}
					}
						
				} 
				  

			} else if ($queryType.val() == 'default_rate') {
				
				
				if($selectedDistrict.val()=='All'){
						
						if(($selectedCounty.val()==' ')&&($selectedSubcounty.val()==' ')){
							window.location.replace("default_rate.jsp");
						}else{
							if($selectedCounty.val()=='All'){
								if($selectedSubcounty.val()==' '){
									window.location.replace("all_county_default_rate.jsp");
								}else{
									if($selectedSubcounty.val()=='All'){
										
										window.location.replace("all_sub_county_default_rate.jsp");
										
									}else{
										if($selectedSubcounty.val()==' '){
											//showServerResponse('ERROR', 'ERROR: Please Select Sub Country','error');
											window.location.replace("county_default_rate.jsp");
										}else{
											window.location.replace("sub_county_default_rate.jsp");
										}
									}
								}
							}else{
								if($selectedCounty.val()==' '){
									
								}else{
									if($selectedSubcounty.val()=='All'){
										window.location.replace("all_sub_county_default_rate.jsp");
									}else{
									if($selectedSubcounty.val()==' '){
										
									}else{
										window.location.replace("sub_county_default_rate.jsp");
									}
									}
								}
							}
						}
						
						
						
					} 	
					else{
						
						if($selectedDistrict.val()==' '){
							showServerResponse('ERROR', 'ERROR: Please Select District','error');
						}else{
							if(($selectedCounty.val()==' ')&&($selectedSubcounty.val()==' ')){
								
							}else{
								if($selectedSubcounty.val()==' '){
									window.location.replace("county_default_rate.jsp");
								}else{
									if($selectedSubcounty.val()=='All'){
										window.location.replace("all_sub_county_default_rate.jsp");
									}else{
										
										if($selectedSubcounty.val()==' '){
											//showServerResponse('ERROR', 'ERROR: Please Select Sub Country','error');
											window.location.replace("county_default_rate.jsp");
										}else{
											window.location.replace("sub_county_default_rate.jsp");
										}
									}
								}
							}
						}
						 
					} 
				  		
			}
			
		} else if ($outPutOption.val() == 'map') {
			var $queryType = $('#query_type_combo');

			if($selectedDistrict.val()=='All'){
				
			if(($selectedCounty.val()=='All'||$selectedCounty.val()!=' ')||($selectedSubcounty.val()=='All'||$selectedSubcounty.val()!=' ')){
				console.log('ERROR: There is no data provided for this query type. Thank you ');
				showServerResponse('ERROR', 'ERROR: The map output option is only available for an All District query at this time ','error');
			}else{
			if ($queryType.val() == 'systems_sold') {
				
				window.location.replace("systems_sold_map.jsp");
				
			} else if ($queryType.val() == 'quality_verified_systems_sold') {
				
				window.location.replace("quality_verified_systems_sold_map.jsp");
				
			} else if ($queryType.val() == 'installed_capacity') {
				
				window.location.replace("installed_capacity_map.jsp");

			} else if ($queryType.val() == 'systems_sold_on_PayG') {
				
				window.location.replace("systems_sold_on_payG_map.jsp");

			} else if ($queryType.val() == 'portfolio_at_risk') {
				
				window.location.replace("portfolio_at_risk_map.jsp");

			} else if ($queryType.val() == 'default_rate') {
				window.location.replace("default_rate_map.jsp");
			}}
		}else{
			console.log('ERROR: The map output option is only available for an All District query at this time ');
			showServerResponse('ERROR', 'ERROR: The map output option is only available for an All District query at this time ','error');
		}
		}
	}

});
	
	function showServerResponse(title, msg,type) {
		var $toastlast;

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}

});