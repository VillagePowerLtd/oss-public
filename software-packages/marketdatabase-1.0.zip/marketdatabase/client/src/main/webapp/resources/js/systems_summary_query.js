$(function(){
	
	loadSummaryData();
	
	function loadSummaryData(){
		
		var $queryType='system';
        var $country=$.cookie('selectedCountry');
        var $district=$.cookie('selectedDistrict');
        
        console.log('$country: '+$country);
        console.log('$district: '+$district);
        
        var query = {
				"type" : "object",
				"systemSoldQuery" : {
					queryType : $queryType,
					country : $country,
					district : $district

				}
			};
        
        var queryJSONString = JSON.stringify(query);
        
         
        $.ajax({
			headers : {
				'Accept' : 'application/json',
				'Content-Type' : 'application/json'
			},
			type : "POST",
			url : SYSTEM_SUMMERY_QUERY,
			data : queryJSONString,
			dataType : "json",
			success : function(data, status) {

				if (data.result) {
					//showServerResponse("Success", data.message, "success")
					//console.log("Result: " + data);
					loadSummaryDataFile(data);
				} else {
					showServerResponse("ERROR", data.errorMessage, "error")
					// loadBathesTable();
				}

			},
			error : function(jqXHR, textStatus, errorThrown) {
				loader.hideLoading();
				if (errorThrown == 'Unauthorized') {

					// onSessionTimeOut();
				}
			}
		});
	
	}
	


function loadSummaryDataFile(data) {
	
	var counter=0;
	
	var queryDataArray = [];
	
	var $lastupdated;
	
	for(var i=0;i<data.districtsSystemSolds.length;i++){
		
		var $systemsSoldNumber=data.districtsSystemSolds[i].displayableSales;
		
		$lastupdated=data.districtsSystemSolds[i].dateCreated;
		 
		
		var queryData = {
				countryName : data.districtsSystemSolds[i].districtId.countryId.countryName,
				totalSystemsSold : data.countrySummary.systemsSold,
				districtName: data.districtsSystemSolds[i].districtId.districtName,
				systemsSoldNumber: $systemsSoldNumber
				
			};
		
		queryDataArray[i] = queryData;
	}
	
	$('#datepicker').val($lastupdated+" :EAT");
	
		var table = $('#systems_sold_query_table').DataTable({
			
			destroy : true,
			data : queryDataArray,
			pageLength: 100,
			dom: 'Bfrtip',
			buttons: [
				'pageLength', 
				'excelFlash',
				'pdfFlash'
			],
			columns : [ 
			{
				name : "country",
				title: "Country",
				data : "countryName"
			}, {
				name : "totalSystemsSold",
				title: "Systems Sold",
				data:	"totalSystemsSold"
			}, {
				name : "district",
				title : "District",
				data : "districtName"
			}, {
				name : "districtSystemsSold",
				title : "Systems Sold",
				data : "systemsSoldNumber" 
			}
			],
			rowsGroup: [
				  0,
				  1
			    ],
			  order: [[ 2, "asc" ]]
		});

	}

	function totalNumberOfSystemsSold(data) {

		
		var total = data.countrySummary.systemsSold;
		return total;
	}
	
	
	function showServerResponse(title, msg,type) {
		var $toastlast; 

		var shortCutFunction = false;
		var $showDuration = "300";
		var $hideDuration = "1000";
		var $timeOut = "5000";
		var $extendedTimeOut = "1000";
		var $showEasing = "swing";
		var $hideEasing = "linear";
		var $showMethod = "fadeIn";
		var $hideMethod = "fadeOut";

		toastr.options = {
			closeButton : false,
			debug : false,
			newestOnTop : false,
			progressBar : false,
			positionClass : "toast-top-full-width",
			preventDuplicates : false,
			onclick : null
		};

		var $toast = toastr[type](msg, title);
		$toastlast = $toast;

	}
});