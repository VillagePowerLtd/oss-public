var SERVER_PATH='http://104.236.194.94:9090/marketDatabase-1.0-SNAPSHOT/';

var GET_LOGED_IN_USER=SERVER_PATH+'webresources/users/userToken';

var ADD_NEW_COMPANY=SERVER_PATH+'webresources/company/addCompany';
var UPDATE_COMPANY=SERVER_PATH+'webresources/company/updateCompany';
var DELETE_COMPANY=SERVER_PATH+'webresources/company/deleteCompany';

var RETRIEVE_COMPANY=SERVER_PATH+'webresources/company/allCompanies';

var ADD_NEW_DEVICE_SUPPORTED=SERVER_PATH+'webresources/device/addDevice';

var UPDATE_DEVICE_SUPPORTED=SERVER_PATH+'webresources/device/updateDevice';

var DELETE_DEVICE_SUPPORTED=SERVER_PATH+'webresources/device/deleteDevice';

var RETRIEVE_DEVICES_SUPPORTED=SERVER_PATH+'webresources/device/allDevices';

var RETRIEVE_LOANS=SERVER_PATH+'webresources/loan/allLoans';

var RETRIEVE_LOANS_BY_COMPANY=SERVER_PATH+'webresources/loan/companyLoans';

var RETRIEVE_COMPANY_DEVICES_SUPPORTED=SERVER_PATH+'webresources/device/companyDevices';

var SAVE_KIT_SPECIFICATION=SERVER_PATH+'webresources/specification/addSpecification';

var UPDATE_KIT_SPECIFICATION=SERVER_PATH+'webresources/specification/updateSpecification';

var DELETE_KIT_SPECIFICATION=SERVER_PATH+'webresources/specification/deleteSpecification';

var SYSTEM_SUMMERY_QUERY=SERVER_PATH+'webresources/loan/queryData';

var COUNTY_SUMMERY_QUERY=SERVER_PATH+'webresources/county/queryDataCounty';

var ALL_COUNTY_SUMMERY_QUERY=SERVER_PATH+'webresources/county/queryAllDataCounty';

var SUB_COUNTY_SUMMERY_QUERY=SERVER_PATH+'webresources/SubCounty/queryDataSubCounty';

var ALL_SUB_COUNTY_SUMMERY_QUERY=SERVER_PATH+'webresources/SubCounty/queryAllDataSubCounty';

var RETRIEVE_DISTRICTS_QUERY=SERVER_PATH+'webresources/company/allDistricts';

var RETRIEVE_ALL_SPECIFICATIONS=SERVER_PATH+'webresources/specification/allSpecifications';

var RETRIEVE_COMPANY_SPECIFICATIONS=SERVER_PATH+'webresources/specification/companySpecifications';

var RETRIEVE_SPECIFICATION_DEVICES=SERVER_PATH+'webresources/specification/SpecificationDevices';

var LOGIN=SERVER_PATH+'webresources/auth/login';

var LOG_OUT=SERVER_PATH+'webresources/auth/logout';

var CREATE_PROFILE=SERVER_PATH+'webresources/users/add';

var RETRIEVE_PROFILE=SERVER_PATH+'webresources/users/allUsers';

var UPDATE_PROFILE=SERVER_PATH+'webresources/users/update';

var UPDATE_USER_PROFILE=SERVER_PATH+'webresources/users/updateUser';

var DELETE_PROFILE=SERVER_PATH+'webresources/users/delete';

var RETRIEVE_COUNTIES=SERVER_PATH+'webresources/county/allCounties';

var RETRIEVE_COUNTIES_BY_DISTRICT=SERVER_PATH+'webresources/county/DistrictCounties';

var RETRIEVE_SUB_COUNTIES=SERVER_PATH+'webresources/SubCounty/allSubCounties';

var RETRIEVE_SUB_COUNTIES_BY_COUNTY=SERVER_PATH+'webresources/SubCounty/CountySubCounties';

var RETRIEVE_PARISHES=SERVER_PATH+'webresources/parish/parishes';

var RETRIEVE_VILLAGES=SERVER_PATH+'webresources/village/villages';

var ADD_COMPANY_REPORTING=SERVER_PATH+'webresources/company/addReporting';

var UPDATE_COMPANY_REPORTING=SERVER_PATH+'webresources/company/updateReporting';

var DELETE_COMPANY_REPORTING=SERVER_PATH+'webresources/company/deleteReporting';

var RETRIEVE_COMPANY_REPORTING=SERVER_PATH+'webresources/company/allReporting';

var RETRIEVE_COMPANY_REPORTING=SERVER_PATH+'webresources/company/allReporting';


var RETRIEVE_SUBCOUNTY_SALES_SUMMARY_HISTORY=SERVER_PATH+'webresources/SubCounty/querySubCountyHistory';





