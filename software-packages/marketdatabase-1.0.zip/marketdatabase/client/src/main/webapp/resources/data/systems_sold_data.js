[
		{
			"country": "Uganda", 
			"totalSystemsSold": 500,
			"district": 'Kampala',
			"districtSystemsSold": 10
		},
		{
			"country": "Uganda", 
			"totalSystemsSold": 500,
			"district": 'Bukomansimbi',
			"districtSystemsSold": 59
		},
		{
			"country": "Uganda", 
			"totalSystemsSold": 500,
			"district": 'Butambala',
			"districtSystemsSold": 138
		},
		{
			"country": "Uganda", 
			"totalSystemsSold": 500,
			"district": 'Buvumba',
			"districtSystemsSold": 40
		},

		{
			"country": "Uganda", 
			"totalSystemsSold": 500,
			"district": 'Gomba',
			"districtSystemsSold": 98
		},

		{
			"country": "Uganda", 
			"totalSystemsSold": 500,
			"district": 'Kalangala',
			"districtSystemsSold": 1
		},

		{
			"country": "Uganda", 
			"totalSystemsSold": 500,
			"district": 'Kalunga',
			"districtSystemsSold": 85
		},

		{
			"country": "Uganda", 
			"totalSystemsSold": 500,
			"district": 'Kayunga',
			"districtSystemsSold": 130
		},

		{
			"country": "Uganda", 
			"totalSystemsSold": 500,
			"district": 'Kiboga',
			"districtSystemsSold": 10
		},
		{
			"country": "Uganda", 
			"totalSystemsSold": 500,
			"district": 'Kyankwanzi',
			"districtSystemsSold": 20
		}
		]