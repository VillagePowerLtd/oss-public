$(function(){
	
	console.log("Loging in security");
	
	if (typeof $.cookie('loginToken') == 'undefined') {
		window.location.replace("login.html");
		console.log("Loging in security: "+$.cookie('loginToken'));
	}
	
	if (typeof $.cookie('userRole') == 'undefined') {
		window.location.replace("login.html");
		console.log("Loging in security: "+$.cookie('loginToken'));
		
	} else {
		
		console.log("Loging in security: all clear..");
		
		if ($.cookie('userRole') == 'Overall admin') {
			console.log("Loging in security: Overall admin");
			
			$('#devices_menu').removeClass("hidden");
			$('#specifications_menu').removeClass("hidden");
			$('#geographics_menu').removeClass("hidden");
			$('#loans_menu').removeClass("hidden");
			$('#companies_menu').removeClass("hidden");
			$('#user_profile_menu').removeClass("hidden");
			$('#sales_summary_menu').removeClass("hidden");
			$('#config_menu').removeClass("hidden");

		}else if($.cookie('userRole') == 'Company admin'){
			
			console.log("Loging in security: administrator");
			
			//$('#geographics_menu').removeClass("hidden");
			//$('#companies_menu').removeClass("hidden");
			//$('#user_profile_menu').removeClass("hidden");
			//$('#config_menu').removeClass("hidden");
			//$('#sales_summary_menu').removeClass("hidden");
			$('#specifications_menu').removeClass("hidden");
			$('#loans_menu').removeClass("hidden");
			$('#devices_menu').removeClass("hidden");
			
		} else if ($.cookie('userRole') == 'User') { 
			
			console.log("Loging in security: investor");
			
			/*$('#devices_menu').addClass("hidden");
			$('#specifications_menu').addClass("hidden");
			$('#geographics_menu').addClass("hidden");
			$('#loans_menu').addClass("hidden");
			$('#companies_menu').addClass("hidden");
			$('#user_profile_menu').addClass("hidden");
			$('#sales_summary_menu').addClass("hidden");
			$('#config_menu').addClass("hidden");*/
			 
		}else{
			window.location.replace("login.html");
		}

	}
	
	
});