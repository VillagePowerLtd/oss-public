/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.rest;


import au.com.bytecode.opencsv.CSVReader;
import ch.villagepower.dao.CompanyService;
import ch.villagepower.dao.CountyService;
import ch.villagepower.dao.DeviceService;
import ch.villagepower.dao.DistrictService;
import ch.villagepower.dao.LoanService;
import ch.villagepower.dao.SaveService;
import ch.villagepower.dao.SpecificationService;
import ch.villagepower.entities.Company;
import ch.villagepower.entities.Country;
import ch.villagepower.entities.CountrySummary;
import ch.villagepower.entities.CountrySummaryHist;
import ch.villagepower.entities.County;
import ch.villagepower.entities.District;
import ch.villagepower.entities.DistrictsSystemSold;
import ch.villagepower.entities.Loan;
import ch.villagepower.entities.Specification;
import ch.villagepower.utils.JsonInput;
import ch.villagepower.utils.JsonReply;
import ch.villagepower.utils.PrintJson;
import com.google.gson.Gson;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;
import org.apache.log4j.Logger;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Days;

/**
 * REST Web Service
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Path("loan")
public class LoanResource {

    final Logger log = Logger.getLogger(LoanResource.class.getName());

    @Context
    private UriInfo context;

    Gson gson;
    JsonReply reply;
    JsonInput input;

    @EJB
    SaveService save = new SaveService();

    @EJB
    DeviceService deviceService = new DeviceService();

    @EJB
    LoanService loanService = new LoanService();

    @EJB
    CompanyService companyService = new CompanyService();

    @EJB
    CountyService countyService = new CountyService();

    @EJB
    DistrictService districtService = new DistrictService();

    @EJB
    SpecificationService specificationService = new SpecificationService();

    /**
     * Creates a new instance of LoanResource
     */
    public LoanResource() {
    }

    //**************upload loans csv file*****************
    @POST
    @Path("csvUpload")
    //@Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @ApiOperation(value = "Upload Loans", notes = "Upload Loan csv file.", response = JsonReply.class)
    public String csvUpload(
            @ApiParam(value = "Actual file") @FormDataParam("file") InputStream uploadedInputStream,
            @FormDataParam("file") FormDataContentDisposition fileDetail,
            @FormDataParam("file") FormDataBodyPart body) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("csvUploadLoan");
        try {

            gson = new Gson();

            String uploadedFileLocation = "/home/glassfish/loanuploadsmarketDB.csv";
            log.info("file location" + uploadedFileLocation);
            // save csv file
            PrintJson.saveToFile(uploadedInputStream, uploadedFileLocation);

            //create CSVReader object
            CSVReader reader = null;
            List<String[]> records = new ArrayList<>();
            List<Loan> loans = new ArrayList<>();
            try {
                //create CSVReader object
                reader = new CSVReader(new FileReader(uploadedFileLocation), ',');
                loans = new ArrayList<>();
                //read all lines at once
                records = reader.readAll();
                reader.close();

            } catch (Exception e) {

                log.info("file exception :" + e);

            } finally {
                //close file io
                if (reader != null) {
                    reader.close();
                }

            }
            log.info("////////////////////" + records.size());
            if (records.size() > 1) {

                Iterator<String[]> iterator = records.iterator();
                //skip header row

                while (iterator.hasNext()) {
                    String[] record = iterator.next();
                    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yy");
                    String dateInString;

                    Loan loan = new Loan();

                    loan.setId(Integer.valueOf(record[1]));

                    loan.setModel(String.valueOf(record[2]));
                    loan.setSalesMode(String.valueOf(record[3]));
                    loan.setTypeOfLoan(record[4]);
                    loan.setCountry(String.valueOf(record[5]));
                    loan.setDistrict(String.valueOf(record[6]));
                    loan.setCounty(String.valueOf(record[7]));
                    loan.setSubCounty(String.valueOf(record[8]));
                    loan.setParish(String.valueOf(record[9]));
                    loan.setVillage(String.valueOf(record[10]));

                    dateInString = record[11];
                    if ("Permanent".equalsIgnoreCase(dateInString) || dateInString.length() < 0 || "Paid UP".equalsIgnoreCase(dateInString) || "defaulter".equalsIgnoreCase(dateInString) || "".equalsIgnoreCase(dateInString)) {
                        loan.setNextPaymentDate(null);
                    } else {

                        Date date = formatter.parse(dateInString);
                        formatter = new SimpleDateFormat("yyyy-MM-dd");
                        dateInString = formatter.format(date);
                        loan.setNextPaymentDate(formatter.parse(dateInString));
                    }
                    loan.setDefaulted(record[12]);
                    if ("".equalsIgnoreCase(record[13])) {
                        loan.setCurrentOutstandingBalance(0.0);
                    } else {
                        loan.setCurrentOutstandingBalance(Double.valueOf(record[13]));
                    }

                    //loan.setLocation(record[13]);
                    loan.setLastUpdated(PrintJson.timeZoneKla());

                    //loan.setInstalled(Boolean.valueOf(record[14]));
                    //loan.setStatus(record[13]);
                    //need to cange after authentication/authorisation to set Compant ID
                    Company cmp = companyService.companyById(Integer.valueOf(record[0]));
                    if (cmp != null) {

                        loan.setCompanyId(cmp.getId());
                    } else {
                        log.info("company does not exist");
                        reply.setError("company does not exist");
                        break;
                    }

                    loans.add(loan);

                }

                for (Loan l : loans) {

                    int days = 0;
                    if (l.getNextPaymentDate() == null) {
                        l.setPar("0");
                    } else {
                        org.joda.time.DateTime secondDate = new DateTime(l.getNextPaymentDate()).toDateTime(DateTimeZone.forID("Africa/Kampala"));
                        org.joda.time.DateTime firstDate = PrintJson.timeZoneDateTimeKla().toDateTime(DateTimeZone.forID("Africa/Kampala"));

                        days = (Days.daysBetween(firstDate.toLocalDate(), secondDate.toLocalDate()).getDays()) / -1;

                    }

                    if (days >= 30) {
                        l.setPar("PAR 30");
                        l.setDaysOverdue(days);
                    } else {
                        l.setPar("within");
                    }

                    if (loanService.loanById(l.getId()) == null) {

                        l.setDateCreated(PrintJson.timeZoneKla());
                        save.saveObject(l);

                    } else {

                        save.updateObject(l);
                    }

                }

                reply.setSucc("Upload Done " + loans.size() + " Loans");
                log.info("@@@@@ Upload Done " + loans.size() + " Loans");

            } else {
                log.error("Empty File : ");
                reply.setError("Empty File");
            }
        } catch (IOException | ParseException ex) {

            log.error("This is file error : " + ex);
            reply.setError("file error" + ex.toString());
        }

        return reply.toString();
    }

    //**************upload districts csv file*****************
    @POST
    @Path("districtUpload")
    //@Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @ApiOperation(value = "Upload Districts", notes = "Upload districts csv file.", response = JsonReply.class)
    public String districtUpload(
            @ApiParam(value = "Actual file") @FormDataParam("file") InputStream uploadedInputStream,
            @FormDataParam("file") FormDataContentDisposition fileDetail,
            @FormDataParam("file") FormDataBodyPart body) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("csvUploadDistrict");
        try {

            gson = new Gson();

            String uploadedFileLocation = "/home/glassfish/districts.csv";
            log.info("file location" + uploadedFileLocation);
            // save csv file
            PrintJson.saveToFile(uploadedInputStream, uploadedFileLocation);

            //create CSVReader object
            CSVReader reader = null;
            List<String[]> records = new ArrayList<>();
            List<District> districts = new ArrayList<>();
            try {
                //create CSVReader object
                reader = new CSVReader(new FileReader(uploadedFileLocation), ',');
                districts = new ArrayList<>();
                //read all lines at once
                records = reader.readAll();
                

            } catch (Exception e) {

                log.info("file exception :" + e);

            } finally {
                //close file io
                //if (reader != null) {
                    reader.close();
                //}

            }
            log.info("////////////////////" + records.size());
            if (records.size() > 1) {

                Iterator<String[]> iterator = records.iterator();
                //skip header row

                while (iterator.hasNext()) {
                    String[] record = iterator.next();

                    District d = new District();

                    d.setDistrictName(record[0]);
                    d.setStringCordinate(record[1]);
                    d.setLatitude(record[2]);
                    d.setLongitude(record[3]);

                    districts.add(d);

                }

                Country country = districtService.countryByName(String.valueOf("uganda").toLowerCase()).get(0);

                for (District l : districts) {

                    if (districtService.districtByName(l.getDistrictName().toUpperCase()).isEmpty()) {

                        l.setDateCreated(PrintJson.timeZoneKla());
                        l.setCountryId(country);
                        save.saveObject(l);

                    } else {

                        District d = districtService.districtByName(l.getDistrictName().toUpperCase()).get(0);
                        d.setLastUpdated(PrintJson.timeZoneKla());
                        d.setLatitude(l.getLatitude());
                        d.setLongitude(l.getLongitude());
                        d.setStringCordinate(l.getStringCordinate());
                        save.updateObject(d);
                    }

                }

                reply.setSucc("Upload Done " + districts.size() + " districts");
                log.info("@@@@@ Upload Done " + districts.size() + " districts");

            } else {
                log.error("Empty File : ");
                reply.setError("Empty File");
            }
        } catch (IOException ex) {

            log.error("This is file error : " + ex);
            reply.setError("file error" + ex.toString());
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: CREATE Loan :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @Path("addLoan")
    public String addLoan(@Context Request req, String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();
        reply = new JsonReply("createLoan");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.loan != null) {

                if (input.loan.getId() < 0) {
                    log.info("Loan should have an id");
                    reply.setError("Loan should have an id");
                } else {

                    //CONSTRUCT SAVE NEW Loan
                    save.saveObject(input.loan);

                    reply.loans = loanService.findAll();

                    reply.setSucc("Loan Added");
                    log.info("Loan Added" + input.loan.getId());

                }

            } else {
                log.info("Please Send some JSON or Send Loan object");
                reply.setError("Please Send some JSON or Send Loan object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    //**************endpoint for all loans*****************
    @GET
    @Path("allLoans")
    //@Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    public String findAll() {

        reply = new JsonReply("getAllloans");

        gson = new Gson();

        List<Loan> loan = loanService.findAll();

        reply.loans = loan;
        reply.setSucc(loan.size() + " Loans");

        return reply.toString();
    }

    // ++++++++++++++++++++++++: UPDATE Loan :+++++++++++++++++++++++++++++++
    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Update Loan", notes = "Update Loan.", response = JsonReply.class)
    @Path("updateLoan")
    public String updateLoan(@Context Request req, @ApiParam(value = "JsonInput.loan") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("updateLoan");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.loan != null) {

                if (input.loan == null) {
                    log.info("Loan should have a value");
                    reply.setError("Deveice should have a value");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    Loan loan = loanService.loanById(input.loan.getId());

                    if (loan != null) {

                        loan.setLastUpdated(PrintJson.timeZoneKla());
                        save.updateObject(loan);

                        reply.loans = loanService.findAll();
                        reply.setSucc("loan updated");

                    } else {
                        log.info("This Loan does not Exist " + input.loan.getId());
                        reply.setError("This Loan does not Exist " + input.loan.getId());
                    }
                }

            } else {
                log.info("Please Send some JSON or Send Loan object");
                reply.setError("Please Send some JSON or Send Loan object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: UPDATE District :+++++++++++++++++++++++++++++++
    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Update District", notes = "Update District.", response = JsonReply.class)
    @Path("updateDistrict")
    public String updateDistrict(@Context Request req, @ApiParam(value = "JsonInput.district") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("updateDistrict");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.district != null) {

                if (input.district == null) {
                    log.info("District should have a value");
                    reply.setError("District should have a value");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    District loan = districtService.districtById(input.district.getId());

                    if (loan != null) {

                        loan.setLastUpdated(PrintJson.timeZoneKla());
                        loan.setDistrictName(input.district.getDistrictName());
                        loan.setLatitude(input.district.getLatitude());
                        loan.setLongitude(input.district.getLongitude());
                        save.updateObject(loan);

                        reply.districts = districtService.findAll();
                        reply.setSucc("District updated");

                    } else {
                        log.info("This district does not Exist " + input.district.getId());
                        reply.setError("This district does not Exist " + input.district.getId());
                    }
                }

            } else {
                log.info("Please Send some JSON or Send District object");
                reply.setError("Please Send some JSON or Send District object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: Get Loans by Company :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Company Loans", notes = "Company Loanns.", response = JsonReply.class)
    @Path("companyLoans")
    public String companyLoans(@Context Request req, @ApiParam(value = "JsonInput.company") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("companyLoanss");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.company != null) {

                if (input.company.getId() == null) {
                    log.info("Company id should have a value");
                    reply.setError("Company id should have a value");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    Company cmp = companyService.companyById(input.company.getId());
                    if (cmp != null) {

                        List<Loan> loans = loanService.companyLoans(cmp.getId());

                        if (!loans.isEmpty()) {

                            reply.loans = loans;
                            reply.setSucc("Loans found");
                        } else {
                            reply.setError("No loans for Company: " + cmp.getName());
                        }

                    } else {
                        log.info("This Company does not Exist " + input.company.getId());
                        reply.setError("This Device does not Exist " + input.company.getId());
                    }
                }

            } else {
                log.info("Please Send some JSON or Send DeviceSupported object");
                reply.setError("Please Send some JSON or Send DeviceSupported object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: Query Analysis Data :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Query Analysis Dats", notes = "Update Analysis Data.", response = JsonReply.class)
    @Path("queryData")
    public String queryData(@Context Request req, @ApiParam(value = "JsonInput.systemSoldQuery") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("updateData");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.systemSoldQuery != null) {

                if (input.systemSoldQuery.getDistrict().length() < 0) {
                    log.info("Query should have a value in district");
                    reply.setError("Query should have in district");
                } else {

                    // if(input.systemSoldQuery.getQueryType().equalsIgnoreCase("system")){
                    List<Country> c = districtService.countryByName(input.systemSoldQuery.getCountry());

                    if (!c.isEmpty()) {
                        List<District> dists = districtService.districtByCountry(c.get(0));
                        if (!dists.isEmpty()) {
                            List<DistrictsSystemSold> dssss = new ArrayList<>();
                            for (District d : dists) {
                                List<DistrictsSystemSold> dss = districtService.districtSold(d);
                                if (!dss.isEmpty()) {

                                    dssss.add(dss.get(0));

                                } else {
                                    log.info("This Country/District has no analysis data " + input.systemSoldQuery.getDistrict());

                                }
                            }

                            List<CountrySummary> cs = districtService.countrySummary(c.get(0).getId());

                            if (!cs.isEmpty()) {
                                reply.countrySummary = cs.get(0);
                            } else {
                                reply.message = "no country summmary";
                            }

                            reply.districtsSystemSolds = dssss;
                            reply.setSucc("Found Data");
                        } else {
                            log.info("This Country has no districts " + input.systemSoldQuery.getCountry());
                            reply.setError("This Country has no districts " + input.systemSoldQuery.getCountry());

                        }
                        /*}else if(input.systemSoldQuery.getQueryType().equalsIgnoreCase("quality")){

                                List<Loan> loans = loanService.loanByCountryDistrict(input.systemSoldQuery.getCountry(), input.systemSoldQuery.getDistrict());

                                if(!loans.isEmpty()){


                                }else{
                                        log.info("This Country/District does not Exist "+input.systemSoldQuery.getCountry());
                                        reply.setError("This Country/District does not Exist "+input.systemSoldQuery.getCountry());
                                }*/
                        // }
                    } else {

                        log.info("This Country/District has no analysis data " + input.systemSoldQuery.getCountry());
                        reply.setError("This Country/District has no analysis data " + input.systemSoldQuery.getCountry());

                    }
                }

            } else {
                log.info("Please Send some JSON or Send Query object");
                reply.setError("Please Send some JSON or Send Query object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }
    
    
    // ++++++++++++++++++++++++: Query Country Analysis History Data :+++++++++++++++++++++++++++++++
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Query Analysis Dats", notes = "Update Analysis Data.", response = JsonReply.class)
    @Path("queryCountryHistory")
    public String queryHistoryData(){



        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("countryHistory");
        
        List<CountrySummaryHist> users = districtService.findAllCountryHist();

        if (!users.isEmpty()) {

            reply.countrySummaryHist = users;

            reply.setSucc("Histroy returned " + users.size());
            log.info("History returned " + users.size());

        } else {
            log.info("No country History Data");
            reply.setError("No country History Data");
        }

        return reply.toString();

    }

    // ++++++++++++++++++++++++: UPDATE Analysis Data :+++++++++++++++++++++++++++++++
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Update Analysis Data", notes = "Update Analysis Data.", response = JsonReply.class)
    @Path("updateData")
    public String updateData() throws com.google.gson.JsonSyntaxException {

        //response
        reply = new JsonReply("updateData");

        try {

            List<District> districts = districtService.findAll();
            List<Country> countries = districtService.findAllCountries();

            int systemSoldNumber;
            int qualityVerifiedNumber;
            float qualityVerifiedAmount;
            double systemSoldAmount;
            int capacityInstalledNumber;
            float capacityInstalledAmount;
            int solarOnPayGo;
            int defaulted;
            double outstandingPar30;
            double outstandingTotal;

            if (!countries.isEmpty()) {

                for (Country c : countries) {

                    for (District d : districts) {

                        List<Loan> loans = loanService.loanByDistrict(d.getDistrictName());

                        systemSoldNumber = loans.size();
                        solarOnPayGo = 0;
                        qualityVerifiedNumber = 0;
                        qualityVerifiedAmount = 0;
                        systemSoldAmount = 0;
                        capacityInstalledNumber = 0;

                        defaulted = 0;
                        outstandingPar30 = 0;
                        outstandingTotal = 0;

                        if (!loans.isEmpty()) {

                            Company cm;

                            for (Loan l : loans) {

                                systemSoldAmount++;//=l.getOriginalOutstandingBalance().floatValue();
                                outstandingTotal += l.getCurrentOutstandingBalance();

                                cm = companyService.companyById(l.getCompanyId());
                                if (cm != null) {
                                    //List<Specification> specs =  specificationService.specificationByModel(l.getModel().toUpperCase());
                                    List<Specification> specs = specificationService.specificationByModelAndCompany(l.getModel().toUpperCase(), cm);

                                    if (!specs.isEmpty()) {

                                        if ("hire-purchase".equalsIgnoreCase(l.getSalesMode())) {
                                            solarOnPayGo++;
                                        }

                                        if ("defaulted".equalsIgnoreCase(l.getDefaulted())) {
                                            defaulted++;
                                        }

                                        if ("PAR 30".equalsIgnoreCase(l.getPar())) {
                                            outstandingPar30 += l.getCurrentOutstandingBalance();

                                        }

                                        for (Specification s : specs) {
                                            if (s.getQualityVerified()) {
                                                qualityVerifiedNumber++;
                                                qualityVerifiedAmount += s.getMaxPowerOutput();//l.getCurrentOutstandingBalance().floatValue();

                                            }

                                            capacityInstalledNumber += s.getMaxPowerOutput();
                                            //capacityInstalledAmount +=s.getMaxPowerOutput();//=l.getCurrentOutstandingBalance().floatValue();
                                        }

                                    }

                                } else {
                                    log.info("A loan belongs to a company that does not exist" + l.getId());
                                    reply.setError("A loan belongs to a company that does not exist" + l.getId());

                                }

                            }

                        }

                        //count number of reporting companies then set displayable                            
                        List<Company> companys = companyService.findAll();
                        int reporting = 0;
                        String displayable;
                        String displayableSales;
                        String displayablePAYG;
                        String displayableVerified;

                        String flagishPAR;
                        String flagishDefaulted;
                        for (Company cmps : companys) {
                            for (Loan ll : loans) {
                                if (Objects.equals(ll.getCompanyId(), cmps.getId())) {
                                    reporting++;
                                    break;
                                }

                            }

                        }

                        if (reporting < companyService.reportingByLevel("district").get(0).getMinimum() && systemSoldNumber > 0) {
                            displayableSales = "Undisclosable";
                            displayable = "Undisclosable";

                        } else if (systemSoldNumber == 0) {
                            displayableSales = "0";
                            displayable = "0";
                        } else {
                            displayableSales = String.valueOf(systemSoldNumber);
                            displayable = String.valueOf(capacityInstalledNumber);
                        }

                        if (reporting < companyService.reportingByLevel("district").get(0).getMinimum() && qualityVerifiedNumber > 0) {
                            displayableVerified = "Undisclosable";

                        } else if (qualityVerifiedNumber == 0) {
                            displayableVerified = "0";
                        } else {
                            displayableVerified = String.valueOf(qualityVerifiedNumber);
                        }

                        if (reporting < companyService.reportingByLevel("district").get(0).getMinimum() && solarOnPayGo > 0) {
                            displayablePAYG = "Undisclosable";

                        } else if (solarOnPayGo == 0) {
                            displayablePAYG = "0";
                        } else {
                            displayablePAYG = String.valueOf(solarOnPayGo);
                        }

                        DistrictsSystemSold dss = new DistrictsSystemSold();
                        dss.setCapacityInstalledNumber(capacityInstalledNumber);
                        dss.setDateCreated(PrintJson.timeZoneKla());
                        dss.setDistrictId(d);
                        dss.setDisplayable(displayable);
                        dss.setDisplayableSales(displayableSales);
                        dss.setDisplayableVerified(displayableVerified);
                        dss.setDisplayablePAYG(displayablePAYG);
                        //dss.setCountryId(c);
                        dss.setQulaityVerifiedNumber(qualityVerifiedNumber);
                        dss.setSystemSoldAmount(systemSoldAmount);
                        dss.setSystemsSoldNumber(systemSoldNumber);
                        dss.setSystemsOnPayGoNumber(solarOnPayGo);

                        double df = 0.0;
                        if (solarOnPayGo == 0 || defaulted == 0) {
                            dss.setDefaultRate(df);
                        } else {
                            df = Double.valueOf(String.valueOf(defaulted)) / Double.valueOf(String.valueOf(solarOnPayGo));
                            dss.setDefaultRate(Math.round(df * 1000.0) / 10.0);
                        }
                        dss.setDefaulted(defaulted);
                        double par=0;
                        if (outstandingTotal==0.0) {
                            dss.setPARnumber(0.0);
                        } else {
                            par = outstandingPar30 /outstandingTotal ;
                            dss.setPARnumber(Math.round(par * 1000.0) / 10.0);
                        }

                        if (reporting < companyService.reportingByLevel("district").get(0).getMinimum() && solarOnPayGo > 0) {
                            flagishPAR = "Undisclosable";
                        } else if (reporting < companyService.reportingByLevel("district").get(0).getMinimum() && solarOnPayGo == 0) {
                            flagishPAR = "No Data";
                        } else if (dss.getPARnumber() == 0) {
                            flagishPAR = "0";
                        } else {
                            flagishPAR = String.valueOf(dss.getPARnumber()) + "%";
                        }

                        if (reporting < companyService.reportingByLevel("district").get(0).getMinimum() && solarOnPayGo > 0) {
                            flagishDefaulted = "Undisclosable";
                        } else if (reporting < companyService.reportingByLevel("district").get(0).getMinimum() && solarOnPayGo == 0) {
                            flagishDefaulted = "No Data";
                        } else if (dss.getDefaultRate() == 0) {
                            flagishDefaulted = "0";
                        } else {
                            flagishDefaulted = String.valueOf(dss.getDefaultRate()) + "%";
                        }

                        dss.setFlagPAR(flagishPAR);
                        dss.setFlagDefaulted(flagishDefaulted);

                        List<DistrictsSystemSold> dis = districtService.districtSoldByDistrict(d);
                        if (dis.isEmpty()) {

                            save.saveObject(dss);
                        } else {
                            dis.get(0).setCapacityInstalledNumber(capacityInstalledNumber);
                            //dis.get(0).set(PrintJson.timeZoneKla());
                            //dis.get(0).setDistrictId(d);

                            //dss.setCountryId(c);
                            dis.get(0).setDateCreated(PrintJson.timeZoneKla());
                            dis.get(0).setQulaityVerifiedNumber(qualityVerifiedNumber);
                            dis.get(0).setSystemSoldAmount(systemSoldAmount);
                            dis.get(0).setSystemsSoldNumber(systemSoldNumber);
                            dis.get(0).setSystemsOnPayGoNumber(solarOnPayGo);
                            dis.get(0).setDisplayable(displayable);
                            dis.get(0).setDisplayableSales(displayableSales);
                            dis.get(0).setDisplayableVerified(displayableVerified);
                            dis.get(0).setDisplayablePAYG(displayablePAYG);
                            dis.get(0).setDefaultRate(Math.round(df * 1000.0) / 10.0);
                            dis.get(0).setDefaulted(defaulted);
                            dis.get(0).setFlagPAR(flagishPAR);
                            dis.get(0).setFlagDefaulted(flagishDefaulted);

                            if ("NaN".equalsIgnoreCase(String.valueOf(par))) {
                                dis.get(0).setPARnumber(0.0);
                            } else {
                                dis.get(0).setPARnumber(Math.round(par * 1000.0) / 10.0);
                            }
                            save.updateObject(dis.get(0));
                        }

                    }

                    List<District> dists = districtService.districtByCountry(c);
                    if (!dists.isEmpty()) {
                        int totalSystemsSold = 0;
                        int totalQualityVerified = 0;
                        int totalInstalledCapacity = 0;
                        double totalPar30 = 0;
                        int totalSystemsPayGo = 0;
                        double totalDefaulted = 0;
                        List<DistrictsSystemSold> dssp;

                        for (District d : dists) {
                            dssp = districtService.districtSold(d);
                            totalSystemsSold += dssp.get(0).getSystemsSoldNumber();
                            totalQualityVerified += dssp.get(0).getQulaityVerifiedNumber();
                            totalInstalledCapacity += dssp.get(0).getCapacityInstalledNumber();
                            totalSystemsPayGo += dssp.get(0).getSystemsOnPayGoNumber();
                            totalDefaulted += dssp.get(0).getDefaulted();
                            totalPar30 += dssp.get(0).getPARnumber();

                        }

                        List<Loan> allLoans = loanService.findAll();

                        double parValue = 0;
                        double totalLoans = 0;

                        for (Loan l : allLoans) {
                            if ("par 30".equalsIgnoreCase(l.getPar())) {
                                parValue += l.getCurrentOutstandingBalance();
                            }
                            totalLoans += l.getCurrentOutstandingBalance();
                        }

                        List<CountrySummary> css = districtService.countrySummary(c.getId());

                        if (!css.isEmpty()) {

                            if (totalSystemsPayGo == 0 /*|| totalDefaulted==0*/) {
                                css.get(0).setDefaultRate(0.0);
                            } else {
                                css.get(0).setDefaultRate(Math.round((totalDefaulted / totalSystemsPayGo) * 1000) / 10.0);

                            }
                            css.get(0).setCountryId(c.getId());
                            css.get(0).setInstalledCapacity(totalInstalledCapacity);
                            if(totalLoans==0){
                                css.get(0).setPar30(0.0);
                            }else{
                                css.get(0).setPar30(Math.round((parValue / totalLoans) * 1000.0) / 10.0);
                            }
                            css.get(0).setQualityVerified(totalQualityVerified);
                            css.get(0).setSystemsOnPaygo(totalSystemsPayGo);
                            css.get(0).setSystemsSold(totalSystemsSold);

                            save.updateObject(css.get(0));
                        } else {

                            CountrySummary cs = new CountrySummary();

                            if (totalSystemsPayGo == 0 /*|| totalDefaulted==0*/) {
                                cs.setDefaultRate(0.0);
                            } else {
                                //System.out.println("totalDefaulted"+totalDefaulted+" totalSystemsPayGo"+totalSystemsPayGo+" Result"+BigDecimal.valueOf(totalDefaulted).divide(BigDecimal.valueOf(totalSystemsPayGo), 2, RoundingMode.HALF_UP));
                                //dont use bigDecimal
                                cs.setDefaultRate(Math.round((totalDefaulted / totalSystemsPayGo) * 1000) / 10.0);
                            }
                            cs.setCountryId(c.getId());
                            cs.setInstalledCapacity(totalInstalledCapacity);
                            if(totalLoans==0){
                                cs.setPar30(0.0);
                            }else{
                                cs.setPar30(Math.round((parValue / totalLoans) * 1000.0) / 10.0);
                            }
                            cs.setQualityVerified(totalQualityVerified);
                            cs.setSystemsOnPaygo(totalSystemsPayGo);
                            cs.setSystemsSold(totalSystemsSold);
                            save.saveObject(cs);
                        }
                        

                        log.info("country " + c.getCountryName() + " data saved");
                        
                        /*Calendar cal = Calendar.getInstance();
                        String month = String.valueOf(cal.get(Calendar.MONTH) + 1);
                        
                        
                        List<CountrySummaryHist> ch=districtService.countrySummaryHist(month);
                        
                        if(ch.isEmpty()){
                            
                                                        
                           CountrySummaryHist csh = new CountrySummaryHist();

                            if (totalSystemsPayGo == 0 ) {
                                csh.setDefaultRate(0.0);
                            } else {
                                
                                csh.setDefaultRate(Math.round((totalDefaulted / totalSystemsPayGo) * 1000) / 10.0);
                            }
                            csh.setCountryId(c.getId());
                            csh.setInstalledCapacity(totalInstalledCapacity);
                            if(totalLoans==0){
                                csh.setPar30(0.0);
                            }else{
                                csh.setPar30(Math.round((parValue / totalLoans) * 1000.0) / 10.0);
                            }
                            csh.setQualityVerified(totalQualityVerified);
                            csh.setSystemsOnPaygo(totalSystemsPayGo);
                            csh.setSystemsSold(totalSystemsSold);
                            csh.setMonth(month);
                            save.saveObject(csh);
                        
                        }else{
                            
                           if (totalSystemsPayGo == 0 ) {//|| totalDefaulted==0
                                ch.get(0).setDefaultRate(0.0);
                            } else {
                                ch.get(0).setDefaultRate(Math.round((totalDefaulted / totalSystemsPayGo) * 1000) / 10.0);

                            }
                            ch.get(0).setCountryId(c.getId());
                            ch.get(0).setInstalledCapacity(totalInstalledCapacity);
                            if(totalLoans==0){
                                ch.get(0).setPar30(0.0);
                            }else{
                                ch.get(0).setPar30(Math.round((parValue / totalLoans) * 1000.0) / 10.0);
                            }
                            ch.get(0).setQualityVerified(totalQualityVerified);
                            ch.get(0).setSystemsOnPaygo(totalSystemsPayGo);
                            ch.get(0).setSystemsSold(totalSystemsSold);

                            save.updateObject(ch.get(0));

                        
                        }*/
                        

                    } else {
                        reply.setError("No districts in country " + c.getCountryName());
                    }

                }

                reply.setSucc("Data analysed and persisted");

            } else {
                reply.setError("Country does not exist");
                log.info("Country does not exist");
            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: DELETE loan :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @Path("deleteLoan")
    @ApiOperation(value = "Delete loan", notes = "delete loan.", response = JsonReply.class)
    public String deleteLoan(@Context Request req, @ApiParam(value = "JsonInput.loan") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        reply = new JsonReply("deleteloan");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null) {
                if (input.loan == null) {
                    log.info("loan  equired");
                    reply.setError("loan required");
                } else {

                    //GET LOAN and BATCH FROM DB
                    Loan b = loanService.loanById(input.loan.getId());

                    if (b != null) {

                        save.deleteObject(b);
                        reply.setSucc("loan deleted");

                    } else {
                        log.error("No loan of that Kind " + input.loan.getId());
                        reply.setError("No loan of that Kind " + input.loan.getId());
                    }

                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    @POST
    @Path("deleteDistrict")
    //@Secured({ch.villagepower.filter.Role.administrator})
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "delete District", notes = "deleteDistrict Delete.", response = JsonReply.class)
    public String deleteDistrict(@Context Request req, @ApiParam(value = "JsonInput.district") String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("deleteDistrict");

        gson = new Gson();

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.district != null) {

                if (input.district.getId() != null) {
                    // get district by Id   
                    District u = districtService.districtById(input.district.getId());
                    if (null != u) {

                        List<County> ur = countyService.countyByDistrict(u);

                        if (!ur.isEmpty()) {
                            for (County urr : ur) {
                                save.deleteObject(urr);
                            }
                            log.info("County deleted successfully");
                        }

                        save.deleteObject(u);
                        reply.setSucc("District deleted successfully");

                    } else {
                        log.info("District does not exist");
                        reply.setError("District does not exist");
                    }

                } else {

                    log.info("Send District object");
                    reply.setError("Send District object");
                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();

    }

    /**
     * Retrieves representation of an instance of
     * ch.villagepower.rest.LoanResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of LoanResource
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void putJson(String content) {
    }
}
