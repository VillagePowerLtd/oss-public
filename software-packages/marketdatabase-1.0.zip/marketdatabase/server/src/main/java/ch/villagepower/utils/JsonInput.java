/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.utils;


/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
import ch.villagepower.entities.Company;
import ch.villagepower.entities.County;
import ch.villagepower.entities.DeviceSupported;
import ch.villagepower.entities.District;
import ch.villagepower.entities.Loan;
import ch.villagepower.entities.Reporting;
import ch.villagepower.entities.Specification;
import ch.villagepower.entities.SubCounty;
import ch.villagepower.entities.Users;

public class JsonInput {

    public Loan loan;

    public String batchId;
    public String loanId;

    public String username;
    public String password;
    public boolean rememberMe;

    public Users users;

    public DeviceSupported deviceSupported;
    public Company company;
    public District district;
    public County county;
    public SubCounty subCounty;
    public Reporting reporting;
    public Specification specification;

    public SystemSoldQuery systemSoldQuery;

    public String hash;
    
    public String token;

}
