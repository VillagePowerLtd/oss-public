/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import com.google.gson.annotations.Expose;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Entity
@Table(name = "sub_county")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SubCounty.findAll", query = "SELECT s FROM SubCounty s"),
    @NamedQuery(name = "SubCounty.findById", query = "SELECT s FROM SubCounty s WHERE s.id = :id"),
    @NamedQuery(name = "SubCounty.findBySubCountyCode", query = "SELECT s FROM SubCounty s WHERE s.subCountyCode = :subCountyCode"),
    @NamedQuery(name = "SubCounty.findBySubCountyName", query = "SELECT s FROM SubCounty s WHERE s.subCountyName = :subCountyName"),
    @NamedQuery(name = "SubCounty.findByLatitude", query = "SELECT s FROM SubCounty s WHERE s.latitude = :latitude"),
    @NamedQuery(name = "SubCounty.findByLongitude", query = "SELECT s FROM SubCounty s WHERE s.longitude = :longitude"),
    @NamedQuery(name = "SubCounty.findByLastUpdated", query = "SELECT s FROM SubCounty s WHERE s.lastUpdated = :lastUpdated"),
    @NamedQuery(name = "SubCounty.findByDateCreated", query = "SELECT s FROM SubCounty s WHERE s.dateCreated = :dateCreated")})
public class SubCounty implements Serializable {

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "subCountyId")
    private List<SubCountySystemSold> subCountySystemSoldList;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Expose
    @Column(name = "id")
    private Integer id;
    @Size(max = 45)
    @Column(name = "sub_county_code")
    @Expose
    private String subCountyCode;
    @Size(max = 145)
    @Column(name = "sub_county_name")
    @Expose
    private String subCountyName;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "latitude")
    @Expose
    private Double latitude;
    @Column(name = "longitude")
    @Expose
    private Double longitude;
    @Column(name = "last_updated")
    @Temporal(TemporalType.TIMESTAMP)
    @Expose
    private Date lastUpdated;
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    @Expose
    private Date dateCreated;
    @JoinColumn(name = "county_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    @Expose
    private County countyId;

    public SubCounty() {
    }

    public SubCounty(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSubCountyCode() {
        return subCountyCode;
    }

    public void setSubCountyCode(String subCountyCode) {
        this.subCountyCode = subCountyCode;
    }

    public String getSubCountyName() {
        return subCountyName;
    }

    public void setSubCountyName(String subCountyName) {
        this.subCountyName = subCountyName;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public County getCountyId() {
        return countyId;
    }

    public void setCountyId(County countyId) {
        this.countyId = countyId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SubCounty)) {
            return false;
        }
        SubCounty other = (SubCounty) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.SubCounty[ id=" + id + " ]";
    }

    @XmlTransient
    public List<SubCountySystemSold> getSubCountySystemSoldList() {
        return subCountySystemSoldList;
    }

    public void setSubCountySystemSoldList(List<SubCountySystemSold> subCountySystemSoldList) {
        this.subCountySystemSoldList = subCountySystemSoldList;
    }

}
