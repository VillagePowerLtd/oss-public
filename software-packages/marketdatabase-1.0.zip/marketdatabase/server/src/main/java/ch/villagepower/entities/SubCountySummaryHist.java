/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;

import com.google.gson.annotations.Expose;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author iainomugisha
 */
@Entity
@Table(name = "sub_county_summary_hist")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SubCountySummaryHist.findAll", query = "SELECT s FROM SubCountySummaryHist s"),
    @NamedQuery(name = "SubCountySummaryHist.findById", query = "SELECT s FROM SubCountySummaryHist s WHERE s.id = :id"),
    @NamedQuery(name = "SubCountySummaryHist.findByCountyId", query = "SELECT s FROM SubCountySummaryHist s WHERE s.countyId = :countyId"),
    @NamedQuery(name = "SubCountySummaryHist.findBySystemsSold", query = "SELECT s FROM SubCountySummaryHist s WHERE s.systemsSold = :systemsSold"),
    @NamedQuery(name = "SubCountySummaryHist.findByQualityVerified", query = "SELECT s FROM SubCountySummaryHist s WHERE s.qualityVerified = :qualityVerified"),
    @NamedQuery(name = "SubCountySummaryHist.findByInstalledCapacity", query = "SELECT s FROM SubCountySummaryHist s WHERE s.installedCapacity = :installedCapacity"),
    @NamedQuery(name = "SubCountySummaryHist.findBySystemsOnPaygo", query = "SELECT s FROM SubCountySummaryHist s WHERE s.systemsOnPaygo = :systemsOnPaygo"),
    @NamedQuery(name = "SubCountySummaryHist.findByPar30", query = "SELECT s FROM SubCountySummaryHist s WHERE s.par30 = :par30"),
    @NamedQuery(name = "SubCountySummaryHist.findByDefaultRate", query = "SELECT s FROM SubCountySummaryHist s WHERE s.defaultRate = :defaultRate"),
    @NamedQuery(name = "SubCountySummaryHist.findByMonth", query = "SELECT s FROM SubCountySummaryHist s WHERE s.month = :month")})
public class SubCountySummaryHist implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    @Expose
    private Integer id;
    @Column(name = "county_id")
    @Expose
    private Integer countyId;
    @Column(name = "systems_sold")
    @Expose
    private Integer systemsSold;
    @Column(name = "quality_verified")
    @Expose
    private Integer qualityVerified;
    @Column(name = "installed_capacity")
    @Expose
    private Integer installedCapacity;
    @Column(name = "systems_on_paygo")
    @Expose
    private Integer systemsOnPaygo;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "par30")
    @Expose
    private Double par30;
    @Column(name = "default_rate")
    @Expose
    private Double defaultRate;
    @Size(max = 45)
    @Column(name = "month")
    @Expose
    private String month;

    public SubCountySummaryHist() {
    }

    public SubCountySummaryHist(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCountyId() {
        return countyId;
    }

    public void setCountyId(Integer countyId) {
        this.countyId = countyId;
    }

    public Integer getSystemsSold() {
        return systemsSold;
    }

    public void setSystemsSold(Integer systemsSold) {
        this.systemsSold = systemsSold;
    }

    public Integer getQualityVerified() {
        return qualityVerified;
    }

    public void setQualityVerified(Integer qualityVerified) {
        this.qualityVerified = qualityVerified;
    }

    public Integer getInstalledCapacity() {
        return installedCapacity;
    }

    public void setInstalledCapacity(Integer installedCapacity) {
        this.installedCapacity = installedCapacity;
    }

    public Integer getSystemsOnPaygo() {
        return systemsOnPaygo;
    }

    public void setSystemsOnPaygo(Integer systemsOnPaygo) {
        this.systemsOnPaygo = systemsOnPaygo;
    }

    public Double getPar30() {
        return par30;
    }

    public void setPar30(Double par30) {
        this.par30 = par30;
    }

    public Double getDefaultRate() {
        return defaultRate;
    }

    public void setDefaultRate(Double defaultRate) {
        this.defaultRate = defaultRate;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SubCountySummaryHist)) {
            return false;
        }
        SubCountySummaryHist other = (SubCountySummaryHist) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.SubCountySummaryHist[ id=" + id + " ]";
    }
    
}
