/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.rest;

import au.com.bytecode.opencsv.CSVReader;
import ch.villagepower.dao.CompanyService;
import ch.villagepower.dao.CountyService;
import ch.villagepower.dao.DeviceService;
import ch.villagepower.dao.DistrictService;
import ch.villagepower.dao.LoanService;
import ch.villagepower.dao.SaveService;
import ch.villagepower.dao.SpecificationService;
import ch.villagepower.dao.SubCountyService;
import ch.villagepower.entities.Company;
import ch.villagepower.entities.County;
import ch.villagepower.entities.CountySummary;
import ch.villagepower.entities.CountySystemSold;
import ch.villagepower.entities.District;
import ch.villagepower.entities.Loan;
import ch.villagepower.entities.Specification;
import ch.villagepower.entities.SubCounty;
import ch.villagepower.utils.JsonInput;
import ch.villagepower.utils.JsonReply;
import ch.villagepower.utils.PrintJson;
import com.google.gson.Gson;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;
import org.apache.log4j.Logger;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

/**
 * REST Web Service
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Path("county")
public class CountyResource {

    @Context
    private UriInfo context;

    final Logger log = Logger.getLogger(CountyResource.class.getName());

    Gson gson;
    JsonReply reply;
    JsonInput input;

    @EJB
    SaveService save = new SaveService();

    @EJB
    DeviceService deviceService = new DeviceService();

    @EJB
    CountyService countyService = new CountyService();

    @EJB
    DistrictService districtService = new DistrictService();

    @EJB
    LoanService loanService = new LoanService();

    @EJB
    SpecificationService specificationService = new SpecificationService();

    @EJB
    CompanyService companyService = new CompanyService();

    @EJB
    SubCountyService subCountyService = new SubCountyService();

    /**
     * Creates a new instance of CountyResource
     */
    public CountyResource() {
    }

    //**************upload countys csv file*****************
    @POST
    @Path("countyUpload")
    //@Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @ApiOperation(value = "Upload Countys", notes = "Upload countys csv file.", response = JsonReply.class)
    public String countyUpload(
            @ApiParam(value = "Actual file") @FormDataParam("file") InputStream uploadedInputStream,
            @FormDataParam("file") FormDataContentDisposition fileDetail,
            @FormDataParam("file") FormDataBodyPart body) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("csvUploadCounty");
        try {

            gson = new Gson();

            String uploadedFileLocation = "/home/glassfish/county.csv";
            log.info("file location" + uploadedFileLocation);
            // save csv file
            PrintJson.saveToFile(uploadedInputStream, uploadedFileLocation);

            //create CSVReader object
            CSVReader reader = null;
            List<String[]> records = new ArrayList<>();
            List<County> counties = new ArrayList<>();
            try {
                //create CSVReader object
                reader = new CSVReader(new FileReader(uploadedFileLocation), ',');
                counties = new ArrayList<>();
                //read all lines at once
                records = reader.readAll();
                reader.close();

            } catch (Exception e) {

                log.info("file exception :" + e);

            } finally {
                //close file io
                if (reader != null) {
                    reader.close();
                }

            }

            log.info("////////////////////" + records.size());

            if (records.size() > 1) {

                Iterator<String[]> iterator = records.iterator();
                //skip header row

                while (iterator.hasNext()) {
                    String[] record = iterator.next();

                    County d = new County();

                    List<District> c = countyService.districtByName(record[0]);

                    if (!c.isEmpty()) {

                        d.setCountyName(record[1]);
                        d.setLatitude(Double.valueOf(record[2]));
                        d.setLongitude(Double.valueOf(record[3]));
                        d.setDistrictId(c.get(0));

                        counties.add(d);
                    } else {
                        log.info("DistrictName does not exist " + record[0]);
                    }

                }

                for (County l : counties) {

                    //District district = districtService.districtById(l.getDistrictId().getId());
                    List<County> cs = countyService.countyByNameAndDistrict(l.getCountyName(), l.getDistrictId());

                    if (cs.isEmpty()) {

                        l.setDateCreated(PrintJson.timeZoneKla());

                        save.saveObject(l);

                    } else {

                        cs.get(0).setCountyName(l.getCountyName());
                        cs.get(0).setLatitude(l.getLatitude());
                        cs.get(0).setLongitude(l.getLongitude());
                        cs.get(0).setDistrictId(l.getDistrictId());

                        save.updateObject(cs.get(0));
                    }

                }

                reply.setSucc("Upload Done " + counties.size() + " countys");
                log.info("@@@@@ Upload Done " + counties.size() + " countys");

            } else {
                log.error("Empty File : ");
                reply.setError("Empty File");
            }
        } catch (IOException ex) {

            log.error("This is file error : " + ex);
            reply.setError("file error" + ex.toString());
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: Get Counties by District :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "District Counties", notes = "District Counties.", response = JsonReply.class)
    @Path("DistrictCounties")
    public String districtCounties(@Context Request req, @ApiParam(value = "JsonInput") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("DistrictCounties");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.district != null) {

                if (input.district.getDistrictName().length() < 0) {
                    log.info("DistrictName should have a value");
                    reply.setError("DistrictName should have a value");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    List<District> cmp = districtService.districtByName(input.district.getDistrictName());
                    if (!cmp.isEmpty()) {

                        List<County> loans = countyService.countyByDistrict(cmp.get(0));

                        if (!loans.isEmpty()) {
                            Collections.sort(loans,new Comparator<County>() {


                                @Override
                                public int compare(County song1, County song2) {
                                    if (song1.equals(song2)) {
                                        return 0;
                                    }
                                    return song1.getCountyName().compareToIgnoreCase(song2.getCountyName());
                                }
                            });

                            reply.counties = loans;
                            reply.setSucc("Counties found");
                        } else {
                            reply.setError("No Counties for District: " + cmp.get(0).getDistrictName());
                        }

                    } else {
                        log.info("This District does not Exist " + input.district.getDistrictName());
                        reply.setError("This District does not Exist " + input.district.getDistrictName());
                    }
                }

            } else {
                log.info("Please Send some JSON or Send DeviceSupported object");
                reply.setError("Please Send some JSON or Send DeviceSupported object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: UPDATE County:+++++++++++++++++++++++++++++++
    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Update County", notes = "Update County.", response = JsonReply.class)
    @Path("updateCounty")
    public String updateCounty(@Context Request req, @ApiParam(value = "JsonInput.county") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("updateCounty");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.county != null) {

                if (input.county == null) {
                    log.info("County should have a value");
                    reply.setError("County should have a value");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    County loan = countyService.countyById(input.county.getId());

                    if (loan != null) {

                        loan.setLastUpdated(PrintJson.timeZoneKla());
                        loan.setCountyName(input.county.getCountyName());
                        loan.setLatitude(input.county.getLatitude());
                        loan.setLongitude(input.county.getLongitude());
                        save.updateObject(loan);

                        reply.counties = countyService.findAll();
                        reply.setSucc("County updated");

                    } else {
                        log.info("This County does not Exist " + input.county.getId());
                        reply.setError("This County does not Exist " + input.county.getId());
                    }
                }

            } else {
                log.info("Please Send some JSON or Send County object");
                reply.setError("Please Send some JSON or Send County object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: Query All county Analysis Data :+++++++++++++++++++++++++++++++
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Query All Analysis Dats", notes = "Update All Analysis Data.", response = JsonReply.class)
    @Path("queryAllDataCounty")
    public String queryAllData() throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("queryAllDataCounty");

        try {

            List<CountySystemSold> dss = countyService.findAllCountyData();
            if (!dss.isEmpty()) {

                reply.countySystemSolds = dss;
                reply.setSucc("Found Data");

            } else {
                log.info("no analysis data ");
                reply.setError("no analysis data ");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: Query Analysis Data :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Query Analysis Dats", notes = "Update Analysis Data.", response = JsonReply.class)
    @Path("queryDataCounty")
    public String queryData(@Context Request req, @ApiParam(value = "JsonInput.systemSoldQuery") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("queryAllDataCounty");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.systemSoldQuery != null) {

                if (input.systemSoldQuery.getDistrict().length() < 0) {
                    log.info("Query should have a value in district");
                    reply.setError("Query should have in district");
                } else {

                    // if(input.systemSoldQuery.getQueryType().equalsIgnoreCase("system")){
                    List<District> c = countyService.districtByName(input.systemSoldQuery.getDistrict());

                    if (!c.isEmpty()) {
                        List<County> dists = countyService.countyByDistrict(c.get(0));
                        if (!dists.isEmpty()) {
                            List<CountySystemSold> dssss = new ArrayList<>();
                            for (County d : dists) {
                                List<CountySystemSold> dss = countyService.countySold(d);
                                if (!dss.isEmpty()) {

                                    dssss.add(dss.get(0));

                                } else {
                                    log.info("This District/County has no analysis data " + input.systemSoldQuery.getCounty());

                                }
                            }

                            List<CountySummary> cs = countyService.countySummary(c.get(0).getId());

                            if (!cs.isEmpty()) {
                                reply.countySummary = cs.get(0);
                            } else {
                                reply.message = "no county summmary";
                            }

                            reply.countySystemSolds = dssss;
                            reply.setSucc("Found Data");
                        } else {
                            log.info("This District has no Counties " + input.systemSoldQuery.getDistrict());
                            reply.setError("This District has no Counties " + input.systemSoldQuery.getDistrict());

                        }
                        /*}else if(input.systemSoldQuery.getQueryType().equalsIgnoreCase("quality")){

                                List<Loan> loans = loanService.loanByCountryDistrict(input.systemSoldQuery.getCountry(), input.systemSoldQuery.getDistrict());

                                if(!loans.isEmpty()){


                                }else{
                                        log.info("This Country/District does not Exist "+input.systemSoldQuery.getCountry());
                                        reply.setError("This Country/District does not Exist "+input.systemSoldQuery.getCountry());
                                }*/
                        // }
                    } else {

                        log.info("This District/County has no analysis data " + input.systemSoldQuery.getDistrict());
                        reply.setError("This District/county has no analysis data " + input.systemSoldQuery.getDistrict());

                    }
                }

            } else {
                log.info("Please Send some JSON or Send Query object");
                reply.setError("Please Send some JSON or Send Query object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: UPDATE Analysis Data on Counties :+++++++++++++++++++++++++++++++
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Update Analysis Data County", notes = "Update Analysis Data County.", response = JsonReply.class)
    @Path("updateDataCounty")
    public String updateDataCounty() throws com.google.gson.JsonSyntaxException {

        //response
        reply = new JsonReply("updateDataCounty");

        try {

            int systemSoldNumber;
            int qualityVerifiedNumber;
            float qualityVerifiedAmount;
            double systemSoldAmount;
            int capacityInstalledNumber;
            float capacityInstalledAmount;
            int solarOnPayGo;
            int defaulted;
            double outstandingPar30;
            double outstandingTotal;

            List<County> counties = countyService.findAll();
            List<District> districts = districtService.findAll();

            //if(!districts.isEmpty()){
            //for(District c:districts){
            for (County d : counties) {

                List<Loan> loans = loanService.loanByCountyInDistrict(d.getCountyName(), d.getDistrictId().getDistrictName());

                systemSoldNumber = loans.size();
                solarOnPayGo = 0;
                qualityVerifiedNumber = 0;
                qualityVerifiedAmount = 0;
                systemSoldAmount = 0;
                capacityInstalledNumber = 0;

                defaulted = 0;
                outstandingPar30 = 0;
                outstandingTotal = 0;

                if (!loans.isEmpty()) {

                    Company cm;

                    for (Loan l : loans) {

                        systemSoldAmount++;//=l.getOriginalOutstandingBalance().floatValue();
                        outstandingTotal += l.getCurrentOutstandingBalance();

                        cm = companyService.companyById(l.getCompanyId());
                        if (cm != null) {
                            //List<Specification> specs =  specificationService.specificationByModel(l.getModel().toUpperCase());
                            List<Specification> specs = specificationService.specificationByModelAndCompany(l.getModel().toUpperCase(), cm);
                            //List<Specification> specs =  specificationService.specificationByModel(l.getModel().toUpperCase());

                            if (!specs.isEmpty()) {
                                if ("hire-purchase".equalsIgnoreCase(l.getSalesMode())) {
                                    solarOnPayGo++;

                                }

                                if ("defaulted".equalsIgnoreCase(l.getDefaulted())) {
                                    defaulted++;
                                }

                                if ("par 30".equalsIgnoreCase(l.getPar())) {
                                    outstandingPar30 += l.getCurrentOutstandingBalance();

                                }

                                for (Specification s : specs) {
                                    if (s.getQualityVerified()) {
                                        qualityVerifiedNumber++;
                                        qualityVerifiedAmount += s.getMaxPowerOutput();//l.getCurrentOutstandingBalance().floatValue();

                                    }

                                    capacityInstalledNumber += s.getMaxPowerOutput();
                                    //capacityInstalledAmount +=s.getMaxPowerOutput();//=l.getCurrentOutstandingBalance().floatValue();
                                }
                            } else {
                                log.info("Specification for loan does not exist" + l.getId());
                                reply.setError("Specification for loan does not exist" + l.getId());

                            }
                        } else {
                            log.info("A loan belongs to a company that does not exist" + l.getId());
                            reply.setError("A loan belongs to a company that does not exist" + l.getId());

                        }

                    }

                }

                //count number of reporting companies then set displayable                            
                List<Company> companys = companyService.findAll();
                int reporting = 0;
                String displayable;
                String displayableSales;
                String displayablePAYG;
                String displayableVerified;

                String flagishPAR;
                String flagishDefaulted;
                for (Company cmps : companys) {
                    for (Loan ll : loans) {
                        if (Objects.equals(ll.getCompanyId(), cmps.getId())) {
                            reporting++;
                            break;
                        }

                    }

                }

                if (reporting < companyService.reportingByLevel("county").get(0).getMinimum() && systemSoldNumber > 0) {
                    displayableSales = "Undisclosable";
                    displayable = "Undisclosable";

                } else if (systemSoldNumber == 0) {
                    displayableSales = "0";
                    displayable = "0";
                } else {
                    displayableSales = String.valueOf(systemSoldNumber);
                    displayable = String.valueOf(capacityInstalledNumber);
                }

                if (reporting < companyService.reportingByLevel("county").get(0).getMinimum() && qualityVerifiedNumber > 0) {
                    displayableVerified = "Undisclosable";

                } else if (qualityVerifiedNumber == 0) {
                    displayableVerified = "0";
                } else {
                    displayableVerified = String.valueOf(qualityVerifiedNumber);
                }

                if (reporting < companyService.reportingByLevel("county").get(0).getMinimum() && solarOnPayGo > 0) {
                    displayablePAYG = "Undisclosable";

                } else if (solarOnPayGo == 0) {
                    displayablePAYG = "0";
                } else {
                    displayablePAYG = String.valueOf(solarOnPayGo);
                }

                CountySystemSold dss = new CountySystemSold();
                dss.setCapacityInstalledNumber(capacityInstalledNumber);
                dss.setDateCreated(PrintJson.timeZoneKla());
                dss.setCountyId(d);
                dss.setDisplayable(displayable);
                dss.setDisplayableSales(displayableSales);
                dss.setDisplayableVerified(displayableVerified);
                dss.setDisplayablePAYG(displayablePAYG);
                //dss.setCountryId(c);
                dss.setQulaityVerifiedNumber(qualityVerifiedNumber);
                dss.setSystemSoldAmount(systemSoldAmount);
                dss.setSystemsSoldNumber(systemSoldNumber);
                dss.setSystemsOnPayGoNumber(solarOnPayGo);

                double df = 0.0;
                if (solarOnPayGo == 0 || defaulted == 0) {
                    dss.setDefaultRate(df);
                } else {
                    df = Double.valueOf(String.valueOf(defaulted)) / Double.valueOf(String.valueOf(solarOnPayGo));
                    dss.setDefaultRate(Math.round(df * 1000.0) / 10.0);
                }
                dss.setDefaulted(defaulted);
                        double par=0;
                        if (outstandingTotal==0.0) {
                            dss.setPARnumber(0.0);
                        } else {
                            par = outstandingPar30 /outstandingTotal ;
                            dss.setPARnumber(Math.round(par * 1000.0) / 10.0);
                        }

                if (reporting < companyService.reportingByLevel("county").get(0).getMinimum() && solarOnPayGo > 0) {
                    flagishPAR = "Undisclosable";
                } else if (reporting < companyService.reportingByLevel("county").get(0).getMinimum() && solarOnPayGo == 0) {
                    flagishPAR = "No Data";
                } else if (dss.getPARnumber() == 0) {
                    flagishPAR = "0";
                } else {
                    flagishPAR = String.valueOf(dss.getPARnumber()) + "%";
                }

                if (reporting < companyService.reportingByLevel("county").get(0).getMinimum() && solarOnPayGo > 0) {
                    flagishDefaulted = "Undisclosable";
                } else if (reporting < companyService.reportingByLevel("county").get(0).getMinimum() && solarOnPayGo == 0) {
                    flagishDefaulted = "No Data";
                } else if (dss.getDefaultRate() == 0) {
                    flagishDefaulted = "0";
                } else {
                    flagishDefaulted = String.valueOf(dss.getDefaultRate()) + "%";
                }

                dss.setFlagPAR(flagishPAR);
                dss.setFlagDefaulted(flagishDefaulted);

                List<CountySystemSold> dis = countyService.countySoldByCounty(d);
                if (dis.isEmpty()) {

                    save.saveObject(dss);
                } else {
                    dis.get(0).setCapacityInstalledNumber(capacityInstalledNumber);
                    //dis.get(0).set(PrintJson.timeZoneKla());
                    //dis.get(0).setDistrictId(d);

                    //dss.setCountryId(c);
                    dis.get(0).setDateCreated(PrintJson.timeZoneKla());
                    dis.get(0).setQulaityVerifiedNumber(qualityVerifiedNumber);
                    dis.get(0).setSystemSoldAmount(systemSoldAmount);
                    dis.get(0).setSystemsSoldNumber(systemSoldNumber);
                    dis.get(0).setSystemsOnPayGoNumber(solarOnPayGo);
                    dis.get(0).setDisplayable(displayable);
                    dis.get(0).setDisplayableSales(displayableSales);
                    dis.get(0).setDisplayableVerified(displayableVerified);
                    dis.get(0).setDisplayablePAYG(displayablePAYG);
                    dis.get(0).setDefaultRate(Math.round(df * 1000.0) / 10.0);
                    dis.get(0).setDefaulted(defaulted);
                    dis.get(0).setFlagPAR(flagishPAR);
                    dis.get(0).setFlagDefaulted(flagishDefaulted);

                    if ("NaN".equalsIgnoreCase(String.valueOf(par))) {
                        dis.get(0).setPARnumber(0.0);
                    } else {
                        dis.get(0).setPARnumber(Math.round(par * 1000.0) / 10.0);
                    }
                    save.updateObject(dis.get(0));
                }

            }

            for (District c : districts) {

                List<County> dists = countyService.countyByDistrict(c);
                if (!dists.isEmpty()) {
                    int totalSystemsSold = 0;
                    int totalQualityVerified = 0;
                    int totalInstalledCapacity = 0;
                    double totalPar30 = 0;
                    int totalSystemsPayGo = 0;
                    double totalDefaulted = 0;
                    List<CountySystemSold> dssp;

                    for (County d : dists) {
                        dssp = countyService.countySold(d);
                        totalSystemsSold += dssp.get(0).getSystemsSoldNumber();
                        totalQualityVerified += dssp.get(0).getQulaityVerifiedNumber();
                        totalInstalledCapacity += dssp.get(0).getCapacityInstalledNumber();
                        totalSystemsPayGo += dssp.get(0).getSystemsOnPayGoNumber();
                        totalDefaulted += dssp.get(0).getDefaulted();
                        totalPar30 += dssp.get(0).getPARnumber();

                    }

                    String cmp = String.valueOf(totalPar30 / 1000.0);

                    List<CountySummary> css = countyService.countySummary(c.getId());

                    if (!css.isEmpty()) {

                        if (totalSystemsPayGo == 0 /*|| totalDefaulted == 0*/) {
                            css.get(0).setDefaultRate(0.0);
                        } else {
                            //css.get(0).setDefaultRate(BigDecimal.valueOf(totalDefaulted).divide(BigDecimal.valueOf(totalSystemsPayGo), 2, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100.0)));
                            css.get(0).setDefaultRate(Math.round((totalDefaulted / totalSystemsPayGo) * 1000) / 10.0);

                        }

                        //css.get(0).setDefaultRate(Math.round((totalDefaulted/totalSystemsPayGo) * 1000.0) / 10.0);
                        css.get(0).setDistrictId(c.getId());
                        css.get(0).setInstalledCapacity(totalInstalledCapacity);

                        if ("NaN".equalsIgnoreCase(cmp)) {
                            css.get(0).setPar30(0.0);
                        } else {
                            css.get(0).setPar30(Math.round((totalPar30 / 1000.0)) * 10.0);
                        }
                        css.get(0).setQualityVerified(totalQualityVerified);
                        css.get(0).setSystemsOnPaygo(totalSystemsPayGo);
                        css.get(0).setSystemsSold(totalSystemsSold);

                        save.updateObject(css.get(0));

                    } else {

                        CountySummary cs = new CountySummary();

                        if (totalSystemsPayGo == 0 /*|| totalDefaulted == 0*/) {
                            //cs.setDefaultRate(BigDecimal.ZERO);
                            cs.setDefaultRate(0.0);
                        } else {
                            //cs.setDefaultRate(BigDecimal.valueOf(totalDefaulted).divide(BigDecimal.valueOf(totalSystemsPayGo), 2, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100.0)));
                            cs.setDefaultRate(Math.round((totalDefaulted / totalSystemsPayGo) * 1000) / 10.0);

                        }

                        cs.setDistrictId(c.getId());
                        cs.setInstalledCapacity(totalInstalledCapacity);

                        if ("NaN".equalsIgnoreCase(cmp)) {
                            cs.setPar30(0.0);
                        } else {
                            cs.setPar30(Math.round((totalPar30 / 1000.0)) * 10.0);
                        }

                        cs.setPar30(Math.round((totalPar30 / 1000.0)) * 10.0);
                        cs.setQualityVerified(totalQualityVerified);
                        cs.setSystemsOnPaygo(totalSystemsPayGo);
                        cs.setSystemsSold(totalSystemsSold);
                        save.saveObject(cs);
                    }

                    log.info("District county " + c.getDistrictName() + " data saved");

                } else {
                    reply.setError("No counties in district " + c.getDistrictName());
                }

            }

            reply.setSucc("Data analysed and persisted");

            /* }else{
                reply.setError("District does not exist");
                log.info("Dstrict does not exist");
                }*/
        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    //**************endpoint for all counties*****************
    @GET
    @Path("allCounties")
    //@Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    public String findAllCounties() {

        reply = new JsonReply("getAllCounties");

        gson = new Gson();

        List<County> company = countyService.getAllCounties();

        Collections.sort(company,new Comparator<County>() {


            @Override
            public int compare(County song1, County song2) {
                if (song1.equals(song2)) {
                    return 0;
                }
                return song1.getCountyName().compareToIgnoreCase(song2.getCountyName());
            }
        });
        
        reply.counties = company;
        reply.setSucc(company.size() + " counties");

        return reply.toString();
    }

    @POST
    @Path("deleteCounty")
    //@Secured({ch.villagepower.filter.Role.administrator})
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "delete County", notes = "deleteCounty Delete.", response = JsonReply.class)
    public String deleteCounty(@Context Request req, @ApiParam(value = "JsonInput.County") String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("deleteCounty");

        gson = new Gson();

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.county != null) {

                if (input.county.getId() != null) {
                    // get district by Id   
                    County u = countyService.countyById(input.county.getId());
                    if (null != u) {

                        List<SubCounty> ur = subCountyService.subCountyByCounty(u);

                        if (!ur.isEmpty()) {
                            for (SubCounty urr : ur) {
                                save.deleteObject(urr);
                            }
                            log.info("SubCounty deleted successfully");
                        }

                        save.deleteObject(u);
                        reply.setSucc("County deleted successfully");

                    } else {
                        log.info("County does not exist");
                        reply.setError("County does not exist");
                    }

                } else {

                    log.info("Send County object");
                    reply.setError("Send County object");
                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();

    }

    /**
     * Retrieves representation of an instance of
     * ch.villagepower.rest.CountyResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public String getXml() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of CountyResource
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }
    
    
}
