/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.rest;


import ch.villagepower.dao.CompanyService;
import ch.villagepower.dao.DistrictService;
import ch.villagepower.dao.SaveService;
import ch.villagepower.entities.Company;
import ch.villagepower.entities.District;
import ch.villagepower.entities.Reporting;
import ch.villagepower.utils.JsonInput;
import ch.villagepower.utils.JsonReply;
import ch.villagepower.utils.PrintJson;
import com.google.gson.Gson;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;
import org.apache.log4j.Logger;

/**
 * REST Web Service
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Path("company")
public class CompanyResource {

    final Logger log = Logger.getLogger(CompanyResource.class.getName());

    @Context
    private UriInfo context;

    Gson gson;
    JsonReply reply;
    JsonInput input;

    @EJB
    private SaveService save = new SaveService();

    @EJB
    CompanyService companyService = new CompanyService();

    @EJB
    DistrictService districtService = new DistrictService();



    // ++++++++++++++++++++++++: CREATE Company Reporting level :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @Path("addReportingg")
    public String addreport(@Context Request req, String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();
        reply = new JsonReply("addReporting");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.reporting != null) {

                if (input.reporting.getMinimum() == null) {
                    log.info("Company reporting should have a value");
                    reply.setError("Company reporting should have a value");
                } else {

                    //CONSTRUCT SAVE NEW Comapny
                    Reporting company = new Reporting();
                    company.setMinimum(input.reporting.getMinimum());
                    company.setLevel(input.reporting.getLevel().toLowerCase());

                    save.saveObject(company);

                    reply.reporting = companyService.findAllReporting();

                    reply.setSucc("Company Reporting Added");
                    log.info("Company Reporting Added" + company.getId());

                }

            } else {
                log.info("Please Send some JSON or Send Company object");
                reply.setError("Please Send some JSON or Send Company object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }
    
        // ++++++++++++++++++++++++: CREATE Company :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @Path("addCompany")
    public String addCompany(@Context Request req, String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();
        reply = new JsonReply("createCompany");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.company != null) {

                if (input.company.getName().length() < 0) {
                    log.info("Company should have a name");
                    reply.setError("Company should have a name");
                } else {

                    //CONSTRUCT SAVE NEW Comapny
                    Company company = new Company();
                    company.setAddress(input.company.getAddress());
                    company.setDateCreated(PrintJson.timeZoneKla());
                    company.setEmail(input.company.getEmail());
                    company.setName(input.company.getName());
                    company.setContact(input.company.getContact());
                    company.setPhone(input.company.getPhone());
                    company.setPostalAddress(input.company.getPostalAddress());
                    save.saveObject(company);

                    reply.companies = companyService.findAll();

                    reply.setSucc("Company Added");
                    log.info("Company Added" + company.getId());

                }

            } else {
                log.info("Please Send some JSON or Send Company object");
                reply.setError("Please Send some JSON or Send Company object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: UPDATE Reporting :+++++++++++++++++++++++++++++++
    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Update Reporting", notes = "Update Reporting.", response = JsonReply.class)
    @Path("updateReporting")
    public String updateReport(@Context Request req, @ApiParam(value = "JsonInput.reporting") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("updateReporting");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.reporting != null) {

                if (input.reporting.getId() == null) {
                    log.info("Company should have an id value");
                    reply.setError("Deveice should have an id value");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    Reporting company = companyService.reportingById(input.reporting.getId());

                    if (company != null) {
                        company.setLevel(input.reporting.getLevel().toLowerCase());

                        company.setMinimum(input.reporting.getMinimum());

                        save.updateObject(company);

                        reply.reporting = companyService.findAllReporting();
                        reply.setSucc("Reportiing updated");

                    } else {
                        log.info("This Company reporting level does not Exist " + input.reporting.getId());
                        reply.setError("This Company reporting lever does not Exist " + input.reporting.getId());
                    }
                }

            } else {
                log.info("Please Send some JSON or Send Reporting object");
                reply.setError("Please Send some JSON or Send Reporting object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    /**
     * Creates a new instance of CompanyResource
     */
    public CompanyResource() {
    }

    

    //**************endpoint for all companies*****************
    @GET
    @Path("allReporting")
    //@Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    public String findAllReporting() {

        reply = new JsonReply("getAllReporting");

        gson = new Gson();

        List<Reporting> company = companyService.findAllReporting();

        reply.reporting = company;
        reply.setSucc(company.size() + " Minimum Companies Reporting");

        return reply.toString();
    }
    
    //**************endpoint for all companies*****************
    @GET
    @Path("allCompanies")
    //@Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    public String findAll() {

        reply = new JsonReply("getAllcompanies");

        gson = new Gson();

        List<Company> company = companyService.findAll();

        reply.companies = company;
        reply.setSucc(company.size() + " Companies");

        return reply.toString();
    }

    //**************endpoint for all districts*****************
    @GET
    @Path("allDistricts")
    //@Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    public String findAllDistricts() {

        reply = new JsonReply("getAllDistricts");

        gson = new Gson();

        List<District> company = districtService.getAllDistricts();
        Collections.sort(company,new Comparator<District>() {


            @Override
            public int compare(District song1, District song2) {
                if (song1.equals(song2)) {
                    return 0;
                }
                return song1.getDistrictName().compareToIgnoreCase(song2.getDistrictName());
            }
        });

        reply.districts = company;
        reply.setSucc(company.size() + " districts");

        return reply.toString();
    }
    
        // ++++++++++++++++++++++++: DELETE company :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @Path("deleteCompany")
    @ApiOperation(value = "Delete company", notes = "delete company.", response = JsonReply.class)
    public String deleteCompany(@Context Request req, @ApiParam(value = "JsonInput.company") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        reply = new JsonReply("deletecompany");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null) {
                if (input.company == null) {
                    log.info("company  equired");
                    reply.setError("company required");
                } else {

                    //GET LOAN and BATCH FROM DB
                    Company b = companyService.companyById(input.company.getId());

                    if (b != null) {

                        save.deleteObject(b);
                        reply.setSucc("company deleted");

                    } else {
                        log.error("No company of that Kind " + input.company.getId());
                        reply.setError("No company of that Kind " + input.company.getId());
                    }

                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: UPDATE Company :+++++++++++++++++++++++++++++++
    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Update Company", notes = "Update Company.", response = JsonReply.class)
    @Path("updateCompany")
    public String updateCompany(@Context Request req, @ApiParam(value = "JsonInput.company") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("updateCompany");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.company != null) {

                if (null == input.company.getId()) {
                    log.info("Company should have an Id");
                    reply.setError("Deveice should have an Id");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    Company company = companyService.companyById(input.company.getId());

                    if (company != null) {
                        company.setAddress(input.company.getAddress());

                        company.setEmail(input.company.getEmail());
                        company.setLastUpdated(PrintJson.timeZoneKla());
                        company.setName(input.company.getName());
                        company.setContact(input.company.getContact());
                        company.setPhone(input.company.getPhone());
                        company.setPostalAddress(input.company.getPostalAddress());

                        save.updateObject(company);

                        reply.companies = companyService.findAll();
                        reply.setSucc("company updated");

                    } else {
                        log.info("This Company does not Exist " + input.company.getId());
                        reply.setError("This Company does not Exist " + input.company.getId());
                    }
                }

            } else {
                log.info("Please Send some JSON or Send Company object");
                reply.setError("Please Send some JSON or Send Company object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }



    /**
     * Retrieves representation of an instance of
     * ch.villagepower.rest.CompanyResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of CompanyResource
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void putJson(String content) {
    }
}
