/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;


import ch.villagepower.entities.Loan;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.apache.log4j.Logger;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Stateless
public class LoanService {

    @PersistenceContext
    private EntityManager em;

    final static Logger log = Logger.getLogger(LoanService.class.getName());

    public List<Loan> findAll() {

        List<Loan> companies;

        Query q = em.createQuery("from Loan", Loan.class);

        companies = q.getResultList();

        return companies;

    }

    public List<Loan> companyLoans(int k) {

        List<Loan> companies;

        companies = em.createQuery("SELECT l FROM Loan l WHERE l.companyId = :c")
                .setParameter("c", k).getResultList();

        return companies;

    }

    //return loan by district and country
    public List<Loan> loanByCountryDistrict(String country, String district) {

        Query q = em.createQuery("SELECT l FROM Loan l WHERE l.country = :c AND l.district = :d")
                .setParameter("c", country)
                .setParameter("d", district);

        List<Loan> loans = q.getResultList();

        return loans;
    }

    //return loan by district and country
    public List<Loan> loanByDistrict(String district) {

        Query q = em.createQuery("SELECT l FROM Loan l WHERE l.district = :d")
                .setParameter("d", district);

        List<Loan> loans = q.getResultList();

        return loans;
    }

    //return loan bycounty
    public List<Loan> loanByCounty(String district) {

        Query q = em.createQuery("SELECT l FROM Loan l WHERE l.county = :d")
                .setParameter("d", district);

        List<Loan> loans = q.getResultList();

        return loans;
    }

    //return loan by county in district
    public List<Loan> loanByCountyInDistrict(String district, String d) {

        Query q = em.createQuery("SELECT l FROM Loan l WHERE l.county = :d AND l.district = :e")
                .setParameter("e", d)
                .setParameter("d", district);

        List<Loan> loans = q.getResultList();

        return loans;
    }

    //return loan by sub-county
    public List<Loan> loanBySubCounty(String district) {

        Query q = em.createQuery("SELECT l FROM Loan l WHERE l.subCounty = :d")
                .setParameter("d", district);

        List<Loan> loans = q.getResultList();

        return loans;
    }

    //return loan by sub-county in county
    public List<Loan> loanBySubCountyInCounty(String subCounty, String county) {

        Query q = em.createQuery("SELECT l FROM Loan l WHERE l.subCounty = :d AND l.county= :e")
                .setParameter("e", county)
                .setParameter("d", subCounty);

        List<Loan> loans = q.getResultList();

        return loans;
    }

    //return loan byt id
    public Loan loanById(Integer id) {

        Loan loan = em.find(Loan.class, id);

        return loan;
    }

}
