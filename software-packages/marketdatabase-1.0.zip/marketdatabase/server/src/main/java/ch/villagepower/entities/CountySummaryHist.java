/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;

import com.google.gson.annotations.Expose;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author iainomugisha
 */
@Entity
@Table(name = "county_summary_hist")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CountySummaryHist.findAll", query = "SELECT c FROM CountySummaryHist c"),
    @NamedQuery(name = "CountySummaryHist.findById", query = "SELECT c FROM CountySummaryHist c WHERE c.id = :id"),
    @NamedQuery(name = "CountySummaryHist.findByDistrictId", query = "SELECT c FROM CountySummaryHist c WHERE c.districtId = :districtId"),
    @NamedQuery(name = "CountySummaryHist.findBySystemsSold", query = "SELECT c FROM CountySummaryHist c WHERE c.systemsSold = :systemsSold"),
    @NamedQuery(name = "CountySummaryHist.findByQualityVerified", query = "SELECT c FROM CountySummaryHist c WHERE c.qualityVerified = :qualityVerified"),
    @NamedQuery(name = "CountySummaryHist.findByInstalledCapacity", query = "SELECT c FROM CountySummaryHist c WHERE c.installedCapacity = :installedCapacity"),
    @NamedQuery(name = "CountySummaryHist.findBySystemsOnPaygo", query = "SELECT c FROM CountySummaryHist c WHERE c.systemsOnPaygo = :systemsOnPaygo"),
    @NamedQuery(name = "CountySummaryHist.findByPar30", query = "SELECT c FROM CountySummaryHist c WHERE c.par30 = :par30"),
    @NamedQuery(name = "CountySummaryHist.findByDefaultRate", query = "SELECT c FROM CountySummaryHist c WHERE c.defaultRate = :defaultRate"),
    @NamedQuery(name = "CountySummaryHist.findByMonth", query = "SELECT c FROM CountySummaryHist c WHERE c.month = :month")})
public class CountySummaryHist implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    @Expose
    private Integer id;
    @Column(name = "district_id")
    private Integer districtId;
    @Column(name = "systems_sold")
    @Expose
    private Integer systemsSold;
    @Column(name = "quality_verified")
    @Expose
    private Integer qualityVerified;
    @Column(name = "installed_capacity")
    @Expose
    private Integer installedCapacity;
    @Column(name = "systems_on_paygo")
    @Expose
    private Integer systemsOnPaygo;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "par30")
    @Expose
    private Double par30;
    @Column(name = "default_rate")
    @Expose
    private Double defaultRate;
    @Size(max = 45)
    @Column(name = "month")
    @Expose
    private String month;

    public CountySummaryHist() {
    }

    public CountySummaryHist(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getDistrictId() {
        return districtId;
    }

    public void setDistrictId(Integer districtId) {
        this.districtId = districtId;
    }

    public Integer getSystemsSold() {
        return systemsSold;
    }

    public void setSystemsSold(Integer systemsSold) {
        this.systemsSold = systemsSold;
    }

    public Integer getQualityVerified() {
        return qualityVerified;
    }

    public void setQualityVerified(Integer qualityVerified) {
        this.qualityVerified = qualityVerified;
    }

    public Integer getInstalledCapacity() {
        return installedCapacity;
    }

    public void setInstalledCapacity(Integer installedCapacity) {
        this.installedCapacity = installedCapacity;
    }

    public Integer getSystemsOnPaygo() {
        return systemsOnPaygo;
    }

    public void setSystemsOnPaygo(Integer systemsOnPaygo) {
        this.systemsOnPaygo = systemsOnPaygo;
    }

    public Double getPar30() {
        return par30;
    }

    public void setPar30(Double par30) {
        this.par30 = par30;
    }

    public Double getDefaultRate() {
        return defaultRate;
    }

    public void setDefaultRate(Double defaultRate) {
        this.defaultRate = defaultRate;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CountySummaryHist)) {
            return false;
        }
        CountySummaryHist other = (CountySummaryHist) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.CountySummaryHist[ id=" + id + " ]";
    }
    
}
