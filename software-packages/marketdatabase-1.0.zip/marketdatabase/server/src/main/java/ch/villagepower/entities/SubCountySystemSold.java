/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import com.google.gson.annotations.Expose;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Entity
@Table(name = "sub_county_system_sold")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SubCountySystemSold.findAll", query = "SELECT s FROM SubCountySystemSold s"),
    @NamedQuery(name = "SubCountySystemSold.findById", query = "SELECT s FROM SubCountySystemSold s WHERE s.id = :id"),
    @NamedQuery(name = "SubCountySystemSold.findBySystemsSoldNumber", query = "SELECT s FROM SubCountySystemSold s WHERE s.systemsSoldNumber = :systemsSoldNumber"),
    @NamedQuery(name = "SubCountySystemSold.findBySystemSoldAmount", query = "SELECT s FROM SubCountySystemSold s WHERE s.systemSoldAmount = :systemSoldAmount"),
    @NamedQuery(name = "SubCountySystemSold.findByQulaityVerifiedNumber", query = "SELECT s FROM SubCountySystemSold s WHERE s.qulaityVerifiedNumber = :qulaityVerifiedNumber"),
    @NamedQuery(name = "SubCountySystemSold.findByCapacityInstalledNumber", query = "SELECT s FROM SubCountySystemSold s WHERE s.capacityInstalledNumber = :capacityInstalledNumber"),
    @NamedQuery(name = "SubCountySystemSold.findBySystemsOnPayGoAmount", query = "SELECT s FROM SubCountySystemSold s WHERE s.systemsOnPayGoAmount = :systemsOnPayGoAmount"),
    @NamedQuery(name = "SubCountySystemSold.findByPARnumber", query = "SELECT s FROM SubCountySystemSold s WHERE s.pARnumber = :pARnumber"),
    @NamedQuery(name = "SubCountySystemSold.findByPARamount", query = "SELECT s FROM SubCountySystemSold s WHERE s.pARamount = :pARamount"),
    @NamedQuery(name = "SubCountySystemSold.findBySystemsOnPayGoNumber", query = "SELECT s FROM SubCountySystemSold s WHERE s.systemsOnPayGoNumber = :systemsOnPayGoNumber"),
    @NamedQuery(name = "SubCountySystemSold.findByDateCreated", query = "SELECT s FROM SubCountySystemSold s WHERE s.dateCreated = :dateCreated"),
    @NamedQuery(name = "SubCountySystemSold.findByDefaultRate", query = "SELECT s FROM SubCountySystemSold s WHERE s.defaultRate = :defaultRate"),
    @NamedQuery(name = "SubCountySystemSold.findByDefaulted", query = "SELECT s FROM SubCountySystemSold s WHERE s.defaulted = :defaulted")})
public class SubCountySystemSold implements Serializable {

    @Size(max = 45)
    @Column(name = "flagPAR")
    @Expose
    private String flagPAR;
    @Size(max = 45)
    @Column(name = "flagDefaulted")
    @Expose
    private String flagDefaulted;

    @Size(max = 45)
    @Column(name = "displayableVerified")
    @Expose
    private String displayableVerified;
    @Size(max = 45)
    @Column(name = "displayablePAYG")
    @Expose
    private String displayablePAYG;
    @Size(max = 45)
    @Column(name = "displayableSales")
    @Expose
    private String displayableSales;

    @Size(max = 45)
    @Expose
    @Column(name = "displayable")
    private String displayable;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    @Expose
    private Integer id;
    @Column(name = "systems_sold_number")
    @Expose
    private Integer systemsSoldNumber;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "system_sold_amount")
    @Expose
    private Double systemSoldAmount;
    @Column(name = "qulaity_verified_number")
    @Expose
    private Integer qulaityVerifiedNumber;
    @Column(name = "capacity_installed_number")
    @Expose
    private Integer capacityInstalledNumber;
    @Column(name = "systems_on_pay_go_amount")
    @Expose
    private Double systemsOnPayGoAmount;
    @Column(name = "PAR_number")
    @Expose
    private Double pARnumber;
    @Column(name = "PAR_amount")
    @Expose
    private Integer pARamount;
    @Column(name = "systems_on_pay_go_number")
    @Expose
    private Integer systemsOnPayGoNumber;
    @Column(name = "date_created")
    @Expose
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    @Column(name = "default_rate")
    @Expose
    private Double defaultRate;
    @Expose
    @Column(name = "defaulted")
    private Integer defaulted;
    @JoinColumn(name = "sub_county_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    @Expose
    private SubCounty subCountyId;

    public SubCountySystemSold() {
    }

    public SubCountySystemSold(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSystemsSoldNumber() {
        return systemsSoldNumber;
    }

    public void setSystemsSoldNumber(Integer systemsSoldNumber) {
        this.systemsSoldNumber = systemsSoldNumber;
    }

    public Double getSystemSoldAmount() {
        return systemSoldAmount;
    }

    public void setSystemSoldAmount(Double systemSoldAmount) {
        this.systemSoldAmount = systemSoldAmount;
    }

    public Integer getQulaityVerifiedNumber() {
        return qulaityVerifiedNumber;
    }

    public void setQulaityVerifiedNumber(Integer qulaityVerifiedNumber) {
        this.qulaityVerifiedNumber = qulaityVerifiedNumber;
    }

    public Integer getCapacityInstalledNumber() {
        return capacityInstalledNumber;
    }

    public void setCapacityInstalledNumber(Integer capacityInstalledNumber) {
        this.capacityInstalledNumber = capacityInstalledNumber;
    }

    public Double getSystemsOnPayGoAmount() {
        return systemsOnPayGoAmount;
    }

    public void setSystemsOnPayGoAmount(Double systemsOnPayGoAmount) {
        this.systemsOnPayGoAmount = systemsOnPayGoAmount;
    }

    public Double getPARnumber() {
        return pARnumber;
    }

    public void setPARnumber(Double pARnumber) {
        this.pARnumber = pARnumber;
    }

    public Integer getPARamount() {
        return pARamount;
    }

    public void setPARamount(Integer pARamount) {
        this.pARamount = pARamount;
    }

    public Integer getSystemsOnPayGoNumber() {
        return systemsOnPayGoNumber;
    }

    public void setSystemsOnPayGoNumber(Integer systemsOnPayGoNumber) {
        this.systemsOnPayGoNumber = systemsOnPayGoNumber;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Double getDefaultRate() {
        return defaultRate;
    }

    public void setDefaultRate(Double defaultRate) {
        this.defaultRate = defaultRate;
    }

    public Integer getDefaulted() {
        return defaulted;
    }

    public void setDefaulted(Integer defaulted) {
        this.defaulted = defaulted;
    }

    public SubCounty getSubCountyId() {
        return subCountyId;
    }

    public void setSubCountyId(SubCounty subCountyId) {
        this.subCountyId = subCountyId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SubCountySystemSold)) {
            return false;
        }
        SubCountySystemSold other = (SubCountySystemSold) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.SubCountySystemSold[ id=" + id + " ]";
    }

    public String getDisplayable() {
        return displayable;
    }

    public void setDisplayable(String displayable) {
        this.displayable = displayable;
    }

    public String getDisplayableVerified() {
        return displayableVerified;
    }

    public void setDisplayableVerified(String displayableVerified) {
        this.displayableVerified = displayableVerified;
    }

    public String getDisplayablePAYG() {
        return displayablePAYG;
    }

    public void setDisplayablePAYG(String displayablePAYG) {
        this.displayablePAYG = displayablePAYG;
    }

    public String getDisplayableSales() {
        return displayableSales;
    }

    public void setDisplayableSales(String displayableSales) {
        this.displayableSales = displayableSales;
    }

    public String getFlagPAR() {
        return flagPAR;
    }

    public void setFlagPAR(String flagPAR) {
        this.flagPAR = flagPAR;
    }

    public String getFlagDefaulted() {
        return flagDefaulted;
    }

    public void setFlagDefaulted(String flagDefaulted) {
        this.flagDefaulted = flagDefaulted;
    }

}
