/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import com.google.gson.annotations.Expose;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Entity
@Table(name = "district")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "District.findAll", query = "SELECT d FROM District d"),
    @NamedQuery(name = "District.findById", query = "SELECT d FROM District d WHERE d.id = :id"),
    @NamedQuery(name = "District.findByDistrictName", query = "SELECT d FROM District d WHERE d.districtName = :districtName"),
    @NamedQuery(name = "District.findByLastUpdated", query = "SELECT d FROM District d WHERE d.lastUpdated = :lastUpdated"),
    @NamedQuery(name = "District.findByCode", query = "SELECT d FROM District d WHERE d.code = :code"),
    @NamedQuery(name = "District.findByDateCreated", query = "SELECT d FROM District d WHERE d.dateCreated = :dateCreated"),
    @NamedQuery(name = "District.findByStringCordinate", query = "SELECT d FROM District d WHERE d.stringCordinate = :stringCordinate")})
public class District implements Serializable {

    @JoinColumn(name = "country_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    @Expose
    private Country countryId;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Expose
    @Column(name = "id")
    private Integer id;
    @Size(max = 145)
    @Column(name = "district_name")
    @Expose
    private String districtName;
    @Lob
    @Size(max = 16777215)
    @Expose
    @Column(name = "latitude")
    private String latitude;
    @Lob
    @Size(max = 16777215)
    @Column(name = "longitude")
    @Expose
    private String longitude;
    @Column(name = "last_updated")
    @Temporal(TemporalType.TIMESTAMP)
    @Expose
    private Date lastUpdated;
    @Size(max = 45)
    @Column(name = "code")
    @Expose
    private String code;
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    @Expose
    private Date dateCreated;
    @Size(max = 145)
    @Column(name = "string_cordinate")
    private String stringCordinate;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "districtId")
    private List<County> countyList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "districtId")
    private List<DistrictsSystemSold> districtsSystemSoldList;

    public District() {
    }

    public District(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getStringCordinate() {
        return stringCordinate;
    }

    public void setStringCordinate(String stringCordinate) {
        this.stringCordinate = stringCordinate;
    }

    @XmlTransient
    public List<County> getCountyList() {
        return countyList;
    }

    public void setCountyList(List<County> countyList) {
        this.countyList = countyList;
    }

    @XmlTransient
    public List<DistrictsSystemSold> getDistrictsSystemSoldList() {
        return districtsSystemSoldList;
    }

    public void setDistrictsSystemSoldList(List<DistrictsSystemSold> districtsSystemSoldList) {
        this.districtsSystemSoldList = districtsSystemSoldList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof District)) {
            return false;
        }
        District other = (District) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.District[ id=" + id + " ]";
    }

    public Country getCountryId() {
        return countryId;
    }

    public void setCountryId(Country countryId) {
        this.countryId = countryId;
    }

}
