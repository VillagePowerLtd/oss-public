/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.shiro;


import org.apache.log4j.Logger;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.config.IniSecurityManagerFactory;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.realm.jdbc.JdbcRealm;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.util.Factory;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
public class Authentication {

    private static Logger log = Logger.getLogger(Authentication.class);

    /**
     * @param args
     */
    public static void main(String[] args) {
        Authentication auth = new Authentication();
        String login = "admin";
        String pass = "admin1";
        Subject subject = auth.authenticateWithShiro(login, pass);
        if (subject != null && subject.isAuthenticated()) {
            System.out.println("successfulln");
        } else {
            System.out.println("Failedin");
        }
        auth.write();
    }

    /**
     *
     * @param username
     * @param pass
     */
    private Subject authenticateWithShiro(String username, String pass) {
        Subject currentUser = null;
        try {
            log.info("Authentication shiro is started...");
            Factory factory = new IniSecurityManagerFactory(
                    "classpath:shiro.ini");
            Object securityManager = factory
                    .getInstance();
            // the key "jdbcRealm" must be the same in the shiro.ini file.
            JdbcRealm realm = (JdbcRealm) ((IniSecurityManagerFactory) factory)
                    .getBeans().get("jdbcRealm");
            realm.setAuthenticationQuery("SELECT password FROM users WHERE username=?");
            realm.setUserRolesQuery("SELECT role.name FROM role,users_roles,users WHERE role.roleId=users_roles.roleId AND users_roles.userId=users.userId AND users.username=?");
            realm.setPermissionsQuery("SELECT permission FROM role_permission,role WHERE role_permission.roleId=role.roleId AND role.name=?");
            realm.setPermissionsLookupEnabled(true);
            SecurityUtils.setSecurityManager((SecurityManager) securityManager);
            currentUser = SecurityUtils.getSubject();
            Session session = currentUser.getSession();
            session.setAttribute("someKey", "aValue");
            String value = (String) session.getAttribute("someKey");
            if ("aValue".equals(value)) {
                log.info("Retrievedcorrect value! [" + value + "]");
            }
            // let's login the current user so we can check against roles and
            // permissions:
            if (!currentUser.isAuthenticated()) {
                UsernamePasswordToken token = new UsernamePasswordToken(
                        username, pass);
                token.setRememberMe(true);
                System.out.println("+++++++++++" + token.getPrincipal().toString());
                currentUser.login(token);

            }
        } catch (Exception e) {
            log.error("Authenticationed", e);
        }
        return currentUser;
    }

    public void write() {
        Subject subject = SecurityUtils.getSubject();
        if (subject.hasRole("Administrator")) {
            log.info("has administrator");
        } else {
            log.info("hasole");
        }
        if (subject.isPermitted("admin:write")) {
            log.info("Administratorermitted to write");
        } else {
            log.info("AdministratorOT permitted to write");
        }

    }

}
