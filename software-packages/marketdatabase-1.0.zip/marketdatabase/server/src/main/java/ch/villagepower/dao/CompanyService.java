/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;


import ch.villagepower.entities.Company;
import ch.villagepower.entities.Reporting;
import ch.villagepower.entities.UserRoles;
import ch.villagepower.entities.Users;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.apache.log4j.Logger;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Stateless
public class CompanyService {

    @PersistenceContext
    private EntityManager em;

    final static Logger log = Logger.getLogger(CompanyService.class.getName());

    public List<Company> findAll() {

        List<Company> companies;

        Query q = em.createQuery("from Company", Company.class);

        companies = q.getResultList();

        return companies;

    }

    //return company byt id
    public Company companyById(Integer id) {

        Company company = em.find(Company.class, id);

        return company;
    }

    public List<Company> companyByName(String id) {

        Query q = em.createQuery("SELECT s FROM Company s WHERE s.name = :a")
                .setParameter("a", id);

        List<Company> device = q.getResultList();

        return device;
    }

    //return company byt id
    public Reporting reportingById(Integer id) {

        Reporting company = em.find(Reporting.class, id);

        return company;
    }

    //return company byt id
    public List<Reporting> reportingByLevel(String id) {

        Query q = em.createQuery("SELECT s FROM Reporting s WHERE s.level = :a")
                .setParameter("a", id);

        return q.getResultList();
    }

    //return userRole by user
    public List<UserRoles> userRoleByUserID(Users id) {

        Query query1 = em.createQuery("SELECT r FROM UserRoles r WHERE r.userId = :b");
        query1.setParameter("b", id);

        return query1.getResultList();
    }

    public List<Reporting> findAllReporting() {

        List<Reporting> companies;

        Query q = em.createQuery("from Reporting", Reporting.class);

        companies = q.getResultList();

        return companies;

    }
}
