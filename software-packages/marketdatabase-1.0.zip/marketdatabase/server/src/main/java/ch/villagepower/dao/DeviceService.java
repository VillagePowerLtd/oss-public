/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;


/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
import ch.villagepower.entities.Company;
import ch.villagepower.entities.DeviceSupported;
import ch.villagepower.entities.Specification;
import ch.villagepower.entities.SpecificationDevice;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.apache.log4j.Logger;

@Stateless
public class DeviceService {

    @PersistenceContext
    private EntityManager em;

    final static Logger log = Logger.getLogger(DeviceService.class.getName());

    public List<DeviceSupported> findAll() {

        List<DeviceSupported> devices;

        Query q = em.createQuery("from DeviceSupported", DeviceSupported.class);

        devices = q.getResultList();

        return devices;

    }

    //return batch byt id
    public DeviceSupported deviceById(Integer id) {

        DeviceSupported device = em.find(DeviceSupported.class, id);

        return device;
    }

    //return device by specification
    public SpecificationDevice deviceSpecificationById(Integer id) {

        SpecificationDevice device = em.find(SpecificationDevice.class, id);

        return device;
    }

    //return device by specification and device
    public List<SpecificationDevice> deviceSpecAndBydeviceId(Specification s, DeviceSupported sd) {

        List<SpecificationDevice> device = em.createQuery("SELECT s FROM SpecificationDevice s WHERE s.specification = :a AND s.deviceSupportedId = :b")
                .setParameter("a", s)
                .setParameter("b", sd)
                .getResultList();

        return device;
    }
    //return device by company

    public List<DeviceSupported> deviceByCompany(Company id) {

        boolean x = true;

        Query q = em.createQuery("SELECT s FROM DeviceSupported s WHERE s.companyId = :a OR s.master = :b")
                .setParameter("a", id)
                .setParameter("b", x);

        List<DeviceSupported> device = q.getResultList();

        return device;
    }

    public List<DeviceSupported> deviceList(Integer id) {

        Query q = em.createQuery("SELECT s FROM DeviceSupported s WHERE s.id = :a")
                .setParameter("a", id);

        List<DeviceSupported> device = q.getResultList();

        return device;
    }
}
