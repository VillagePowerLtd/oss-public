/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import com.google.gson.annotations.Expose;

/**
 *
 * @author iainomugisha
 */
@Entity
@Table(name = "sub_county_system_sold_hist")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SubCountySystemSoldHist.findAll", query = "SELECT s FROM SubCountySystemSoldHist s"),
    @NamedQuery(name = "SubCountySystemSoldHist.findById", query = "SELECT s FROM SubCountySystemSoldHist s WHERE s.id = :id"),
    @NamedQuery(name = "SubCountySystemSoldHist.findBySystemsSoldNumber", query = "SELECT s FROM SubCountySystemSoldHist s WHERE s.systemsSoldNumber = :systemsSoldNumber"),
    @NamedQuery(name = "SubCountySystemSoldHist.findBySystemSoldAmount", query = "SELECT s FROM SubCountySystemSoldHist s WHERE s.systemSoldAmount = :systemSoldAmount"),
    @NamedQuery(name = "SubCountySystemSoldHist.findByQulaityVerifiedNumber", query = "SELECT s FROM SubCountySystemSoldHist s WHERE s.qulaityVerifiedNumber = :qulaityVerifiedNumber"),
    @NamedQuery(name = "SubCountySystemSoldHist.findByCapacityInstalledNumber", query = "SELECT s FROM SubCountySystemSoldHist s WHERE s.capacityInstalledNumber = :capacityInstalledNumber"),
    @NamedQuery(name = "SubCountySystemSoldHist.findBySystemsOnPayGoAmount", query = "SELECT s FROM SubCountySystemSoldHist s WHERE s.systemsOnPayGoAmount = :systemsOnPayGoAmount"),
    @NamedQuery(name = "SubCountySystemSoldHist.findByPAR30number", query = "SELECT s FROM SubCountySystemSoldHist s WHERE s.pAR30number = :pAR30number"),
    @NamedQuery(name = "SubCountySystemSoldHist.findByPAR30amount", query = "SELECT s FROM SubCountySystemSoldHist s WHERE s.pAR30amount = :pAR30amount"),
    @NamedQuery(name = "SubCountySystemSoldHist.findBySystemsOnPayGoNumber", query = "SELECT s FROM SubCountySystemSoldHist s WHERE s.systemsOnPayGoNumber = :systemsOnPayGoNumber"),
    @NamedQuery(name = "SubCountySystemSoldHist.findByDateCreated", query = "SELECT s FROM SubCountySystemSoldHist s WHERE s.dateCreated = :dateCreated"),
    @NamedQuery(name = "SubCountySystemSoldHist.findByMonth", query = "SELECT s FROM SubCountySystemSoldHist s WHERE s.month = :month"),
    @NamedQuery(name = "SubCountySystemSoldHist.findByDefaulted", query = "SELECT s FROM SubCountySystemSoldHist s WHERE s.defaulted = :defaulted"),
    @NamedQuery(name = "SubCountySystemSoldHist.findBySubCountyName", query = "SELECT s FROM SubCountySystemSoldHist s WHERE s.subCountyName = :subCountyName")})
public class SubCountySystemSoldHist implements Serializable {

    
    @Column(name = "outstandingTotal")
    @Expose
    private Double outstandingTotal;

    @Column(name = "PAR30_number")
    @Expose
    private Integer pAR30number;
    
    @Expose
    @Column(name = "PAR30_amount")
    private Double pAR30amount;
    @Size(max = 5)
    @Column(name = "month")
    @Expose
    private String month;

    @Column(name = "sub_county_id")
    @Expose
    private Integer subCountyId;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    @Expose
    private Integer id;
    @Column(name = "systems_sold_number")
    @Expose
    private Integer systemsSoldNumber;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "system_sold_amount")
    @Expose
    private Double systemSoldAmount;
    @Column(name = "qulaity_verified_number")
    @Expose
    private Integer qulaityVerifiedNumber;
    @Expose
    @Column(name = "capacity_installed_number")
    private Integer capacityInstalledNumber;
    @Column(name = "systems_on_pay_go_amount")
    @Expose
    private Double systemsOnPayGoAmount;
    @Column(name = "systems_on_pay_go_number")
    @Expose
    private Integer systemsOnPayGoNumber;
    @Column(name = "date_created")
    @Expose
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    @Expose
    @Column(name = "defaulted")
    private Integer defaulted;
    @Size(max = 245)
    @Column(name = "sub_county_name")
    @Expose
    private String subCountyName;

    public SubCountySystemSoldHist() {
    }

    public SubCountySystemSoldHist(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSystemsSoldNumber() {
        return systemsSoldNumber;
    }

    public void setSystemsSoldNumber(Integer systemsSoldNumber) {
        this.systemsSoldNumber = systemsSoldNumber;
    }

    public Double getSystemSoldAmount() {
        return systemSoldAmount;
    }

    public void setSystemSoldAmount(Double systemSoldAmount) {
        this.systemSoldAmount = systemSoldAmount;
    }

    public Integer getQulaityVerifiedNumber() {
        return qulaityVerifiedNumber;
    }

    public void setQulaityVerifiedNumber(Integer qulaityVerifiedNumber) {
        this.qulaityVerifiedNumber = qulaityVerifiedNumber;
    }

    public Integer getCapacityInstalledNumber() {
        return capacityInstalledNumber;
    }

    public void setCapacityInstalledNumber(Integer capacityInstalledNumber) {
        this.capacityInstalledNumber = capacityInstalledNumber;
    }

    public Double getSystemsOnPayGoAmount() {
        return systemsOnPayGoAmount;
    }

    public void setSystemsOnPayGoAmount(Double systemsOnPayGoAmount) {
        this.systemsOnPayGoAmount = systemsOnPayGoAmount;
    }

    public Integer getSystemsOnPayGoNumber() {
        return systemsOnPayGoNumber;
    }

    public void setSystemsOnPayGoNumber(Integer systemsOnPayGoNumber) {
        this.systemsOnPayGoNumber = systemsOnPayGoNumber;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }


    public Integer getDefaulted() {
        return defaulted;
    }

    public void setDefaulted(Integer defaulted) {
        this.defaulted = defaulted;
    }

    public String getSubCountyName() {
        return subCountyName;
    }

    public void setSubCountyName(String subCountyName) {
        this.subCountyName = subCountyName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SubCountySystemSoldHist)) {
            return false;
        }
        SubCountySystemSoldHist other = (SubCountySystemSoldHist) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.SubCountySystemSoldHist[ id=" + id + " ]";
    }

    public Integer getSubCountyId() {
        return subCountyId;
    }

    public void setSubCountyId(Integer subCountyId) {
        this.subCountyId = subCountyId;
    }

    public Integer getPAR30number() {
        return pAR30number;
    }

    public void setPAR30number(Integer pAR30number) {
        this.pAR30number = pAR30number;
    }

    public Double getPAR30amount() {
        return pAR30amount;
    }

    public void setPAR30amount(Double pAR30amount) {
        this.pAR30amount = pAR30amount;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Double getOutstandingTotal() {
        return outstandingTotal;
    }

    public void setOutstandingTotal(Double outstandingTotal) {
        this.outstandingTotal = outstandingTotal;
    }
    
}
