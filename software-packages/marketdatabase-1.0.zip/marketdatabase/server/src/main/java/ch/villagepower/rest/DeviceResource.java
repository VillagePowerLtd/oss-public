/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.rest;


import ch.villagepower.dao.CompanyService;
import ch.villagepower.dao.DeviceService;
import ch.villagepower.dao.SaveService;
import ch.villagepower.dao.SpecificationService;
import ch.villagepower.dao.UserService;
import ch.villagepower.entities.Company;
import ch.villagepower.entities.DeviceSupported;
import ch.villagepower.entities.Users;
import ch.villagepower.utils.JsonInput;
import ch.villagepower.utils.JsonReply;
import ch.villagepower.utils.PrintJson;
import com.google.gson.Gson;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;
import org.apache.log4j.Logger;

/**
 * REST Web Service
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Path("device")
public class DeviceResource {

    final Logger log = Logger.getLogger(DeviceResource.class.getName());

    @Context
    private UriInfo context;

    Gson gson;
    JsonReply reply;
    JsonInput input;

    @EJB
    SaveService save = new SaveService();

    @EJB
    DeviceService deviceService = new DeviceService();

    @EJB
    CompanyService companyService = new CompanyService();

    @EJB
    UserService userService = new UserService();

    @EJB
    SpecificationService specificationService = new SpecificationService();

    /**
     * Creates a new instance of DeviceResource
     */
    public DeviceResource() {
    }

    //**************endpoint for all devices*****************
    @GET
    @Path("allDevices")
    //@Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    public String findAll() {

        reply = new JsonReply("getAllDevices");

        gson = new Gson();

        List<DeviceSupported> deviceSupported = deviceService.findAll();

        reply.devicesSupported = deviceSupported;
        reply.setSucc(deviceSupported.size() + " Devices");

        return reply.toString();
    }

    // ++++++++++++++++++++++++: CREATE DEVICES :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @Path("addDevice")
    public String addDevice(@Context Request req, String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();
        reply = new JsonReply("addDevice");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.deviceSupported != null && input.users != null) {

                if (input.deviceSupported.getDevicesName() == null || input.deviceSupported.getCode() == null) {
                    log.info("Device should have a name or Code");
                    reply.setError("Send Deveice name and Code");
                } else {

                    Users user = userService.userById(input.users.getUserId());

                    if (user != null) {

                        //CONSTRUCT SAVE NEW BATCH
                        Company cmp = companyService.companyById(input.deviceSupported.getCompanyId().getId());
                        if (cmp != null) {
                            DeviceSupported devicesSupported = new DeviceSupported();
                            devicesSupported.setCode(input.deviceSupported.getCode());
                            devicesSupported.setDevicesName(input.deviceSupported.getDevicesName());
                            devicesSupported.setDescription(input.deviceSupported.getDescription());
                            devicesSupported.setId(input.deviceSupported.getId());
                            devicesSupported.setCompanyId(cmp);
                            devicesSupported.setDateCreated(PrintJson.timeZoneKla());

                            if ("superadministrator".equalsIgnoreCase(user.getRole())) {
                                devicesSupported.setMaster(Boolean.TRUE);
                            }

                            save.saveObject(devicesSupported);

                            DeviceSupported dev = deviceService.deviceById(devicesSupported.getId());
//                            dev.setSpecificationList(spec);
                            save.updateObject(dev);

                            reply.devicesSupported = deviceService.findAll();

                            reply.setSucc("Device Added");
                            log.info("Device Added" + devicesSupported.getId());

                        } else {
                            log.info("no company with id: " + input.deviceSupported.getCompanyId().getId());
                            reply.setError("no company with id: " + input.deviceSupported.getCompanyId().getId());
                        }

                    } else {
                        log.info("no user with id: " + input.users.getUserId());
                        reply.setError("no user with id: " + input.users.getUserId());

                    }
                }

            } else {
                log.info("Please Send some JSON or Send Device object");
                reply.setError("Please Send some JSON or Send Device object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: UPDATE Device :+++++++++++++++++++++++++++++++
    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Update Device Supported", notes = "Update Device Supported.", response = JsonReply.class)
    @Path("updateDevice")
    public String updateDevice(@Context Request req, @ApiParam(value = "JsonInput.deviceSupported") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("updateDevice");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.deviceSupported != null) {

                if (input.deviceSupported == null) {
                    log.info("Device should have a value");
                    reply.setError("Deveice should have a value");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    DeviceSupported device = deviceService.deviceById(input.deviceSupported.getId());
                    if (device != null) {
                        device.setCode(input.deviceSupported.getCode());

                        device.setDescription(input.deviceSupported.getDescription());
                        device.setDevicesName(input.deviceSupported.getDevicesName());
                        device.setCompanyId(input.deviceSupported.getCompanyId());

                        device.setLastUpdated(PrintJson.timeZoneKla());
//                        device.setSpecificationList(input.deviceSupported.getSpecificationList());

                        save.updateObject(device);

                        reply.devicesSupported = deviceService.findAll();
                        reply.setSucc("device updated");

                    } else {
                        log.info("This Device does not Exist " + input.deviceSupported.getId());
                        reply.setError("This Device does not Exist " + input.deviceSupported.getId());
                    }
                }

            } else {
                log.info("Please Send some JSON or Send DeviceSupported object");
                reply.setError("Please Send some JSON or Send DeviceSupported object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: Get Devices by Company :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Company Devices Supported", notes = "Company Devices.", response = JsonReply.class)
    @Path("companyDevices")
    public String companyDevice(@Context Request req, @ApiParam(value = "JsonInput.company") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("companyDevices");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.company != null) {

                if (input.company.getId() == null) {
                    log.info("Company id should have a value");
                    reply.setError("Company id should have a value");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    Company cmp = companyService.companyById(input.company.getId());
                    if (cmp != null) {

                        List<DeviceSupported> ds = deviceService.deviceByCompany(cmp);

                        if (!ds.isEmpty()) {

                            reply.devicesSupported = ds;
                            reply.setSucc("devices found");
                        } else {
                            reply.setError("No devices for Company: " + cmp.getName());
                        }

                    } else {
                        log.info("This Company does not Exist " + input.company.getId());
                        reply.setError("This Device does not Exist " + input.company.getId());
                    }
                }

            } else {
                log.info("Please Send some JSON or Send DeviceSupported object");
                reply.setError("Please Send some JSON or Send DeviceSupported object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: DELETE device :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @Path("deleteDevice")
    @ApiOperation(value = "Delete device", notes = "delete device.", response = JsonReply.class)
    public String deleteDevice(@Context Request req, @ApiParam(value = "JsonInput.device") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        reply = new JsonReply("deletedevice");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null) {
                if (input.deviceSupported == null) {
                    log.info("device  equired");
                    reply.setError("device required");
                } else {

                    //GET LOAN and BATCH FROM DB
                    DeviceSupported b = deviceService.deviceById(input.deviceSupported.getId());

                    if (b != null) {

                        save.deleteObject(b);
                        reply.setSucc("device deleted");

                    } else {
                        log.error("No device of that Kind " + input.deviceSupported.getId());
                        reply.setError("No device of that Kind " + input.deviceSupported.getId());
                    }

                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    /**
     * Retrieves representation of an instance of
     * ch.villagepower.rest.DeviceResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public String getXml() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of DeviceResource
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }
}
