/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.utils;


import ch.villagepower.entities.Company;
import ch.villagepower.entities.CountrySummary;
import ch.villagepower.entities.CountrySummaryHist;
import ch.villagepower.entities.County;
import ch.villagepower.entities.CountySummary;
import ch.villagepower.entities.CountySystemSold;
import ch.villagepower.entities.DeviceSupported;
import ch.villagepower.entities.District;
import ch.villagepower.entities.DistrictsSystemSold;
import ch.villagepower.entities.Loan;
import ch.villagepower.entities.Reporting;
import ch.villagepower.entities.Specification;
import ch.villagepower.entities.SpecificationDevice;
import ch.villagepower.entities.SubCounty;
import ch.villagepower.entities.SubCountySummary;
import ch.villagepower.entities.SubCountySummaryHist;
import ch.villagepower.entities.SubCountySystemSold;
import ch.villagepower.entities.SubCountySystemSoldHist;
import ch.villagepower.entities.Users;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.Expose;
import java.util.List;
import org.apache.log4j.Logger;

/**
 *
 * @author Mac
 */
public class JsonReply/* implements Serializable*/ {

    //private static final long serialVersionUID = 1L;
    final transient Logger log = Logger.getLogger(JsonReply.class.getName());

    //public Gson gson;
    //static Gson toStringGson = new GsonBuilder().registerTypeAdapterFactory(HibernateProxyTypeAdapter.FACTORY).setDateFormat("dd/MM/yyyy HH:mm a").setPrettyPrinting().create();
    //static Gson toStringGson = new GsonBuilder().registerTypeAdapter(SpecificationDevice.class, new MyTypeAdapter<SpecificationDevice>()).setDateFormat("dd/MM/yyyy HH:mm a").setPrettyPrinting().create();
    static Gson toStringGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("dd/MM/yyyy HH:mm a").setPrettyPrinting().create();
    @Expose
    public String transType;
    @Expose
    public boolean result;
    @Expose
    public String errorMessage;
    @Expose
    public String message;

    @Expose
    public String role;
    @Expose
    public String email;
    @Expose
    public Users user;
    @Expose
    public List<Users> users;
    @Expose
    public List<CountrySummaryHist> countrySummaryHist;
    @Expose
    public List<SubCountySummaryHist> subCountySummaryHist;
    @Expose
    public List<SubCountySystemSoldHist> subCountySystemSoldHist;
    @Expose
    public List<DeviceSupported> devicesSupported;
    @Expose
    public List<Company> companies;
    @Expose
    public List<Reporting> reporting;
    @Expose
    public List<District> districts;
    @Expose
    public List<County> counties;
    @Expose
    public List<SubCounty> subCounties;
    @Expose
    public List<Loan> loans;
    @Expose
    public List<Specification> specifications;
    @Expose
    public List<SpecificationDevice> specificationDevices;
    @Expose
    public DistrictsSystemSold districtsSystemSold;

    @Expose
    public List<DistrictsSystemSold> districtsSystemSolds;

    @Expose
    public List<CountySystemSold> countySystemSolds;

    @Expose
    public List<SubCountySystemSold> subCountySystemSolds;
    @Expose
    public String country;

    @Expose
    public int totalSystems;

    @Expose
    public CountrySummary countrySummary;

    @Expose
    public CountySummary countySummary;

    @Expose
    public SubCountySummary subCountySummary;
    @Expose
    public String jwt;
    @Expose
    public String photoUrl;
    @Expose
    public String displayableCounty;

    public JsonReply(String type) {
        log.info("+++++++++++: TRANS INIT:" + type);
        this.transType = type;
        //  gson = new Gson();
    }

    public JsonReply() {
    }

    //UTILS FOR PROCESSING
    //SET ERROR
    public void setError(String error) {
        result = false;
        errorMessage = error;
    }

    //SET SUCCESS
    public void setSucc(String message) {
        result = true;
        this.message = message;
    }

    @Override
    public String toString() {
        return toStringGson.toJson(this);
    }

}
