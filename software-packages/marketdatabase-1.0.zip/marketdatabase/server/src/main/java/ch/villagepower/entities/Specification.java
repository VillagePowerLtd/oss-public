/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import com.google.gson.annotations.Expose;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Entity
@Table(name = "specification")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Specification.findAll", query = "SELECT s FROM Specification s"),
    @NamedQuery(name = "Specification.findById", query = "SELECT s FROM Specification s WHERE s.id = :id"),
    @NamedQuery(name = "Specification.findByModel", query = "SELECT s FROM Specification s WHERE s.model = :model"),
    @NamedQuery(name = "Specification.findByQualityVerified", query = "SELECT s FROM Specification s WHERE s.qualityVerified = :qualityVerified"),
    @NamedQuery(name = "Specification.findByWp", query = "SELECT s FROM Specification s WHERE s.wp = :wp"),
    @NamedQuery(name = "Specification.findByMaxPowerOutput", query = "SELECT s FROM Specification s WHERE s.maxPowerOutput = :maxPowerOutput"),
    @NamedQuery(name = "Specification.findByDeviceSupported", query = "SELECT s FROM Specification s WHERE s.deviceSupported = :deviceSupported"),
    @NamedQuery(name = "Specification.findByLastUpdated", query = "SELECT s FROM Specification s WHERE s.lastUpdated = :lastUpdated"),
    @NamedQuery(name = "Specification.findByDateCreated", query = "SELECT s FROM Specification s WHERE s.dateCreated = :dateCreated"),
    @NamedQuery(name = "Specification.findByQuantity", query = "SELECT s FROM Specification s WHERE s.quantity = :quantity")})
public class Specification implements Serializable {

    @Size(max = 45)
    @Expose
    @Column(name = "installed")
    private String installed;

    @Column(name = "quality_verified")
    @Expose
    private Boolean qualityVerified;
    @Size(max = 145)
    @Column(name = "current")
    @Expose
    private String current;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    @Expose
    private Integer id;
    @Expose
    @Size(max = 45)
    @Column(name = "model")
    private String model;
    @Expose
    @Column(name = "Wp")
    private Integer wp;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Expose
    @Column(name = "max_power_output")
    private Double maxPowerOutput;
    @Expose
    @Column(name = "device_supported")
    private Integer deviceSupported;
    @Expose
    @Column(name = "last_updated")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdated;
    @Expose
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    //@Expose
    @Column(name = "quantity")
    private Integer quantity;
    @Expose
    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "specification")
    private List<SpecificationDevice> specificationDeviceList;
    @JoinColumn(name = "company_id", referencedColumnName = "id")
    @Expose
    @ManyToOne(optional = false)
    private Company companyId;

    public Specification() {
    }

    public Specification(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Boolean getQualityVerified() {
        return qualityVerified;
    }

    public void setQualityVerified(Boolean qualityVerified) {
        this.qualityVerified = qualityVerified;
    }

    public Integer getWp() {
        return wp;
    }

    public void setWp(Integer wp) {
        this.wp = wp;
    }

    public Double getMaxPowerOutput() {
        return maxPowerOutput;
    }

    public void setMaxPowerOutput(Double maxPowerOutput) {
        this.maxPowerOutput = maxPowerOutput;
    }

    public Integer getDeviceSupported() {
        return deviceSupported;
    }

    public void setDeviceSupported(Integer deviceSupported) {
        this.deviceSupported = deviceSupported;
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    @XmlTransient
    public List<SpecificationDevice> getSpecificationDeviceList() {
        return specificationDeviceList;
    }

    public void setSpecificationDeviceList(List<SpecificationDevice> specificationDeviceList) {
        this.specificationDeviceList = specificationDeviceList;
    }

    public Company getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Company companyId) {
        this.companyId = companyId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Specification)) {
            return false;
        }
        Specification other = (Specification) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.Specification[ id=" + id + " ]";
    }

    public String getCurrent() {
        return current;
    }

    public void setCurrent(String current) {
        this.current = current;
    }

    public String getInstalled() {
        return installed;
    }

    public void setInstalled(String installed) {
        this.installed = installed;
    }

}
