/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import com.google.gson.annotations.Expose;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Entity
@Table(name = "loan")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Loan.findAll", query = "SELECT l FROM Loan l"),
    @NamedQuery(name = "Loan.findById", query = "SELECT l FROM Loan l WHERE l.id = :id"),
    @NamedQuery(name = "Loan.findByOriginalOutstandingBalance", query = "SELECT l FROM Loan l WHERE l.originalOutstandingBalance = :originalOutstandingBalance"),
    @NamedQuery(name = "Loan.findByCurrentOutstandingBalance", query = "SELECT l FROM Loan l WHERE l.currentOutstandingBalance = :currentOutstandingBalance"),
    @NamedQuery(name = "Loan.findByDaysOverdue", query = "SELECT l FROM Loan l WHERE l.daysOverdue = :daysOverdue"),
    @NamedQuery(name = "Loan.findByTotalDaysOverdue", query = "SELECT l FROM Loan l WHERE l.totalDaysOverdue = :totalDaysOverdue"),
    @NamedQuery(name = "Loan.findByLocation", query = "SELECT l FROM Loan l WHERE l.location = :location"),
    @NamedQuery(name = "Loan.findByModel", query = "SELECT l FROM Loan l WHERE l.model = :model"),
    @NamedQuery(name = "Loan.findByInstalled", query = "SELECT l FROM Loan l WHERE l.installed = :installed"),
    @NamedQuery(name = "Loan.findByStatus", query = "SELECT l FROM Loan l WHERE l.status = :status"),
    @NamedQuery(name = "Loan.findByTypeOfLoan", query = "SELECT l FROM Loan l WHERE l.typeOfLoan = :typeOfLoan"),
    @NamedQuery(name = "Loan.findByLastUpdated", query = "SELECT l FROM Loan l WHERE l.lastUpdated = :lastUpdated"),
    @NamedQuery(name = "Loan.findByDateCreated", query = "SELECT l FROM Loan l WHERE l.dateCreated = :dateCreated"),
    @NamedQuery(name = "Loan.findBySalesMode", query = "SELECT l FROM Loan l WHERE l.salesMode = :salesMode"),
    @NamedQuery(name = "Loan.findByDistrict", query = "SELECT l FROM Loan l WHERE l.district = :district"),
    @NamedQuery(name = "Loan.findByCountry", query = "SELECT l FROM Loan l WHERE l.country = :country"),
    @NamedQuery(name = "Loan.findByCounty", query = "SELECT l FROM Loan l WHERE l.county = :county"),
    @NamedQuery(name = "Loan.findBySubCounty", query = "SELECT l FROM Loan l WHERE l.subCounty = :subCounty"),
    @NamedQuery(name = "Loan.findByParish", query = "SELECT l FROM Loan l WHERE l.parish = :parish"),
    @NamedQuery(name = "Loan.findByVillage", query = "SELECT l FROM Loan l WHERE l.village = :village"),
    @NamedQuery(name = "Loan.findByNextPaymentDate", query = "SELECT l FROM Loan l WHERE l.nextPaymentDate = :nextPaymentDate"),
    @NamedQuery(name = "Loan.findByCompanyId", query = "SELECT l FROM Loan l WHERE l.companyId = :companyId")})
public class Loan implements Serializable {

    @Size(max = 45)
    @Column(name = "par")
    @Expose
    private String par;

    @Size(max = 145)
    @Column(name = "defaulted")
    @Expose
    private String defaulted;

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id")
    @Expose
    private Integer id;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "original_outstanding_balance")
    @Expose
    private Double originalOutstandingBalance;
    @Column(name = "current_outstanding_balance")
    @Expose
    private Double currentOutstandingBalance;
    @Column(name = "days_overdue")
    @Expose
    private Integer daysOverdue;
    @Column(name = "total_days_overdue")
    @Expose
    private Integer totalDaysOverdue;
    @Size(max = 145)
    @Column(name = "location")
    @Expose
    private String location;
    @Size(max = 45)
    @Column(name = "model")
    @Expose
    private String model;
    @Column(name = "installed")
    @Expose
    private Boolean installed;
    @Size(max = 45)
    @Column(name = "status")
    @Expose
    private String status;
    @Size(max = 145)
    @Column(name = "type_of_loan")
    @Expose
    private String typeOfLoan;
    @Column(name = "last_updated")
    @Expose
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdated;
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    @Expose
    private Date dateCreated;
    @Size(max = 45)
    @Column(name = "sales_mode")
    @Expose
    private String salesMode;
    @Size(max = 145)
    @Column(name = "district")
    @Expose
    private String district;
    @Size(max = 245)
    @Column(name = "country")
    @Expose
    private String country;
    @Size(max = 145)
    @Column(name = "county")
    @Expose
    private String county;
    @Size(max = 145)
    @Column(name = "sub_county")
    @Expose
    private String subCounty;
    @Size(max = 145)
    @Column(name = "parish")
    @Expose
    private String parish;
    @Size(max = 145)
    @Column(name = "village")
    @Expose
    private String village;
    @Expose
    @Column(name = "next_payment_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date nextPaymentDate;
    @Expose
    @Column(name = "company_id")
    private Integer companyId;

    public Loan() {
    }

    public Loan(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Double getOriginalOutstandingBalance() {
        return originalOutstandingBalance;
    }

    public void setOriginalOutstandingBalance(Double originalOutstandingBalance) {
        this.originalOutstandingBalance = originalOutstandingBalance;
    }

    public Double getCurrentOutstandingBalance() {
        return currentOutstandingBalance;
    }

    public void setCurrentOutstandingBalance(Double currentOutstandingBalance) {
        this.currentOutstandingBalance = currentOutstandingBalance;
    }

    public Integer getDaysOverdue() {
        return daysOverdue;
    }

    public void setDaysOverdue(Integer daysOverdue) {
        this.daysOverdue = daysOverdue;
    }

    public Integer getTotalDaysOverdue() {
        return totalDaysOverdue;
    }

    public void setTotalDaysOverdue(Integer totalDaysOverdue) {
        this.totalDaysOverdue = totalDaysOverdue;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Boolean getInstalled() {
        return installed;
    }

    public void setInstalled(Boolean installed) {
        this.installed = installed;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTypeOfLoan() {
        return typeOfLoan;
    }

    public void setTypeOfLoan(String typeOfLoan) {
        this.typeOfLoan = typeOfLoan;
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getSalesMode() {
        return salesMode;
    }

    public void setSalesMode(String salesMode) {
        this.salesMode = salesMode;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getSubCounty() {
        return subCounty;
    }

    public void setSubCounty(String subCounty) {
        this.subCounty = subCounty;
    }

    public String getParish() {
        return parish;
    }

    public void setParish(String parish) {
        this.parish = parish;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public Date getNextPaymentDate() {
        return nextPaymentDate;
    }

    public void setNextPaymentDate(Date nextPaymentDate) {
        this.nextPaymentDate = nextPaymentDate;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Loan)) {
            return false;
        }
        Loan other = (Loan) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.Loan[ id=" + id + " ]";
    }

    public String getDefaulted() {
        return defaulted;
    }

    public void setDefaulted(String defaulted) {
        this.defaulted = defaulted;
    }

    public String getPar() {
        return par;
    }

    public void setPar(String par) {
        this.par = par;
    }

}
