/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import com.google.gson.annotations.Expose;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Entity
@Table(name = "country_system_sold")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CountrySystemSold.findAll", query = "SELECT c FROM CountrySystemSold c"),
    @NamedQuery(name = "CountrySystemSold.findById", query = "SELECT c FROM CountrySystemSold c WHERE c.id = :id"),
    @NamedQuery(name = "CountrySystemSold.findBySystemsSoldNumber", query = "SELECT c FROM CountrySystemSold c WHERE c.systemsSoldNumber = :systemsSoldNumber"),
    @NamedQuery(name = "CountrySystemSold.findBySystemsSoldAmount", query = "SELECT c FROM CountrySystemSold c WHERE c.systemsSoldAmount = :systemsSoldAmount"),
    @NamedQuery(name = "CountrySystemSold.findByPARamount", query = "SELECT c FROM CountrySystemSold c WHERE c.pARamount = :pARamount"),
    @NamedQuery(name = "CountrySystemSold.findByPARnumber", query = "SELECT c FROM CountrySystemSold c WHERE c.pARnumber = :pARnumber"),
    @NamedQuery(name = "CountrySystemSold.findBySystemsOnPayGoAmount", query = "SELECT c FROM CountrySystemSold c WHERE c.systemsOnPayGoAmount = :systemsOnPayGoAmount"),
    @NamedQuery(name = "CountrySystemSold.findBySystemsOnPayGoNumber", query = "SELECT c FROM CountrySystemSold c WHERE c.systemsOnPayGoNumber = :systemsOnPayGoNumber"),
    @NamedQuery(name = "CountrySystemSold.findByQualityVerifiedNumber", query = "SELECT c FROM CountrySystemSold c WHERE c.qualityVerifiedNumber = :qualityVerifiedNumber"),
    @NamedQuery(name = "CountrySystemSold.findByCapacityInstalledNumber", query = "SELECT c FROM CountrySystemSold c WHERE c.capacityInstalledNumber = :capacityInstalledNumber"),
    @NamedQuery(name = "CountrySystemSold.findByDateCreated", query = "SELECT c FROM CountrySystemSold c WHERE c.dateCreated = :dateCreated"),
    @NamedQuery(name = "CountrySystemSold.findByDefaultRate", query = "SELECT c FROM CountrySystemSold c WHERE c.defaultRate = :defaultRate"),
    @NamedQuery(name = "CountrySystemSold.findByDefaulted", query = "SELECT c FROM CountrySystemSold c WHERE c.defaulted = :defaulted")})
public class CountrySystemSold implements Serializable {

    @Column(name = "displayable")
    @Expose
    private Boolean displayable;
    @JoinColumn(name = "id", referencedColumnName = "id")
    @OneToOne(optional = false)
    private County county;

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id")
    @Expose
    private Integer id;
    @Column(name = "systems_sold_number")
    private Integer systemsSoldNumber;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "systems_sold_amount")
    @Expose
    private Double systemsSoldAmount;
    @Column(name = "PAR_amount")
    @Expose
    private Double pARamount;
    @Column(name = "PAR_number")
    @Expose
    private Double pARnumber;
    @Column(name = "systems_on_pay_go_amount")
    @Expose
    private Double systemsOnPayGoAmount;
    @Column(name = "systems_on_pay_go_number")
    @Expose
    private Integer systemsOnPayGoNumber;
    @Column(name = "quality_verified_number")
    @Expose
    private Integer qualityVerifiedNumber;
    @Column(name = "capacity_installed_number")
    @Expose
    private Integer capacityInstalledNumber;
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    @Expose
    private Date dateCreated;
    @Column(name = "default_rate")
    @Expose
    private Double defaultRate;
    @Column(name = "defaulted")
    @Expose
    private Integer defaulted;
    @JoinColumn(name = "county_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    @Expose
    private County countyId;

    public CountrySystemSold() {
    }

    public CountrySystemSold(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSystemsSoldNumber() {
        return systemsSoldNumber;
    }

    public void setSystemsSoldNumber(Integer systemsSoldNumber) {
        this.systemsSoldNumber = systemsSoldNumber;
    }

    public Double getSystemsSoldAmount() {
        return systemsSoldAmount;
    }

    public void setSystemsSoldAmount(Double systemsSoldAmount) {
        this.systemsSoldAmount = systemsSoldAmount;
    }

    public Double getPARamount() {
        return pARamount;
    }

    public void setPARamount(Double pARamount) {
        this.pARamount = pARamount;
    }

    public Double getPARnumber() {
        return pARnumber;
    }

    public void setPARnumber(Double pARnumber) {
        this.pARnumber = pARnumber;
    }

    public Double getSystemsOnPayGoAmount() {
        return systemsOnPayGoAmount;
    }

    public void setSystemsOnPayGoAmount(Double systemsOnPayGoAmount) {
        this.systemsOnPayGoAmount = systemsOnPayGoAmount;
    }

    public Integer getSystemsOnPayGoNumber() {
        return systemsOnPayGoNumber;
    }

    public void setSystemsOnPayGoNumber(Integer systemsOnPayGoNumber) {
        this.systemsOnPayGoNumber = systemsOnPayGoNumber;
    }

    public Integer getQualityVerifiedNumber() {
        return qualityVerifiedNumber;
    }

    public void setQualityVerifiedNumber(Integer qualityVerifiedNumber) {
        this.qualityVerifiedNumber = qualityVerifiedNumber;
    }

    public Integer getCapacityInstalledNumber() {
        return capacityInstalledNumber;
    }

    public void setCapacityInstalledNumber(Integer capacityInstalledNumber) {
        this.capacityInstalledNumber = capacityInstalledNumber;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Double getDefaultRate() {
        return defaultRate;
    }

    public void setDefaultRate(Double defaultRate) {
        this.defaultRate = defaultRate;
    }

    public Integer getDefaulted() {
        return defaulted;
    }

    public void setDefaulted(Integer defaulted) {
        this.defaulted = defaulted;
    }

    public County getCountyId() {
        return countyId;
    }

    public void setCountyId(County countyId) {
        this.countyId = countyId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CountrySystemSold)) {
            return false;
        }
        CountrySystemSold other = (CountrySystemSold) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.CountrySystemSold[ id=" + id + " ]";
    }

    public Boolean getDisplayable() {
        return displayable;
    }

    public void setDisplayable(Boolean displayable) {
        this.displayable = displayable;
    }

    public County getCounty() {
        return county;
    }

    public void setCounty(County county) {
        this.county = county;
    }

}
