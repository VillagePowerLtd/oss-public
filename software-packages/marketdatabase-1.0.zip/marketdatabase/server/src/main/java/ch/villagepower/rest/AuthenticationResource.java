/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.rest;


import ch.villagepower.dao.UserService;
import ch.villagepower.entities.Users;
import ch.villagepower.filter.JWTokenUtility;
import ch.villagepower.utils.JsonInput;
import ch.villagepower.utils.JsonReply;
import ch.villagepower.utils.PrintJson;
import com.google.gson.Gson;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import org.apache.log4j.Logger;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Path("auth")
@Api(value = "auth", description = "Endpoint for Authentication specific operations")
//@Produces(MediaType.APPLICATION_JSON)
public class AuthenticationResource {

    public static final String CURRENT_USER_KEY = "currentUser";

    final static Logger log = Logger.getLogger(AuthenticationResource.class.getName());

    @EJB
    UserService userService = new UserService();

    Gson gson;
    JsonReply reply;
    JsonInput input;

    SecurityContext sc;

    @POST
    @Path("login")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "User Login", notes = "User Authentication.", response = JsonReply.class)
    public String login(@Context Request req, @ApiParam(value = "JsonInput.username & JsonInput.password") String json) throws com.google.gson.JsonSyntaxException, AuthenticationException {

        reply = new JsonReply("login");

        gson = new Gson();

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null) {
                if (input.username != null && input.password != null) {

                    if (!SecurityUtils.getSubject().isAuthenticated()) {

                        try {
                            SecurityUtils.getSubject().login(new UsernamePasswordToken(input.username, input.password, input.rememberMe));
                            Subject subject = SecurityUtils.getSubject();

                            if (subject.hasRole("company admin")) {
                                reply.role = "Company Admin";
                                reply.user = userService.findByEmail(subject.getPrincipal().toString()).get(0);
                                reply.email = subject.getPrincipal().toString();
                                reply.photoUrl = userService.findByEmail(subject.getPrincipal().toString()).get(0).getImageUrl();
                            } else if (subject.hasRole("user")) {
                                reply.role = "User";
                                reply.user = userService.findByEmail(subject.getPrincipal().toString()).get(0);
                                reply.email = subject.getPrincipal().toString();
                                //reply.usergraph = userBatchService.userGraphByUser(subject.getPrincipal().toString());
                                reply.photoUrl = userService.findByEmail(subject.getPrincipal().toString()).get(0).getImageUrl();
                            } else if (subject.hasRole("overall admin")) {
                                reply.role = "Overall Admin";
                                reply.user = userService.findByEmail(subject.getPrincipal().toString()).get(0);
                                reply.email = subject.getPrincipal().toString();
                                //reply.usergraph = userBatchService.userGraphByUser(subject.getPrincipal().toString());
                                reply.photoUrl = userService.findByEmail(subject.getPrincipal().toString()).get(0).getImageUrl();
                            }
                            reply.jwt = JWTokenUtility.buildJWT(SecurityUtils.getSubject().getPrincipal().toString());

                            log.info("successful Login");
                            reply.setSucc("Success");
                        } catch (AuthenticationException e) {

                            log.info("Login attempt :" + e);
                            reply.setError("Login attempt :Credentials did not match");
                        }

                    } else {
                        reply.setError("User is loggedIn already");
                        log.info("Already loggedIn " + SecurityUtils.getSubject().getPrincipal().toString());
                    }

                } else {

                    log.info("Username and password required");
                    reply.setError("Username and password required");
                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException | NullPointerException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR" + ex.toString());
        }

        return reply.toString();
    }

    @GET
    @Path("logout")
    @ApiOperation(value = "Logout", notes = "Authenticated User Logout.", response = JsonReply.class)
    public String logout(@Context HttpServletRequest request) {

        reply = new JsonReply("logOUT");

        gson = new Gson();
        Subject subject = SecurityUtils.getSubject();

        subject.logout();

        reply.setSucc("logged out ");
        return reply.toString();

    }

    @GET
    @Path("message")
    public Response getCurrentUser() {
        Subject subject = SecurityUtils.getSubject();
        Session session = subject.getSession(false);
        String message;
        if (session != null) {
            message = "Current user: " + subject.getPrincipal().toString();
        } else {
            message = "No current user, no session created";
        }
        return Response.ok(message).build();
    }

    @POST
    @Path("me")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public String getSubjectInfo(@Context Request req, String json) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("me");

        gson = new Gson();

        try {

            Subject subject = SecurityUtils.getSubject();
            Session session = subject.getSession(false);

            if (subject.isAuthenticated()) {

                session.getAttribute("JSESSIONID");

                Users connectedUser = this.userService.findByUsername(subject.getPrincipal().toString()).get(0);
                log.info("55555555555--ok");
                reply.setSucc("user :" + connectedUser.getUsername() + " " + session.getAttribute("JSESSIONID"));

            } else {
                log.info("faaaaileeeeed");
                reply.setError("error Not autherd");

            }
        } catch (com.google.gson.JsonSyntaxException e) {
            log.info("faaaaileeeeed" + e);
            reply.setError("failed" + e.toString());
        }

        return reply.toString();

    }

}
