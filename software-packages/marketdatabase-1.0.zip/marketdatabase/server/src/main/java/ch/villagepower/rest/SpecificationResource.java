/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.rest;


import ch.villagepower.dao.CompanyService;
import ch.villagepower.dao.DeviceService;
import ch.villagepower.dao.SaveService;
import ch.villagepower.dao.SpecificationService;
import ch.villagepower.entities.Company;
import ch.villagepower.entities.DeviceSupported;
import ch.villagepower.entities.Specification;
import ch.villagepower.entities.SpecificationDevice;
import ch.villagepower.utils.JsonInput;
import ch.villagepower.utils.JsonReply;
import ch.villagepower.utils.PrintJson;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.lang.reflect.Type;
import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;
import org.apache.log4j.Logger;
import org.json.JSONObject;

/**
 * REST Web Service
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Path("specification")
public class SpecificationResource {

    final static Logger log = Logger.getLogger(SpecificationResource.class.getName());

    @Context
    private UriInfo context;

    Gson gson;
    JsonReply reply;
    JsonInput input;

    @EJB
    SaveService save = new SaveService();

    @EJB
    SpecificationService specificationService = new SpecificationService();

    @EJB
    DeviceService deviceService = new DeviceService();

    @EJB
    CompanyService companyService = new CompanyService();

    /**
     * Creates a new instance of SpecificationResource
     */
    public SpecificationResource() {
    }

    // ++++++++++++++++++++++++: CREATE Specification :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @Path("addSpecification")
    public String addSpecification(@Context Request req, String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();
        reply = new JsonReply("createSpec");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            JSONObject js = new JSONObject(json);
            Type listOfTestObject = new TypeToken<List<SpecificationDevice>>() {
            }.getType();
            List<SpecificationDevice> s = gson.fromJson(js.getJSONObject("specification").getJSONArray("specificationDeviceList").toString(), listOfTestObject);

            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.specification != null) {

                if (input.specification == null) {
                    log.info("Specification should have a name");
                    reply.setError("Specification should have a name");
                } else {

                    //List<DeviceSupported> ds = deviceService.deviceList(input.specification.getDeviceSupported());
                    Company cmp = companyService.companyById(input.specification.getCompanyId().getId());
                    if (!input.specification.getSpecificationDeviceList().isEmpty() && cmp != null) {

                        //CONSTRUCT SAVE NEW Specification
                        Specification specification = new Specification();
                        specification.setDateCreated(PrintJson.timeZoneKla());
                        specification.setDeviceSupported(input.specification.getDeviceSupported());
                        specification.setMaxPowerOutput(input.specification.getMaxPowerOutput());
                        specification.setModel(input.specification.getModel());
                        specification.setInstalled(input.specification.getInstalled());
                        specification.setQualityVerified(input.specification.getQualityVerified());
                        specification.setWp(input.specification.getWp());
                        specification.setCompanyId(cmp);
                        specification.setQuantity(input.specification.getQuantity());
                        specification.setCurrent(input.specification.getCurrent());

                        if (!s.isEmpty()) {
                            for (SpecificationDevice ss : s) {
                                ss.setSpecification(specification);
                            }

                            specification.setSpecificationDeviceList(s);
                        }

                        save.saveObject(specification);

                        reply.specifications = specificationService.findAll();

//                            for(Specification sss:reply.specifications){
//                                //System.out.println("list "+s.getSpecificationDeviceList().get(0).getDeviceSupportedId().toString());
//                                sss.setSpecificationDeviceList(sss.getSpecificationDeviceList());
//                            }
//                            System.out.println("transient "+reply.specifications.get(0).getSpecificationDeviceList().get(0).getDevice().toString());
                        reply.setSucc("Specification Added");
                        log.info("Specification Added" + specification.getId());
                    } else {
                        log.info("Spec is not attached to valid device/Company");
                        reply.setError("Spec is not attached to valid device/Company");
                    }

                }

            } else {
                log.info("Please Send some JSON or Send Specification object");
                reply.setError("Please Send some JSON or Send Specification object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    //**************endpoint for all specifications*****************
    @GET
    @Path("allSpecifications")
    //@Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    public String findAll() {

        reply = new JsonReply("getAllspecifications");

        gson = new Gson();

        List<Specification> specification = specificationService.findAll();

        reply.specifications = specification;
        reply.setSucc(specification.size() + " Specs");

        return reply.toString();
    }

    // ++++++++++++++++++++++++: UPDATE Specification :+++++++++++++++++++++++++++++++
    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Update Specification", notes = "Update Specification.", response = JsonReply.class)
    @Path("updateSpecification")
    public String updateSpecification(@Context Request req, @ApiParam(value = "JsonInput.specification") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("updateSpecification");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.specification != null) {

                if (input.specification == null) {
                    log.info("Specification should have a value");
                    reply.setError("Deveice should have a value");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    Specification specification = specificationService.specificationById(input.specification.getId());
                    //DeviceSupported ds = deviceService.deviceById(input.specification.getDeviceSupported());

                    List<SpecificationDevice> ds = input.specification.getSpecificationDeviceList();

                    if (!ds.isEmpty()) {

                        List<SpecificationDevice> d;

//                        for(SpecificationDevice dev:ds){
//                            d = deviceService.deviceSpecificationById(dev.getId());
//                            d.setQuantity(dev.getQuantity());
//                            save.updateObject(d);
//                        }
                        Company cmp = companyService.companyById(input.specification.getCompanyId().getId());

                        if (specification != null /*&& !ds.isEmpty()*/ && cmp != null) {

                            specification.setCompanyId(input.specification.getCompanyId());

                            specification.setDeviceSupported(input.specification.getDeviceSupported());
                            specification.setLastUpdated(PrintJson.timeZoneKla());
                            specification.setMaxPowerOutput(input.specification.getMaxPowerOutput());
                            specification.setInstalled(input.specification.getInstalled());
                            specification.setModel(input.specification.getModel());
                            specification.setQualityVerified(input.specification.getQualityVerified());
                            specification.setWp(input.specification.getWp());
                            specification.setQuantity(input.specification.getQuantity());
                            //specification.setSpecificationDeviceList(input.specification.getSpecificationDeviceList());

                            save.updateObject(specification);

                            if (!ds.isEmpty()) {
                                for (SpecificationDevice dev : ds) {
                                    d = deviceService.deviceSpecAndBydeviceId(specification, dev.getDeviceSupportedId());

                                    if (!d.isEmpty()) {
                                        d.get(0).setQuantity(dev.getQuantity());
                                        save.updateObject(d.get(0));
                                    } else {
                                        save.saveObject(dev);
                                    }
                                }
                            }

                            reply.specifications = specificationService.findAll();
                            reply.setSucc("specification updated");
                        } else {
                            log.info("SpecificationDeviceList cannot be empty");
                            reply.setError("SpecificationDeviceList cannot be empty");
                        }

                    } else {
                        log.info("This Specification/company/device does not Exist " + input.specification.getId() + " " + input.specification.getCompanyId().getId() + " " + input.specification.getDeviceSupported());
                        reply.setError("This Specification/company/device does not Exist " + input.specification.getId() + " " + input.specification.getCompanyId().getId() + " " + input.specification.getDeviceSupported());
                    }
                }

            } else {
                log.info("Please Send some JSON or Send Specification object");
                reply.setError("Please Send some JSON or Send Specification object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            System.out.println("Json Error:" + ex);
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: Get Specifications by Company :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Company Specifications", notes = "Company Specifications.", response = JsonReply.class)
    @Path("companySpecifications")
    public String companySpecs(@Context Request req, @ApiParam(value = "JsonInput.company") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("companyspecifications");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.company != null) {

                if (input.company.getId() == null) {
                    log.info("Company id should have a value");
                    reply.setError("Company id should have a value");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    Company cmp = companyService.companyById(input.company.getId());
                    if (cmp != null) {

                        List<Specification> specs = specificationService.specificationByCompany(cmp);

                        if (!specs.isEmpty()) {

                            List<DeviceSupported> ds = deviceService.deviceByCompany(cmp);

                            if (!ds.isEmpty()) {
                                reply.devicesSupported = ds;
                            }

                            reply.specifications = specs;
                            reply.setSucc("Specifications found");
                        } else {
                            reply.setError("No specifications for Company: " + cmp.getName());
                        }

                    } else {
                        log.info("This Company does not Exist " + input.company.getId());
                        reply.setError("This Device does not Exist " + input.company.getId());
                    }
                }

            } else {
                log.info("Please Send some JSON or Send DeviceSupported object");
                reply.setError("Please Send some JSON or Send DeviceSupported object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: Get Specifications  devices :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Specifications Devices", notes = "Specifications Devices.", response = JsonReply.class)
    @Path("SpecificationDevices")
    public String specificationDevices(@Context Request req, @ApiParam(value = "JsonInput.specification") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("SpecificationDevices");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.specification != null) {

                if (input.specification.getId() == null) {
                    log.info("specification id should have a value");
                    reply.setError("specification id should have a value");
                } else {

                    //CONSTRUCT specification
                    Specification cmp = specificationService.specificationById(input.specification.getId());
                    if (cmp != null) {

                        List<SpecificationDevice> devices = specificationService.specificationDeviceBySpecification(cmp);

                        if (!devices.isEmpty()) {

                            reply.specificationDevices = devices;
                            reply.setSucc("SpecificationDevices found");
                        } else {
                            reply.setError("No specificationDevices for Specification: " + cmp.getId());
                        }

                    } else {
                        log.info("This specification does not Exist " + input.specification.getId());
                        reply.setError("This Specification does not Exist " + input.specification.getId());
                    }
                }

            } else {
                log.info("Please Send some JSON or Send Specification object");
                reply.setError("Please Send some JSON or Send Sepecification object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: DELETE specification :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @Path("deleteSpecification")
    @ApiOperation(value = "Delete specification", notes = "delete specification.", response = JsonReply.class)
    public String deleteSpecification(@Context Request req, @ApiParam(value = "JsonInput.specification") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        reply = new JsonReply("deletespecification");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null) {
                if (input.specification == null) {
                    log.info("specification  equired");
                    reply.setError("specification required");
                } else {

                    //GET LOAN and BATCH FROM DB
                    Specification b = specificationService.specificationById(input.specification.getId());

                    if (b != null) {

                        save.deleteObject(b);
                        reply.setSucc("specification deleted");

                    } else {
                        log.error("No specification of that Kind " + input.specification.getId());
                        reply.setError("No specification of that Kind " + input.specification.getId());
                    }

                }
            } else {
                log.info("Please Send some JSON");
                reply.setError("Please Send some JSON");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    /**
     * Retrieves representation of an instance of
     * ch.villagepower.rest.SpecificationResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public String getXml() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of SpecificationResource
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }
}
