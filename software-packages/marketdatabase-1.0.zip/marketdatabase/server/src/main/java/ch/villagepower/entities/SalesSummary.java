/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Entity
@Table(name = "Sales_Summary")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SalesSummary.findAll", query = "SELECT s FROM SalesSummary s"),
    @NamedQuery(name = "SalesSummary.findById", query = "SELECT s FROM SalesSummary s WHERE s.id = :id"),
    @NamedQuery(name = "SalesSummary.findByUploadDate", query = "SELECT s FROM SalesSummary s WHERE s.uploadDate = :uploadDate"),
    @NamedQuery(name = "SalesSummary.findBySystemsSold", query = "SELECT s FROM SalesSummary s WHERE s.systemsSold = :systemsSold"),
    @NamedQuery(name = "SalesSummary.findByDefaultedLoans", query = "SELECT s FROM SalesSummary s WHERE s.defaultedLoans = :defaultedLoans"),
    @NamedQuery(name = "SalesSummary.findByQualityVerifiedSystemsSold", query = "SELECT s FROM SalesSummary s WHERE s.qualityVerifiedSystemsSold = :qualityVerifiedSystemsSold"),
    @NamedQuery(name = "SalesSummary.findByInstalledCapacity", query = "SELECT s FROM SalesSummary s WHERE s.installedCapacity = :installedCapacity"),
    @NamedQuery(name = "SalesSummary.findBySoldOnPayg", query = "SELECT s FROM SalesSummary s WHERE s.soldOnPayg = :soldOnPayg"),
    @NamedQuery(name = "SalesSummary.findBySoldOnCommercial", query = "SELECT s FROM SalesSummary s WHERE s.soldOnCommercial = :soldOnCommercial"),
    @NamedQuery(name = "SalesSummary.findByPortfolioAtRisk", query = "SELECT s FROM SalesSummary s WHERE s.portfolioAtRisk = :portfolioAtRisk"),
    @NamedQuery(name = "SalesSummary.findByReposessedSystems", query = "SELECT s FROM SalesSummary s WHERE s.reposessedSystems = :reposessedSystems"),
    @NamedQuery(name = "SalesSummary.findByLastUpdated", query = "SELECT s FROM SalesSummary s WHERE s.lastUpdated = :lastUpdated"),
    @NamedQuery(name = "SalesSummary.findByDateCreated", query = "SELECT s FROM SalesSummary s WHERE s.dateCreated = :dateCreated")})
public class SalesSummary implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "upload_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date uploadDate;
    @Column(name = "systems_sold")
    private Integer systemsSold;
    @Column(name = "defaulted_loans")
    private Integer defaultedLoans;
    @Column(name = "quality_verified_systems_sold")
    private Integer qualityVerifiedSystemsSold;
    @Column(name = "installed_capacity")
    private Integer installedCapacity;
    @Column(name = "sold_on_payg")
    private Integer soldOnPayg;
    @Column(name = "sold_on_commercial")
    private Integer soldOnCommercial;
    @Column(name = "portfolio_at_risk")
    private Integer portfolioAtRisk;
    @Column(name = "reposessed_systems")
    private Integer reposessedSystems;
    @Column(name = "last_updated")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdated;
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    @JoinColumn(name = "company_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Company companyId;

    public SalesSummary() {
    }

    public SalesSummary(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(Date uploadDate) {
        this.uploadDate = uploadDate;
    }

    public Integer getSystemsSold() {
        return systemsSold;
    }

    public void setSystemsSold(Integer systemsSold) {
        this.systemsSold = systemsSold;
    }

    public Integer getDefaultedLoans() {
        return defaultedLoans;
    }

    public void setDefaultedLoans(Integer defaultedLoans) {
        this.defaultedLoans = defaultedLoans;
    }

    public Integer getQualityVerifiedSystemsSold() {
        return qualityVerifiedSystemsSold;
    }

    public void setQualityVerifiedSystemsSold(Integer qualityVerifiedSystemsSold) {
        this.qualityVerifiedSystemsSold = qualityVerifiedSystemsSold;
    }

    public Integer getInstalledCapacity() {
        return installedCapacity;
    }

    public void setInstalledCapacity(Integer installedCapacity) {
        this.installedCapacity = installedCapacity;
    }

    public Integer getSoldOnPayg() {
        return soldOnPayg;
    }

    public void setSoldOnPayg(Integer soldOnPayg) {
        this.soldOnPayg = soldOnPayg;
    }

    public Integer getSoldOnCommercial() {
        return soldOnCommercial;
    }

    public void setSoldOnCommercial(Integer soldOnCommercial) {
        this.soldOnCommercial = soldOnCommercial;
    }

    public Integer getPortfolioAtRisk() {
        return portfolioAtRisk;
    }

    public void setPortfolioAtRisk(Integer portfolioAtRisk) {
        this.portfolioAtRisk = portfolioAtRisk;
    }

    public Integer getReposessedSystems() {
        return reposessedSystems;
    }

    public void setReposessedSystems(Integer reposessedSystems) {
        this.reposessedSystems = reposessedSystems;
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Company getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Company companyId) {
        this.companyId = companyId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SalesSummary)) {
            return false;
        }
        SalesSummary other = (SalesSummary) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.SalesSummary[ id=" + id + " ]";
    }

}
