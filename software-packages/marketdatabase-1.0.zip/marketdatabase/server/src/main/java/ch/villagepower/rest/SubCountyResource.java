/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.rest;


import au.com.bytecode.opencsv.CSVReader;
import ch.villagepower.dao.CompanyService;
import ch.villagepower.dao.CountyService;
import ch.villagepower.dao.DeviceService;
import ch.villagepower.dao.DistrictService;
import ch.villagepower.dao.LoanService;
import ch.villagepower.dao.SaveService;
import ch.villagepower.dao.SpecificationService;
import ch.villagepower.dao.SubCountyService;
import ch.villagepower.entities.Company;
import ch.villagepower.entities.County;
import ch.villagepower.entities.District;
import ch.villagepower.entities.Loan;
import ch.villagepower.entities.Specification;
import ch.villagepower.entities.SubCounty;
import ch.villagepower.entities.SubCountySummary;
import ch.villagepower.entities.SubCountySystemSold;
import ch.villagepower.entities.CountySystemSold;
import ch.villagepower.entities.SubCountySystemSoldHist;
import ch.villagepower.utils.JsonInput;
import ch.villagepower.utils.JsonReply;
import ch.villagepower.utils.PrintJson;
import com.google.gson.Gson;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;
import org.apache.log4j.Logger;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

/**
 * REST Web Service
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Path("SubCounty")
public class SubCountyResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of SubSubCountyResource
     */
    public SubCountyResource() {
    }

    final Logger log = Logger.getLogger(SubCountyResource.class.getName());

    Gson gson;
    JsonReply reply;
    JsonInput input;

    @EJB
    SaveService save = new SaveService();

    @EJB
    DeviceService deviceService = new DeviceService();

    @EJB
    SubCountyService subCountyService = new SubCountyService();

    @EJB
    CountyService countyService = new CountyService();

    @EJB
    CompanyService companyService = new CompanyService();

    @EJB
    DistrictService districtService = new DistrictService();

    @EJB
    LoanService loanService = new LoanService();

    @EJB
    SpecificationService specificationService = new SpecificationService();

    //**************upload subCountys csv file*****************
    @POST
    @Path("subCountyUpload")
    //@Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @ApiOperation(value = "Upload SubCountys", notes = "Upload subCountys csv file.", response = JsonReply.class)
    public String subCountyUpload(
            @ApiParam(value = "Actual file") @FormDataParam("file") InputStream uploadedInputStream,
            @FormDataParam("file") FormDataContentDisposition fileDetail,
            @FormDataParam("file") FormDataBodyPart body) throws com.google.gson.JsonSyntaxException {

        reply = new JsonReply("csvUploadSubCounty");
        try {

            gson = new Gson();

            String uploadedFileLocation = "/home/glassfish/subCounty.csv";
            log.info("file location" + uploadedFileLocation);
            // save csv file
            PrintJson.saveToFile(uploadedInputStream, uploadedFileLocation);

            //create CSVReader object
            CSVReader reader = null;
            List<String[]> records = new ArrayList<>();
            List<SubCounty> counties = new ArrayList<>();
            try {
                //create CSVReader object
                reader = new CSVReader(new FileReader(uploadedFileLocation), ',');
                counties = new ArrayList<>();
                //read all lines at once
                records = reader.readAll();
                reader.close();

            } catch (Exception e) {

                log.info("file exception :" + e);

            } finally {
                //close file io
                if (reader != null) {
                    reader.close();
                }

            }

            log.info("////////////////////" + records.size());
            if (records.size() > 1) {

                Iterator<String[]> iterator = records.iterator();
                //skip header row

                //fredrick needs to upload all subcounties
                while (iterator.hasNext()) {
                    String[] record = iterator.next();

                    SubCounty d = new SubCounty();

                    List<District> dist = countyService.districtByName(record[0]);

                    List<County> c = subCountyService.countyByNameInDistrict(record[1], dist.get(0));

                    if (!c.isEmpty()) {

                        d.setSubCountyName(record[2]);
                        d.setLatitude(Double.valueOf(record[3]));
                        d.setLongitude(Double.valueOf(record[4]));
                        d.setCountyId(c.get(0));

                        counties.add(d);
                    }

                }

                for (SubCounty l : counties) {

                    //County county = districtService.districtById(l.getDistrictId().getId());
                    List<SubCounty> cs = subCountyService.subCountyByNameInCounty(l.getSubCountyName(), l.getCountyId());

                    if (cs.isEmpty()) {

                        l.setDateCreated(PrintJson.timeZoneKla());
                        System.out.println("/////////////////" + l.getCountyId());
                        System.out.println("////////////////" + l.getSubCountyName());

                        save.saveObject(l);

                    } else {

                        cs.get(0).setSubCountyName(l.getSubCountyName());
                        cs.get(0).setLatitude(l.getLatitude());
                        cs.get(0).setLongitude(l.getLongitude());
                        cs.get(0).setCountyId(l.getCountyId());

                        save.updateObject(cs.get(0));
                    }

                }

                reply.setSucc("Upload Done " + counties.size() + " subCountys");
                log.info("@@@@@ Upload Done " + counties.size() + " subCountys");

            } else {
                log.error("Empty File : ");
                reply.setError("Empty File");
            }
        } catch (IOException ex) {

            log.error("This is file error : " + ex);
            reply.setError("file error" + ex.toString());
        }

        return reply.toString();
    }
    
    
    
        // ++++++++++++++++++++++++: Query SubCounty Analysis History Data :+++++++++++++++++++++++++++++++
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Query Analysis Dats", notes = "Update Analysis Data.", response = JsonReply.class)
    @Path("querySubCountyHistory")
    public String queryHistoryData(){



        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("SubCountyHistory");
        
        List<SubCountySystemSoldHist> users = subCountyService.findAllSubCountyHist();

        if (!users.isEmpty()) {

            reply.subCountySystemSoldHist = users;

            reply.setSucc("Histroy returned " + users.size());
            log.info("History returned " + users.size());

        } else {
            log.info("No SubCounty History Data");
            reply.setError("No SubCounty History Data");
        }

        return reply.toString();

    }

    // ++++++++++++++++++++++++: UPDATE SubCounty:+++++++++++++++++++++++++++++++
    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Update SubCounty", notes = "Update SubCounty.", response = JsonReply.class)
    @Path("updateSubCounty")
    public String updateSubCounty(@Context Request req, @ApiParam(value = "JsonInput.subCounty") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("updateSubCounty");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.subCounty != null) {

                if (input.subCounty == null) {
                    log.info("SubCounty should have a value");
                    reply.setError("SubCounty should have a value");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    SubCounty loan = subCountyService.subCountyById(input.subCounty.getId());

                    if (loan != null) {

                        loan.setLastUpdated(PrintJson.timeZoneKla());
                        loan.setSubCountyName(input.subCounty.getSubCountyName());
                        loan.setLatitude(input.subCounty.getLatitude());
                        loan.setLongitude(input.subCounty.getLongitude());
                        save.updateObject(loan);

                        reply.subCounties = subCountyService.findAll();
                        reply.setSucc("SubCounty updated");

                    } else {
                        log.info("This SubCounty does not Exist " + input.subCounty.getId());
                        reply.setError("This SubCounty does not Exist " + input.subCounty.getId());
                    }
                }

            } else {
                log.info("Please Send some JSON or Send SubCounty object");
                reply.setError("Please Send some JSON or Send SubCounty object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: Query All sub-county Analysis Data :+++++++++++++++++++++++++++++++
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Query All Analysis Dats", notes = "Update All Analysis Data.", response = JsonReply.class)
    @Path("queryAllDataSubCounty")
    public String queryAllData() throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("queryAllDataSubCounty");

        try {

            List<SubCountySystemSold> dss = subCountyService.findAllSubCountyData();
            if (!dss.isEmpty()) {

                reply.subCountySystemSolds = dss;
                reply.setSucc("Found Data");

            } else {
                log.info("no analysis data ");
                reply.setError("no analysis data ");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: Query Analysis Data :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Query Analysis Dats", notes = "Update Analysis Data.", response = JsonReply.class)
    @Path("queryDataSubCounty")
    public String queryData(@Context Request req, @ApiParam(value = "JsonInput.systemSoldQuery") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("updateDataSubCounty");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.systemSoldQuery != null) {

                if (input.systemSoldQuery.getCounty().length() < 0) {
                    log.info("Query should have a value in district");
                    reply.setError("Query should have in district");
                } else {

                    // if(input.systemSoldQuery.getQueryType().equalsIgnoreCase("system")){
                    //List<District> c = subCountyService.districtByName(input.systemSoldQuery.getDistrict());
                    List<County> c = subCountyService.countyByName(input.systemSoldQuery.getCounty());

                    if (!c.isEmpty()) {
                        List<SubCounty> dists = subCountyService.subCountyByCounty(c.get(0));
                        if (!dists.isEmpty()) {
                            List<SubCountySystemSold> dssss = new ArrayList<>();
                            for (SubCounty d : dists) {
                                List<SubCountySystemSold> dss = subCountyService.subCountySold(d);
                                if (!dss.isEmpty()) {

                                    dssss.add(dss.get(0));

                                } else {
                                    log.info("This County/Subcounty has no analysis data " + input.systemSoldQuery.getCounty());

                                }
                            }

                            List<SubCountySummary> cs = subCountyService.subCountySummary(c.get(0).getId());

                            if (!cs.isEmpty()) {
                                reply.subCountySummary = cs.get(0);
                            } else {
                                reply.message = "no Subcounty summmary";
                            }

                            List<CountySystemSold> csss= countyService.countySoldByCounty(c.get(0));
                            reply.displayableCounty = csss.get(0).getDisplayableSales();
                            reply.subCountySystemSolds = dssss;
                            reply.setSucc("Found Data");
                        } else {
                            log.info("This County has no Sub-counties " + input.systemSoldQuery.getCounty());
                            reply.setError("This County has no Sub-countiess " + input.systemSoldQuery.getCounty());

                        }
                        /*}else if(input.systemSoldQuery.getQueryType().equalsIgnoreCase("quality")){

                                List<Loan> loans = loanService.loanByCountryDistrict(input.systemSoldQuery.getCountry(), input.systemSoldQuery.getDistrict());

                                if(!loans.isEmpty()){


                                }else{
                                        log.info("This Country/District does not Exist "+input.systemSoldQuery.getCountry());
                                        reply.setError("This Country/District does not Exist "+input.systemSoldQuery.getCountry());
                                }*/
                        // }
                    } else {

                        log.info("This County/Subcounty has no analysis data " + input.systemSoldQuery.getCounty());
                        reply.setError("This County/Subcounty has no analysis data " + input.systemSoldQuery.getCounty());

                    }
                }

            } else {
                log.info("Please Send some JSON or Send Query object");
                reply.setError("Please Send some JSON or Send Query object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: UPDATE Analysis Data on Counties :+++++++++++++++++++++++++++++++
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "Update Analysis Data SubCounty", notes = "Update Analysis Data SubCounty.", response = JsonReply.class)
    @Path("updateDataSubCounty")
    public String updateDataSubCounty() throws com.google.gson.JsonSyntaxException {

        //response
        reply = new JsonReply("updateDataSubCounty");

        try {

            int systemSoldNumber;
            int qualityVerifiedNumber;
            float qualityVerifiedAmount;
            double systemSoldAmount;
            int capacityInstalledNumber;
            float capacityInstalledAmount;
            int solarOnPayGo;
            double solarOnPayGoAmount;
            int defaulted;
            double outstandingPar30;
            double outstandingTotal;
            int par30;

            List<SubCounty> sCounties = subCountyService.findAll();
            List<County> counties = countyService.findAll();

            //if(!counties.isEmpty()){
            //for(County c:counties){
            for (SubCounty d : sCounties) {

                //to change   
                List<Loan> loans = loanService.loanBySubCountyInCounty(d.getSubCountyName(), d.getCountyId().getCountyName());

                systemSoldNumber = loans.size();
                solarOnPayGo = 0;
                qualityVerifiedNumber = 0;
                qualityVerifiedAmount = 0;
                systemSoldAmount = 0;
                capacityInstalledNumber = 0;
                solarOnPayGoAmount = 0;
                defaulted = 0;
                outstandingPar30 = 0;
                outstandingTotal = 0;
                par30 =0;
                

                if (!loans.isEmpty()) {

                    Company cm;

                    for (Loan l : loans) {

                        systemSoldAmount++;//=l.getOriginalOutstandingBalance().floatValue();
                        outstandingTotal += l.getCurrentOutstandingBalance();
                        cm = companyService.companyById(l.getCompanyId());
                        if (cm != null) {
                            //List<Specification> specs =  specificationService.specificationByModel(l.getModel().toUpperCase());
                            List<Specification> specs = specificationService.specificationByModelAndCompany(l.getModel().toUpperCase(), cm);
                            //List<Specification> specs =  specificationService.specificationByModel(l.getModel().toUpperCase());
                            if (!specs.isEmpty()) {

                                if ("hire-purchase".equalsIgnoreCase(l.getSalesMode())) {
                                    solarOnPayGo++;
                                    solarOnPayGoAmount+=l.getCurrentOutstandingBalance();
                                }

                                if ("defaulted".equalsIgnoreCase(l.getDefaulted())) {
                                    defaulted++;
                                }

                                if ("par 30".equalsIgnoreCase(l.getPar())) {
                                    outstandingPar30 += l.getCurrentOutstandingBalance();
                                    par30++;

                                }

                                for (Specification s : specs) {
                                    if (s.getQualityVerified()) {
                                        qualityVerifiedNumber++;
                                        qualityVerifiedAmount += s.getMaxPowerOutput();//l.getCurrentOutstandingBalance().floatValue();

                                    }

                                    capacityInstalledNumber += s.getMaxPowerOutput();
                                    //capacityInstalledAmount +=s.getMaxPowerOutput();//=l.getCurrentOutstandingBalance().floatValue();
                                }
                            }
                        } else {
                            log.info("A loan belongs to a company that does not exist" + l.getId());
                            reply.setError("A loan belongs to a company that does not exist" + l.getId());

                        }

                    }

                }

                //count number of reporting companies then set displayable                            
                List<Company> companys = companyService.findAll();
                int reporting = 0;
                String displayable;
                String displayableSales;
                String displayablePAYG;
                String displayableVerified;

                String flagishPAR;
                String flagishDefaulted;
                for (Company cmps : companys) {
                    for (Loan ll : loans) {
                        if (Objects.equals(ll.getCompanyId(), cmps.getId())) {
                            reporting++;
                            break;
                        }

                    }

                }

                if (reporting < companyService.reportingByLevel("subcounty").get(0).getMinimum() && systemSoldNumber > 0) {
                    displayableSales = "Undisclosable";
                    displayable = "Undisclosable";

                } else if (systemSoldNumber == 0) {
                    displayableSales = "0";
                    displayable = "0";
                } else {
                    displayableSales = String.valueOf(systemSoldNumber);
                    displayable = String.valueOf(capacityInstalledNumber);
                }

                if (reporting < companyService.reportingByLevel("subcounty").get(0).getMinimum() && qualityVerifiedNumber > 0) {
                    displayableVerified = "Undisclosable";

                } else if (qualityVerifiedNumber == 0) {
                    displayableVerified = "0";
                } else {
                    displayableVerified = String.valueOf(qualityVerifiedNumber);
                }

                if (reporting < companyService.reportingByLevel("subcounty").get(0).getMinimum() && solarOnPayGo > 0) {
                    displayablePAYG = "Undisclosable";

                } else if (solarOnPayGo == 0) {
                    displayablePAYG = "0";
                } else {
                    displayablePAYG = String.valueOf(solarOnPayGo);
                }

                SubCountySystemSold dss = new SubCountySystemSold();
                dss.setCapacityInstalledNumber(capacityInstalledNumber);
                dss.setDateCreated(PrintJson.timeZoneKla());
                dss.setSubCountyId(d);
                dss.setDisplayable(displayable);
                dss.setDisplayableSales(displayableSales);
                dss.setDisplayableVerified(displayableVerified);
                dss.setDisplayablePAYG(displayablePAYG);
                //dss.setCountryId(c);
                dss.setQulaityVerifiedNumber(qualityVerifiedNumber);
                dss.setSystemSoldAmount(systemSoldAmount);
                dss.setSystemsSoldNumber(systemSoldNumber);
                dss.setSystemsOnPayGoNumber(solarOnPayGo);

                double df = 0.0;
                if (solarOnPayGo == 0 || defaulted == 0) {
                    dss.setDefaultRate(df);
                } else {
                    df = Double.valueOf(String.valueOf(defaulted)) / Double.valueOf(String.valueOf(solarOnPayGo));
                    dss.setDefaultRate(Math.round(df * 1000.0) / 10.0);
                }
                dss.setDefaulted(defaulted);
                        double par=0;
                        if (outstandingTotal==0.0) {
                            dss.setPARnumber(0.0);
                        } else {
                            par = outstandingPar30 /outstandingTotal ;
                            dss.setPARnumber(Math.round(par * 1000.0) / 10.0);
                        }

                if (reporting < companyService.reportingByLevel("subcounty").get(0).getMinimum() && solarOnPayGo > 0) {
                    flagishPAR = "Undisclosable";
                } else if (reporting < companyService.reportingByLevel("subcounty").get(0).getMinimum() && solarOnPayGo == 0) {
                    flagishPAR = "No Data";
                } else if (dss.getPARnumber() == 0) {
                    flagishPAR = "0";
                } else {
                    flagishPAR = String.valueOf(dss.getPARnumber()) + "%";
                }

                if (reporting < companyService.reportingByLevel("subcounty").get(0).getMinimum() && solarOnPayGo > 0) {
                    flagishDefaulted = "Undisclosable";
                } else if (reporting < companyService.reportingByLevel("subcounty").get(0).getMinimum() && solarOnPayGo == 0) {
                    flagishDefaulted = "No Data";
                } else if (dss.getDefaultRate() == 0) {
                    flagishDefaulted = "0";
                } else {
                    flagishDefaulted = String.valueOf(dss.getDefaultRate()) + "%";
                }

                dss.setFlagPAR(flagishPAR);
                dss.setFlagDefaulted(flagishDefaulted);

                List<SubCountySystemSold> dis = subCountyService.subCountySoldBySubCounty(d);
                if (dis.isEmpty()) {

                    save.saveObject(dss);
                } else {
                    dis.get(0).setCapacityInstalledNumber(capacityInstalledNumber);
                    //dis.get(0).set(PrintJson.timeZoneKla());
                    //dis.get(0).setDistrictId(d);

                    //dss.setCountryId(c);
                    dis.get(0).setDateCreated(PrintJson.timeZoneKla());
                    dis.get(0).setQulaityVerifiedNumber(qualityVerifiedNumber);
                    dis.get(0).setSystemSoldAmount(systemSoldAmount);
                    dis.get(0).setSystemsSoldNumber(systemSoldNumber);
                    dis.get(0).setSystemsOnPayGoNumber(solarOnPayGo);
                    dis.get(0).setDisplayable(displayable);
                    dis.get(0).setDisplayableSales(displayableSales);
                    dis.get(0).setDisplayableVerified(displayableVerified);
                    dis.get(0).setDisplayablePAYG(displayablePAYG);
                    dis.get(0).setDefaultRate(Math.round(df * 1000.0) / 10.0);
                    dis.get(0).setDefaulted(defaulted);
                    dis.get(0).setFlagPAR(flagishPAR);
                    dis.get(0).setFlagDefaulted(flagishDefaulted);

                    if ("NaN".equalsIgnoreCase(String.valueOf(par))) {
                        dis.get(0).setPARnumber(0.0);
                    } else {
                        dis.get(0).setPARnumber(Math.round(par * 1000.0) / 10.0);
                    }
                    save.updateObject(dis.get(0));
                }
                
                //get current month
                Calendar cal = Calendar.getInstance();
                String month = String.valueOf(cal.get(Calendar.MONTH) + 1);
                
                
                List<SubCountySystemSoldHist> history = subCountyService.subCountySoldHistory(d,month);
                if (history.isEmpty()) {
                    SubCountySystemSoldHist hist = new SubCountySystemSoldHist();
                    
                    hist.setCapacityInstalledNumber(capacityInstalledNumber);
                    hist.setDateCreated(PrintJson.timeZoneKla());
                    hist.setQulaityVerifiedNumber(qualityVerifiedNumber);
                    hist.setSystemSoldAmount(outstandingTotal);
                    hist.setSystemsSoldNumber(systemSoldNumber);
                    hist.setSystemsOnPayGoNumber(solarOnPayGo);
                    hist.setSystemsOnPayGoAmount(solarOnPayGoAmount);
                    hist.setSubCountyId(d.getId());
                    hist.setMonth(month);
                    hist.setPAR30amount(outstandingPar30);
                    hist.setPAR30number(par30);
                    hist.setSubCountyName(d.getSubCountyName());
                    hist.setDefaulted(defaulted);
                    hist.setOutstandingTotal(outstandingTotal);

                    save.saveObject(hist);
                } else {
                    history.get(0).setCapacityInstalledNumber(capacityInstalledNumber);
                    history.get(0).setDateCreated(PrintJson.timeZoneKla());
                    history.get(0).setQulaityVerifiedNumber(qualityVerifiedNumber);
                    history.get(0).setSystemSoldAmount(outstandingTotal);
                    history.get(0).setSystemsSoldNumber(systemSoldNumber);
                    history.get(0).setSystemsOnPayGoNumber(solarOnPayGo);
                    history.get(0).setSystemsOnPayGoAmount(solarOnPayGoAmount);
                    history.get(0).setSubCountyId(d.getId());
                    history.get(0).setMonth(month);
                    history.get(0).setPAR30amount(outstandingPar30);
                    history.get(0).setPAR30number(par30);
                    history.get(0).setSubCountyName(d.getSubCountyName());
                    history.get(0).setDefaulted(defaulted);
                    history.get(0).setOutstandingTotal(outstandingTotal);


                    save.updateObject(history.get(0));
                }

            }

            for (County c : counties) {

                List<SubCounty> dists = subCountyService.subCountyByCounty(c);
                if (!dists.isEmpty()) {
                    int totalSystemsSold = 0;
                    int totalQualityVerified = 0;
                    int totalInstalledCapacity = 0;
                    double totalPar30 = 0;
                    int totalSystemsPayGo = 0;
                    double totalDefaulted = 0;
                    List<SubCountySystemSold> dssp;
                    //need to save subcounty with its county

                    for (SubCounty d : dists) {
                        dssp = subCountyService.subCountySold(d);
                        totalSystemsSold += dssp.get(0).getSystemsSoldNumber();
                        totalQualityVerified += dssp.get(0).getQulaityVerifiedNumber();
                        totalInstalledCapacity += dssp.get(0).getCapacityInstalledNumber();
                        totalSystemsPayGo += dssp.get(0).getSystemsOnPayGoNumber();
                        totalDefaulted += dssp.get(0).getDefaulted();
                        totalPar30 += dssp.get(0).getPARnumber();

                    }

                    String cmp = String.valueOf(totalPar30 / 1000.0);

                    List<SubCountySummary> css = subCountyService.subCountySummary(c.getId());

                    if (!css.isEmpty()) {

                        if (totalSystemsPayGo == 0 /*|| totalDefaulted==0*/) {
                            //if("NaN".equalsIgnoreCase(cmpp)){
                            css.get(0).setDefaultRate(0.0);
                        } else {
                            css.get(0).setDefaultRate(Math.round((totalDefaulted / totalSystemsPayGo) * 1000) / 10.0);
                            
                            
                        }

                        css.get(0).setCountyId(c.getId());
                        css.get(0).setInstalledCapacity(totalInstalledCapacity);

                        if ("NaN".equalsIgnoreCase(cmp)) {
                            css.get(0).setPar30(0.0);
                        } else {
                            css.get(0).setPar30(Math.round((totalPar30 / 1000.0)) * 10.0);

                        }

                        css.get(0).setQualityVerified(totalQualityVerified);
                        css.get(0).setSystemsOnPaygo(totalSystemsPayGo);
                        css.get(0).setSystemsSold(totalSystemsSold);

                        save.updateObject(css.get(0));
                    } else {

                        SubCountySummary cs = new SubCountySummary();
                        //if("NaN".equalsIgnoreCase(cmpp)){
                        if (totalSystemsPayGo == 0 /*|| totalDefaulted==0*/) {
                            cs.setDefaultRate(0.0);
                        } else {
                            cs.setDefaultRate(Math.round((totalDefaulted / totalSystemsPayGo) * 1000) / 10.0);
                            //System.out.println("@@@@@@@@@"+Math.round((totalDefaulted/totalSystemsPayGo) * 1000.0) / 10.0);
                        }
                        cs.setCountyId(c.getId());
                        cs.setInstalledCapacity(totalInstalledCapacity);
                        if ("NaN".equalsIgnoreCase(cmp)) {
                            cs.setPar30(0.0);
                        } else {
                            cs.setPar30(Math.round((totalPar30 / 1000.0)) * 10.0);
                            System.out.println("@@@@@@@@@2" + Math.round((totalPar30 / 1000.0)) * 10.0);
                        }
                        cs.setQualityVerified(totalQualityVerified);
                        cs.setSystemsOnPaygo(totalSystemsPayGo);
                        cs.setSystemsSold(totalSystemsSold);
                        save.saveObject(cs);
                    }

                    log.info("County Sub-county " + c.getCountyName() + " data saved");
                    
                    /* Not required
                        Calendar cal = Calendar.getInstance();
                        String month = String.valueOf(cal.get(Calendar.MONTH) + 1);
                        
                        
                        List<SubCountySummaryHist> ch=subCountyService.subCountySummaryHist(month);
                        
                        if(ch.isEmpty()){
                            

                            SubCountySummaryHist csh = new SubCountySummaryHist();

                                if (totalSystemsPayGo == 0 ) {
                                    csh.setDefaultRate(0.0);
                                } else {
                                    csh.setDefaultRate(Math.round((totalDefaulted / totalSystemsPayGo) * 1000) / 10.0);

                                }
                            csh.setCountyId(c.getId());
                            csh.setInstalledCapacity(totalInstalledCapacity);
                                if ("NaN".equalsIgnoreCase(cmp)) {
                                    csh.setPar30(0.0);
                                } else {
                                    csh.setPar30(Math.round((totalPar30 / 1000.0)) * 10.0);
                                    System.out.println("@@@@@@@@@2" + Math.round((totalPar30 / 1000.0)) * 10.0);
                                }
                            csh.setQualityVerified(totalQualityVerified);
                            csh.setSystemsOnPaygo(totalSystemsPayGo);
                            csh.setSystemsSold(totalSystemsSold);
                            csh.setMonth(month);
                            save.saveObject(csh);
                        
                        }else{
                            if (totalSystemsPayGo == 0 ) {

                                ch.get(0).setDefaultRate(0.0);
                            } else {
                                ch.get(0).setDefaultRate(Math.round((totalDefaulted / totalSystemsPayGo) * 1000) / 10.0);


                            }

                            ch.get(0).setCountyId(c.getId());
                            ch.get(0).setInstalledCapacity(totalInstalledCapacity);

                                if ("NaN".equalsIgnoreCase(cmp)) {
                                    ch.get(0).setPar30(0.0);
                                } else {
                                    ch.get(0).setPar30(Math.round((totalPar30 / 1000.0)) * 10.0);

                                }

                            ch.get(0).setQualityVerified(totalQualityVerified);
                            ch.get(0).setSystemsOnPaygo(totalSystemsPayGo);
                            ch.get(0).setSystemsSold(totalSystemsSold);

                            save.updateObject(ch.get(0));

                        
                        }*/

                } else {
                    reply.setError("No Sub-counties in County " + c.getCountyName());
                }

            }

            reply.setSucc("Data analysed and persisted");

            /* }else{
                reply.setError("County does not exist");
                log.info("County does not exist");
                }*/
        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    // ++++++++++++++++++++++++: Get Sub-Counties by County :+++++++++++++++++++++++++++++++
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    //@Secured({Role.administrator})
    @ApiOperation(value = "County SubCounties", notes = "County SubCounties.", response = JsonReply.class)
    @Path("CountySubCounties")
    public String CountySubCounties(@Context Request req, @ApiParam(value = "JsonInput.county") String json) throws com.google.gson.JsonSyntaxException {

        //INNIT JSON INPUT
        input = new JsonInput();

        //INIT GSON
        gson = new Gson();

        //response
        reply = new JsonReply("CountySubCounties");

        try {

            //PRINT INPUT
            PrintJson.printJ(json);

            //GET JINPUT JSON OBJECT FROM GSON
            input = gson.fromJson(json, JsonInput.class);
            if (input != null && input.county != null) {

                if (input.county.getCountyName().length() < 0) {
                    log.info("CountyName should have a value");
                    reply.setError("CountyName should have a value");
                } else {

                    //CONSTRUCT SAVE NEW PORTFOLIO
                    List<County> cmp = countyService.countyByName(input.county.getCountyName());
                    if (!cmp.isEmpty()) {

                        List<SubCounty> loans = subCountyService.subCountyByCounty(cmp.get(0));

                        if (!loans.isEmpty()) {
                            Collections.sort(loans,new Comparator<SubCounty>() {


                                @Override
                                public int compare(SubCounty song1, SubCounty song2) {
                                    if (song1.equals(song2)) {
                                        return 0;
                                    }
                                    return song1.getSubCountyName().compareToIgnoreCase(song2.getSubCountyName());
                                }
                            });

                            reply.subCounties = loans;
                            reply.setSucc("SubCounties found");
                        } else {
                            reply.setError("No Sub-Counties for County: " + cmp.get(0).getCountyName());

                        }

                    } else {
                        log.info("This County does not Exist " + input.county.getCountyName());
                        reply.setError("This County does not Exist " + input.county.getCountyName());
                    }
                }

            } else {
                log.info("Please Send some JSON or Send County object");
                reply.setError("Please Send some JSON or Send County object");

            }

        } catch (com.google.gson.JsonSyntaxException ex) {
            log.error("Json Error:" + ex);
            reply.setError("JSON ERROR");
        }

        return reply.toString();
    }

    //**************endpoint for all sub-counties*****************
    @GET
    @Path("allSubCounties")
    //@Secured({Role.administrator})
    @Produces(MediaType.APPLICATION_JSON)
    public String findAllSubCounties() {

        reply = new JsonReply("getAllSubCounties");

        gson = new Gson();

        List<SubCounty> company = subCountyService.getAllSubCounties();
        
        Collections.sort(company,new Comparator<SubCounty>() {


            @Override
            public int compare(SubCounty song1, SubCounty song2) {
                if (song1.equals(song2)) {
                    return 0;
                }
                return song1.getSubCountyName().compareToIgnoreCase(song2.getSubCountyName());
            }
        });

        reply.subCounties = company;
        reply.setSucc(company.size() + " SubCounties");

        return reply.toString();
    }

    /**
     * Retrieves representation of an instance of
     * ch.villagepower.rest.SubSubCountyResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public String getXml() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of SubSubCountyResource
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }
}
