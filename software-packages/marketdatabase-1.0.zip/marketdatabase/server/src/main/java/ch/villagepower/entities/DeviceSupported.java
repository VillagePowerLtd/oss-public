/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import com.google.gson.annotations.Expose;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Entity
@Table(name = "device_supported")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "DeviceSupported.findAll", query = "SELECT d FROM DeviceSupported d"),
    @NamedQuery(name = "DeviceSupported.findById", query = "SELECT d FROM DeviceSupported d WHERE d.id = :id"),
    @NamedQuery(name = "DeviceSupported.findByCode", query = "SELECT d FROM DeviceSupported d WHERE d.code = :code"),
    @NamedQuery(name = "DeviceSupported.findByDescription", query = "SELECT d FROM DeviceSupported d WHERE d.description = :description"),
    @NamedQuery(name = "DeviceSupported.findByDevicesName", query = "SELECT d FROM DeviceSupported d WHERE d.devicesName = :devicesName"),
    @NamedQuery(name = "DeviceSupported.findByLastUpdated", query = "SELECT d FROM DeviceSupported d WHERE d.lastUpdated = :lastUpdated"),
    @NamedQuery(name = "DeviceSupported.findByDateCreated", query = "SELECT d FROM DeviceSupported d WHERE d.dateCreated = :dateCreated")})
public class DeviceSupported implements Serializable {

    @Column(name = "master")
    @Expose
    private Boolean master;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "deviceSupportedId")
    private transient List<SpecificationDevice> specificationDeviceList;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Expose
    @Column(name = "id")
    private Integer id;
    @Size(max = 45)
    @Expose
    @Column(name = "code")
    private String code;
    @Size(max = 245)
    @Expose
    @Column(name = "description")
    private String description;
    @Size(max = 45)
    @Expose
    @Column(name = "devices_name")
    private String devicesName;
    @Expose
    @Column(name = "last_updated")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdated;
    @Expose
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    @Expose
    @JoinColumn(name = "company_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Company companyId;

    public DeviceSupported() {
    }

    public DeviceSupported(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDevicesName() {
        return devicesName;
    }

    public void setDevicesName(String devicesName) {
        this.devicesName = devicesName;
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Company getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Company companyId) {
        this.companyId = companyId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DeviceSupported)) {
            return false;
        }
        DeviceSupported other = (DeviceSupported) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.DeviceSupported[ id=" + id + " ]";
    }

    @XmlTransient
    public List<SpecificationDevice> getSpecificationDeviceList() {
        return specificationDeviceList;
    }

    public void setSpecificationDeviceList(List<SpecificationDevice> specificationDeviceList) {
        this.specificationDeviceList = specificationDeviceList;
    }

    public Boolean getMaster() {
        return master;
    }

    public void setMaster(Boolean master) {
        this.master = master;
    }

}
