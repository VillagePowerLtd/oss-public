/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;

import ch.villagepower.entities.Company;
import ch.villagepower.entities.Specification;
import ch.villagepower.entities.SpecificationDevice;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.apache.log4j.Logger;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Stateless
public class SpecificationService {

    @PersistenceContext
    private EntityManager em;

    final static Logger log = Logger.getLogger(SpecificationService.class.getName());

    public List<Specification> findAll() {

        List<Specification> companies;

        Query q = em.createQuery("from Specification", Specification.class);

        companies = q.getResultList();

        return companies;

    }

    //return specification byt id
    public Specification specificationById(Integer id) {

        Specification specification = em.find(Specification.class, id);

        return specification;
    }

    //return device by company
    public List<Specification> specificationByCompany(Company id) {

        Query q = em.createQuery("SELECT s FROM Specification s WHERE s.companyId = :a")
                .setParameter("a", id);

        List<Specification> specs = q.getResultList();

        return specs;
    }

    public List<SpecificationDevice> specificationDeviceBySpecification(Specification id) {

        Query q = em.createQuery("SELECT s FROM SpecificationDevice s WHERE s.specification = :a")
                .setParameter("a", id);

        List<SpecificationDevice> specs = q.getResultList();

        return specs;
    }

    public List<Specification> specificationList(Integer id) {

        Query q = em.createQuery("SELECT s FROM Specification s WHERE s.id = :a")
                .setParameter("a", id);

        List<Specification> specs = q.getResultList();

        return specs;
    }

    public List<Specification> specificationByModel(String id) {

        Query q = em.createQuery("SELECT s FROM Specification s WHERE s.model = :a")
                .setParameter("a", id);

        List<Specification> specs = q.getResultList();

        return specs;
    }

    public List<Specification> specificationByModelAndCompany(String id, Company c) {

        Query q = em.createQuery("SELECT s FROM Specification s WHERE s.model = :a AND s.companyId=:b")
                .setParameter("a", id)
                .setParameter("b", c);

        List<Specification> specs = q.getResultList();

        return specs;
    }

}
