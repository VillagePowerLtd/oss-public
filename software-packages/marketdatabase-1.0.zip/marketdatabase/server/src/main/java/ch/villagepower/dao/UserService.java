/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;


import ch.villagepower.entities.Users;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
@Stateless
public class UserService {

    @PersistenceContext
    EntityManager em;

    @EJB
    SaveService save = new SaveService();

    public void save(Users entity) {
        save.saveObject(entity);

    }

    public List<Users> findAll() {
        return this.em.createNamedQuery("Users.findAll", Users.class)
                .getResultList();
    }

    public List<Users> findByUsername(String username) {
        Query query = em.createNamedQuery("Users.findByUsername");
        query.setParameter("username", username);

        return query.getResultList();

    }

    public List<Users> findByEmail(String username) {
        Query query = em.createNamedQuery("Users.findByEmail");
        query.setParameter("email", username);

        return query.getResultList();

    }

    public List<Users> findByHashID(String userId, String hash) {
        Query query = em.createQuery("SELECT s FROM Users s WHERE s.userId = :a AND s.salt = :b");
        query.setParameter("a", Integer.valueOf(userId));
        query.setParameter("b", hash);

        return query.getResultList();

    }

    public List<Users> findAllAdmins(String userId) {
        Query query = em.createQuery("SELECT s FROM Users s WHERE s.role = :a");
        query.setParameter("a", userId);

        return query.getResultList();

    }

    //return user by id
    public Users userById(Integer id) {

        Users u = em.find(Users.class, id);

        return u;
    }

    //return batch by batch
    public List<Users> userByInvestor(String s) {

        Query query = em.createQuery("SELECT s FROM Users s WHERE s.role = :a");
        query.setParameter("a", s);

        return query.getResultList();
    }

}
