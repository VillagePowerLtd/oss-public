/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.shiro;


/**
 *
 * @author Isaac Tumusiime isaac@village-power.ug
 */
import java.math.BigInteger;
import java.security.SecureRandom;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.apache.shiro.util.SimpleByteSource;

public class HashGenerator {

    public String generateSalt() {
        return new BigInteger(250, new SecureRandom()).toString(32);
    }

    public String generateHash(String password) {
        Sha256Hash hash = new Sha256Hash(password);
        return hash.toHex();
    }

    public String saltHashPassword(String password, String salt) {
        Sha256Hash hash = new Sha256Hash(password, (new SimpleByteSource(salt)).getBytes());
        return hash.toHex();

    }

}
