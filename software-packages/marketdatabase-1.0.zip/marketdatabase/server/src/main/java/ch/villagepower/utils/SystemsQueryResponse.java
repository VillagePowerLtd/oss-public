/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.utils;


import java.util.List;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
public class SystemsQueryResponse {

    String counrty;
    float systemsSold;
    List<SystemsQueryResponse> sqr;

    public String getCounrty() {
        return counrty;
    }

    public void setCounrty(String counrty) {
        this.counrty = counrty;
    }

    public float getSystemsSold() {
        return systemsSold;
    }

    public void setSystemsSold(float systemsSold) {
        this.systemsSold = systemsSold;
    }

    public List<SystemsQueryResponse> getSqr() {
        return sqr;
    }

    public void setSqr(List<SystemsQueryResponse> sqr) {
        this.sqr = sqr;
    }

}
