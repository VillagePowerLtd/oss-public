/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;


import ch.villagepower.entities.Company;
import ch.villagepower.entities.Country;
import ch.villagepower.entities.County;
import ch.villagepower.entities.CountySummary;
import ch.villagepower.entities.CountySystemSold;
import ch.villagepower.entities.District;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.apache.log4j.Logger;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Stateless
public class CountyService {

    @PersistenceContext
    private EntityManager em;

    final static Logger log = Logger.getLogger(CountyService.class.getName());

    public List<County> findAll() {

        List<County> companies;

        Query q = em.createQuery("from County", County.class);

        companies = q.getResultList();

        return companies;

    }

    public List<County> countyByDistrict(District id) {

        Query q = em.createQuery("SELECT s FROM County s WHERE s.districtId = :a")
                .setParameter("a", id);

        List<County> specs = q.getResultList();

        return specs;
    }

    /**
     * *************************FROM DistrictsSystemSold
     * services***********************************
     */
    public List<CountySystemSold> countySold(County id) {

        Query q = em.createQuery("SELECT s FROM CountySystemSold s WHERE s.countyId = :a")
                .setParameter("a", id);

        List<CountySystemSold> specs = q.getResultList();

        return specs;
    }

    //return county byt id
    public County countyById(Integer id) {

        County county = em.find(County.class, id);

        return county;
    }

    //return device by company
    public List<County> countyByCompany(Company id) {

        Query q = em.createQuery("SELECT s FROM County s WHERE s.companyId = :a")
                .setParameter("a", id);

        List<County> specs = q.getResultList();

        return specs;
    }

    public List<County> countyList(Integer id) {

        Query q = em.createQuery("SELECT s FROM County s WHERE s.id = :a")
                .setParameter("a", id);

        List<County> specs = q.getResultList();

        return specs;
    }

    public List<County> countyByName(String id) {

        Query q = em.createQuery("SELECT s FROM County s WHERE s.countyName = :a")
                .setParameter("a", id);

        List<County> specs = q.getResultList();

        return specs;
    }

    public List<County> countyByNameAndDistrict(String id, District d) {

        Query q = em.createQuery("SELECT s FROM County s WHERE s.countyName = :a AND s.districtId = :b")
                .setParameter("b", d)
                .setParameter("a", id);

        List<County> specs = q.getResultList();

        return specs;
    }

    public List<CountySystemSold> findAllCountyData() {

        List<CountySystemSold> companies;

        Query q = em.createQuery("from CountySystemSold", CountySystemSold.class);

        companies = q.getResultList();

        return companies;

    }

    public List<CountySystemSold> countySoldById(County b, Country c) {

        List<CountySystemSold> companies;

        Query q = em.createQuery("SELECT s FROM CountySystemSold s WHERE s.countyId = :a AND s.countryId=:c")
                .setParameter("a", b)
                .setParameter("c", c);

        companies = q.getResultList();

        return companies;

    }

    public List<CountySystemSold> countySoldByCounty(County b) {

        List<CountySystemSold> companies;

        Query q = em.createQuery("SELECT s FROM CountySystemSold s WHERE s.countyId = :a")
                .setParameter("a", b);

        companies = q.getResultList();

        return companies;

    }

    public List<County> getAllCountys() {

        List<County> companies;

        Query q = em.createQuery("from County", County.class);

        companies = q.getResultList();

        return companies;

    }

    /**
     * *************************Country
     * services***************************************
     */
    public List<Country> findAllCountries() {

        List<Country> companies;

        Query q = em.createQuery("from Country", Country.class);

        companies = q.getResultList();

        return companies;

    }

    public Country countryById(Integer id) {

        Country county = em.find(Country.class, id);

        return county;
    }

    public List<Country> countryByName(String b) {

        List<Country> companies;

        Query q = em.createQuery("SELECT s FROM Country s WHERE s.countryName = :a")
                .setParameter("a", b);

        companies = q.getResultList();

        return companies;

    }

    public List<District> districtByName(String b) {

        List<District> companies;

        Query q = em.createQuery("SELECT s FROM District s WHERE s.districtName = :a")
                .setParameter("a", b);

        companies = q.getResultList();

        return companies;

    }

    public List<CountySummary> countySummary(int b) {

        List<CountySummary> companies;

        Query q = em.createQuery("SELECT s FROM CountySummary s WHERE s.districtId = :a")
                .setParameter("a", b);

        companies = q.getResultList();

        return companies;

    }

    public List<County> getAllCounties() {

        List<County> companies;

        Query q = em.createQuery("from County", County.class);

        companies = q.getResultList();

        return companies;

    }

}
