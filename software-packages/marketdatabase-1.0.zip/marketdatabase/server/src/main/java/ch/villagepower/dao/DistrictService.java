/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.dao;


import ch.villagepower.entities.Company;
import ch.villagepower.entities.Country;
import ch.villagepower.entities.CountrySummary;
import ch.villagepower.entities.CountrySummaryHist;
import ch.villagepower.entities.District;
import ch.villagepower.entities.DistrictsSystemSold;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.apache.log4j.Logger;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Stateless
public class DistrictService {

    @PersistenceContext
    private EntityManager em;

    final static Logger log = Logger.getLogger(DistrictService.class.getName());

    public List<District> findAll() {

        List<District> companies;

        Query q = em.createQuery("from District", District.class);

        companies = q.getResultList();

        return companies;

    }
    
    
    public List<CountrySummaryHist> findAllCountryHist() {

        List<CountrySummaryHist> companies;

        Query q = em.createQuery("from CountrySummaryHist", CountrySummaryHist.class);

        companies = q.getResultList();

        return companies;

    }

    //return district byt id
    public District districtById(Integer id) {

        District district = em.find(District.class, id);

        return district;
    }

    //return device by company
    public List<District> districtByCompany(Company id) {

        Query q = em.createQuery("SELECT s FROM District s WHERE s.companyId = :a")
                .setParameter("a", id);

        List<District> specs = q.getResultList();

        return specs;
    }

    public List<District> districtList(Integer id) {

        Query q = em.createQuery("SELECT s FROM District s WHERE s.id = :a")
                .setParameter("a", id);

        List<District> specs = q.getResultList();

        return specs;
    }

    public List<District> districtByCountry(Country id) {

        Query q = em.createQuery("SELECT s FROM District s WHERE s.countryId = :a")
                .setParameter("a", id);

        List<District> specs = q.getResultList();

        return specs;
    }

    public List<District> districtByName(String id) {

        Query q = em.createQuery("SELECT s FROM District s WHERE s.districtName LIKE :a")
                .setParameter("a", id);

        List<District> specs = q.getResultList();

        return specs;
    }

    /**
     * *************************FROM DistrictsSystemSold
     * services***********************************
     */
    public List<DistrictsSystemSold> districtSold(District id) {

        Query q = em.createQuery("SELECT s FROM DistrictsSystemSold s WHERE s.districtId = :a")
                .setParameter("a", id);

        List<DistrictsSystemSold> specs = q.getResultList();

        return specs;
    }

    public List<DistrictsSystemSold> findAllDistrictData() {

        List<DistrictsSystemSold> companies;

        Query q = em.createQuery("from DistrictsSystemSold", DistrictsSystemSold.class);

        companies = q.getResultList();

        return companies;

    }

    public List<DistrictsSystemSold> districtSoldById(District b, Country c) {

        List<DistrictsSystemSold> companies;

        Query q = em.createQuery("SELECT s FROM DistrictsSystemSold s WHERE s.districtId = :a AND s.countryId=:c")
                .setParameter("a", b)
                .setParameter("c", c);

        companies = q.getResultList();

        return companies;

    }

    public List<DistrictsSystemSold> districtSoldByDistrict(District b) {

        List<DistrictsSystemSold> companies;

        Query q = em.createQuery("SELECT s FROM DistrictsSystemSold s WHERE s.districtId = :a")
                .setParameter("a", b);

        companies = q.getResultList();

        return companies;

    }

    public List<District> getAllDistricts() {

        List<District> companies;

        Query q = em.createQuery("from District", District.class);

        companies = q.getResultList();

        return companies;

    }

    /**
     * *************************Country
     * services***************************************
     */
    public List<Country> findAllCountries() {

        List<Country> companies;

        Query q = em.createQuery("from Country", Country.class);

        companies = q.getResultList();

        return companies;

    }

    public Country countryById(Integer id) {

        Country district = em.find(Country.class, id);

        return district;
    }

    public List<Country> countryByName(String b) {

        List<Country> companies;

        Query q = em.createQuery("SELECT s FROM Country s WHERE s.countryName = :a")
                .setParameter("a", b);

        companies = q.getResultList();

        return companies;

    }

    public List<CountrySummary> countrySummary(int b) {

        List<CountrySummary> companies;

        Query q = em.createQuery("SELECT s FROM CountrySummary s WHERE s.countryId = :a")
                .setParameter("a", b);

        companies = q.getResultList();

        return companies;

    }
    
    public List<CountrySummaryHist> countrySummaryHist(String b) {

        List<CountrySummaryHist> companies;

        Query q = em.createQuery("SELECT s FROM CountrySummaryHist s WHERE s.month = :a")
                .setParameter("a", b);

        companies = q.getResultList();

        return companies;

    }

}
