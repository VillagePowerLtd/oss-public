/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import com.google.gson.annotations.Expose;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Entity
@Table(name = "specification_device")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SpecificationDevice.findAll", query = "SELECT s FROM SpecificationDevice s"),
    @NamedQuery(name = "SpecificationDevice.findById", query = "SELECT s FROM SpecificationDevice s WHERE s.id = :id"),
    @NamedQuery(name = "SpecificationDevice.findByDateCreated", query = "SELECT s FROM SpecificationDevice s WHERE s.dateCreated = :dateCreated"),
    @NamedQuery(name = "SpecificationDevice.findByDateUpdated", query = "SELECT s FROM SpecificationDevice s WHERE s.dateUpdated = :dateUpdated"),
    @NamedQuery(name = "SpecificationDevice.findByQuantity", query = "SELECT s FROM SpecificationDevice s WHERE s.quantity = :quantity")})
public class SpecificationDevice implements Serializable {

    @JoinColumn(name = "device_supported_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    @Expose
    private DeviceSupported deviceSupportedId;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Expose
    @Column(name = "id")
    private Integer id;
    @Expose
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    @Expose
    @Column(name = "date_updated")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateUpdated;
    @Expose
    @Column(name = "quantity")
    private Integer quantity;
    @JoinColumn(name = "specification", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Specification specification;

    public SpecificationDevice() {
    }

    public SpecificationDevice(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Date dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Specification getSpecification() {
        return specification;
    }

    public void setSpecification(Specification specification) {
        this.specification = specification;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SpecificationDevice)) {
            return false;
        }
        SpecificationDevice other = (SpecificationDevice) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.SpecificationDevice[ id=" + id + " ]";
    }

    public DeviceSupported getDeviceSupportedId() {
        return deviceSupportedId;
    }

    public void setDeviceSupportedId(DeviceSupported deviceSupportedId) {
        this.deviceSupportedId = deviceSupportedId;
    }

}
