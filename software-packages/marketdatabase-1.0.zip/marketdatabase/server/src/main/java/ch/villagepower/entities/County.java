/* 
 * Copyright (C) 2017 Village-Power AG
 * 
 *    This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package ch.villagepower.entities;


import com.google.gson.annotations.Expose;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Isaac Tumusiime <isaac@village-power.ug>
 */
@Entity
@Table(name = "county")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "County.findAll", query = "SELECT c FROM County c"),
    @NamedQuery(name = "County.findById", query = "SELECT c FROM County c WHERE c.id = :id"),
    @NamedQuery(name = "County.findByCode", query = "SELECT c FROM County c WHERE c.code = :code"),
    @NamedQuery(name = "County.findByCountyName", query = "SELECT c FROM County c WHERE c.countyName = :countyName"),
    @NamedQuery(name = "County.findByLatitude", query = "SELECT c FROM County c WHERE c.latitude = :latitude"),
    @NamedQuery(name = "County.findByLongitude", query = "SELECT c FROM County c WHERE c.longitude = :longitude"),
    @NamedQuery(name = "County.findByLastUpdated", query = "SELECT c FROM County c WHERE c.lastUpdated = :lastUpdated"),
    @NamedQuery(name = "County.findByDateCreated", query = "SELECT c FROM County c WHERE c.dateCreated = :dateCreated")})
public class County implements Serializable {

    @OneToOne(cascade = CascadeType.ALL, mappedBy = "county")
    private CountrySystemSold countrySystemSold;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "countyId")
    private List<CountySystemSold> countySystemSoldList;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "id")
    private List<CountrySystemSold> countrySystemSoldList;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "id")
    private List<SubCounty> subCountyList;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    @Expose
    private Integer id;
    @Size(max = 45)
    @Column(name = "code")
    @Expose
    private String code;
    @Size(max = 145)
    @Column(name = "county_name")
    @Expose
    private String countyName;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "latitude")
    @Expose
    private Double latitude;
    @Column(name = "longitude")
    @Expose
    private Double longitude;
    @Column(name = "last_updated")
    @Temporal(TemporalType.TIMESTAMP)
    @Expose
    private Date lastUpdated;
    @Column(name = "date_created")
    @Temporal(TemporalType.TIMESTAMP)
    @Expose
    private Date dateCreated;
    @JoinColumn(name = "district_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    @Expose
    private District districtId;

    public County() {
    }

    public County(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCountyName() {
        return countyName;
    }

    public void setCountyName(String countyName) {
        this.countyName = countyName;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public District getDistrictId() {
        return districtId;
    }

    public void setDistrictId(District districtId) {
        this.districtId = districtId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof County)) {
            return false;
        }
        County other = (County) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.villagepower.entities.County[ id=" + id + " ]";
    }

    @XmlTransient
    public List<SubCounty> getSubCountyList() {
        return subCountyList;
    }

    public void setSubCountyList(List<SubCounty> subCountyList) {
        this.subCountyList = subCountyList;
    }

    @XmlTransient
    public List<CountrySystemSold> getCountrySystemSoldList() {
        return countrySystemSoldList;
    }

    public void setCountrySystemSoldList(List<CountrySystemSold> countrySystemSoldList) {
        this.countrySystemSoldList = countrySystemSoldList;
    }

    @XmlTransient
    public List<CountySystemSold> getCountySystemSoldList() {
        return countySystemSoldList;
    }

    public void setCountySystemSoldList(List<CountySystemSold> countySystemSoldList) {
        this.countySystemSoldList = countySystemSoldList;
    }

    public CountrySystemSold getCountrySystemSold() {
        return countrySystemSold;
    }

    public void setCountrySystemSold(CountrySystemSold countrySystemSold) {
        this.countrySystemSold = countrySystemSold;
    }

}
